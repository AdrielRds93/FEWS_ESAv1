 /*
 * Firebird Open Source J2ee connector - jdbc driver
 *
 * Distributable under LGPL license.
 * You may obtain a copy of the License at http://www.gnu.org/copyleft/lgpl.html
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * LGPL License for more details.
 *
 * This file was created by members of the firebird development team.
 * All individual contributions remain the Copyright (C) of those
 * individuals.  Contributors to this file are either listed here or
 * can be obtained from a CVS history command.
 *
 * All rights reserved.
 */

package org.firebirdsql.jdbc.field;

import org.firebirdsql.gds.XSQLVAR;

import java.sql.Date;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;

 /**
 * Describe class <code>FBTimestampField</code> here.
 *
 * @author <a href="mailto:rrokytskyy@users.sourceforge.net">Roman Rokytskyy</a>
 * @version 1.0
 */
class FBTimestampField extends FBField {
    // line added by OA
    private static final int HARRISON = 40587; // January 1, 1970 (Gregorian)
     // line added by OA
    private static final long DAY_MILLIS = 24 * 60 * 60 * 1000;
     // line added by OA
     private static final long TEN_THOUSAND_YEARS_MILLIS = 365 * 10000 * DAY_MILLIS;
     private static final int TEN_THOUSAND_YEARS_DAYS = 365 * 10000;

     FBTimestampField(XSQLVAR field, FieldDataProvider dataProvider, int requiredType)
        throws SQLException 
    {
        super(field, dataProvider, requiredType);
    }
    
    /*
    public Object getObject() throws SQLException {
        if (getFieldData()==null) return OBJECT_NULL_VALUE;

        return field.decodeTimestamp(getFieldData());
    }
    */
    
    public String getString() throws SQLException {
        if (getFieldData()==null) return STRING_NULL_VALUE;

        return String.valueOf(field.decodeTimestamp(getFieldData()));
    }
    public Date getDate(Calendar cal) throws SQLException {
        if (getFieldData()==null) return DATE_NULL_VALUE;

        return field.decodeDate(getDate(),cal);
    }
    public Date getDate() throws SQLException {
        if (getFieldData()==null) return DATE_NULL_VALUE;

        return new Date(getTimestamp().getTime());
    }
    public Time getTime(Calendar cal) throws SQLException {
        if (getFieldData()==null) return TIME_NULL_VALUE;

        return field.decodeTime(getTime(),cal, isInvertTimeZone());
    }
    public Time getTime() throws SQLException {
        if (getFieldData()==null) return TIME_NULL_VALUE;

        return new Time(getTimestamp().getTime());
    }
    public Timestamp getTimestamp(Calendar cal) throws SQLException {
        // changed by OA, store the the time stamp always in GMT
        // if (getFieldData()==null) return TIMESTAMP_NULL_VALUE;
        // return field.decodeTimestamp(getTimestamp(),cal, isInvertTimeZone());

        return getTimestamp();
    }
    public Timestamp getTimestamp() throws SQLException {
        if (getFieldData()==null) return TIMESTAMP_NULL_VALUE;

        // return field.decodeTimestamp(getFieldData());
        // changed by OA
        // hi speed implementation by OA, by passing calendar and always assuming timestamp is stored in GMT
        byte[] bytes = getFieldData();
        if (bytes.length != 8)
            throw new IllegalArgumentException("Bad parameter to decode");


        long millis = (getDays(bytes) - HARRISON) * DAY_MILLIS + getHunderdNanos(bytes) / 10;

        return new Timestamp(millis);
    }
    //--- setXXX methods

    public void setString(String value) throws SQLException {
        if (value == STRING_NULL_VALUE) {
            setNull();
            return;
        }

        setTimestamp(Timestamp.valueOf(value));
    }
    public void setDate(Date value, Calendar cal) throws SQLException {
        if (value == DATE_NULL_VALUE) {
            setNull();
            return;
        }

        setDate(field.encodeDate(value,cal));
    }
    public void setDate(Date value) throws SQLException {
        if (value == DATE_NULL_VALUE) {
            setNull();
            return;
        }

        setTimestamp(new Timestamp(value.getTime()));
    }
    public void setTime(Time value, Calendar cal) throws SQLException {
        if (value == TIME_NULL_VALUE) {
            setNull();
            return;
        }

        setTime(field.encodeTime(value,cal, isInvertTimeZone()));
    }
    public void setTime(Time value) throws SQLException {
        if (value == TIME_NULL_VALUE) {
            setNull();
            return;
        }

        setTimestamp(new Timestamp(value.getTime()));
    }
    public void setTimestamp(Timestamp value, Calendar cal) throws SQLException {
//        if (value == TIMESTAMP_NULL_VALUE) {
//            setNull();
//            return;
//        }
//
//        setTimestamp(field.encodeTimestamp(value,cal, isInvertTimeZone()));
        // changed by OA
        setTimestamp(value);
    }

    public void setTimestamp(Timestamp value) throws SQLException {
        if (value == TIMESTAMP_NULL_VALUE) {
            setNull();
            return;
        }

       setFieldData(field.encodeTimestamp(value));

        // changed by OA
        // hi speed implementation by passing calendar and always storing
        // the the timestamp in GMT

        // note, we cannot simply pass millis to the database, because
        // Firebird stores timestamp in format (citing Ann W. Harrison):
        //
        // "[timestamp is] stored a two long words, one representing
        // the number of days since 17 Nov 1858 and one representing number
        // of 100 nano-seconds since midnight"

        // TEN_THOUSAND_YEARS to ensure time is positive and operators / and % works the way we want
        long time = TEN_THOUSAND_YEARS_MILLIS + value.getTime();
        int days = HARRISON + (int) (time / DAY_MILLIS) - TEN_THOUSAND_YEARS_DAYS;
        int hunderdnanos = (int) (time % DAY_MILLIS) * 10;
        setFieldData(toBytes(days, hunderdnanos));
    }

     // added by OA
     private static byte[] toBytes(int days, int hunderdenanos) {
         byte[] res = new byte[8];
         res[0] = (byte) (days >>> 0);
         res[1] = (byte) (days >>> 8);
         res[2] = (byte) (days >>> 16);
         res[3] = (byte) (days >>> 24);
         res[4] = (byte) (hunderdenanos >>> 0);
         res[5] = (byte) (hunderdenanos >>> 8);
         res[6] = (byte) (hunderdenanos >>> 16);
         res[7] = (byte) (hunderdenanos >>> 24);
         return res;
    }

     // added by OA
     private static int getDays(byte[] bytes) {
         int ch4 = bytes[0] & 0xff;
         int ch3 = bytes[1] & 0xff;
         int ch2 = bytes[2] & 0xff;
         int ch1 = bytes[3] & 0xff;
         return (ch1 << 24) + (ch2 << 16) + (ch3 << 8) + (ch4 << 0);
     }

     // added by OA
     private static int getHunderdNanos(byte[] bytes) {
         int ch4 = bytes[4] & 0xff;
         int ch3 = bytes[5] & 0xff;
         int ch2 = bytes[6] & 0xff;
         int ch1 = bytes[7] & 0xff;
         return (ch1 << 24) + (ch2 << 16) + (ch3 << 8) + (ch4 << 0);
     }
 }

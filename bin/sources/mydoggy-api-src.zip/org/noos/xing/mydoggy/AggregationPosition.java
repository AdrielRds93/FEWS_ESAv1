package org.noos.xing.mydoggy;

/**
 * @author Angelo De Caro (angelo.decaro@gmail.com)
 */
public enum AggregationPosition {

    LEFT,
    RIGHT,
    TOP,
    BOTTOM,
    DEFAULT

}

package skt.swing.table;

/**
 * MySwing: Advanced Swing Utilites
 * Copyright (C) 2005  Santhosh Kumar T
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 */

import javax.swing.*;
import javax.swing.event.MouseInputAdapter;
import javax.swing.table.TableModel;
import javax.swing.table.TableColumnModel;
import javax.swing.table.JTableHeader;
import java.util.Vector;
import java.util.EventObject;

/**
 * Enhanced JTable
 *
 * @author Santhosh Kumar T
 * @email  santhosh@in.fiorano.com
 */
public class MyTable extends JTable{

    /*-------------------------------------------------[ Constructors ]---------------------------------------------------*/

    public MyTable(){
    }

    public MyTable(int numRows, int numColumns){
        super(numRows, numColumns);
    }

    public MyTable(TableModel dm){
        super(dm);
    }

    public MyTable(final Object[][] rowData, final Object[] columnNames){
        super(rowData, columnNames);
    }

    public MyTable(Vector rowData, Vector columnNames){
        super(rowData, columnNames);
    }

    public MyTable(TableModel dm, TableColumnModel cm){
        super(dm, cm);
    }

    public MyTable(TableModel dm, TableColumnModel cm, ListSelectionModel sm){
        super(dm, cm, sm);
    }

    private static TableColumnAutoResizer columnAutoResizer = new TableColumnAutoResizer();

    public void addNotify(){
        super.addNotify();
        getTableHeader().addMouseListener(columnAutoResizer);
    }

    public void removeNotify(){
        super.removeNotify();
        getTableHeader().removeMouseListener(columnAutoResizer);
    }

    public void setTableHeader(JTableHeader tableHeader){
        if(getTableHeader()!=null)
            getTableHeader().removeMouseListener(columnAutoResizer);
        super.setTableHeader(tableHeader);
        if(tableHeader!=null && isShowing())
            tableHeader.addMouseListener(columnAutoResizer);
    }

    /*-------------------------------------------------[ Column & Row Resizing ]---------------------------------------------------*/

    protected MouseInputAdapter rowResizer, columnResizer = null;

    // turn resizing on/of
    public void setResizable(boolean row, boolean column){
        if(row){
            if(rowResizer==null)
                rowResizer = new TableRowResizer(this);
        }else if(rowResizer!=null){
            removeMouseListener(rowResizer);
            removeMouseMotionListener(rowResizer);
            rowResizer = null;
        }
        if(column){
            if(columnResizer==null)
                columnResizer = new TableColumnResizer(this);
        }else if(columnResizer!=null){
            removeMouseListener(columnResizer);
            removeMouseMotionListener(columnResizer);
            columnResizer = null;
        }
    }

    // mouse events intended for resize shouldn't activate editing
    public boolean editCellAt(int row, int column, EventObject e){
        if(getCursor()==TableColumnResizer.resizeCursor || getCursor()==TableRowResizer.resizeCursor)
            return false;
        return super.editCellAt(row, column, e);
    }

    // mouse press intended for resize shouldn't change row/col/cell celection
    public void changeSelection(int row, int column, boolean toggle, boolean extend) {
        if(getCursor()==TableColumnResizer.resizeCursor || getCursor()==TableRowResizer.resizeCursor)
            return;
        super.changeSelection(row, column, toggle, extend);
    }

    /*-------------------------------------------------[ Scrollable ]---------------------------------------------------*/

    // overriden to make the height of scroll match viewpost height
    // if smaller
    public boolean getScrollableTracksViewportHeight() {
        return getPreferredSize().height < getParent().getHeight();
    }
}
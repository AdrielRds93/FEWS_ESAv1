package skt.swing.scroll;

/**
 * MySwing: Advanced Swing Utilites
 * Copyright (C) 2005  Santhosh Kumar T
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 */

import skt.swing.SwingUtil;

import javax.swing.*;
import java.awt.*;
import java.awt.event.AWTEventListener;
import java.awt.event.MouseEvent;
import java.awt.event.InputEvent;

/**
 * @author Santhosh Kumar T
 * @email  santhosh@in.fiorano.com
 */
public class ScrollGestureRecognizer implements AWTEventListener{
    private static ScrollGestureRecognizer instance = new ScrollGestureRecognizer();

    private ScrollGestureRecognizer(){
        start();
    }

    public static ScrollGestureRecognizer getInstance(){
        return instance;
    }

    public void start(){
        Toolkit.getDefaultToolkit().addAWTEventListener(this, AWTEvent.MOUSE_EVENT_MASK);
    }

    public void stop(){
        Toolkit.getDefaultToolkit().removeAWTEventListener(this);
    }

    public void eventDispatched(AWTEvent event){
        MouseEvent me = (MouseEvent)event;
        boolean isGesture = SwingUtilities.isMiddleMouseButton(me) && me.getID()==MouseEvent.MOUSE_PRESSED;
        if(!isGesture)
            return;

        Component comp = me.getComponent();
        comp = SwingUtilities.getDeepestComponentAt(comp, me.getX(), me.getY());
        JViewport viewPort = (JViewport)SwingUtilities.getAncestorOfClass(JViewport.class, comp);
        if(viewPort==null || !SwingUtil.canScroll(viewPort))
            return;

        JRootPane rootPane = SwingUtilities.getRootPane(viewPort);
        if(rootPane==null)
            return;
        Point location = SwingUtilities.convertPoint(me.getComponent(), me.getPoint(), rootPane.getGlassPane());
        ScrollGlassPane glassPane = new ScrollGlassPane(rootPane.getGlassPane(), viewPort, location);
        rootPane.setGlassPane(glassPane);
        glassPane.setVisible(true);

        try{
            Robot robot = new Robot();
            robot.mouseRelease(InputEvent.BUTTON2_MASK);
            robot.mousePress(InputEvent.BUTTON2_MASK);
        } catch(AWTException ignore){
            glassPane.movingTimer.start();
        }
    }
}
package skt.swing.scroll;

/**
 * MySwing: Advanced Swing Utilites
 * Copyright (C) 2005  Santhosh Kumar T
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 */

import skt.swing.SwingUtil;

import javax.swing.*;
import javax.swing.event.MouseInputListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.InputEvent;

/**
 * @author Santhosh Kumar T
 * @email  santhosh@in.fiorano.com
 */
class ScrollGlassPane extends JPanel implements ActionListener, MouseInputListener, SwingConstants{
    private static final Image AUTOSCROLL_IMG = Toolkit.getDefaultToolkit().createImage(
            ScrollGlassPane.class.getResource("autoscroll.png"));
    private static final Image HORIZ_AUTOSCROLL_IMG = Toolkit.getDefaultToolkit().createImage(
            ScrollGlassPane.class.getResource("horiz_autoscroll.png"));
    private static final Image VERT_AUTOSCROLL_IMG = Toolkit.getDefaultToolkit().createImage(
            ScrollGlassPane.class.getResource("vert_autoscroll.png"));

    private static final int IMG_WIDTH = 32, IMG_HEIGHT = 32;

    Component oldGlassPane = null;
    public Point location = null;

    Timer movingTimer;
    private Point mouseLocation;
    private JViewport viewport;
    private Image img;
    private Rectangle imgBounds;

    public ScrollGlassPane(Component oldGlassPane, JViewport viewport, Point location){
        this.oldGlassPane = oldGlassPane;
        this.viewport = viewport;
        this.location = mouseLocation = location;
        imgBounds = new Rectangle(location.x-IMG_WIDTH/2, location.y-IMG_HEIGHT/2, IMG_WIDTH, IMG_HEIGHT);

        boolean canHScroll = SwingUtil.canHScroll(viewport);
        boolean canVScroll = SwingUtil.canVScroll(viewport);
        if(canHScroll && canVScroll)
            img = AUTOSCROLL_IMG;
        else img = canHScroll ? HORIZ_AUTOSCROLL_IMG : VERT_AUTOSCROLL_IMG;

        setOpaque(false);

        ScrollGestureRecognizer.getInstance().stop();
        addMouseListener(this);
        addMouseMotionListener(this);

        movingTimer = new Timer(100, this);
        movingTimer.setRepeats(true);
//        movingTimer.start();
    }

    protected void paintComponent(Graphics g){
        g.drawImage(img, location.x-15, location.y-15, this);
    }

    /*-------------------------------------------------[ ActionListener ]---------------------------------------------------*/

    public void actionPerformed(ActionEvent e) {
        int deltax = (mouseLocation.x - location.x)/4;
        int deltay = (mouseLocation.y - location.y)/4;


        Point p = viewport.getViewPosition();
        p.translate(deltax, deltay);

        if(p.x<0)
            p.x=0;
        else if(p.x>=viewport.getView().getWidth()-viewport.getWidth())
            p.x = viewport.getView().getWidth()-viewport.getWidth();

        if(p.y<0)
            p.y = 0;
        else if(p.y>=viewport.getView().getHeight()-viewport.getHeight())
            p.y = viewport.getView().getHeight()-viewport.getHeight();

        viewport.setViewPosition(p);

        setCursor(imgBounds.contains(mouseLocation) ? Cursor.getPredefinedCursor(Cursor.MOVE_CURSOR) : null);
    }

    /*-------------------------------------------------[ MouseListener ]---------------------------------------------------*/

    public void mousePressed(MouseEvent e) {
        if(ignoreMousePress){
            ignoreMousePress = false;
            return;
        }
        if(movingTimer.isRunning()){
            movingTimer.stop();
            try{
                new Robot().mouseRelease(InputEvent.BUTTON2_MASK);
            } catch(AWTException ignore){
            }
            setVisible(false);
            JRootPane rootPane = SwingUtilities.getRootPane(this);
            rootPane.setGlassPane(oldGlassPane);
            ScrollGestureRecognizer.getInstance().start();
        }else
            movingTimer.start();
    }

    private boolean ignoreMousePress = false;
    public void mouseReleased(MouseEvent e){
        if(dragged)
            mousePressed(e);
        else{
            try{
                ignoreMousePress = true;
                Robot robot = new Robot();
                robot.mousePress(InputEvent.BUTTON2_MASK);
            } catch(AWTException ignore){
                mousePressed(e);
            }
        }
    }

    public void mouseMoved(MouseEvent e) {
        mouseLocation = e.getPoint();
    }

    private boolean dragged = false;

    public void mouseDragged(MouseEvent e){
        dragged = true;
        mouseLocation = e.getPoint();
    }

    public void mouseEntered(MouseEvent e){}
    public void mouseExited(MouseEvent e){}
    public void mouseClicked(MouseEvent e){}
}
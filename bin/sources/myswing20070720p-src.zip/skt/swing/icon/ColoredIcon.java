/**
 * MySwing: Advanced Swing Utilites
 * Copyright (C) 2005  Santhosh Kumar T
 * <p/>
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * <p/>
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 */

package skt.swing.icon;

import javax.swing.*;
import java.awt.image.BufferedImage;
import java.awt.*;

/**
 * Colors the given icon with specified color
 *
 * @author Santhosh Kumar T
 */
public class ColoredIcon implements Icon{
    private Icon delegate;

    /**
     * Colors the given icon with textHighlight color from look and feel
     *
     * @param delegate the icon to be colored
     */
    public ColoredIcon(Icon delegate){
        this(delegate, UIManager.getColor("textHighlight"), 0.5F);
    }

    public ColoredIcon(Icon delegate, Color color){
        this(delegate, color, 0.5F);
    }

    public ColoredIcon(Icon delegate, Color color, float alpha){
        this.delegate = delegate;
        createMask(color, alpha);
    }

    /*--------------------------------[ Mask ]--------------------------------*/

    private BufferedImage mask;

    private void createMask(Color color, float alpha){
        mask = new BufferedImage(delegate.getIconWidth(), delegate.getIconHeight(), BufferedImage.TYPE_INT_ARGB);
        Graphics2D gbi = (Graphics2D)mask.getGraphics();
        delegate.paintIcon(new JLabel(), gbi, 0, 0);
        gbi.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_IN, alpha));
        gbi.setColor(color);
        gbi.fillRect(0, 0, mask.getWidth()-1, mask.getHeight()-1);
    }

    /*----------------------------------[ Color Painted ]-----------------------------------*/

    private boolean colorPainted = true;

    public boolean isColorPainted(){
        return colorPainted;
    }

    public void setColorPainted(boolean colorPainted){
        this.colorPainted = colorPainted;
    }

    /*-------------------------------------------------[ Icon Interface ]---------------------------------------------------*/

    public void paintIcon(Component c, Graphics g, int x, int y){
        delegate.paintIcon(c, g, x, y);
        if(colorPainted)
            g.drawImage(mask, x, y, c);
    }

    public int getIconWidth(){
        return delegate.getIconWidth();
    }

    public int getIconHeight(){
        return delegate.getIconHeight();
    }
}

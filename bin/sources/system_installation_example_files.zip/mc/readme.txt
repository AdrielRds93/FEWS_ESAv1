README FIRST
============
The upload of the mc config xml file is very powerful. For instance, when uploading the mc config xml, the Tasks that for the current Master Controller that are not listed in this file will be made inactive / marked as 'D' (done).

Therefore the following procedure is recommended for uploading a new mc.xml via the Admin Interface:

1. Always start with downloading the current mc config xml.

2. When needed, 

a. edit the mc.xml (see the examples for common options)
b. upload the new mc.xml

Always verify the number of changes reported by the Admin Interface before confirming the upload. 

For instance, a change that only affects the McConfigFile is reported as: 
	"Upload mc config 'small_change_mc.xml' by user 'ai_admin': row changes: 1 ( updates: 1 [ McConfigFiles: 1 ] )"

This implies that only the McConfigFile contains some changes. Other additions to the mc config will cause multiple changes to database rows: 

	"Upload mc config 'new_mc.xml' by user 'ai_admin': row changes: 33 ( removals: 14 [ FssGroups: 2 WorkflowMappings: 2 WhatIfScenarios: 2 Tasks: 1 ActionConfigurations: 3 ActionMappings: 3 McFailoverPriorities: 1 ] insertions: 14 [ FssGroups: 2 WorkflowMappings: 2 WhatIfScenarios: 2 Tasks: 1 ActionConfigurations: 3 ActionMappings: 2 McFailoverPriorities: 2 ] updates: 5 [ LiveMcAvailability: 1 McSynchStatus: 1 McFailoverPriorities: 2 McConfigFiles: 1 ] )"




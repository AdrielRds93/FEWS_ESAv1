package org.firebirdsql.gds.impl.wire;

/**
 * Java implementation of GDS.
 * 
 * @author <a href="mailto:sjardine@users.sourceforge.net">Steve Jardine </a>
 */
public class JavaGDSImpl extends AbstractJavaGDSImpl {

}

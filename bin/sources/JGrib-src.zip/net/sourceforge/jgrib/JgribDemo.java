package net.sourceforge.jgrib;
// import statements
import java.lang.*;       // Standard java functions
import java.io.*;					// Input/Output functions
import java.util.*;   		// Exstra utillities from sun

/***************************************************************************
 *
 * This class demonstrates the use of the Jgrib package.<br>
 * The demonstation shows how to exstract information about
 * the grib file targeted. Purpose of this demo program is to help
 * new users of the Jgrib package to get familiar whith
 * some of the aspects of the package.
 *
 * @author Peter Gylling<br>email: Peg@fomfrv.dk
 *
 * @since 1.2
 *
 ****************************************************************************/
public class JgribDemo {

   /************************************************************************
    *
    * Dumps usage of the class, if called without arguments
    *
    ************************************************************************/
   public void usage(String className) {
      System.out.println();
      System.out.println("Usage of " + className + ":");
      System.out.println();
      System.out.println("Parameters is optional (Supplied by -D option)");
      System.out.println("GribTabURL=\"Location of gribtab file\"");
      System.out.println("E.g.   -D\"GribTabURL=file:///D:/JGrib/jgrib/tables\"");
      System.out.println();
      System.out.println("java [-D\"GribTabURL=<url>\"] " + className + " <GribFileToRead>");
      System.exit(0);
   }

   /***********************************************************************
    * Dump of meta data<br>
    *
    * @param  args Filename of gribfile to read
    *
    *************************************************************************/
   public static void main(String args[]) {

      // Function References
      JgribDemo func = new JgribDemo();

      // Test usage
      if (args.length !=1) {
         // Get class name as String
         Class cl = func.getClass();
         func.usage(cl.getName());
      }

      // Get UTC TimeZone
      // A list of available ID's show that UTC has ID = 127
      TimeZone tz = TimeZone.getTimeZone("127");
      TimeZone.setDefault(tz);

      // Say hello
      Date now = Calendar.getInstance().getTime();
      System.out.println(now.toString() + " ... Start of JgribDemo");

//      // Read supplied gribtab file in a try-cath block, but first we
//      // check if it actually is supplied using -D option.
//      String gribtab = System.getProperty("gribtab");
//      if (gribtab != null) {
//         // Use gribtab supplied by user
//         try {
//            GribTables.readParamterTable(gribtab);
//            System.out.println("Using user supplied gribtab table!");
//         } catch (IOException e) {
//        System.err.println(e);
//      }
//      } else {
//         // Use standard gribtab, ie do nothing
//         System.out.println("Using default gribtab table (NCEP)!");
//      }

      // Reading of grib files must be inside a try-catch block
      try {
         // Create GribFile instance
         GribFile gribFile = new GribFile(args[0]);

         // Get light grib reccord (used to get the meta data)
         GribRecord[] gribLight = gribFile.getLightRecords();
         System.out.println("Processing first record!");

         // Get grib Information Section
         GribRecordIS gribIS = gribLight[0].getIS();
         System.out.println(gribIS.toString());

         // Get grib Grid Description Section
         GribRecordGDS gribGDS = gribLight[0].getGDS();
         System.out.println(gribGDS.toString());

         // Get grib Product Description Section
         GribRecordPDS gribPDS = gribLight[0].getPDS();
         System.out.println(gribPDS.toString());


         // Get grib scan mode to define reading direction
         int scan = gribGDS.getGridScanmode();
         System.out.println("\tScan order is " + scan + "\n");


         // Get data from first record remember that first record is number 1
         // and not number 0.
         GribRecord rec = gribFile.getRecord(1);
         GribRecordBDS gribBDS = rec.getBDS();
         System.out.println(gribBDS.toString());

         // Catch thrown errors from GribFile
      } catch (FileNotFoundException noFileError) {
         System.err.println("FileNotFoundException : " + noFileError);
      } catch (IOException ioError) {
         System.err.println("IOException : " + ioError);
      } catch (NoValidGribException noGrib) {
         System.err.println("NoValidGribException : " + noGrib);
      } catch (NotSupportedException noSupport) {
         System.err.println("NotSupportedException : " + noSupport);
      }


   // Goodbye message
   now = Calendar.getInstance().getTime();
   System.out.println(now.toString() + " ... End of JgribDemo!");

   }
}

/*
 * Bytes2Number.java  1.0  01/01/2001
 *
 * (C) Benjamin Stark
 */

package net.sourceforge.jgrib;


/**
 * A class that contains several static methods for converting multiple bytes into
 * one float or integer.
 *
 * @author  Benjamin Stark
 * @version 1.0
 */

public class Bytes2Number
{

   /**
    * Convert two bytes into a signed integer.
    *
    * @param a higher byte
    * @param b lower byte
    *
    * @return integer value
    */
   public static int int2(int a, int b)
   {

      return (1 - ((a & 128) >> 6)) * ((a & 127) << 8 | b);
   }


   /**
    * Convert three bytes into a signed integer.
    *
    * @param a higher byte
    * @param b middle part byte
    * @param c lower byte
    *
    * @return integer value
    */
   public static int int3(int a, int b, int c)
   {

      return (1 - ((a & 128) >> 6)) * ((a & 127) << 16 | b << 8 | c);
   }


   /**
    * Convert four bytes into a signed integer.
    *
    * @param a highest byte
    * @param b higher middle byte
    * @param c lower middle byte
    * @param d lowest byte
    *
    * @return integer value
    */
   public static int int4(int a, int b, int c, int d)
   {

      return (1 - ((a & 128) >> 6)) * ((a & 127) << 24 | b << 16 | c << 8 | d);
   }


   /**
    * Convert two bytes into an unsigned integer.
    *
    * @param a higher byte
    * @param b lower byte
    *
    * @return integer value
    */
   public static int uint2(int a, int b)
   {

      return a << 8 | b;
   }


   /**
    * Convert three bytes into an unsigned integer.
    *
    * @param a higher byte
    * @param b middle byte
    * @param c lower byte
    *
    * @return integer value
    */
   public static int uint3(int a, int b, int c)
   {

      return a << 16 | b << 8 | c;
   }


   /**
    * Convert four bytes into a float value.
    *
    * @param a highest byte
    * @param b higher byte
    * @param c lower byte
    * @param d lowest byte
    *
    * @return float value
    */
   public static float float4(int a, int b, int c, int d)
   {

      int sgn, mant, exp;

      mant = b << 16 | c << 8 | d;
      if (mant == 0) return 0.0f;

      sgn = -(((a & 128) >> 6) - 1);
      exp = (a & 127) - 64;

      return (float) (sgn * Math.pow(16.0, exp - 6) * mant);
   }

}


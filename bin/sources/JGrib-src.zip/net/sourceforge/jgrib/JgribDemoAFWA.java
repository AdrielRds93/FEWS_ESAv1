package net.sourceforge.jgrib;
// import statements

import nl.wldelft.util.ExceptionUtils;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/***************************************************************************
 *
 * This class demonstrates several ways to use the Jgrib package.<br>
 * The purpose of this demo program is to help
 * new users of the Jgrib package get familiar with
 * some of the aspects of the package.
 *
 * @author Peter Gylling<br>email: Peg@fomfrv.dk
 * @author Richard D. Gonzalez - heavily modified to work with new changes
 * (AFWA stands for Air Force Weather Agency - I modified JGrib specifically
 * to be able to read GRIB files produced by AFWA)
 *
 * This demo demonstrates three things:
 * 1.  Listing records in the order they appear in the file - useful for
 *        getting record number for extracting single records
 * 2.  Listing short names from the parameter table to see what types are in
 *        the GRIB file.
 * 3.  Sorting and extracting records using the methods in the GribFile class
 *
 * This dumps a lot of text to the screen - you may want to pipe the output to a
 * file, or set the properties of you window to have a large buffer size.
 *
 * @since 1.2
 *
 ****************************************************************************/
public class JgribDemoAFWA {

   /************************************************************************
    *
    * Dumps usage of the class, if called without arguments
    *
    ************************************************************************/
   public void usage(String className) {
      System.out.println();
      //System.out.println("Usage of " + className + ":");
      System.out.println("Usage of JGrib:");
      System.out.println("java -jar jgrib.jar <GribFileToRead>");
      System.out.println("E.g.:");
      System.out.println("java -jar jgrib.jar  cf0120");
      System.exit(0);
   }

   /***********************************************************************
    * Dump of file content<br>
    *
    * @param  args Filename of gribfile to read
    *
    *************************************************************************/
   public static  void main(String args[]) {

      boolean printGridValues = true;

      int recordCount;

      // Function References
      JgribDemoAFWA demo = new JgribDemoAFWA();

      // Test usage
      if (args.length != 1) {
         // Get class name as String
         Class cl = demo.getClass();
         demo.usage(cl.getName());
      }

      //Check wheteher the grib-file exists
      File file = new File(args[0]);
      if ( ! file.exists()) {
          System.out.println("Grib file "+args[0]+" does not exist !");
          System.exit(-1);
      }

      //Determine the name of the output file and open it
      String outputFileName;
      if (file.getParent() != null) {
           outputFileName = file.getParent()+"\\content_"+file.getName();
      } else {
           outputFileName = "content_"+file.getName();
      }
      TextFileWriter contentWriter=null;
      try {
          contentWriter = new TextFileWriter(outputFileName);
      } catch (java.io.IOException ex){
          System.out.println("Cannot open output file "+ outputFileName + "\n"+ ExceptionUtils.getMessage(ex));
          System.exit(-1);
      }


      // Get UTC TimeZone
      // A list of available ID's show that UTC has ID = 127
      TimeZone tz = TimeZone.getTimeZone("127");
      TimeZone.setDefault(tz);

      // Say hello
      Date now = Calendar.getInstance().getTime();
      System.out.println(now.toString() + "\nStart reading file...");


      // Reading of grib files must be inside a try-catch block
      try {
         // Create GribFile instance
         GribFile gribFile = new GribFile(args[0]);

         // Get light grib reccord (used to get the meta data)
         GribRecord[] gribLight = gribFile.getLightRecords();

         // determine how many GribRecords are stored
         recordCount = gribFile.getRecordCount();
         System.out.println("Grib file reports " + recordCount + " records.");
         contentWriter.println("Grib file reports " + recordCount + " records,");
         contentWriter.println("the first record's IS and GDS indicate:");

         // Get grib Indicator Section
         GribRecordIS gribIS = gribLight[0].getIS();
         contentWriter.println(gribIS.toString());

         // Get grib Grid Description Section
         GribRecordGDS[] GDSs = gribFile.getGrids();
         contentWriter.println("found " + GDSs.length + " grids");
         for (int i=0;i<GDSs.length;i++){
             contentWriter.println(GDSs[i].toString());
             contentWriter.println("coordinates long/lat");
             double[] coors = GDSs[i].getGridCoords();
             for (int j = 0; j < coors.length; j++) {
                 contentWriter.println(coors[j++] + "\t" + coors[j]);
             }
         }

         // Get grib Product Definition Section
         contentWriter.println(gribLight[0].getPDS().headerToString());

         // Get grib scan mode to define reading direction
//         int scan = gribGDS.getGridScanmode();
//         System.out.println("\n      Scan order is " + scan);

         // Get data from first record. remember that first record is number 1
         // and not number 0.
         GribRecord rec = gribFile.getRecord(1);
         GribRecordBDS gribBDS = rec.getBDS();
         contentWriter.println(gribBDS.toString());

         //Print the parameter types the file contains
         System.out.println("GribFile contains following parameters:");
         contentWriter.println("GribFile contains following parameters:");
         for (int i = 0;i<gribFile.getTypeNames().length;i++){
            System.out.println((gribFile.getTypeNames())[i]);
            contentWriter.println((gribFile.getTypeNames())[i]);
         }

         //printParameterDetailInfo(gribFile, contentWriter);

         // compare the Lat/Lon values stored in the GRIB file (if there) with
         //    those computed by the projection
//         compareCoords(gribFile);

        //Print grid values
        //tester(gribFile, contentWriter);
        testerShort(gribFile, contentWriter, printGridValues);

      // Catch thrown errors from GribFile
      } catch (FileNotFoundException noFileError) {
         System.err.println("FileNotFoundException : " + noFileError);
      } catch (IOException ioError) {
         System.err.println("IOException : " + ioError);
      } catch (NoValidGribException noGrib) {
         System.err.println("NoValidGribException : " + noGrib);
      } catch (NotSupportedException noSupport) {
         System.err.println("NotSupportedException : " + noSupport);
      }


      //Close output file
       try {
           contentWriter.close();
       } catch (java.io.IOException ioe){
               System.out.println("Cannot close output file "+ outputFileName);
       }

       System.out.println("\nFinished");

   }



   private static void printParameterDetailInfo(GribFile gribFile, TextFileWriter contentWriter){


       String[] parameters = gribFile.getTypeNames();
       for (int i = 0; i < parameters.length; i++) {
           String par = parameters[i];
           GribRecordGDS[] gdsArray = gribFile.getGridsForType(par);
           for (int j = 0; j < gdsArray.length; j++) {
              GribRecordGDS gds = gdsArray[j];
              int[] units  = gribFile.getZunitsForTypeGrid(par, gds);
              for (int k = 0; k < units.length; k++) {
                  int unit = units[k];
                  GribPDSLevel[] levels = gribFile.getLevelsForTypeGridUnit(par, gds, unit);
                  for (int l = 0; l < levels.length; l++) {
                     GribPDSLevel level = levels[l];
                     contentWriter.println(par+" "+ level.getIndex() + " " + level.getLevel() + " " + level.getName() +
                                           " " + level.getUnits() + " " + j);
                  }

              }
           }
       }


   }


    /**
     * A method which extracts sorted records from the GRIB file.  This is the
     * intended method for a full extraction of all the records.
     * @param gribFile
     */
    public static  void testerShort(GribFile gribFile, TextFileWriter contentWriter, boolean printGridValues){
        NumberFormat numberFormat = new DecimalFormat("###0");

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        int count = 0;
        int countConsole = 0;

        System.out.println("\nExtracting and printing records to the output file.......\n" +
                           "REMARKS:\n" +
                           "Time range wil be printed only if the any timerange defined (i.e. pds octet 21 > 1)\n " +
                           "Only every fiftieth record wil be printed to the console");

        contentWriter.println("\nRecords extracted from the Grib file :\n" +
                              "Remarks:\n" +
                              "Level unit may be not specified.\n"+
                              "Time range wil be printed only if the any timerange defined (i.e. pds octet 21 > 1)");
        contentWriter.println("Each record is identified by\n" +
                              "Parameter;   Forecast Time;    Base time;    Unit;    Level code (name,unit);    Grid Size  [Counter]  Time Range");
        contentWriter.println("-----------------------------------------------------------------------------------------------------------------");


        GribRecord  gribRecordLight[] = gribFile.getLightRecords();
        for (int i=0; i < gribRecordLight.length; i++){

            count++;
            countConsole++;

            GribRecordGDS gds = gribRecordLight[i].getGDS();
            GribRecordPDS pds = gribRecordLight[i].getPDS();
            String levelName = pds.getLevelName();
            int levelIndex = pds.getPDSLevel().getIndex();
            String levelUnit =   pds.getPDSLevel().getUnits();
            if (levelUnit.trim().length() < 1) levelUnit = "-";
            String unit = pds.getUnit();
            String type = pds.getType();  //=parameter
            long forecastTime = pds.getLocalForecastTime().getTimeInMillis();
            long baseTime = pds.getLocalBaseTime().getTimeInMillis();


            if (printGridValues) {
                contentWriter.println("\n\n");
            }

            String lineOut = (padLeft(type,5) +
                              ";   " +  dateFormat.format(forecastTime)  +
                              ";   " +  dateFormat.format(baseTime)  +
                              ";   " +  unit + ";   " + levelIndex + " ("+levelName+","+levelUnit+")" + ";   " +
                              gds.getGridNX() + "x" + gds.getGridNY() +
                                "  ["+count+"]  ") + pds.getTimeRange();

            contentWriter.println(lineOut);

            if (printGridValues) {
              float[] values = gribRecordLight[i].getValues();
              contentWriter.println(makeStringOfValues(values, gds.getGridNX(), gds.getGridNY()));
            }
            if ( countConsole == 50) {
                System.out.println(lineOut);
            }

            if (countConsole > 50) {
                countConsole=0;
            }

        }
    }

    private static String makeStringOfValues(float[] values, int numX, int numY) {

        DecimalFormat decimalFormat = new DecimalFormat("0.0000", new DecimalFormatSymbols(Locale.US));
        StringBuffer res = new StringBuffer();
        for (int ix = 0; ix < numX; ix++) {
            res.append("\n");
            for (int iy = 0; iy < numY; iy++) {
                int indx = ix * numY  + iy;
                float value = values[indx];
                String strValue = decimalFormat.format(value);
                res.append(padLeft(strValue,10));
                res.append(' ');
            }
        }
        return res.toString();
    }

   /**
    * A method which extracts sorted records from the GRIB file.  This is the
    * intended method for a full extraction of all the records.
    * @param gribFile
    */
   public static  void tester(GribFile gribFile, TextFileWriter contentWriter){

      DecimalFormat decimalFormat = new DecimalFormat("##0.##E0", new DecimalFormatSymbols(Locale.US));
      SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

      GribFile gf = gribFile;
      String[] types;
      GribRecordGDS[] gdsArray;
      int[] levelTypes;
      Date[] dates;
      GribPDSLevel[] levels;
      GribRecord[] sortedRecords = new GribRecord[gf.getRecordCount()];
      int count = 0;
      int countConsole = 0;

      System.out.println("\nExtracting and printing records to the output file....\n" +
                         "  (Only every fiftieth record wil be printed to the console)");

      contentWriter.println("\nRecords extracted from the Grib file :");
      contentWriter.println("Each record is identified by\n" +
                            "Parameter;   Level id:Level name;   Grid Size;   ForecastTime   Base time [Counter]");
      contentWriter.println("-------------------------------------------------------------------------------------");

       // get the parameter types

      types = gf.getTypeNames();
      for (int count1=0;count1 < types.length;count1++){
         String type = types[count1];
         // get the grids for each type
         gdsArray = gf.getGridsForType(type);
         for (int count2=0;count2< gdsArray.length; count2++){
            GribRecordGDS gds = gdsArray[count2];
            // get the vertical coordinates for each type, grid
            levelTypes = gf.getZunitsForTypeGrid(type,gds);

            for (int count3=0;count3<levelTypes.length;count3++){
               int unit = levelTypes[count3];
               // get the levels for each type, grid, zUnit
               levels = gf.getLevelsForTypeGridUnit(type,gds,unit);


               for (int count4=0;count4<levels.length;count4++){
                  GribPDSLevel level = levels[count4];
                  // get the dates for each type, grid, level
                  dates = gf.getDatesForTypeGridLevel(type,gds,level);
                  for (int count5=0;count5<dates.length;count5++){
                     Date date = dates[count5];
                     // get the record for each type, grid, level, date
                     // if this works properly, should get every record

                     try{

                        //sortedRecords[count++] = gf.getRecord(type,gds,level.getLevel(),date);
                         GribRecord gribRecord = gf.getRecord(type,gds,level.getLevel(),date);
                         long forecastTime = gribRecord.getPDS().getLocalForecastTime().getTimeInMillis();
                         long baseTime = gribRecord.getPDS().getLocalBaseTime().getTimeInMillis();

                         String lineOut = (type + "; " +
                                          unit + ":" + level.getLevel() + "; " +
                                          gds.getGridNX() + "x" + gds.getGridNY() +
                                          "; " +  dateFormat.format(forecastTime)  +
                                          "; " +  dateFormat.format(baseTime)  +
                                          "["+count+"]");

                        contentWriter.println("Values for the record: "+lineOut);
                        if ( countConsole == 50) {
                           System.out.println("Record: "+lineOut);
                        }

                        count++;
                        countConsole++;
                        if (countConsole > 50) {
                             countConsole=0;
                        }


                        //Print grid
                         StringBuffer buffer = new  StringBuffer();
                         float values[] = gribRecord.getValues();
                         for (int numval=0; numval < values.length; numval++) {
                             if ( ! Float.isNaN(values[numval])) {
                                  buffer.append(decimalFormat.format(values[numval]));
                                 buffer.append(" ");
                             } else {
                                 buffer.append("NaN ");
                             }

                         }
                         contentWriter.println(buffer.toString());


                     } catch (java.io.IOException ioe){
                        System.err.println("Couldn't convert GribLightRecords to GribRecords - exiting");
                        System.exit(-1);
                     }catch (NoValidGribException nvge){
                        System.err.println("Couldn't convert GribLightRecords to GribRecords - exiting");
                        System.exit(-1);
                     }catch (NotSupportedException nse){
                        System.err.println("Couldn't convert GribLightRecords to GribRecords - exiting");
                        System.exit(-1);
                     }

                  }
               }

            }
         }
      }
      System.out.println("GribFile has " + gf.getRecordCount() + " records; " +
                         "Sorted Records Array length is " + sortedRecords.length +
                         " and loop count is " + count + " - if these don't all " +
                         "match, JGrib didn't properly process all the records");

   }

   private static void compareCoords(GribFile gribFile) {
      try {
         // compare computed latitude and longitude to records in file
         GribRecord[] latRecords = gribFile.getRecordForType("Lat");
         GribRecord[] lonRecords = gribFile.getRecordForType("Lon");
         GribRecord gribLat = null;
         GribRecord gribLon = null;
         double[] latCoords;
         double[] lonCoords;
         float[] latValues;
         float[] lonValues;

         double error, sumErrors = 0, rmse, maxError=0;

         int latLength;
         int lonLength;
         for (int i=0;i<latRecords.length;i++){
            gribLat = latRecords[i];
            gribLon = lonRecords[i];
            lonLength = gribLat.getGDS().getGridNX();
            latLength = gribLon.getGDS().getGridNY();
            latCoords = gribLat.getGridCoords();
            lonCoords = gribLon.getGridCoords();
            System.out.println("\nLats/Lons for level: " + gribLat.getLevel());
            latValues = gribLat.getBDS().getValues();
            lonValues = gribLon.getBDS().getValues();

            for (int n=0;n<latValues.length;n++){
               error = latValues[n] - latCoords[n*2+1];
               sumErrors += error*error;
               if (error > maxError) maxError = error;
            }
            rmse = Math.sqrt(sumErrors/latValues.length);
            System.out.println("lat RMSE = " + rmse + "Max error = " + maxError);

            sumErrors = 0;
            maxError = 0;
            for (int n=0;n<lonValues.length;n++){
               error = lonValues[n] - lonCoords[n*2];
               sumErrors += error*error;
               if (error > maxError) maxError = error;
            }
            rmse = Math.sqrt(sumErrors/latValues.length);
            System.out.println("lon RMSE = " + rmse + "Max error = " + maxError);


            for (int n=0;n<latValues.length;n=n+lonLength){
               System.out.println("lat[" + n + "]: " + latValues[n] +
                                  " latCoords[" + (n*2+1) +"]: " + latCoords[n*2+1]);
            }
            for (int n=0;n<lonLength;n++){
               System.out.println("lon[" + n + "]: " + lonValues[n] +
                                  " lonCoords[" + (2*n) +"]: " + lonCoords[2*n]);
            }
         }
      } catch (Exception error) {
         System.err.println(error);
      } 
   }


    private static class TextFileWriter {
       private PrintStream printStream;

       public TextFileWriter(String path) throws IOException {
           File file = new File(path);
           open(new BufferedOutputStream(new FileOutputStream(file)));

       }
       private void open(OutputStream out) {
           printStream = new PrintStream(out);
       }

       public void println(String text) {
           printStream.println(text);
       }

       public void close() throws IOException {
           printStream.close();
           if (printStream.checkError()) {
               throw new IOException("Can not close output file !");
          }
       }
    }

    public static String padLeft(String aText, int aLength) {
        return padLeft(aText, aLength, ' ');
    }

    public static String padLeft(String aText, int aLength, char aChar) {
        if (aText.length() >= aLength) return aText;

        return string(aChar, aLength - aText.length()) + aText;
    }

    public static String string(char aChar, int aLength) {
        char buf[] = new char[aLength];
        for (int i = 0; i < buf.length; i++) {
            buf[i] = aChar;
        }

        return new String(buf);
    }
}
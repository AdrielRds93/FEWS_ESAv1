package net.sourceforge.jgrib.util;

/**
  * A comparator class used with HashSet-s when storing/sorting Records as
  * they are read.
  *
  * Compares numerous features from the record information to sort according
  * to a time, level, level-type, y-axis, x-axis order
  * @author Capt Richard D. Gonzalez
  * @version 1.0
  */
import java.util.Comparator;
import java.util.Calendar;
import net.sourceforge.jgrib.GribPDSLevel;


public class GribPDSLevelComparator implements Comparator {
   /**
    * Method required to implement Comparator.
    * If obj1 is less than obj2, return -1, if equal, return 0, else return 1
    */
   public int compare(Object obj1, Object obj2){

      // quick check to see if they're the same PDSLevel
      if (obj1 == obj2) return 0;

      float z1;
      float z2;
      String levelType1;
      String levelType2;
      GribPDSLevel level1;
      GribPDSLevel level2;
      int check;

      // get the levels
      level1 = (GribPDSLevel)obj1;
      level2 = (GribPDSLevel)obj2;



      // compare the levels
      if (level1.getIndex() < level2.getIndex()) return -1;
      if (level1.getIndex() > level2.getIndex()) return 1; // if neither, then equal; continue

      // compare the z levels
      z1 = level1.getValue1();
      z2 = level2.getValue1();
      // if the levels are supposed to decrease with height, reverse comparator
      if (!(level1.getIsIncreasingUp())) {
         z1 = -z1;
         z2 = -z2;
      }
      if (z1 < z2) return -1;
      if (z1 > z2) return 1; //if neither, then equal; continue

      z1 = level1.getValue2();
      z2 = level2.getValue2();
      // if the levels are supposed to decrease with height, reverse comparator
      if (!(level1.getIsIncreasingUp())) {
         z1 = -z1;
         z2 = -z2;
      }
      if (z1 < z2) return -1;
      if (z1 > z2) return 1; // last check, if neither, then equal

      return 0;
   } // end of method compare

}
package org.noos.xing.mydoggy.plaf.ui.drag;

/**
 * @author Angelo De Caro (angelo.decaro@gmail.com)
 */
public interface DragGestureInitiator {

    void setDragGesture(DragGesture dragGesture);
    
}

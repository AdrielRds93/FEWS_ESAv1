package org.noos.xing.mydoggy.plaf.ui.cmp;

import java.awt.*;

/**
 * @author Angelo De Caro (angelo.decaro@gmail.com)
 */
public interface TranslucentComponent {

    void setAlphaModeRatio(float transparency);

    float getAlphaModeEnabled();

}

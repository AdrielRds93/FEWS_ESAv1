package org.noos.xing.mydoggy.plaf.ui.content;

import org.noos.xing.mydoggy.Content;
import org.noos.xing.mydoggy.ContentManager;
import org.noos.xing.mydoggy.ContentManagerUI;
import org.noos.xing.mydoggy.ContentManagerUIListener;
import org.noos.xing.mydoggy.ContentUI;
import org.noos.xing.mydoggy.ToolWindowAnchor;
import org.noos.xing.mydoggy.event.ContentManagerUIEvent;
import org.noos.xing.mydoggy.plaf.MyDoggyContent;
import org.noos.xing.mydoggy.plaf.MyDoggyToolWindowBar;
import org.noos.xing.mydoggy.plaf.MyDoggyToolWindowManager;
import org.noos.xing.mydoggy.plaf.PropertyChangeEventSource;
import org.noos.xing.mydoggy.plaf.ui.ResourceManager;
import org.noos.xing.mydoggy.plaf.ui.util.SwingUtil;

import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.SwingUtilities;
import javax.swing.event.EventListenerList;
import java.awt.Component;
import java.awt.Container;
import java.awt.Rectangle;
import java.awt.Window;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.WindowEvent;
import java.awt.event.WindowFocusListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.util.Hashtable;
import java.util.Map;

/**
 * @author Angelo De Caro (angelo.decaro@gmail.com)
 */
public abstract class MyDoggyContentManagerUI<T extends ContentUI> extends PropertyChangeEventSource implements PropertyChangeListener {
    protected ContentManagerUI contentManagerUI;
    protected MyDoggyToolWindowManager toolWindowManager;
    protected ContentManager contentManager;
    protected ResourceManager resourceManager;
    protected Map<Content, T> contentUIMap;

    protected boolean closeable, detachable, minimizable;
    protected boolean installed;
    protected boolean uninstalling;

    protected PropertyChangeSupport internalPropertyChangeSupport;
    protected EventListenerList contentManagerUIListeners;
    protected PropertyChangeListener contentUIListener;
    
    protected Content maximizedContent;
    protected Content lastSelected;

    protected boolean valueAdjusting;
    protected boolean contentValueAdjusting;

    private JComponent toolbars;
    private JComponent currentDisplayToolbar = null;
    private MyDoggyTopToolBar currentDisplayToolbarOwner = null;
    private boolean toolbarFits = false;

    private final PropertyChangeListener buttonAddedListener = evt -> {
        if (!toolbarFits) return;
        if (!evt.getPropertyName().equals("buttons.added")) return;
        toolBarResized();
    };

    public MyDoggyContentManagerUI() {
        contentManagerUIListeners = new EventListenerList();
        this.closeable = this.detachable = this.minimizable = true;
        this.contentUIMap = new Hashtable<Content,T>();
    }

    public void setToolBars(JComponent toolBars) {
        this.toolbars = toolBars;
        toolBars.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                toolBarResized();
            }
        });
        if (toolWindowManager != null) {
            var toolWindowBar = (MyDoggyToolWindowBar) toolWindowManager.getToolWindowBar(ToolWindowAnchor.TOP);
            toolWindowBar.getContainer().addComponentListener(new ComponentAdapter() {
                @Override
                public void componentResized(ComponentEvent e) {
                    toolBarResized();
                }
            });
        }
    }

    public void setCloseable(boolean closeable) {
        boolean old = this.closeable;
        this.closeable = closeable;

        for (ContentUI contentUI : contentUIMap.values()) {
            contentUI.setCloseable(closeable);
        }

        fireContentManagerUIProperty("closeable", old, closeable);
    }

    public boolean isCloseable() {
        return closeable;
    }

    public void setDetachable(boolean detachable) {
        boolean old = this.detachable;
        this.detachable = detachable;

        for (ContentUI contentUI : contentUIMap.values()) {
            contentUI.setDetachable(detachable);
        }

        fireContentManagerUIProperty("detachable", old, detachable);
    }

    public boolean isDetachable() {
        return detachable;
    }

    public void setMinimizable(boolean minimizable) {
        boolean old = this.minimizable;
        this.minimizable = minimizable;

        for (ContentUI contentUI : contentUIMap.values()) {
            contentUI.setMinimizable(minimizable);
        }

        fireContentManagerUIProperty("minimizable", old, minimizable);
    }

    public boolean isMinimizable() {
        return minimizable;
    }

    public T getContentUI(Content content) {
        return contentUIMap.get(content);
    }

    public void addContentManagerUIListener(ContentManagerUIListener listener) {
        contentManagerUIListeners.add(ContentManagerUIListener.class, listener);
    }

    public void removeContentManagerUIListener(ContentManagerUIListener listener) {
        contentManagerUIListeners.remove(ContentManagerUIListener.class, listener);
    }

    public ContentManagerUIListener[] getContentManagerUiListener() {
        return contentManagerUIListeners.getListeners(ContentManagerUIListener.class);
    }

    public void propertyChange(PropertyChangeEvent evt) {
        internalPropertyChangeSupport.firePropertyChange(evt);
    }


    public boolean isInstalled() {
        return installed;
    }

    public void addContent(PlafContent content, Object... constraints) {
        if (maximizedContent != null) {
            maximizedContent.setMaximized(false);
            maximizedContent = null;
        }

        // Add the content to the ui...
        addUIForContent(content, constraints);

        // Register a plaf listener
        content.addPlafPropertyChangeListener(this);
    }

    public void removeContent(PlafContent content) {
        try {
            if (content.isDetached()) {
                propertyChange(new PropertyChangeEvent(content, "detached.dispose", true, false));
            } else if (content.isMinimized()) {
                toolWindowManager.getDockableDescriptor(content.getId()).setAvailable(false);
            } else {
                removeUIForContent(content);
            }
        } finally {
            // Remove listeners
            content.getContentUI().removePropertyChangeListener(contentUIListener);
            content.removePlafPropertyChangeListener(this);

            // Clean desccriptor for minimization
            toolWindowManager.removeDockableDescriptor(content.getId());

            // Remove the contentUI part
            contentUIMap.remove(content);
            if (lastSelected == content)
                lastSelected = null;
        }
    }

    public boolean isSelected(Content content) {
        return content == lastSelected;
    }


    protected abstract Object addUIForContent(Content content, Object[] constraints);

    protected abstract void removeUIForContent(Content content);


    protected void setContentManagerUI(ContentManagerUI contentManagerUI) {
        this.contentManagerUI = contentManagerUI;
    }

    protected Content getMaximizedContent() {
        for (Content content : contentManager.getContents()) {
            if (content.isMaximized())
                return content;
        }
        return null;
    }

    protected boolean isContentManagerEnabled() {
        return contentManager.isEnabled();
    }

    protected Component findAndRequestFocus(Component component) {
        Container container;
        if (component instanceof JDialog) {
            container = ((JDialog) component).getContentPane();
        } else if (component instanceof Container)
            container = (Container) component;
        else
            return null;

        Component focusRequester = SwingUtil.findFocusable(container);
        if (focusRequester == null) {
            focusRequester = container;
        }
        tryMoveToolbarToMainToolbar(component);
        SwingUtil.requestFocus(focusRequester);
        return focusRequester;
    }


    private void tryMoveToolbarToMainToolbar(Component component) {
        if (currentDisplayToolbarOwner == component) return;
        attachToolbarToOwner();
        if (component instanceof JDialog) return;
        if (!(component instanceof MyDoggyTopToolBar)) return;
        currentDisplayToolbar = ((MyDoggyTopToolBar) component).detachTopToolbar();
        if (currentDisplayToolbar == null) return;
        currentDisplayToolbar.addPropertyChangeListener(buttonAddedListener);
        currentDisplayToolbarOwner = (MyDoggyTopToolBar) component;
        toolbarFits = isEnoughSpaceAvailable(currentDisplayToolbar);
        if (!toolbarFits) {
            ((MyDoggyTopToolBar) component).attachTopToolbar();
            return;
        }
        toolbars.add(currentDisplayToolbar);
        invalidateWindow();
    }

    private void invalidateWindow() {
        var containingWindow = getContainingWindow(toolbars);
        if (containingWindow == null) return;
        containingWindow.invalidate();
        containingWindow.validate();
        containingWindow.repaint();
    }

    private void toolBarResized() {
        if (currentDisplayToolbar == null) return;
        var toolbarFits = isEnoughSpaceAvailable(currentDisplayToolbar);
        if (this.toolbarFits == toolbarFits) return;
        this.toolbarFits = toolbarFits;
        if (toolbarFits) {
            var toolbar = currentDisplayToolbarOwner.detachTopToolbar();
            assert toolbar == currentDisplayToolbar;
            toolbars.add(currentDisplayToolbar);
            invalidateWindow();
            return;
        }
        toolbars.remove(currentDisplayToolbar);
        currentDisplayToolbarOwner.attachTopToolbar();
        invalidateWindow();
    }

    private void attachToolbarToOwner() {
        if (currentDisplayToolbar == null) return;
        currentDisplayToolbar.removePropertyChangeListener(buttonAddedListener);
        if (toolbarFits) {
            toolbars.remove(currentDisplayToolbar);
            currentDisplayToolbarOwner.attachTopToolbar();
        }
        currentDisplayToolbar = null;
        currentDisplayToolbarOwner = null;
        invalidateWindow();
    }

    private static Window getContainingWindow(Component component) {
        while (component != null && !(component instanceof Window)) {
            component = component.getParent();
        }
        return (Window) component;
    }


    private boolean isEnoughSpaceAvailable(JComponent toolbar) {
        var toolWindowBar = (MyDoggyToolWindowBar) toolWindowManager.getToolWindowBar(ToolWindowAnchor.TOP);
        if (toolWindowBar.getContainer().getHeight() > 0) return false;
        var firstToolBarWidth = toolbars.getComponentCount() == 0 ? 0 : getMaxWith((JComponent) toolbars.getComponent(0));
        return firstToolBarWidth + getMaxWith(toolbar) < toolbars.getWidth();
    }

    private static int getMaxWith(JComponent toolBar) {
        var size = toolBar.getSize();
        try {
            toolBar.setSize(100000, toolBar.getHeight());   // for wrapping layout
            return toolBar.getPreferredSize().width;
        } finally {
            toolBar.setSize(size);
        }
    }

    protected boolean fireContentUIRemoving(ContentUI contentUI) {
        
        ContentManagerUIEvent event = new ContentManagerUIEvent(contentManagerUI, ContentManagerUIEvent.ActionId.CONTENTUI_REMOVING, contentUI);

        for (ContentManagerUIListener listener : contentManagerUIListeners.getListeners(ContentManagerUIListener.class)) {
            if (!listener.contentUIRemoving(event))
                return false;
        }
        return true;
    }

    protected void fireContentUIDetached(ContentUI contentUI) {
        var selectedContent = ((MyDoggyTabbedContentManagerUI) this).tabbedContentPane.getSelectedContent();
        var component = selectedContent == null ? null : ((MyDoggyContent) selectedContent).getComponent();
        tryMoveToolbarToMainToolbar(component);
        ContentManagerUIEvent event = new ContentManagerUIEvent(contentManagerUI, ContentManagerUIEvent.ActionId.CONTENTUI_DETACHED, contentUI);
        for (ContentManagerUIListener listener : contentManagerUIListeners.getListeners(ContentManagerUIListener.class)) {
            listener.contentUIDetached(event);
        }
    }

    protected void fireContentManagerUIProperty(String property, Object oldValue, Object newValue) {
        firePropertyChangeEvent(new PropertyChangeEvent(contentManagerUI, property, oldValue, newValue));
    }


    protected class ContentDialogFocusListener implements WindowFocusListener {
        protected Content content;

        public ContentDialogFocusListener(Content content) {
            this.content = content;
        }

        public void windowGainedFocus(WindowEvent e) {
            if (!valueAdjusting && !contentValueAdjusting) {
                Content newSelected = content;

                if (newSelected == lastSelected)
                    return;

                if (lastSelected != null) {
                    try {
                        lastSelected.setSelected(false);
                    } catch (Exception ignoreIt) {
                    }
                }

                newSelected.setSelected(true);
                lastSelected = newSelected;
            }
        }

        public void windowLostFocus(WindowEvent e) {
        }
    }
    
    protected class ContentUIListener implements PropertyChangeListener {

        public void propertyChange(PropertyChangeEvent evt) {
            ContentUI contentUI = (ContentUI) evt.getSource();

            if (contentUI.getContent().isDetached()) {
                if ("detachedBounds".equals(evt.getPropertyName())) {
                    Window window = SwingUtilities.windowForComponent(contentUI.getContent().getComponent());
                    window.setBounds((Rectangle) evt.getNewValue());
                } else if ("addToTaskBar".equals(evt.getPropertyName())) {
                    Content content = contentUI.getContent();
                    ContentDescriptor contentDescriptor = ((MyDoggyContent) content).getDescriptor();
                    //EP only apply when window != null FEWS-13397
                    if (contentDescriptor.getContentContainer().window != null){
                        Window oldWindow = contentDescriptor.getContentContainer().window;
                        boolean visible = oldWindow.isVisible();
                        oldWindow.setVisible(false);
                        oldWindow.dispose();
                        contentDescriptor.getContentContainer().window = null;
                        contentDescriptor.getContentContainer().setVisible(visible);
                    }


                }
            }
        }
    }
}

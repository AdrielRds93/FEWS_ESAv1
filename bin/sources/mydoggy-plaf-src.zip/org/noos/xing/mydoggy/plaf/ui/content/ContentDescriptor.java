package org.noos.xing.mydoggy.plaf.ui.content;

import org.noos.xing.mydoggy.Content;
import org.noos.xing.mydoggy.Dockable;
import org.noos.xing.mydoggy.ToolWindowAnchor;
import org.noos.xing.mydoggy.plaf.MyDoggyToolWindowManager;
import org.noos.xing.mydoggy.plaf.ui.CustomDockableDescriptor;
import org.noos.xing.mydoggy.plaf.ui.DockableDescriptor;
import org.noos.xing.mydoggy.plaf.ui.MyDoggyKeySpace;
import org.noos.xing.mydoggy.plaf.ui.cmp.AggregateIcon;
import org.noos.xing.mydoggy.plaf.ui.cmp.TextIcon;
import org.noos.xing.mydoggy.plaf.ui.look.ContentRepresentativeAnchorUI;

import javax.swing.*;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.LabelUI;
import java.awt.*;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

/**
 * EDR: Added the content container to give an altered look and feel to the undocked content display.
 */
public class ContentDescriptor extends CustomDockableDescriptor implements PropertyChangeListener {
    protected Content content;
    private ContentContainer container;
    private boolean idVisibleOnTitleBar;

    public ContentDescriptor(MyDoggyToolWindowManager manager, Content content) {
        super(manager, ToolWindowAnchor.LEFT, content.getId());
        this.content = content;
        this.anchor = ToolWindowAnchor.LEFT;

        content.addPropertyChangeListener(this);
    }


    public void propertyChange(PropertyChangeEvent evt) {
        updateRepresentativeAnchor();
    }

    public DockableType getDockableType() {
        return DockableType.CONTENT;
    }

    public Dockable getDockable() {
        return content;
    }

    /**
     * Added EDR
     * @return
     */
    public ContentContainer getContentContainer(){
        if (container == null){
            container = new ContentContainer(this);
        }
        return container;
    }

    public JComponent getRepresentativeAnchor(Component parent) {
        if (representativeAnchor == null) {
            ToolWindowAnchor anchor = getAnchor();

            String labelText = getResourceManager().getUserString(content.getId());
            Icon toolIcon = content.getIcon();

            switch (anchor) {
                case BOTTOM:
                case TOP:
                    representativeAnchor = new RepresentativeAnchorLabel(labelText, toolIcon, JLabel.CENTER);
                    break;
                case LEFT:
                    TextIcon textIcon = new TextIcon(parent, labelText, TextIcon.ROTATE_LEFT);
                    textIcon.setForeground(manager.getResourceManager().getColor(MyDoggyKeySpace.RAB_FOREGROUND));
                    AggregateIcon compositeIcon = new AggregateIcon(textIcon, toolIcon, SwingConstants.VERTICAL);
                    representativeAnchor = new RepresentativeAnchorLabel(compositeIcon, JLabel.CENTER);
                    break;
                case RIGHT:
                    textIcon = new TextIcon(parent, labelText, TextIcon.ROTATE_RIGHT);
                    textIcon.setForeground(manager.getResourceManager().getColor(MyDoggyKeySpace.RAB_FOREGROUND));
                    compositeIcon = new AggregateIcon(toolIcon, textIcon, SwingConstants.VERTICAL);
                    representativeAnchor = new RepresentativeAnchorLabel(compositeIcon, JLabel.CENTER);
                    break;
            }

            representativeAnchor.setName("toolWindow.rb." + content.getId());
            representativeAnchor.setOpaque(true);
            representativeAnchor.setFocusable(false);
            representativeAnchor.putClientProperty(DockableDescriptor.class, this);
        }

        return representativeAnchor;
    }

    public JComponent getRepresentativeAnchor() {
        return representativeAnchor;
    }

    public void resetRepresentativeAnchor() {
        representativeAnchor = null;
    }

    public int getAnchorIndex() {
        if (representativeAnchor == null)
            return anchorIndex;
        
        return getToolBar().getRepresentativeAnchorIndex(representativeAnchor);
    }

    public void updateRepresentativeAnchor() {
        if (representativeAnchor != null) {
            ToolWindowAnchor anchor = getAnchor();

            String labelText = getResourceManager().getUserString(content.getId());
            Icon toolIcon = content.getIcon();

            JLabel representativeLabel = (JLabel) representativeAnchor;
            switch (anchor) {
                case BOTTOM:
                case TOP:
                    representativeLabel.setIcon(toolIcon);
                    representativeLabel.setText(labelText);
                    break;
                case LEFT:
                    TextIcon textIcon = new TextIcon(((TextIcon) ((AggregateIcon) representativeLabel.getIcon()).getLeftIcon()).getComponent(), labelText, TextIcon.ROTATE_LEFT);
                    textIcon.setForeground(manager.getResourceManager().getColor(MyDoggyKeySpace.RAB_FOREGROUND));
                    AggregateIcon compositeIcon = new AggregateIcon(textIcon, toolIcon, SwingConstants.VERTICAL);
                    representativeLabel.setText(null);
                    representativeLabel.setIcon(compositeIcon);
                    break;
                case RIGHT:
                    textIcon = new TextIcon(((TextIcon) ((AggregateIcon) representativeLabel.getIcon()).getRightIcon()).getComponent(), labelText, TextIcon.ROTATE_RIGHT);
                    textIcon.setForeground(manager.getResourceManager().getColor(MyDoggyKeySpace.RAB_FOREGROUND));
                    compositeIcon = new AggregateIcon(toolIcon, textIcon, SwingConstants.VERTICAL);
                    representativeLabel.setText(null);
                    representativeLabel.setIcon(compositeIcon);
                    break;
            }
        }
    }

    /**
     * Added EDR
     */
    public void setIdOnTitleBar() {
        if (container != null) {
            if (isIdVisibleOnTitleBar())
                container.enableIdOnTitleBar();
            else
                container.disableIdOnTitleBar();
        }
    }

    /**
     * Added EDR
     * @return
     */
    public boolean isIdVisibleOnTitleBar(){
        return idVisibleOnTitleBar;
    }

    /**
     * Added EDR
     * @param idVisibleOnTitleBar
     */
    public void setIdVisibleOnTitleBar(boolean idVisibleOnTitleBar) {
        if (this.idVisibleOnTitleBar == idVisibleOnTitleBar)
            return;

        this.idVisibleOnTitleBar = idVisibleOnTitleBar;
        setIdOnTitleBar();
    }

    public void cleanup() {
        getCleaner().cleanup();

        if (representativeAnchor != null) representativeAnchor.putClientProperty(DockableDescriptor.class, null);
        resetRepresentativeAnchor();

        content.removePropertyChangeListener(this);

        content = null;
        manager = null;
    }

   public Window getWindowAnchestor() {
        return manager.getWindowAnchestor() instanceof Window ? (Window) manager.getWindowAnchestor() : null;
    }


    public class RepresentativeAnchorLabel extends JLabel {

        public RepresentativeAnchorLabel(Icon image, int horizontalAlignment) {
            super(image, horizontalAlignment);
            super.setUI((LabelUI) createRepresentativeAnchorUI());
        }

        public RepresentativeAnchorLabel(String text, Icon icon, int horizontalAlignment) {
            super(text, icon, horizontalAlignment);
            super.setUI((LabelUI) createRepresentativeAnchorUI());
        }

        public void setUI(LabelUI ui) {
        }

        public void updateUI() {
            firePropertyChange("UI", null, getUI());
        }

        protected ComponentUI createRepresentativeAnchorUI() {
            return new ContentRepresentativeAnchorUI(ContentDescriptor.this);
        }
    }

}

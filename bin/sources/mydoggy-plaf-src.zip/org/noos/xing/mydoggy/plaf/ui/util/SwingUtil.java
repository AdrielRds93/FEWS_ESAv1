package org.noos.xing.mydoggy.plaf.ui.util;

import org.noos.xing.mydoggy.plaf.ui.drag.DragGesture;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JToolBar;
import javax.swing.JViewport;
import javax.swing.SwingUtilities;
import java.applet.Applet;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.GraphicsConfiguration;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.IllegalComponentStateException;
import java.awt.Insets;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.Window;
import java.awt.dnd.DnDConstants;
import java.awt.dnd.DragSource;
import java.beans.PropertyChangeEvent;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.lang.management.ManagementFactory;
import java.net.URL;
import java.util.HashMap;
import java.util.Properties;

/**
 * @author Angelo De Caro
 */
public final class SwingUtil {
    private static final HashMap<Component, Rectangle> fullScreenBounds = new HashMap<>();

    private SwingUtil() {
    }

    public static void centrePositionOnScreen(Window window) {
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        Dimension frameSize = window.getSize();
        window.setLocation(screenSize.width - frameSize.width >> 1, screenSize.height - frameSize.height >> 1);
    }

    public static void requestFocus(Component component) {
        SwingUtilities.invokeLater(component::requestFocusInWindow);
    }

    public static void repaint(Component component) {
        SwingUtilities.invokeLater(() -> {
            component.invalidate();
            component.validate();
            component.repaint();
        });
    }

    public static void repaint(Component component, Runnable runnable) {
        SwingUtilities.invokeLater(() -> {
            component.invalidate();
            component.validate();
            component.repaint();
            SwingUtilities.invokeLater(runnable);
        });
    }

    public static void revalidate(JComponent component) {
        SwingUtilities.invokeLater(component::revalidate);
    }

    public static void repaintNow(Component component) {
        component.invalidate();
        component.validate();
        component.repaint();
    }

    public static void registerDragGesture(Component c, DragGesture dragGesture) {
        DragSource dragSource = new DragSource();
        dragSource.createDefaultDragGestureRecognizer(c, DnDConstants.ACTION_MOVE, dragGesture);
        dragSource.addDragSourceMotionListener(dragGesture);
    }

    public static boolean hasParent(Component component, Container parent) {
        for (Container p = component.getParent(); p != null; p = p.getParent()) {
            if (p == parent)
                return true;
        }
        return false;
    }

    public static Icon loadIcon(String urlDef) {
        return loadIcon(SwingUtil.class.getClassLoader(), urlDef);
    }

    public static Icon loadIcon(ClassLoader classLoader, String urlDef) {
        try {
            URL url = classLoader.getResource(urlDef);
            if (url == null)
                throw new IllegalArgumentException("Invalid URL : " + urlDef);

            return new ImageIcon(Toolkit.getDefaultToolkit().getImage(url));
        } catch (Throwable e) {
            throw new RuntimeException("Cannot load icon : "  + e.getMessage(), e);
        }
    }

    public static Component findFocusable(Component cmp) {
        // TODO: move to question....
        if (cmp.isFocusable() && !(cmp instanceof JPanel) &&
            !(cmp instanceof JLabel) &&
            !(cmp instanceof JScrollPane) &&
            !(cmp instanceof JViewport) &&
            !(cmp instanceof JToolBar) )
            return cmp;

        if (cmp instanceof Container) {
            Container container = (Container) cmp;
            for (int i = 0, size = container.getComponentCount(); i < size; i++) {
                Component finded = findFocusable(container.getComponent(i));
                if (finded != null)
                    return finded;
            }
        }
        return null;
    }

    public static Component getParent(Component c, String parentName) {
        if (c == null || parentName == null)
            return null;

        if (c.getName() != null && c.getName().startsWith(parentName))
            return c;

        for (; c != null; c = c.getParent()) {
            if (c.getName() != null && c.getName().startsWith(parentName))
                return c;
        }
        return null;
    }

    public static int getIconWidth(Icon icon) {
        return icon != null ? icon.getIconWidth() : 0;
    }

    public static int getIconHeight(Icon icon) {
        return icon != null ? icon.getIconHeight() : 0;
    }


    public static Rectangle getVirtualScreenBounds() {
        Rectangle virtualBounds = new Rectangle();
        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        GraphicsDevice[] gs = ge.getScreenDevices();

        for (GraphicsDevice gd : gs) {
            GraphicsConfiguration[] gc = gd.getConfigurations();
            for (GraphicsConfiguration aGc : gc) {
                virtualBounds = virtualBounds.union(aGc.getBounds());
            }
        }
        return virtualBounds;
    }

    public static Rectangle validateBounds(Rectangle bounds, Rectangle referenceBounds) {
        if (bounds == null)
            return null;

        if (bounds.x < referenceBounds.x)
            bounds.x = referenceBounds.x;

        if (bounds.x > referenceBounds.getMaxX())
            bounds.x = (int) referenceBounds.getMaxX() - bounds.width;

        if (bounds.y < referenceBounds.y)
            bounds.y = referenceBounds.y;

        if (bounds.y > referenceBounds.getMaxY())
            bounds.y = (int) referenceBounds.getMaxY() - bounds.height;

        return bounds;
    }

    public static Rectangle validateBounds(Rectangle bounds) {
        return validateBounds(bounds, getVirtualScreenBounds());
    }

    public static void validateBounds(Component component) {
        component.setBounds(validateBounds(component.getBounds(), getVirtualScreenBounds()));
    }

    public static void validateBounds(Component component, Rectangle referenceBounds) {
        component.setBounds(validateBounds(component.getBounds(), referenceBounds));
    }

    public static boolean isMaximumBounds(JFrame frame) {
        GraphicsConfiguration gc = frame.getGraphicsConfiguration();
        Rectangle bounds = gc.getBounds();
        Insets screenInsets = Toolkit.getDefaultToolkit().getScreenInsets(gc);
        Rectangle frameBounds = frame.getBounds();
        return bounds.width - screenInsets.left - screenInsets.right <= frameBounds.width && bounds.height - screenInsets.bottom - screenInsets.top <= frameBounds.height;
    }

    public static void setFullScreen(Container frame, boolean overrideOldBounds) {
        GraphicsConfiguration gc = frame.getGraphicsConfiguration();
        Rectangle bounds = gc.getBounds();
        Insets screenInsets = Toolkit.getDefaultToolkit().getScreenInsets(gc);
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        if (isX11() && isWsl() && screenSize.width >= 3.5 * screenSize.height) { // two monitors on x11
            screenSize.width /= 2;
            bounds.width /= 2;
            bounds.x = screenSize.width; // maximize on second screen
            screenInsets.bottom = 30;
        }


        if (!bounds.equals(frame.getBounds()) && (!fullScreenBounds.containsKey(frame) || overrideOldBounds)) {
            fullScreenBounds.put(frame, frame.getBounds());
        }
        //FEWS-19232: Work around: Do make bounds a bit smaller than maximum to avoid locking of maximized window on Linux.
        frame.setBounds(bounds.x, bounds.y, bounds.width - screenInsets.left - screenInsets.right - 1, bounds.height - screenInsets.bottom - screenInsets.top - 1);
    }

    public static boolean isWsl() {
        var version = ManagementFactory.getOperatingSystemMXBean().getVersion();
        return System.getProperty("os.name").contains("Linux") && version.toLowerCase().contains("microsoft");
    }

    public static boolean isX11() {
        if (GraphicsEnvironment.isHeadless()) return false;
        var screenDevices = GraphicsEnvironment.getLocalGraphicsEnvironment().getScreenDevices();
        return screenDevices[0].toString().startsWith("X11");
    }

    public static void restoreFullScreenWindow(Container frame) {
        GraphicsConfiguration gc = frame.getGraphicsConfiguration();
        Rectangle bounds = gc.getBounds();

        Rectangle oldBounds = fullScreenBounds.remove(frame);
        if (oldBounds != null){
            frame.setBounds(oldBounds);
        } else {
            Dimension preferredSize = frame.getPreferredSize();
            frame.setBounds(bounds.x, bounds.y, preferredSize.width, preferredSize.height);
        }

    }

    public static int findDisplayedMnemonicIndex(String text, int mnemonic) {
        if (text == null || mnemonic == '\0') {
            return -1;
        }

        char uc = Character.toUpperCase((char) mnemonic);
        char lc = Character.toLowerCase((char) mnemonic);

        int uci = text.indexOf(uc);
        int lci = text.indexOf(lc);

        if (uci == -1) {
            return lci;
        } else if (lci == -1) {
            return uci;
        } else {
            return lci < uci ? lci : uci;
        }
    }

    public static Properties loadPropertiesFile(String resourceName, ClassLoader classLoader) {
        try {
            if (classLoader == null)
                classLoader = SwingUtil.class.getClassLoader();

            URL resource = classLoader.getResource("META-INF/" + resourceName);
            if (resource == null) {
                File file = new File(resourceName);
                if (file.exists())
                    resource = file.toURI().toURL();
                else {
                    file = new File(System.getProperty("user.home") + File.separator + resourceName);
                    if (file.exists())
                        resource = file.toURI().toURL();
                    else
                        throw new RuntimeException("Cannot find resource property file called " + resourceName + ".");
                }
            }
            try (InputStream is = resource.openStream()) {
                Properties properties = new Properties();
                properties.load(is);
                return properties;
            }
        } catch (IOException e) {
            throw new RuntimeException("Cannot load resource property file.", e);
        }
    }

    public static Object newObject(String className) {
        try {
            return SwingUtil.class.getClassLoader().loadClass(className).newInstance();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static String toString(PropertyChangeEvent event) {
        return event.getPropertyName() + ":\n\t" + event.getSource() + ":\n\t" + event.getOldValue() + ":\n\t" + event.getNewValue();
    }

    public static Point convertPointFromScreen(Point p, Component c) {

        do {
            int x;
            int y;
            if (c instanceof JComponent) {
                x = c.getX();
                y = c.getY();
            } else if (c instanceof Applet ||
                       c instanceof Window) {
                try {
                    Point pp = c.getLocationOnScreen();
                    x = pp.x;
                    y = pp.y;
                } catch (IllegalComponentStateException icse) {
                    x = c.getX();
                    y = c.getY();
                }
            } else {
                x = c.getX();
                y = c.getY();
            }

            p.x -= x;
            p.y -= y;

            if (c instanceof Window || c instanceof Applet) {
                return p;
            }
            c = c.getParent();
        } while (c != null);
        return p;
    }

    public static <T> T getParent(Component c, Class<? extends T> parentClass) {
        if (c == null || parentClass == null)
            return null;

        if (parentClass.isInstance(c))
            return (T) c;

        for (; c != null; c = c.getParent()) {
            if (parentClass.isInstance(c))
                return (T) c;
        }
        return null;
    }

    public static <T> T getParentClientProperty(Component c, Class<? extends T> propertyIdClass) {
        if (c == null || propertyIdClass == null)
            return null;

        if (c instanceof JComponent) {
            T t = (T) ((JComponent) c).getClientProperty(propertyIdClass);
            if (t != null)
                return t;
        }

        for (; c != null; c = c.getParent()) {
            if (c instanceof JComponent) {
                T t = (T) ((JComponent) c).getClientProperty(propertyIdClass);
                if (t != null)
                    return t;
            }
        }

        return null;
    }

    public static Component findAndRequestFocus(Component component) {
        Container container;
        if (component instanceof JDialog) {
            container = ((JDialog) component).getContentPane();
        } else if (component instanceof Container)
            container = (Container) component;
        else
            return null;

        Component focusRequester = findFocusable(container);
        if (focusRequester == null) {
            focusRequester = container;
        }
        requestFocus(focusRequester);
        return focusRequester;
    }

    public static Component getComponentWhoseParentIs(Component c, Component p) {
        if (c == null || p == null)
            return null;

        while (c != null) {
            if (c.getParent() == p)
                return c;
            c = c.getParent();
        }
        return null;
    }

    public static void setWindowTitle(Component component, String title) {
        Window window = SwingUtilities.windowForComponent(component);
        if (window instanceof Dialog) {
            ((Dialog) window).setTitle(title);
        } else if (window instanceof Frame) {
            ((Frame) window).setTitle(title);
        } else
            throw new IllegalArgumentException("Cannot set title for that component");
    }

    public static Component getWindowAncestor(Component c) {
        for (Container p = c.getParent(); p != null; p = p.getParent()) {
            if (p instanceof Window) {
                return p;
            } else if (p instanceof Applet) {
                return p;
            }
        }
        return null;
    }

}

/*
 * Created on Dec 9, 2003
 */
package samples.preview_new_graphdraw.event;


/**
 * @author danyelf
 */
public interface ClickListener {

	public void edgeClicked(ClickEvent ece);
	public void vertexClicked(ClickEvent vce);

}

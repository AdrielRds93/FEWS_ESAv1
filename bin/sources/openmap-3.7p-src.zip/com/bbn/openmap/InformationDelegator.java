/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/InformationDelegator.java,v $
 * $Revision: 1.20 $
 * $Date: 2000/05/08 14:21:56 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap;

import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import java.util.Hashtable;
import java.util.Enumeration;
import java.net.URL;

import javax.swing.*;
import javax.swing.event.*;
import javax.accessibility.*;

// import sunw.hotjava.bean.HotJavaBrowserBean;
import com.bbn.openmap.event.*;
import com.bbn.openmap.util.WebBrowser;

/**
 * The InformationDelegator manages the display of information
 * requested by Layers and other map components.  It can bring up a
 * web browser to display web pages and files, and pop up a message
 * window to provide status information to the user.  It also has a
 * visible status window that contains a layer status indicator, and
 * an information line that can display short messages.
 *
 * InformationDelegators are added to layers, and the layer fires
 * events through the InfoDisplayListener interface.  The
 * InformationDelegator has a method called listenToLayers() that lets
 * you give it an array of layers, and it adds itself as a
 * InfoDisplayListener to those layers.
 */
public class InformationDelegator extends JToolBar
    implements InfoDisplayListener, LayerStatusListener, MouseMotionListener,
    PropertyChangeListener
{

    protected JLabel infoLineHolder;
    protected WebBrowser browser;
    protected JOptionPane messageWindow;
    protected JPanel statusBar;

    protected JProgressBar progressBar;
    protected int numlayers = 0;
    protected boolean showLatLon = true;
    protected MapBean map;
    protected Layer[] layers;
    protected Hashtable statusLights = new Hashtable();

    protected final static transient URL greyURL = 
        InformationDelegator.class.getResource("grey.gif");
    public final static transient ImageIcon greyIcon =
	new ImageIcon(greyURL, "unknown");

    protected final static transient URL redURL = 
        InformationDelegator.class.getResource("red.gif");
    public final static transient ImageIcon redIcon =
	new ImageIcon(redURL, "working");

    protected final static transient URL greenURL = 
	InformationDelegator.class.getResource("green.gif");
    public final static transient ImageIcon greenIcon =
	new ImageIcon(greenURL, "stable");

    private String fudgeString = "";
    /** Used to remember what the MouseModeCursor is, which is the
     * base cursor setting for the MapBean.  The gesture modes set
     * this cursor, and it gets used when the currentMapBeanCursor is
     * null.
     * */
    protected Cursor fallbackMapBeanCursor = Cursor.getDefaultCursor();
    /** Used to remember any cursor that may bave been requested by a
     *  layer. This is usually null, unless a layer has requested a
     *  cursor.  The MapBean gesture modes set the
     *  fallbackMapBeanCursor instead.
     * */
    protected Cursor currentMapBeanCursor = null;
    protected boolean waitingForLayers = false;
    protected boolean showWaitCursor = false;

    public InformationDelegator() {
	super();
 	setLayout(new BoxLayout(this,BoxLayout.X_AXIS));
	setAlignmentX(LEFT_ALIGNMENT);
	setAlignmentY(TOP_ALIGNMENT);

	infoLineHolder = new JLabel(fudgeString);
	add(infoLineHolder);

	statusBar = new JPanel(new FlowLayout(FlowLayout.RIGHT));

 	setStatusBar();
	add(statusBar);

	initBrowser();
	initMessageWindow();
    }

    public void setMap(MapBean map) {
	this.map = map;
	map.addMouseMotionListener(this);
	map.addPropertyChangeListener(this);

	fallbackMapBeanCursor = map.getCursor();
   }

    public void initMessageWindow(){
	messageWindow = new JOptionPane();
    }

    public void initBrowser(){

	browser = new WebBrowser();
	browser.setInfoDelegator(this);
    }

    public void setInfoLineHolder(JLabel ilh){
	infoLineHolder = ilh;
    }

    public JLabel getInfoLineHolder(){
	return infoLineHolder;
    }

    /**
     *  Listen for changes to the active mouse mode and for any
     *  changes to the list of available mouse modes.  If the active
     *  mouse mode is "gestures", then the lat lon updates to the
     *  status line are deactivated.
     *
     *  Also, listen for the layer changes within the MapBean, to
     *  display the status lights for each layer.
     */
    public void propertyChange(PropertyChangeEvent evt) {

	if (evt.getPropertyName() == MouseDelegator.ActiveModeProperty) {
	    String mmID = ((MapMouseMode)evt.getNewValue()).getID();
	    if (mmID.equalsIgnoreCase("gestures")) {
		showLatLon = false;
		setLabel(fudgeString);
	    }
	    else showLatLon = true;
	    setResetCursor(((MapMouseMode)evt.getNewValue()).getModeCursor());
	}
	else if (evt.getPropertyName() == MapBean.LayersProperty){
	    listenToLayers((Layer[])evt.getNewValue());
	}
	else if (evt.getPropertyName() == MapBean.CursorProperty){
	    fallbackMapBeanCursor = ((Cursor)evt.getNewValue());
	}
    }

    /**
     * Set the information line label.
     * @param str String
     */
    public void setLabel(String str) {
	infoLineHolder.setText(str);

	// HACK This wasn't necessary in JDK1.1.5 and Swing1.0.1, but is now.
	// Without the following two lines, the infoline doesn't show up at all
	infoLineHolder.invalidate();
	this.validate();
    }

    public void setProgressBar(JProgressBar progressBar){
	this.progressBar = progressBar;
	if (numlayers >= 0)
	    progressBar.setMaximum(numlayers);
    }

    public JProgressBar getProgressBar() {
	return progressBar;
    }

    /**
     * Method to add the information delegator as a Information
     * Display Event listener to a list of layers.  Should not be
     * called directly, because it is called as a result of the
     * property change (layers) of the MapBean.
     */
    protected void listenToLayers(Layer[] newLayers){
	int i;

	if (layers != null){
	    for (i = 0; i < layers.length; i++){
		layers[i].removeInfoDisplayListener(this);
		layers[i].removeLayerStatusListener(this);
	    }
	}

	if (newLayers != null){
	    for (i = 0; i < newLayers.length; i++) {
		newLayers[i].addInfoDisplayListener(this);
		newLayers[i].addLayerStatusListener(this);
		getStatusLightForLayer(newLayers[i]);
	    }
	    layers = newLayers;
	    setStatusBar();
	}
    }

    /**
     * Convenience function to add the information delegator as a
     * Information Display Event listener to a layer.  If the MapBean
     * has been given to the InformationDelegator, though, you don't
     * need to call this, because the Informationelegator adds itself
     * as a PropertyChangeListener to the MapBean and will add the
     * layers automatically.
     */
    public void addLayer(Layer l) {
	if (l != null) {
	    l.addInfoDisplayListener(this);
	    l.addLayerStatusListener(this);
	    getStatusLightForLayer(l);
	    setStatusBar();
	}
    }

    /**
     * This method is really a get and set.  The JLabel status gif is
     * returned out of the HashTable for the layer.  If the layer
     * isn't in the HashTable, the new light is created, and a tooltip
     * for it set.
     *
     * @param layer the layer for the needed light.
     * @return JLabel representing the status of the layer.
     */
    protected JLabel getStatusLightForLayer(Layer layer){
	JLabel newLight = (JLabel) statusLights.get(layer);
	if(newLight == null){
	    newLight = new JLabel(greyIcon, SwingConstants.LEFT);
	    statusLights.put(layer, newLight);
	    newLight.setToolTipText(layer.getName());
	}
	return newLight;
    }

    /**
     * The method that updates the InformationDelegator display
     * window with the correct layer representation.
     */
    protected void setStatusBar(){
	statusBar.removeAll();
	if (layers != null){
	    for (int i=0; i < layers.length; i++){
		JLabel statusgif = getStatusLightForLayer(layers[i]);
		statusBar.add(statusgif);
	    }
	}
	statusBar.invalidate();
	statusBar.validate();
    }	

    /**
     * Set the light in the window to be a certain color, depending
     * on the working status.  If the layer light isn't stored, the
     * whole thing is blown off.  If the icon is red, then the watch
     * cursor is requested, if allowed by showWaitCursor.
     *
     * @param layer the layer to update.
     * @param icon the icon light representing the status.
     */
    protected void setLayerStatus(Layer layer, Icon icon){
	JLabel statusgif = (JLabel) statusLights.get(layer);
	if (statusgif != null){
	    statusgif.setIcon(icon);

	    if (this.map != null){
		if (icon == redIcon && showWaitCursor){
		    this.map.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
		    waitingForLayers = true;
		}
		else if (icon == greenIcon){
		    Enumeration lights = statusLights.elements();
		    waitingForLayers = false;
		    while (lights.hasMoreElements()){
			JLabel light = (JLabel)lights.nextElement();
			if (light.getIcon() == redIcon)
			    waitingForLayers = true;
		    }
		    if (!waitingForLayers){
			if(currentMapBeanCursor != null){
			    this.map.setCursor(currentMapBeanCursor);
			}			    
			else {
			    resetCursor();
			}			    
		    }
		}
	    }
	}
    }

    public void setBrowser(WebBrowser wb){
	browser = wb;
	browser.setInfoDelegator(this);
    }

    public WebBrowser getBrowser(){
	return browser;
    }
    
    public void checkBrowser(){
	if (browser != null) browser.exitValue();
    }

    public void displayURL(String url){
	if (browser != null)
	    browser.launch(url);
	else {
	    initBrowser();
	    browser.launch(url);
	}	    
    }
    
    public void displayBrowserContent(String content){
	if (browser != null)
	    browser.writeAndLaunch(content);
	else {
	    initBrowser();
	    browser.launch(content);
	}	    
    }
    
    public void displayInfoLine(String infoLine){
	if (infoLineHolder != null)
	    setLabel(infoLine);
    }

    public void displayMessage(String title, String message){
	messageWindow.showMessageDialog(null, message, title,
					JOptionPane.INFORMATION_MESSAGE);
    }


    ///////////////////////////////////////////
    //  InfoDisplayListener interface

    /**
     * Handle layer requests to have a URL displayed in a Browser.
     *
     * @param event InfoDisplayEvent
     */
    public void requestURL (InfoDisplayEvent event){
	displayURL(event.getInformation());
    }

    /**
     * Handle layer requests to have a message displayed in a dialog
     * window.
     *
     * @param event InfoDisplayEvent
     */
    public void requestMessage (InfoDisplayEvent event){	    
	Layer l = event.getLayer();
	String layername = (l == null) ? null : l.getName();
	displayMessage("Message from " + 
		       layername + " layer:",
		       event.getInformation());
    }
    
    /**
     * Handle layer requests to have an information line displayed
     * in an application status window.
     *
     * @param event InfoDisplayEvent
     */
    public void requestInfoLine (InfoDisplayEvent event){
	displayInfoLine(event.getInformation());
    }

    /**
     * Handle layer requests that plain text or html text be
     * displayed in a browser.
     *
     * @param event InfoDisplayEvent
     */
    public void requestBrowserContent (InfoDisplayEvent event){
	displayBrowserContent(event.getInformation());
    }

    /**
     * Change the cursor for the MapBean.  If the MapBean hasn't been
     * set, then nothing will happen on the screen. If a null value is
     * passed in, the cursor is reset to the MouseMode value.  If the
     * InformationDelegator is alowed to show the wait cursor, and the
     * layers are busy, the wait cursor will take precidence.  The
     * requested cursor from a layer will be set if the layers finish.
     *
     * @param cursor java.awt.Cursor to change the cursor to.
     */
    public void requestCursor(java.awt.Cursor cursor){
	// This is interpreted as a release from a requester
	if (cursor == null){
	    // If we're not supposed to be showing the wait cursor...
	    if (showWaitCursor && !waitingForLayers)
		resetCursor();
	    // Set this to null, so that when we're done waiting for
	    // the layers, we'll just reset.
	    currentMapBeanCursor = null;
	}
	else if (this.map != null){
	    Cursor newCursor;
	    // If we're supposed to be showing the watch, do it, but
	    // save the request for when the layers are done.
	    if (showWaitCursor && waitingForLayers){
		newCursor = Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR);
		currentMapBeanCursor = cursor;
	    }
	    else newCursor = cursor;

	    map.setCursor(newCursor);
	}
    }

    /**
     * Set the cursor to use when the waiting is done, if a layer
     * hasn't asked for one to be displayed.  For the MouseMode
     * changes, this is automatically called.
     */
    public void setResetCursor(java.awt.Cursor cursor){
	fallbackMapBeanCursor = cursor;
    }

    /** 
     * Sets the cursor over the mapbean to the assigned default, or
     * whatever has been set by the MouseMode.
     */
    public void resetCursor(){
	if (this.map != null)
	    map.setCursor(fallbackMapBeanCursor);
    }

    /**
     * If the value passed in is true, the cursor over the MapBean
     * will be the waiting cursor layers are off working.  The status
     * lights will work, too, no matter what the value is.  If false,
     * the cursor won't change if the layers are working.
     */
    public void setShowWaitCursor(boolean value){
	showWaitCursor = value;
    }

    /**
     * Returns whether the wait cursor will be shown if the layers
     * are working.
     */
    public boolean isShowWaitCursor(){
	return showWaitCursor;
    }

    ///////////////////////////////////////////
    //  LayerStatusListener interface

    /**
     * Update the Layer status.
     * @param evt LayerStatusEvent 
     */
    public void updateLayerStatus(LayerStatusEvent evt) {
	if (statusBar == null)
	    return;

	switch (evt.getStatus()) {
	    // these need to be coordinated correctly by the Layer, otherwise
	    // we'll get phantom status ticks or maybe an ArrayOutOfBounds
	    // negative...
	    case LayerStatusEvent.START_WORKING:
		setLayerStatus((Layer) evt.getSource(), redIcon);
		break;
	    case LayerStatusEvent.STATUS_UPDATE:
		break;
	    case LayerStatusEvent.FINISH_WORKING:
		setLayerStatus((Layer) evt.getSource(), greenIcon);
		break;
	    default:
		System.err.println(
			"InformationDelegator.updateLayerStatus(): " +
			"unknown status: " + evt.getStatus());
		break;
	}
    }

    /**
     * MouseMotionListener interface.
     * @param e MouseEvent
     */
    public void mouseDragged(MouseEvent e) {}


    /**
     * MouseMotionListener interface.
     * @param e MouseEvent
     */
    public void mouseMoved(MouseEvent e) {
	if (showLatLon){
	    int x = e.getX(), y = e.getY();
	    LatLonPoint temp = map.getProjection().inverse(x,y);
	    setLabel("Lat,Lon ("+temp.getLatitude()+","+temp.getLongitude()+
		     ") - x,y ("+x+","+y+")");
	}
    }
}

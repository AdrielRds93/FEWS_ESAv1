/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/MouseDelegator.java,v $
 * $Revision: 1.30 $
 * $Date: 2000/07/27 15:03:09 $
 * $Author: dietrick $
 * 
 * **********************************************************************
 */

package com.bbn.openmap;

import java.awt.*;
import java.awt.event.*;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.beans.PropertyChangeEvent;
import java.util.Vector;

import com.bbn.openmap.util.Debug;
import com.bbn.openmap.event.*;

/**
 * The MouseDelegator manages the MapMouseModes that handle
 * MouseEvents on the map.
 * @see MapMouseMode
 * @see AbstractMouseMode
 * @see NavMouseMode
 * @see SelectMouseMode
 */
public class MouseDelegator 
    implements PropertyChangeListener, java.io.Serializable {
    
    public final static transient String ActiveModeProperty =
	"NewActiveMouseMode";
    public final static transient String MouseModesProperty = 
	"NewListOfMouseModes";

    /**
     * The active MapMouseMode.
     */
    protected transient MapMouseMode activeMouseMode = null;

    /**
     * The registered MapMouseModes.
     */
    protected transient Vector mouseModes = new Vector(0);

    /**
     * The MapBean.
     */
    protected transient MapBean map;

    /**
     * Handles property listeners and events.
     */
    protected transient PropertyChangeSupport propDelegate=null;


    /**
     * Construct a MouseDelegator with an associated MapBean.
     * @param map MapBean
     */
    public MouseDelegator(MapBean map) {
	propDelegate = new PropertyChangeSupport(this);
	setMap(map);
    }


    /**
     * Construct a MouseDelegator without an associated MapBean.
     * You will need to set the MapBean via <code>setMap()</code>.
     * @see #setMap
     */
    public MouseDelegator() {
	this(null);
    }


    /**
     * Set the associated MapBean.
     * @param mapbean MapBean
     */
    public void setMap(MapBean mapbean) {
	map = mapbean;
	if (map != null) {
	    map.addPropertyChangeListener(this);
	}
    }

    //----------------------------------------------------------------------
    //
    // Mouse Event handling support
    //
    //----------------------------------------------------------------------

    /**
     * Returns the ID string for the active Mouse Mode.
     * @return String ID of the active mouse mode.
     */
    public String getActiveMouseModeID(){
	if (activeMouseMode != null)
	    return activeMouseMode.getID();
	else
	    return null;
    }

    /**
     * Sets the mouse mode to the mode with the same ID string.  If
     * none of the MouseEventDelagates have a matching ID string, the
     * mode is not changed.<br>
     * The map mouse cursor is set to the recommended cursor 
     * retrieved from the active mouseMode.
     *
     * @param MouseModeID the string ID of the mode to set active.
     */
    public void setActiveMouseModeWithID(String MouseModeID){
	if (MouseModeID == null){
	    Debug.error("MouseDelegator:setActiveMouseModeWithID() - null value");
	    return;
	}

	MapMouseMode oldActive = activeMouseMode;
	setInactive(activeMouseMode);

	for (int i = 0; i < mouseModes.size(); i++){
	    MapMouseMode med = (MapMouseMode)mouseModes.elementAt(i);
	    if (MouseModeID.equals(med.getID())){
		activeMouseMode = med;
		setActive(med);
 		if (Debug.debugging("mousemode")){
		    Debug.output("MouseDelegator.setActiveMouseModeWithID() setting new mode to mode " + i + " " + med.getID());
		}
		break;
	    }
	}

	if (propDelegate != null)
	    propDelegate.firePropertyChange(ActiveModeProperty,
					    oldActive, activeMouseMode);

	if ((map != null) && (activeMouseMode != null)) {
	    //Debug.output(activeMouseMode.getModeCursor());
	    map.setCursor(activeMouseMode.getModeCursor());
	}

    }

    /**
     * Returns the mouse mode delegate that is active at the moment.
     * @return MapMouseMode the active mouse mode
     */
    public MapMouseMode getActiveMouseMode(){
 	return activeMouseMode;
   }

    /**
     * Sets the active mouse mode.  If the MapMouseMode is not a
     * member of the current mouse modes, it is added to the list.<br>
     * The map mouse cursor is set to the recommended cursor retrieved
     * from the active mouseMode.
     * @param aMed a MapMouseMode to make active.
     */
    public void setActiveMouseMode(MapMouseMode aMed){
	if (aMed == null){
	    Debug.error("MouseDelegator:setActiveMouseMode() - null value");
	    return;
	}
	MapMouseMode oldActive = activeMouseMode;
	setInactive(activeMouseMode);
	boolean isAlreadyAMode = false;

	for (int i = 0; i < mouseModes.size(); i++){
	    MapMouseMode med = (MapMouseMode)mouseModes.elementAt(i);
	    // Need to go through the modes, turn off the other active
	    // mode, and turn on this one.
	    if (aMed.getID().equals(med.getID())){
		isAlreadyAMode = true;
	    }
	}

	if (!isAlreadyAMode){
	    addMouseMode(aMed);
	}

	activeMouseMode = aMed;
	setActive(aMed);

	if (propDelegate != null)
	    propDelegate.firePropertyChange(ActiveModeProperty,
					    oldActive, activeMouseMode);
	if (map != null){
	    //Debug.output(activeMouseMode.getModeCursor());
	    map.setCursor(activeMouseMode.getModeCursor());
	}
    }

    /**
     * Returns an array of MapMouseModes that are available to the
     * MapBean.
     * @return an array of MapMouseModes.
     */
    public MapMouseMode[] getMouseModes(){
	int nMouseModes = mouseModes.size();
	if (nMouseModes == 0)
	    return (new MapMouseMode[0]);
	MapMouseMode[] result = new MapMouseMode[nMouseModes];
	for (int i=0; i<nMouseModes; i++) {
	    result[i] = (MapMouseMode)mouseModes.elementAt(i);
	}
	return result;
    }

    /**
     * Used to set the mouseModes available to the MapBean.  The
     * Delegator drops all references to any mouseModes it knew about
     * previously.  It also sets the index of the array to be the
     * active mouse mode.<br>
     * The map mouse cursor is set to the recommended cursor retrieved
     * from the active mouseMode.
     * @param meds an array of MapMouseModes
     * @param activeIndex which mouse mode to make active
     */
    public void setMouseModes(MapMouseMode[] meds, int activeIndex){
	mouseModes.removeAllElements();
	MapMouseMode oldActive = activeMouseMode;
	setInactive(activeMouseMode);
	for (int i = 0; i < meds.length; i++){
	    mouseModes.addElement(meds[i]);

	    if (i == activeIndex){ // activate the right mode
		activeMouseMode = meds[i];
		setActive(meds[i]);
	    }

	    if (propDelegate != null)
		propDelegate.firePropertyChange(MouseModesProperty,
					    null, mouseModes);
	}

	if (propDelegate != null)
	    propDelegate.firePropertyChange(ActiveModeProperty,
					    oldActive, activeMouseMode);

	if (map != null){
	    //Debug.output(activeMouseMode.getModeCursor());
	    map.setCursor(activeMouseMode.getModeCursor());
	}
    }


    /**
     * Used to set the mouseModes available to the MapBean.  The
     * MapBean drops all references to any mouseModes it knew about
     * previously. The meds[0] mode is made active, by default.
     * @param meds an array of MapMouseModes
     */
    public void setMouseModes(MapMouseMode[] meds){
	setMouseModes(meds, 0);
    }

    /**
     * Adds a MapMouseMode to the MouseMode list.  Does not make it
     * the active mode.
     * @param med the MouseEvent Delegate to add.
     */
    public void addMouseMode(MapMouseMode med){

	mouseModes.addElement(med);
	//  All of the MouseModes will think they are active, but
	//  the Delegator will only pass events to the one it
	//  thinks is...

	if (mouseModes.size() == 1){
	    activeMouseMode = med;
	    setActive(med);
	    if (map != null){
		//Debug.output(activeMouseMode.getModeCursor());
		map.setCursor(activeMouseMode.getModeCursor());
	    }
	}

	if (propDelegate != null)
	    propDelegate.firePropertyChange(MouseModesProperty,
					    null, mouseModes);

    }

    /**
     * Removes a particular MapMouseMode from the MouseMode list.
     * @param med the MapMouseMode that should be removed.
     */
    public void removeMouseMode(MapMouseMode med){
	boolean needToAdjustActiveMode = false;
	if (med.equals(activeMouseMode)) {
	    needToAdjustActiveMode = true;
	    activeMouseMode = null;
	    setInactive(med);
	}

	for (int i = 0; i < mouseModes.size(); i++){
	    if (med.equals(mouseModes.elementAt(i))){
		med.removeAllMapMouseListeners();
		mouseModes.removeElementAt(i);
	    }
	    // Set the first mode to the active one, if deleting the
	    // active one.
	    else if (needToAdjustActiveMode){
		activeMouseMode = med;
		setActive(med);
		needToAdjustActiveMode = false;
	    }
	}

	if (propDelegate != null)
	    propDelegate.firePropertyChange(MouseModesProperty,
					    null, mouseModes);

    }

    /**
     * Removes a particular MapMouseMode from the MouseMode list, with
     * the ID given.
     * @param id the ID of the MapMouseMode that should be removed
     */
    public void removeMouseMode(String id){
	for (int i = 0; i < mouseModes.size(); i++){
	    MapMouseMode med = (MapMouseMode)mouseModes.elementAt(i);
	    if (id.equals(med.getID())) {
		removeMouseMode(med);
		break;
	    }
	}
    }

    /**
     * Sets the three default OpenMap mouse modes.
     * These modes are: NavMouseMode (Map Navigation), the
     * SelectMouseMode (MouseEvents go to Layers), and NullMouseMode
     * (MouseEvents are ignored).
     */
    public void setDefaultMouseModes(){
	MapMouseMode[] modes = new MapMouseMode[3];
	modes[0] = new NavMouseMode(true);
	modes[1] = new SelectMouseMode(true);
 	modes[2] = new NullMouseMode();
	
	setMouseModes(modes);
    }


    /**
     * PropertyChangeListenter Interface method.
     * @param evt PropertyChangeEvent
     */
    public void propertyChange(PropertyChangeEvent evt) {
	String property = evt.getPropertyName();
	if (property == MapBean.LayersProperty) {
	    Layer[] newLayers = (Layer[])evt.getNewValue();
	    for (int j = 0; j < mouseModes.size(); j++){
		// Clear out the old listeners first
		MapMouseMode med = 
		    (MapMouseMode) mouseModes.elementAt(j);
		med.removeAllMapMouseListeners();
		
		for (int i=0; i < newLayers.length; i++) {
		    // Add the listeners from each layer to the mouse mode.
		    MapMouseListener tempmml = newLayers[i].getMapMouseListener();
		    if (tempmml == null) { continue; }
		    String[] services = tempmml.getMouseModeServiceList();
		    if (services != null)
			for (int k = 0; k < services.length; k++){
			    if (med.getID().equals(services[k])){
				med.addMapMouseListener(tempmml);
				if (Debug.debugging("mousemode")) {
				    Debug.output(
					    "MouseDelegator.propertyChange():" +
					    " layer = " + newLayers[i].getName() +
					    " service = " + med.getID()
					    );
				}
				break;
			    }
			}
		}
	    }
	}

    }

    /**
     * Set the active MapMouseMode.
     * This sets the MapMouseMode of the associated MapBean.
     * @param mm MapMouseMode
     */
    public void setActive(MapMouseMode mm){
	if (Debug.debugging("mousemode")) {
	    Debug.output("MouseDelegator.setActive(): " + mm.getID());
 	}
	if (map != null){
	    map.addMouseListener(mm);
	    map.addMouseMotionListener(mm);
	    if (mm instanceof ProjectionListener) {
		map.addProjectionListener((ProjectionListener)mm);
	    }
	}
    }


    /**
     * Deactivate the MapMouseMode.
     * @param mm MapMouseMode.
     */
    public void setInactive(MapMouseMode mm){
	if (map != null){
	    map.removeMouseListener(mm);
	    map.removeMouseMotionListener(mm);
	    if (mm instanceof ProjectionListener) 
		map.removeProjectionListener((ProjectionListener)mm);
	}
    }

    //----------------------------------------------------------------------
    //
    // Outgoing Event support
    //
    //----------------------------------------------------------------------

    public void addPropertyChangeListener(PropertyChangeListener listener) {
	propDelegate.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
	propDelegate.removePropertyChangeListener(listener);
    }
}

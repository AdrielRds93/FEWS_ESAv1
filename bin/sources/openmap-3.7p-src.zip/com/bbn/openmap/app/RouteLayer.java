/* **********************************************************************
 * 
 *  BBNT Solutions LLC, A part of GTE
 *  10 Moulton St.
 *  Cambridge, MA 02138
 *  (617) 873-2000
 * 
 *  Copyright (C) 1998, 2000
 *  This software is subject to copyright protection under the laws of 
 *  the United States and other countries.
 * 
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/app/RouteLayer.java,v $
 * $Revision: 1.5 $
 * $Date: 2000/05/08 14:21:59 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.app;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com.bbn.openmap.Layer;
import com.bbn.openmap.event.ProjectionEvent;
import com.bbn.openmap.proj.Projection;

public class RouteLayer extends Layer
{

    Projection projection;
    double[] routes = {
	40d, -70d, 0d, 0d,
	40d, 70d, 0d, 0d,
    };
    int[] points;

    public RouteLayer () {
	setName("Dummy routes");
	if ((routes.length % 4) != 0) {
	    throw new IllegalArgumentException(
	            "routes must be a multiple of 4"
		    );
	}
	points = new int[routes.length];
    }

    public void paint (Graphics g) {
	if (projection == null) return;
	if (points == null) return;
	for (int i=0; i<routes.length; i+=4) {
	    g.drawLine(points[i], points[i+1], points[i+2], points[i+3]);
	}
    }

    public void projectionChanged (ProjectionEvent e) {
	projection = e.getProjection();
	Point pt = new Point();
	for (int i=0; i<routes.length; i+=2) {
	    projection.forward(routes[i], routes[i+1], pt);
	    points[i] = pt.x;
	    points[i+1] = pt.y;
	}
	repaint();
    }
}

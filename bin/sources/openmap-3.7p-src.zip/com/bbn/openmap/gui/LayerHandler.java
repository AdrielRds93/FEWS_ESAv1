/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/gui/LayerHandler.java,v $
 * $Revision: 1.12 $
 * $Date: 2000/08/21 23:08:04 $
 * $Author: dietrick $
 * 
 * **********************************************************************
 */
package com.bbn.openmap.gui;

import com.bbn.openmap.*;
import com.bbn.openmap.util.Debug;
import com.bbn.openmap.event.*;

import java.awt.event.*;
import java.util.*;
import javax.swing.*;

public class LayerHandler {

    /** Property for space separated layers. If a prefix is needed,
     *  just use the methods that let you use the prefix - don't worry
     *  about the period, it will be added automatically.*/
    public static final String layersProperty = "layers";
    /** Property for space separated layers to be displayed at
     *  startup. If a prefix is needed, just use the methods that let
     *  you use the prefix - don't worry about the period, it will be
     *  added automatically. */
    public static final String startUpLayersProperty = "startUpLayers";

    /** The Component that controls the layers - to turn them on/off,
     *  bring up their palettes, and adjust their order. */
    protected LayersPanel layersPanel;
    /** The ActionListener that will bring up the LayersPanel. */
    protected ActionListener layersPanelActionListener;
    /** Standard checkbox menu to turn layers on/off. */
    protected LayersMenu layersMenu;
    /** A button on the bottom of the menu to bring up the layersPanel. */
    protected JMenuItem edit;

    // One or the other of these are used, depending on if the
    // application is running in a applet or application.
    /** The application layers panel frame. */
    protected JFrame layersWindowFrame;
    /** The applet layers panel frame. */
    protected JInternalFrame layersWindow;
    /** The thing that's interested in the layer arraignment.
     *  Usually, the MapBean. */
    protected LayerListener listener;
    /** The list of all layers, even the ones not part of the map. */
    protected Layer[] allLayers;

    /** 
     * If you use this constructor, don't do ANYTHING to this class
     * until you call init().
     */
    public LayerHandler(){}

    /**
     * Start the LayerHandler, and have it create all the layers as
     * defined in a properties file.
     * @param props properties as defined in an openmap.properties file.
     */
    public LayerHandler(Properties props){
	init(null, props);
    }

    /**
     * Start the LayerHandler, and have it create all the layers as
     * defined in a properties file.
     * @param prefix the prefix for the layers and startUpLayers
     * properties, as if they are listed as prefix.layers, and
     * prefix.startUpLayers.
     * @param props properties as defined in an openmap.properties file.  
     */
    public LayerHandler(String prefix, Properties props){
	init(prefix, props);
    }

    /**
     * Start the LayerHandler with configured layers.
     */
    public LayerHandler(Layer[] layers){
	init(layers);
    }

    /**
     * Initialize the LayerHandler by having it construct it's layers
     * from a properties object.  The properties should be created
     * from an openmap.properties file.
     * @param prefix the prefix to use for the layers and startUpLayers properties.
     * @param props properties as defined in an openmap.properties file.
     */
    public void init(String prefix, Properties props){
	init(getLayers(prefix, props));
    }

    /**
     * Initialize the LayerHandler by having it construct it's layers
     * from a URL containing an openmap.properties file.
     * @param url a url for a properties file.
     */
    public void init(java.net.URL url){
	init(null, url);
    }

    /**
     * Initialize the LayerHandler by having it construct it's layers
     * from a URL containing an openmap.properties file.
     * @param prefix the prefix to use for the layers and startUpLayers properties.
     * @param url a url for a properties file.
     */
    public void init(String prefix, java.net.URL url){
	try {
	    java.io.InputStream in = url.openStream();
	    Properties props = new Properties();
	    props.load(in);
	    init(getLayers(prefix, props));
	} catch (java.net.MalformedURLException murle){
	    Debug.error("LayerHandler.init(URL): " + url + " is not a valid URL");
	} catch (java.io.IOException e) {
	    Debug.error("LayerHandler.init(URL): Caught an IOException");
	}
    }

    /**
     * Initialize from an array of layers. This will cause the
     * LayersMenu and LayersPanel, if they exist, to update themselves
     * with the current list of layers.
     *
     * @param layers the initial array of layers. 
     */
    public void init(Layer[] layers){
	setLayers(layers);
    }

    /** Get a Layers panel. */
    public LayersPanel getLayersPanel(){
	if (layersPanel == null){
	    layersPanel = new LayersPanel(this);
	}
	return layersPanel;
    }

    /**
     * Get a Layers menu, without a LayersPanel button on the bottom.
     * @return a LayersMenu
     */
    public LayersMenu getLayersMenu(){
	return getLayersMenu(null);
    }

    /** 
     * Get a Layers menu, with the option of adding a button on the
     * bottom to bring up a LayersPanel window.  The string supplied
     * as an argument is used as the title for the button.  If the
     * string is null, the button isn't added.
     * @param editLayersButtonTitle the title to use on the
     * LayersPanel button.  Use null to not create the button.
     * @return a LayersMenu.
     */
    public LayersMenu getLayersMenu(String editLayersButtonTitle){

	if (layersMenu == null){
	    layersMenu = new LayersMenu(this);
	    if (editLayersButtonTitle != null){
		// initalize the Edit Layers... button.
		edit = new JMenuItem(editLayersButtonTitle);
		edit.setActionCommand("edit");
		edit.addActionListener(getLayersPanelActionListener());
		
		layersMenu.add(new JSeparator());
		layersMenu.add(edit);
	    }
	    // Final stage bootstrap.
	    if (Environment.getBoolean(Environment.UseInternalFrames)){
		JRootPane rootPane = ((JApplet)(Environment.getApplet())).getRootPane();
		final JLayeredPane desktop = rootPane.getLayeredPane();
		desktop.setOpaque(true);
		layersMenu.setDesktop(desktop);
	    }
	}
	return layersMenu;
    }

    /** 
     * Get the ActionListener that triggers the LayersPanel.  Useful
     * to have to provide an alternative way to bring up the
     * LayersPanel.  
     */
    public ActionListener getLayersPanelActionListener(){

	if (layersPanelActionListener == null){
	    // Try to group the applet-specific stuff in here...
	    if (Environment.getBoolean(Environment.UseInternalFrames)){

		JRootPane rootPane = ((JApplet)(Environment.getApplet())).getRootPane();
		final JLayeredPane desktop = rootPane.getLayeredPane();
		desktop.setOpaque(true);

		layersWindow = new JInternalFrame(
		    "Layers",
		    /*resizable*/ true,
		    /*closable*/ true,
		    /*maximizable*/ false,
		    /*iconifiable*/ true);
		layersWindow.setBounds(2, 2, 328, 300);
		layersWindow.setContentPane(getLayersPanel());
		layersWindow.setOpaque(true);
		try {
		    layersWindow.setClosed(true);//don't show until it's needed
		} catch (java.beans.PropertyVetoException e) {}
		//	desktop.add(layersWindow, JLayeredPane.PALETTE_LAYER);
		
		layersPanelActionListener = ( new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
			    try {
				if (layersWindow.isClosed()) {
				    layersWindow.setClosed(false);
				    // hmmm is this the best way to do this?
				    desktop.remove(layersWindow);
				    desktop.add(layersWindow, 
						JLayeredPane.PALETTE_LAYER);
				}
			    } catch (java.beans.PropertyVetoException e) {
				System.err.println(e);
			    }
			}
		    });
		
	    } else { // Working as an application...
		layersWindowFrame = new JFrame("Layers");
		layersWindowFrame.setBounds(2, 2, 328, 300);
		layersWindowFrame.setContentPane(getLayersPanel());
		layersWindowFrame.setVisible(false);//don't show until it's needed
		
		layersPanelActionListener = ( new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
			    layersWindowFrame.setVisible(true);
			    layersWindowFrame.setState(java.awt.Frame.NORMAL);
			}
		    });
	    }
	}

	return layersPanelActionListener;
    }

    /**
     * Parse the list of layers from the Environment containing the
     * layers that should be displayed upon map startup.
     * <p>
     * @param active a string containing a space delimited list of layer markers
     * @return Vector startup layers
     */ 
    public static Vector parseSpacedMarkers(String active) {
	if (active == null){
	    return new Vector(0);
	}

	// First, get rid of the quotation marks;
	active = active.replace('\"', '\0');
	// Next, tokenize the space delimited string
	StringTokenizer tokens = new StringTokenizer(active, " ");
	Vector activelayers = new Vector(tokens.countTokens());
	while (tokens.hasMoreTokens()) {
	    String name = tokens.nextToken().trim();
	    activelayers.addElement(name);
	}
	return activelayers;
    }

    /**
     *  This is the method that gets used to parse the layer
     *  properties from an openmap.properties file, where the layer
     *  marker names are listed under a openmap.layers property, and
     *  each layer is then represented by a marker.class property, and
     *  a maker.prettyName property.
     *  @param p properties containing layers property, the
     *  startupLayers property listing the layers to make visible
     *  immediately, and the layer properties as well. 
     */
    protected Layer[] getLayers(Properties p) {
	return getLayers(null, p);
    }

    /**
     *  This is the method that gets used to parse the layer
     *  properties from an openmap.properties file, where the layer
     *  marker names are listed under a openmap.layers property, and
     *  each layer is then represented by a marker.class property, and
     *  a maker.prettyName property.
     *  @param prefix the prefix to use to use for the layer list
     *  (layers) property and the startUpLayers property.  If it is
     *  not null, this will cause the method to looke for
     *  prefix.layers and prefix.startUpLayers.
     *  @param p the properties to build the layers from.
     */
    protected Layer[] getLayers(String prefix, Properties p) {
	Debug.message("layerhandler", 
		      "LayerHandler: Getting new layers from properties...");

	// First, load the layer marker names into a vector for later use
 	Vector startuplayers;
	Vector layersValue;
	if (prefix == null){
	    startuplayers = parseSpacedMarkers(p.getProperty(startUpLayersProperty));
	    layersValue = parseSpacedMarkers(p.getProperty(layersProperty));
	} else {
	    startuplayers = parseSpacedMarkers(p.getProperty(prefix + "." + 
							     startUpLayersProperty));
	    layersValue = parseSpacedMarkers(p.getProperty(prefix + "." + 
							   layersProperty));
	}

	if (startuplayers.size() == 0){
	    Debug.output("LayerHandler: No layers on startup list");	    
	}

	if (layersValue.size() == 0) {
	    Debug.error("LayerHandler.getLayers(): No property \"" + layersProperty
			+ "\" found in properties.");
	    return new Layer[0];
	} else {
	    if (Debug.debugging("layerhandler")){
		Debug.output("LayerHandler: Layer markers found = " + layersValue);
	    }
	}

	return getLayers(layersValue, startuplayers, p);
    }

    public static Layer[] getLayers(Vector layerList, 
				    Vector visibleLayerList, 
				    Properties p){

	int nLayerNames = layerList.size();
	Vector layers = new Vector(nLayerNames);
	for (int i = 0; i < nLayerNames; i++) {
	    String layerName = (String)layerList.elementAt(i);
	    String classProperty = layerName + ".class";
	    String className = p.getProperty(classProperty);
	    if (className == null) {
		Debug.error("LayerHandler.getLayers(): Failed to locate property \""
			    + classProperty + "\"\n  Skipping layer \"" + 
			    layerName + "\"");
		continue;
	    }

	    Layer l = getLayerClass(className);
	    if (l != null){
		// Figure out of the layer is on the startup list,
		// and make it visible if it is...
		l.setVisible(visibleLayerList.contains(layerName));
		
		l.setProperties(layerName, p);
		layers.addElement(l);
		
		if (Debug.debugging("layerhandler")){
		    Debug.output("LayerHandler: layer " +
				 l.getName() +
				 (l.isVisible()?" is visible":" is not visible"));
		}
	    } else {
		Debug.error("Skipped \"" + layerName + "\"");
	    }
	}

	int nLayers = layers.size();
	if (nLayers == 0) {
	    return new Layer[0];
	} else {
	    Layer[] value = new Layer[nLayers];
	    layers.copyInto(value);
	    return value;
	}
    }

    public static Layer getLayerClass(String layerClassName){
	try {
	    if (Debug.debugging("layerhandler")) {
		Debug.output("LayerHandler.getLayerClass(): instantiating layer \""+
			     layerClassName+"\"");
	    }
	    
	    // Doesn't work for applet!
	    //		Object obj = java.beans.Beans.instantiate(null, layerClassName);
	    Object obj = Class.forName(layerClassName).newInstance();// Works for applet!
	    if (obj instanceof Layer) {
		return (Layer)obj;
	    }
	    
	    if (false) throw new java.io.IOException();//fool javac compiler
	} catch (java.lang.ClassNotFoundException e) {
	    Debug.error("LayerHandler.getLayerClass: Layer class not found: \""
			+ layerClassName + "\", Skipping layer...");
	} catch (java.io.IOException e) {
	    Debug.error("LayerHandler.getLayerClass: IO Exception instantiating class \""
			+ layerClassName + "\", Skipping layer...");
	} catch (Exception e) {
	    Debug.error("LayerHandler.getLayerClass: Exception instantiating class \""
			+ layerClassName + "\": " + e);
	}
	return null;
    }
    
    /** 
     * Add a LayerListener to the LayerHandler, in order to be told
     * about layers that need to be added to the map.
     * @param ll LayerListener, usually the MapBean.
     */
    public void addLayerListener(LayerListener ll){
	listener = ll;
	listener.setLayers(new LayerEvent(this, LayerEvent.ADD, getMapLayers()));
    }

    /**  
     * Tell the layers menu and layers panel to get the current name
     * from their layers.  
     */
    public void updateLayerLabels(){
	setLayers(allLayers);
    }

    /** 
     * Set the layers on the map, layers menu and layers panel.  Adds
     * the edit layers button ob the bottom to the layers menu, and
     * the new layers are turned on if their visibility is set to true.
     *
     * @param layers Layer array.  
     */
    public void setLayers(Layer[] layers){
	allLayers = layers;

	if (Debug.debugging("layerhandler")){
	    Debug.output("LayerHandler.setLayers: " + layers);
	}
	if (layersPanel != null){
	    layersPanel.setLayers(allLayers);
	}
	if (layersMenu != null){
	    layersMenu.setLayers(allLayers);
	    if (edit != null){
		layersMenu.add(new JSeparator());
		layersMenu.add(edit);
	    }
	}
	if (listener != null){
	    listener.setLayers(new LayerEvent(this, LayerEvent.REPLACE,
					      getMapLayers()));
	}
    }

    /** 
     * Set the layers on the map, layers menu and layers panel.  Adds
     * the edit layers button to the bottom to the layers menu.
     *
     * @param layers Layer array.
     * @param newLayersTurnedOn turn the new layers on.
     * @deprecated Layers are turned on if their visibility is set true.
     */
    public void setLayers(Layer[] layers, boolean newLayersTurnedOn){
	setLayers(layers);
    }

    /**
     * Get the current layer array, of potential layers that CAN be
     * added to the map, not the ones that are active on the map.  
     */
    public Layer[] getLayers(){
	return allLayers;
    }

    /** 
     * Get the layers that are currently part of the Map - the ones
     * that are visible.
     * @return an array of visible Layers. 
     */
    public Layer[] getMapLayers() {
	Debug.message("layerhandler", "LayerHandler.getMapLayers()");

	int numEnabled = 0;
	int cakeIndex = 0;
	Layer[] cake = null;
	Layer[] layers = getLayers();

	// First loop finds out how many visible layers there are,
	// Second loop creates the layer cake of visible layers.
	for (int j = 0; j < 2; j++){
	    for (int i = 0; i < layers.length; i++){
		if (layers[i].isVisible()) {
		    if (j==0) {
			numEnabled++;
		    } else {
			cake[cakeIndex++] = layers[i];
		    }
		}
	    }
	    if (j == 0){
		cake = new Layer[numEnabled];
	    }
	}
	return cake;
    }

   /** 
     * Add a layer to a certain position in the layer array.  If the
     * position is 0 or less, the layer is put up front (on top).  If
     * the position is greater thatn the length of the current array,
     * the layer is put at the end, (on the bottom).  The layer is
     * placed on the map if it's visiblity is true.
     *
     * @param layer the layer to add.
     * @param position the array index to place it.  
     */
    public void addLayer(Layer layer, int position){
	Layer[] newLayers = new Layer[allLayers.length +1];

	if (position >= allLayers.length){
	    // Put the new layer on the bottom
	    System.arraycopy(allLayers, 0, newLayers, 0, allLayers.length);
	    newLayers[allLayers.length] = layer;
	} else if (position <= 0){
	    // Put the new layer on top
	    System.arraycopy(allLayers, 0, newLayers, 1, allLayers.length);
	    newLayers[0] = layer;
	} else {
	    newLayers[position] = layer;
	    System.arraycopy(allLayers, 0, newLayers, 0, position);
	    System.arraycopy(allLayers, position, newLayers, position + 1,
			     allLayers.length - position);
	}

	setLayers(newLayers);
    }

    /** 
     * Add a layer to a certain position in the layer array.  If the
     * position is 0 or less, the layer is put up front (on top).  If
     * the position is greater thatn the length of the current array,
     * the layer is put at the end, (on the bottom).
     *
     * @param layer the layer to add.
     * @param position the array index to place it. 
     * @param addedLayerTurnedOn turn the layer on.
     * @deprecated the layer will be turned on if its visibility is true.
     */
    public void addLayer(Layer layer, int position, boolean addedLayerTurnedOn){
	layer.setVisible(addedLayerTurnedOn);
	addLayer(layer, position);
    }

    /**
     * Remove a layer from the list of potentials.
     *
     * @param layer to remove.
     */
    public void removeLayer(Layer layer){
	int index = -1;
	for (int i = 0; i < allLayers.length; i++){
	    if (layer == allLayers[i]){
		index = i;
		break;
	    }
	}
	// If the layer is actually there...
	if (index != -1){
	    removeLayer(allLayers, index);
	}
    }

    /**
     * Remove a layer from the list of potentials.
     *
     * @param index of layer in the layer array.  Top-most is first.  
     */
    public void removeLayer(int index){
	if (index >=0 && index < allLayers.length){
	    removeLayer(allLayers, index);
	}
    }

    /** 
     * The version that does the work.  The other two functions do
     * sanity checks. Calls setLayers().
     * 
     * @param currentLayers the current layers handled in the LayersMenu.
     * @param the validated index of the layer to remove.
     */
    protected void removeLayer(Layer[] currentLayers, int index){
	Layer[] rLayer = new Layer[1];
	rLayer[0] = currentLayers[index];
	rLayer[0].setVisible(false);
//    	layersMenu.layerDelegate.fireLayer(LayerEvent.REMOVE, rLayer);

	Layer[] newLayers = new Layer[currentLayers.length - 1];
	System.arraycopy(currentLayers, 0, newLayers, 0, index);
	System.arraycopy(currentLayers, index + 1, newLayers, index,
			 currentLayers.length - index - 1);
	setLayers(newLayers);
    }

    /**
     * Take a layer that the LayersMenu knows about, that may or may
     * not be a part of the map, and change its visibility by
     * adding/removing it from the MapBean.
     * @param setting true to add layer to the map.
     * @param layer the index of the layer to turn on/off.
     * @return true of index represented a layer, false if not or if
     * something went wrong.
     */
    public boolean turnLayerOn(boolean setting, int index){
	try {
	    turnLayerOn(setting, allLayers[index]);
	    return true;
	} catch (ArrayIndexOutOfBoundsException aoobe){
	    // Do nothing...
	} catch (NullPointerException npe){
	    // Do nothing...
	}
	return false;
    }

    /**
     * Take a layer that the LayersMenu knows about, that may or may
     * not be a part of the map, and change its visibility by
     * adding/removing it from the MapBean.  If the layer is not
     * found, it's added and the visibility depends on the setting
     * parameter.
     * @param setting true to add layer to the map.
     * @param layer the layer to turn on.  
     * @return true if the layer was found, false if not or if
     * something went wrong.
     */
    public boolean turnLayerOn(boolean setting, Layer layer){
	
	if ((setting && !layer.isVisible()) || 
	    (!setting && layer.isVisible())){
	    Debug.message("layerhandler", "LayerHandler: turning " +
			  layer.getName() + (setting?" on":" off"));

	    layer.setVisible(setting);
	    listener.setLayers(new LayerEvent(this, LayerEvent.REPLACE,
					      getMapLayers()));
	    return true;
	}	    
  	return false;
    }
}






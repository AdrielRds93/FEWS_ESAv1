/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/gui/Tool.java,v $
 * $Revision: 1.2 $
 * $Date: 2000/05/08 14:22:13 $
 * $Author: wjeuerle $
 * 
 * ***********************************************************************/

package com.bbn.openmap.gui;

import javax.swing.*;
import javax.swing.event.*;
import java.awt.event.*;
import java.awt.*;

/** 
 * Represents an item on the ToolPanel.
 *
 * @author john gash contributed to this notion of a Tool.
 */

abstract public class Tool {
    /** The key of the tool, as known by the ToolPanel. */
    protected String key = "";

    /** Constructor. */
    public Tool() { }
    
    /** Constructor with name.
     *
     * @param aKey name that tool will be known by. 
     */
    public Tool(String aKey) { 
	key = aKey; 
    }
    
    /** 
     * The retrieval tool's interface. This is added to the
     * tool bar.
     *
     * @return String The key for this tool.
     */
    abstract public Container getFace();
    
    /** 
     * The retrieval key for this tool
     *
     * @return String The key for this tool.
     **/
    public String getKey(){
	return key;
    }
    
    /** 
     * Set the retrieval key for this tool
     *
     * @param key The key for this tool.
     */
    public void setKey(String aKey){
	key = aKey;
    }
}

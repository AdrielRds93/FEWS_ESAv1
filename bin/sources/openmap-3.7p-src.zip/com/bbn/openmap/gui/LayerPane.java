/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/gui/LayerPane.java,v $
 * $Revision: 1.15 $
 * $Date: 2000/07/27 14:51:51 $
 * $Author: dietrick $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.gui;

import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import java.io.Serializable;
import java.net.URL;
import java.util.*;

import javax.swing.*;
import javax.swing.event.*;
import javax.accessibility.*;

import com.bbn.openmap.*;
import com.bbn.openmap.event.LayerEvent;
import com.bbn.openmap.event.LayerListener;
import com.bbn.openmap.event.LayerSupport;
import com.bbn.openmap.util.Assert;
import com.bbn.openmap.util.Debug;
import com.bbn.openmap.util.PaletteHelper;

/** 
 *  A LayerPane is a single instance of how a layer represented in the
 *  LayersPanel. It contains three widgets: an on/off button; a palette
 *  button; and a toggle button with the layer name.
 */
public class LayerPane extends JPanel 
    implements Serializable, ActionListener, ComponentListener {

    protected transient JCheckBox onoffButton;

    // Next line uncommented for toggle button
//      protected transient JCheckBox paletteButton;
    // Comment next line out for toggle button
    protected transient JButton paletteButton;

    protected transient JToggleButton layerName;
    protected transient boolean selected;
    protected transient Layer layer;
    
    // palette variables
    protected transient JInternalFrame paletteWindow = null;
    protected transient JFrame paletteWindow2 = null;
    protected transient LayerHandler layerHandler;

    // the icons
    protected static transient URL url1;
    protected static transient ImageIcon paletteIcon;
    protected static transient URL url2;
    protected static transient ImageIcon paletteOnIcon;
    protected static transient URL url3;
    protected static transient ImageIcon layerOnIcon;
    protected static transient URL url4;
    protected static transient ImageIcon layerOffIcon;

    public transient final static String showPaletteCmd = "showPalette";
    public transient final static String toggleLayerCmd = "toggleLayerCmd";

    // default initializations
    static {
	url1 = LayerPane.class.getResource("PaletteOff.gif");
	paletteIcon = new ImageIcon(url1, "palette");
	url2 = LayerPane.class.getResource("PaletteOn.gif");
	paletteOnIcon = new ImageIcon(url2, "palette on");

	url3 = LayerPane.class.getResource("BulbOn.gif");
	layerOnIcon = new ImageIcon(url3, "layer selected");
	url4 = LayerPane.class.getResource("BulbOff.gif");
	layerOffIcon = new ImageIcon(url4, "layer not selected");
    }


    /**
     *  @param layer the layer to be represented by the pane.
     *  @param cake the list of layers currently displayed on the map.
     *  @param layerHandler the LayerHandler that contains information
     *  about the Layers. 
     */
    public LayerPane(Layer layer, LayerHandler layerHandler, ButtonGroup bg) {
	super();

	setLayout(new BoxLayout(this, BoxLayout.X_AXIS));
	setAlignmentX(LEFT_ALIGNMENT);
	setAlignmentY(TOP_ALIGNMENT);
	//setBorder(new LineBorder(Color.black));

	this.layer = layer;
	this.layer.addComponentListener(this);

	this.layerHandler = layerHandler;
	onoffButton = new JCheckBox(layerOffIcon);
	onoffButton.setMargin(new Insets(0,0,0,0));
	onoffButton.setSelectedIcon(layerOnIcon);
	onoffButton.setActionCommand(toggleLayerCmd);
	onoffButton.addActionListener(this);
	onoffButton.setToolTipText("Turn " +layer.getName() + " layer on/off");

	// Determine if this layer has already been activated 
	onoffButton.setSelected(layer.isVisible());

	// add the palette show/hide checkbutton
//  	paletteButton = new JCheckBox(paletteIcon);
//  	paletteButton.setSelected(false);
//  	paletteButton.setSelectedIcon(paletteOnIcon);
//  	paletteButton.setToolTipText("Display/Hide tools for " 
//  				     + layer.getName() + " layer");

	paletteButton = new JButton(paletteIcon);
	paletteButton.setBorderPainted(false);
	paletteButton.setToolTipText("Display tools for " 
				     + layer.getName() + " layer");

	paletteButton.setMargin(new Insets(0,0,0,0));
	paletteButton.setActionCommand(showPaletteCmd);
	paletteButton.addActionListener(this);
	    
	layerName = new JToggleButton(layer.getName());
	layerName.setBorderPainted(false);
	layerName.setToolTipText("Click to select layer");
	bg.add(layerName);

	add(onoffButton);
	add(paletteButton);
	add(layerName);
    }
	
    public void cleanup(){
	layer.removeComponentListener(this);
	onoffButton.removeActionListener(this);
	layer = null;
	layerHandler = null;
    }

    public Dimension getPreferredSize() {
	return new Dimension(200, 32);
    }

    public Dimension getMinimumSize() {
	return new Dimension(100, 20);
    }

    /**
     *  @return whether the layer is on
     */ 
    public boolean isLayerOn() {
	return onoffButton.isSelected();
    }
    /**
     *  Turns the button on or off
     */
    public void setLayerOn(boolean value) {
	onoffButton.setSelected(value);
    }

    /**
     *  @return whether the palette for this layer is on
     */ 
    public boolean isPaletteOn() {
	return paletteButton.isSelected();
    }
    /**
     * Turns the palette button on or off
     */
    public void setPaletteOn(boolean value) {
	paletteButton.setSelected(value);
    }

    /**
     *  @return the status of the layerName toggle button
     */
    public boolean isSelected() { 
	return layerName.isSelected(); 
    }
    /**
     *  Highlights/unhighlights the layerName toggle button
     */
    public void setSelected(boolean select) {
	layerName.setSelected(select);
    }
    
    /**
     * @return the layer represented by this LayerPane
     */
    public Layer getLayer() {
	return layer;
    }

    /** 
     * Tell the pane to check with the layer to get the current layer
     * name for it's label.  
     */
    public void updateLayerLabel(){
	layerName.setText(getLayer().getName());
    }

    protected void showPalette () {
	if (Environment.getBoolean(Environment.UseInternalFrames)){
	    JRootPane rootPane = 
		((JApplet)(Environment.getApplet())).getRootPane();
	    final JLayeredPane desktop = rootPane.getLayeredPane();
	    desktop.setOpaque(true);
	    // get the window
	    paletteWindow = PaletteHelper.getPaletteInternalWindow(layer,
		  new InternalFrameAdapter() {
		      public void internalFrameClosed(InternalFrameEvent e) {
			  desktop.remove(paletteWindow);
			  desktop.repaint();
			  paletteWindow = null;
			  paletteButton.setSelected(false);
		      };
		  });
	    // add the window to the desktop
	    desktop.add(paletteWindow);

	} else {
	    if (paletteWindow2 == null) {
		paletteWindow2 = PaletteHelper.getPaletteWindow(
		    layer, new ComponentAdapter(){  
			    public void componentHidden(ComponentEvent e){
			// Next line uncommented for toggle button
//  			paletteButton.setSelected(false);
			// Comment next line out for toggle button
				paletteButton.setIcon(paletteIcon);
			    };
			} );
	    }
	    paletteWindow2.setVisible(true);
	    paletteWindow2.setState(java.awt.Frame.NORMAL);
	}
    }
    
    
    protected void hidePalette () {
	if (Environment.getBoolean(Environment.UseInternalFrames)){
	    if (paletteWindow == null)
		return;

	    // close the palette
	    try { paletteWindow.setClosed(true); }
	    catch (java.beans.PropertyVetoException evt) {
		com.bbn.openmap.util.Assert.assertTrue(
		    false, "LayersPanel.hidePalette(): " +
		    "internal error!");
	    }
	} else {

	    if (paletteWindow2 == null) return;
	    else paletteWindow2.setVisible(false);
	}
    }
    

    /**
     * ActionListener interface.
     * @param e ActionEvent
     */
    public void actionPerformed(java.awt.event.ActionEvent e) {

	if (e.getSource().equals(paletteButton)){
	    layerName.setSelected(true);

	    // This for a JButton control
	    paletteButton.setIcon(paletteOnIcon);
	    showPalette();

	    // All this for a toggle button control...
//  	    if (paletteButton.isSelected()) {
//  		if (paletteWindow == null) {
//  		    showPalette();
//  		} else {
//  		    // shouldn't get here!
//  		    com.bbn.openmap.util.Assert.assert(
//  			false, "LayerPane.actionPerformed(): internal error!");
//  		}
//  	    } else {
//  		hidePalette();
//  	    }

	}
	else if (e.getSource().equals(onoffButton)) {
	    layerName.setSelected(true);
	    // layer is selected, add it to or remove it from map
	    layerHandler.turnLayerOn(onoffButton.isSelected(), layer);

	    if (Debug.debugging("layerspanel")){
		Debug.output("LayerPane: Layer " + layer.getName() + 
			     (layer.isVisible()?" is visible.":" is NOT visible"));
	    }
	}
    }

    /**
     * Invoked when component has been resized.
     */
    public void componentResized(ComponentEvent e){}

    /**
     * Invoked when component has been moved.
     */    
    public void componentMoved(ComponentEvent e){}

    /**
     * Invoked when component has been shown.
     */
    public void componentShown(ComponentEvent e){
	if (Debug.debugging("layerspanel")){
	    Debug.output("LayerPane: layer panel for " + layer.getName() +
			 " receiving componentShown event");
	}

	if (e.getComponent() == layer){
	    if (isLayerOn() != true) {
		setLayerOn(true);
		if (Debug.debugging("layerspanel")){
		    Debug.output("LayerPane: layer " + layer.getName() +
				 " is now visible.");
		}
	    }
	}
    }

    /**
     * Invoked when component has been hidden.
     */
    public void componentHidden(ComponentEvent e){
	if (Debug.debugging("layerspanel")){
	    Debug.output("LayerPane: layer panel for " + layer.getName() +
			 " receiving componentHidden event");
	}
	if (e.getComponent() == layer){
	    if (isLayerOn() != false){
		setLayerOn(false);
		if (Debug.debugging("layerspanel")){
		    Debug.output("LayerPane: layer " + layer.getName() +
				 " is now hidden.");
		}
	    }
	}
    }
}

/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/gui/OverviewMapHandler.java,v $
 * $Revision: 1.4 $
 * $Date: 2000/08/03 16:23:22 $
 * $Author: dietrick $
 * 
 * **********************************************************************
 */
package com.bbn.openmap.gui;

import com.bbn.openmap.BufferedMapBean;
import com.bbn.openmap.Environment;
import com.bbn.openmap.LatLonPoint;
import com.bbn.openmap.Layer;
import com.bbn.openmap.MapBean;
import com.bbn.openmap.event.DefaultOverviewMouseMode;
import com.bbn.openmap.event.LayerEvent;
import com.bbn.openmap.event.MapMouseMode;
import com.bbn.openmap.event.OverviewMapStatusListener;
import com.bbn.openmap.event.ProjectionEvent;
import com.bbn.openmap.event.ProjectionListener;
import com.bbn.openmap.event.ProjectionSupport;
import com.bbn.openmap.layer.OverviewMapAreaLayer;
import com.bbn.openmap.layer.util.LayerUtils;
import com.bbn.openmap.proj.Mercator;
import com.bbn.openmap.proj.Proj;
import com.bbn.openmap.proj.Projection;
import com.bbn.openmap.proj.ProjectionFactory;
import com.bbn.openmap.util.Debug;

import javax.swing.JApplet;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JLayeredPane;
import javax.swing.JRootPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.util.Properties;
import java.util.Vector;

/**
 * The OverviewMapHandler contains a MapBean that contains a projection
 * that reflects another MapBean's projection.  It manages the two
 * MapBeans and the differences in the projections betwen them.  The
 * OverviewMapHandler can have a projection type independent of that of the
 * source MapBean (the MapBean that the OverviewMapHandler's MapBean is
 * paying attention to).  It also contains a scale factor, which is a
 * multiplier to use against the scale of the source MapBean's scale.
 * <P>
 *
 * The OverviewMapHandler MapBean can also be used to control the source
 * MapBean's projection center and scale.  The source MapBean just
 * needs to be added to the OverviewMapHandler by
 * OverviewMapHandler.addControlledMap(MapBean).  <P>
 *
 * The OverviewMapHandler needs to be added to the source MapBean as a
 * ProjectionListener.  Then, the overview MapBean can be added to the
 * ContentPane of a Component by calling
 * Component.setContentPane(OverviewMapHandler.getMap()); The OverviewMapHandler
 * should also be added as a ComponentListener to the Component.  <P>
 *
 * After the first projectionChanged() call is received, the
 * OverviewMapHandler knows about the source MapBean.  Since the
 * OverviewMapHandler is a ComponentListener and will therefore find out
 * when it's parent is hidden, it will disengage and engage itself
 * from the source MapBean as it's visibility changes.  <P>
 *
 * To get the overview map to appear in the OpenMap application, add
 * the following properties to your openmap.properties file:
 * <pre>
 * overviewLayers=overviewLayer
 * overviewScaleFactor=10d
 * overviewMinScale=10000000d
 * overviewStatusLayer=com.bbn.openmap.layer.OverviewMapAreaLayer
 *
 * # A sample overview map layer
 * overviewLayer.class=com.bbn.openmap.layer.shape.ShapeLayer
 * overviewLayer.prettyName=Overview
 * overviewLayer.shapeFile=/home/dietrick/dev/openmap/share/dcwpo-browse.shp
 * overviewLayer.spatialIndex=/home/dietrick/dev/openmap/share/dcwpo-browse.ssx
 * overviewLayer.lineColor=ff000000
 * overviewLayer.fillColor=ffbdde83
 * </pre>
 * <p>
 *
 * If layers are not added to the overview map, then it won't show
 * up in the application.  
 */
public class OverviewMapHandler implements ProjectionListener, ComponentListener {

    public final static String OverviewMapHandlerLayerProperty = "overviewLayers";
    public final static String ScaleFactorProperty = "overviewScaleFactor";
    public final static String ProjectionTypeProperty = "overviewProjectionType";
    public final static String MinScaleProperty = "overviewMinScale";
    public final static String StatusLayerProperty = "overviewStatusLayer";
    public final static double defaultScaleFactor = 20d;
    public final static double defaultMinScale = 500000d;

    /** The multiplier to apply to the scale of the project received. */
    protected double scaleFactor;
    /** The minimum scale to use for the window.  If it gets too small
     *  with a general type layer, it won't be any use. */
    protected double minScale;
    /** The map of the overview panel. */
    protected MapBean map;
    /** The source MapBean to show the overview of.  Gets set when the
     *  first projectionChanged() gets called.  Also used to
     *  disconnect from the MapBean when the component that this
     *  OverviewMapHandler is listening to is hidden, and to connect to the
     *  MapBean when the component is shown.
     */
    protected MapBean sourceMap;
    /** The projection of the overview map bean. */
    protected Proj projection;
    /** A layer that can be set to constantly be on the top of the
     *  map.  If the status layer is also a OverviewMapStatusListener,
     *  it also receives the source map projection when that changes,
     *  which gives it the capability to draw stuff based on that. */
    protected Layer statusLayer;
    /** The support to send the source MapBean setCenter and setScale
     *  commands if a controlled map is added - usually the source map bean. */
    protected ControlledMapSupport listener;
    /** The mouse mode to use for the overview map.  */
    protected MapMouseMode mmm;
    /** A JFrame to house the overview map, if desired.  Ask for the
     *  listener, and it will get created if it's running in an
     *  application. */
    protected JFrame overviewWindowFrame = null;
    /** A JFrame to house the overview map, if desired.  Ask for the
     *  listener, and it will get created if it's running in an
     *  applet. */
    protected JInternalFrame overviewWindow = null;
    /** The thing listening for a request to bring up a JFrame or JInternalFrame.*/
    protected ActionListener overviewFrameActionListener = null;

    /**
     * Create an OverviewMapHandler with properties that do not contain a prefix. 
     * @param props properties object.
     */
    public OverviewMapHandler(Properties props) throws Exception {
	this(null, props);
    }

    /**
     * Create an OverviewMapHandler with properties that do contain a prefix. 
     * @param prefix the prefix to place in front of each property -
     * i.e., so that each property will be under prefix.propertyName.
     * The period between the two will be added.
     * @param props properties object.  
     */
    public OverviewMapHandler(String prefix, Properties props) throws Exception {

	Vector overviewLayers;
	String layerPropertyName;
	String scaleFactorPropertyName;
	String projectionTypePropertyName;
	String minScalePropertyName;
	String statusLayerPropertyName;

	if (prefix == null){
	    layerPropertyName = OverviewMapHandlerLayerProperty;
	    scaleFactorPropertyName = ScaleFactorProperty;
	    minScalePropertyName = MinScaleProperty;
	    projectionTypePropertyName = ProjectionTypeProperty;
	    statusLayerPropertyName = StatusLayerProperty;
	} else {
	    layerPropertyName = prefix + "." + OverviewMapHandlerLayerProperty;
	    scaleFactorPropertyName = prefix + "." + ScaleFactorProperty;
	    minScalePropertyName =  prefix + "." + MinScaleProperty;
	    projectionTypePropertyName = prefix + "." + ProjectionTypeProperty;
	    statusLayerPropertyName = prefix + "." + StatusLayerProperty;
	}
	overviewLayers = 
	    LayerHandler.parseSpacedMarkers(props.getProperty(layerPropertyName));
	
	if (overviewLayers.size() == 0){
	    Debug.message("overview", "OverviewMapHandler:  created without layer!");
	    throw new Exception("No layers given to OverviewMapHandler - not created.");
	}

	scaleFactor = LayerUtils.doubleFromProperties(props, scaleFactorPropertyName,
            defaultScaleFactor);
	minScale = LayerUtils.doubleFromProperties(props, minScalePropertyName,
            defaultMinScale);

	String statusLayerName = props.getProperty(statusLayerPropertyName);
	if (statusLayerName != null){
	    statusLayer = LayerHandler.getLayerClass(statusLayerName);
	    if (statusLayer == null){
		Debug.error("OverviewMapHandler.setProperties: status layer not set.");
	    }
	} else {
	    statusLayer = new OverviewMapAreaLayer();
	}

	// We don't need another copyright message, right?
	MapBean.suppressCopyright = true;
	map = new BufferedMapBean();

	String projName = props.getProperty(projectionTypePropertyName);
	if (projName == null){
	    projName = Mercator.MercatorName;
	}
	int projType = ProjectionFactory.getProjType(projName);

	//  The scale, lat/lon and size shouldn't matter, because the
	//  size will get reset when it is added to a component, and
	//  the projection will change when it is added to a MapBean
	//  as a projection listener.
	projection = (Proj) ProjectionFactory.makeProjection(
	    projType,
	    Environment.getDouble(Environment.Latitude, 0d),
	    Environment.getDouble(Environment.Longitude, 0d),
	    Environment.getDouble(Environment.Scale,
				 Double.POSITIVE_INFINITY)*scaleFactor,
	    10, 10);

	setLayers(LayerHandler.getLayers(overviewLayers, overviewLayers, props));
    }

    /** 
     * Set the layers in the Overview MapBean.  An AreaLayer is
     * automatically added on top.
     */
    public void setLayers(Layer[] layers){
	map.setLayers(new LayerEvent(this, LayerEvent.REPLACE, new Layer[0]));
	if (statusLayer != null){
	    map.add(statusLayer);
	}
	map.setLayers(new LayerEvent(this, LayerEvent.ADD, layers));
    }
    
    /**
     * Part of the ProjectionListener interface.  The new projections
     * from the source MapBean arrive here.
     * @param projEvent the projection event from the source MapBean.
     */
    public void projectionChanged(ProjectionEvent projEvent){
	if (sourceMap == null){
	    sourceMap = (MapBean)projEvent.getSource();
	}

	Projection proj = projEvent.getProjection();
	if (proj == null) return;

	if (statusLayer != null && 
	    statusLayer instanceof OverviewMapStatusListener){
	    ((OverviewMapStatusListener)statusLayer).setSourceMapProjection(proj);
	}
	double newScale = proj.getScale()*scaleFactor;
	if (newScale < minScale){
	    newScale = minScale;
	}
	projection.setScale(newScale);
	projection.setCenter(proj.getCenter());

	map.setProjection(projection);
    }

    /**
     * Set the MapMouseMode for the overview map.  If you want the
     * status layer to listen to the mouse mode, you have to get the
     * layer an wire it up yourself.
     */
    public void setMouseMode(MapMouseMode ammm){
	// If we're removing a mouse mode, disconnect it from the map.
	if (ammm == null){
	    deactivateMouseMode();
	}
	mmm = ammm;
	activateMouseMode();
    }

    /**
     * Get the MapMouseMode used for the overview map.
     */
    public MapMouseMode getMouseMode(){
	return mmm;
    }

    /**
     * Adds the mouse mode as a listener to the overview map.  If the
     * mouse mode is null, the default is created.  
     */
    public void activateMouseMode(){
	if (mmm == null){
	    mmm = new DefaultOverviewMouseMode(this);
	}
	if (map != null){
	    map.addMouseListener(mmm);
	    map.addMouseMotionListener(mmm);
	}
    }

    /**
     * Disconnects the mouse mode from the overview map.
     */
    public void deactivateMouseMode(){
	if (mmm != null){
	    map.removeMouseListener(mmm);
	    map.removeMouseMotionListener(mmm);
	}
    }

    /**
     * Add a controlled MapBean to the OverviewMapHandler.  Use this method
     * to add another MapBean to the overview map in order to have its
     * projection controlled by the overview panel.  If the overview
     * panel is clicked on, the listening MapBean will be recentered.
     * If a box is drawn with a mouse drag, the scale of the
     * controlled map will be modified.
     * @param l MapBean. 
     */
    public void addControlledMap(MapBean l) {
	if (listener == null){
	    listener = new ControlledMapSupport(map);
	    // If nobody has been listening don't draw anything.
	    // Since someone is now being controlled, we'll do the
	    // drawing.
	    activateMouseMode();
	}
	listener.addProjectionListener(l);
    }

    /**
     * Remove a controlled MapBean from the OverviewMapHandler.
     * @param l a MapBean.
     */
    public void removeControlledMap(MapBean l) {
	if (listener != null){
	    listener.removeProjectionListener(l);
	    
	    if (listener.size() == 0){
		deactivateMouseMode();
	    }
	}
    }

    /** 
     * Get the overview MapBean. 
     * @return overview MapBean.
     */
    public MapBean getMap(){
	return map;
    }

    /**
     * Set the overview MapBean.
     */
    public void setMap(MapBean map){
	this.map = map;
    }

    /**
     * Get the ControlledMapSupport, which usually contains the source
     * map.  
     */
    public ControlledMapSupport getControlledMapListeners(){
	return listener;
    }

    /**
     * Set the ControlledMapSupport, which usually contains the source
     * map.  
     */
    public void setControlledMapListeners(ControlledMapSupport list){
	listener = list;
    }

    /**
     * Get the status layer, which is always drawn on top of the other
     * layers, and maintained separately from other layers.  
     */
    public Layer getStatusLayer(){
	return statusLayer;
    }

    /**
     * Get the status layer, which is always drawn on top of the other
     * layers, and maintained separately from other layers.  If the
     * layer is also an OverviewMapStatusListener, it will receive
     * source map projection changes, so it can draw stuff on itself
     * representing what's going on the source map.
     */
    public void setStatusLayer(Layer layer){
	statusLayer = layer;
    }

    /**
     *  Set the scale factor to use between the source MapBean and the
     *  overview MapBean.  It's a direct multiplier, so the overview
     *  MapBean can actually be a magnified map, too.  The overview
     *  map scale = source MapBean scale * scaleFactor.
     * @param setting scale factor 
     */
    public void setScaleFactor(double setting){
	scaleFactor = setting;
    }

    /**
     * Get the scale factor used for the overview MapBean.
     */
    public double getScaleFactor(){
	return scaleFactor;
    }

    /** 
     * Set the projection of the overview MapBean.  Lets you set the
     * type, really.  The scale and center will be reset when a
     * projection event is received.
     */
    public void setProjection(Proj proj){
	projection = proj;
    }

    /**
     * Get the current projection of the overview MapBean. 
     */
    public Proj getProjection(){
	return projection;
    }

    /**
     * Set the minimum scale to use for the overview map.  If this is
     * set too small with a very general map layer, it won't be of any
     * use, really, if it gets really zoomed in. 
     * @param setting the scale setting - 1:setting
     */
    public void setMinScale(double setting){
	if (setting > 0){
	    minScale = setting;
	}
    }

    public double getMinScale(){
	return minScale;
    }

    /**
     * Invoked when component has been resized.  This component should
     * be the component that contains the OverviewMapHandler.
     */
    public void componentResized(ComponentEvent e){
	projection.setWidth(((java.awt.Component)e.getSource()).getWidth());
	projection.setHeight(((java.awt.Component)e.getSource()).getHeight());
	map.setProjection(projection);
    }

    /**
     * Invoked when component has been moved.  This component should
     * be the component that contains the OverviewMapHandler.  
     */
    public void componentMoved(ComponentEvent e){}

    /**
     * Invoked when component has been shown.  This component should
     * be the component that contains the OverviewMapHandler.  
     */
    public void componentShown(ComponentEvent e){
	if (sourceMap != null){
	    sourceMap.addProjectionListener(this);
	}
    }

    /**
     * Invoked when component has been hidden.  This component should
     * be the component that contains the OverviewMapHandler.  
     */
    public void componentHidden(ComponentEvent e){
	if (sourceMap != null){
	    sourceMap.removeProjectionListener(this);
	}
    }

    /**
     * Return an ActionListener that will bring up an independent
     * window with an Overview Map.
     * @param sourceMap the MapBean to mirror coverage of.
     * @param controlMap true to enable gesture controls on the
     * overview map to change the projection on the source map.
     * @param frameTitle the title to put on the JFrame window.  
     * @return ActionListener that brings up a Window when an
     * actionPerformed is called.
     */
    public ActionListener getOverviewFrameActionListener(MapBean sourceMap, 
							 boolean controlMap, 
							 String frameTitle){
	if (overviewFrameActionListener == null){
	    // Try to group the applet-specific stuff in here...
	    if (Environment.getBoolean(Environment.UseInternalFrames)){

		JRootPane rootPane = ((JApplet)(Environment.getApplet())).getRootPane();
		final JLayeredPane desktop = rootPane.getLayeredPane();
		desktop.setOpaque(true);

		overviewWindow = new JInternalFrame(
		    frameTitle,
		    /*resizable*/ true,
		    /*closable*/ true,
		    /*maximizable*/ false,
		    /*iconifiable*/ true);
		overviewWindow.setBounds(2, 2, 200, 100);
		overviewWindow.setContentPane(getMap());
		sourceMap.addProjectionListener(this);
		overviewWindow.addComponentListener(this);
		if (controlMap){
		    addControlledMap(sourceMap);
		}
		overviewWindow.setOpaque(true);
		try {
		    overviewWindow.setClosed(true);//don't show until it's needed
		} catch (java.beans.PropertyVetoException e) {}
		//	desktop.add(overviewWindow, JLayeredPane.PALETTE_LAYER);
		
		overviewFrameActionListener = ( new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
			    try {
				if (overviewWindow.isClosed()) {
				    overviewWindow.setClosed(false);
				    // hmmm is this the best way to do this?
				    desktop.remove(overviewWindow);
				    desktop.add(overviewWindow, 
						JLayeredPane.PALETTE_LAYER);
				}
			    } catch (java.beans.PropertyVetoException e) {
				System.err.println(e);
			    }
			}
		    });
		
	    } else { // Working as an application...
		overviewWindowFrame = new JFrame(frameTitle);
		overviewWindowFrame.setBounds(2, 2, 200, 100);
		overviewWindowFrame.setContentPane(getMap());
		sourceMap.addProjectionListener(this);
		overviewWindowFrame.addComponentListener(this);
		if (controlMap){
		    addControlledMap(sourceMap);
		}
		overviewWindowFrame.setVisible(false);//don't show until it's needed
		
		overviewFrameActionListener = ( new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
			    overviewWindowFrame.setVisible(true);
			    overviewWindowFrame.setState(java.awt.Frame.NORMAL);
			}
		    });
	    }
	}

	return overviewFrameActionListener;
    }

    /**
     * Support for directing the setCenter and setScale calls to any
     * MapBeans that care to be listening. 
     */
    public class ControlledMapSupport extends ProjectionSupport {

 	/**
	 * Construct a ControlledMapSupport.
	 */
	public ControlledMapSupport() {
	    super();
	}
	
	/**
	 * Construct a ControlledMapSupport.
	 * @param aSource source Object
	 */
	public ControlledMapSupport(Object aSource) {
	    super(aSource);
	}

	/**
	 * Return how many listeners there are.
	 */
	public int size(){
	    java.util.Vector targets = getListeners();
	    return targets.size();
	}

	/**
	 * Set the center coordinates on all registered listeners.
	 * @param proj Projection
	 */
	public void setCenter (LatLonPoint llp) {
	    java.util.Vector targets = getListeners();

	    if (targets == null || targets.size() == 0) {
		return;
	    }
	    
	    int nTargets = targets.size();
	    for (int i = 0; i < nTargets; i++) {
		((MapBean)targets.elementAt(i)).setCenter(llp);
	    }
	}

	/**
	 * Set the scale on all registered listeners.
	 * @param proj Projection
	 */
	public void setScale (double scale) {
	    java.util.Vector targets = getListeners();

	    if (targets == null || targets.size() == 0) {
		return;
	    }
	    
	    int nTargets = targets.size();
	    for (int i = 0; i < nTargets; i++) {
		((MapBean)targets.elementAt(i)).setScale(scale);
	    }
	}
    }
}

/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/gui/CoordPanel.java,v $
 * $Revision: 1.12 $
 * $Date: 2000/05/08 14:22:12 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.gui;

import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import java.io.Serializable;

import javax.swing.*;
import javax.swing.border.*;
import javax.accessibility.*;

import com.bbn.openmap.*;
import com.bbn.openmap.event.*;
import com.bbn.openmap.util.Debug;


/**
 *  CoordPanel is a simple gui with entry boxes and labels 
 *  for latitude and longitude. It sets the center
 *  of a map with the entered coordinates by firing CenterEvents.
 */
public class CoordPanel extends JPanel implements Serializable
{
    protected transient JTextField latitude, longitude;
    protected transient CenterSupport centerDelegate;

    /**
     *  Creates the panel.
     */
    public CoordPanel () {
	centerDelegate = new CenterSupport(this);
	makeWidgets();
    }

    /**
     *  Creates the panel.
     */
    public CoordPanel (CenterSupport support) {
	centerDelegate = support;
	makeWidgets();
    }

    /**
     *  Creates and adds the labels and entry fields for latitude and longitude
     */
    protected void makeWidgets () {
	setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
	setBorder(new TitledBorder(new EtchedBorder(), "Decimal Degrees"));

	JPanel latPanel = new JPanel();
	latPanel.setLayout(new BoxLayout(latPanel, BoxLayout.X_AXIS));
	latitude = new JTextField(6);
	JLabel latlabel = new JLabel("Latitude: ");
	//	latlabel.setLabelFor(latitude);
	JPanel lonPanel = new JPanel();
	lonPanel.setLayout(new BoxLayout(lonPanel, BoxLayout.X_AXIS));
	longitude = new JTextField(6);
	JLabel lonlabel = new JLabel("Longitude: ");
	//lonlabel.setLabelFor(longitude);

	latPanel.add(latlabel);
	latPanel.add(latitude);
	lonPanel.add(lonlabel);
	lonPanel.add(longitude);
	add(latPanel);
	add(lonPanel);
    }


    /**
     *  @return the LatLonPoint represented by contents of the entry boxes
     */
    public com.bbn.openmap.LatLonPoint getLatLon() {
	double lat, lon;
	try {
	    lat = Double.valueOf(latitude.getText()).floatValue();
	    lon = Double.valueOf(longitude.getText()).floatValue();
	} catch (NumberFormatException except) {
	    System.out.println(except.toString());
	    latitude.setText("");
	    longitude.setText("");
	    return null;
	}

	System.out.println("lat: " +lat + "  lon: "+lon);
	return (new com.bbn.openmap.LatLonPoint(lat,lon));
    }

    /**
     *  Sets the contents of the latitude and longitude entry boxes
     *  @param llpoint the object containt the coordinates that should go in the boxes
     */
    public void setLatLon(com.bbn.openmap.LatLonPoint llpoint) {
	latitude.setText(""+llpoint.getLatitude());
	longitude.setText(""+llpoint.getLongitude());
    }

    /**
     *  Sets the center of the map to be the coordinates in the 
     *  latitude and logitude entry boxes
     */
    public boolean setCenter() {
	double lat, lon;
	try {
	    lat = Double.valueOf(latitude.getText()).floatValue();
	    lon = Double.valueOf(longitude.getText()).floatValue();
	} catch (NumberFormatException e) {
	    System.out.println("CoordPanel.setCenter(): " + e);
	    latitude.setText("");
	    longitude.setText("");
	    return false;
	}

	centerDelegate.fireCenter(lat, lon);

	//System.out.println("lat: " +lat + "  lon: "+lon);
	return true;
    }


    /**
     * Add a CenterListener to the listener list.
     *
     * @param listener  The CenterListener to be added
     */
    public void addCenterListener (CenterListener listener) {
	centerDelegate.addCenterListener(listener);
    }


    /**
     * Remove a CenterListener from the listener list.
     *
     * @param listener  The CenterListener to be removed
     */
    public void removeCenterListener (CenterListener listener) {
	centerDelegate.removeCenterListener(listener);
    }


    /*
    public static void main(String[] args) {
	JFrame frame = new JFrame("CoordBox");
	frame.setSize(220,100);
	CoordPanel cp = new CoordPanel();
	frame.getContentPane().add(cp);
	frame.setVisible(true);
    }
    */
}

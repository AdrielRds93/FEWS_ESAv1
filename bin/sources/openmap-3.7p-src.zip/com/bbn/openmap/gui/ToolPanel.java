/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/gui/ToolPanel.java,v $
 * $Revision: 1.33 $
 * $Date: 2000/05/08 14:22:13 $
 * $Author: wjeuerle $
 * 
 * ***********************************************************************/

package com.bbn.openmap.gui;

import javax.swing.*;
import javax.swing.event.*;
import java.awt.event.*;
import java.util.*;
import java.awt.*;

/** 
 * Represents the toolbar containing tools to apply to the map.
 * Tools can be added in sequential order, and retrieved using the
 * tool's keyword.  NOTE: Every time a string is passed into a method
 * of this class, the intern90 version of it is used as a key.
 *
 * @author john gash 
 */

public class ToolPanel extends JToolBar
{
    /** The set of tools contained on the toolbar. */
    protected Hashtable items = new Hashtable();
    protected boolean autoSpace = true;
    
    /**
     * Constructor
     **/
    public ToolPanel(){
	super();
    }
    
    /**
     * Add an item to the tool bar
     *
     * @params key The key associated with the item.
     * @params item The jamsTool to add.
     **/
    public void add(String key, Tool item){
	items.put(key.intern(), item); 
	if (autoSpace && items.size() > 0) 
	    addSpace();
	add(item.getFace());
    }

    /** 
     * Add an item to the tool bar.  Assumes that the key will be
     * picked out of the Tool.
     *
     * @params item The jamsTool to add.
     **/
    public void add(Tool item){
	add(item.getKey().intern(), item);
    }

    /**
     * Get an item from the tool bar
     *
     * @params key The key associated with the item.
     * @return The tool associated with the key, null if not found.
     */
    public Tool get(String key){
	return (Tool)items.get(key.intern()); 
    } 
    
    /** Remove a tool with the right key */
    public void remove(String key){
	items.remove(key.intern());
    }

    /** Add a space between tools. */
    protected void addSpace(){ 
	add(new JLabel("   "));
    }

    /** Set whether spaces are placed between tools. */
    public void setAutoSpace(boolean set){
	autoSpace = set;
    }

    /** Find out whether spaces are being placed between tools. */
    public boolean isAutoSpace(){
	return autoSpace;
    }
}


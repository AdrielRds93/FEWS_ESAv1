/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/gui/ZoomPanel.java,v $
 * $Revision: 1.9 $
 * $Date: 2000/07/27 14:51:53 $
 * $Author: dietrick $
 * 
 * **********************************************************************
 */
package com.bbn.openmap.gui;

import com.bbn.openmap.util.Debug;
import javax.swing.*;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.beans.*;
import java.io.Serializable;
import java.net.URL;

import com.bbn.openmap.*;
import com.bbn.openmap.event.*;

/**
 * Bean to zoom the Map.
 * <p>
 * This bean is a source for ZoomEvents.  It is a simple widget with a ZoomIn
 * button and a ZoomOut button.  When a button is pressed, the appropriate
 * zoom event is fired to all registered listeners.
 * @see #addZoomListener
 */
public class ZoomPanel extends JPanel implements ActionListener, Serializable {

    public final static transient String zoomInCmd = "zoomin";
    public final static transient String zoomOutCmd = "zoomout";


    protected transient JButton zoomInButton, zoomOutButton;
    protected transient ZoomSupport zoomDelegate;

    /**
     * Default Zoom In Factor is 0.5.
     */
    protected transient double zoomInFactor = 0.5d;


    /**
     * Default Zoom Out Factor is 2.0.
     */
    protected transient double zoomOutFactor = 2.0d;


    /**
     * Construct the ZoomPanel.
     */
    public ZoomPanel() {
	super();
//  	setLayout(new BoxLayout(this, BoxLayout.X_AXIS));
	setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
	    
	zoomDelegate = new ZoomSupport(this);
	zoomInButton = addButton("zoomIn", "Zoom In", zoomInCmd);
	zoomOutButton = addButton("zoomOut", "Zoom Out", zoomOutCmd);
    }


    /**
     * Get the Zoom In Factor.
     * @return double the degree by which map scale will be multiplied when
     * zoom in button is pressed
     */
    public double getZoomInFactor() {
	return zoomInFactor;
    }


    /**
     * Sets the Zoom In factor.
     * The factor must be &lt; 1.0.  (otherwise it would make ZoomIn into
     * a ZoomOut).
     * @param factor the degree by which map scale should be multiplied
     */
    public void setZoomInFactor(double factor) {
	if (factor < 1.0d){
	    zoomInFactor=factor;
	    zoomInButton.setToolTipText("zoom in X" +zoomInFactor);
	}
	else {
	    throw new IllegalArgumentException(
		    "Zoom In factor too large (must be < 1.0)");
	}
    }


    /**
     * Get the Zoom Out Factor.
     * @return double the degree by which map scale will be multiplied when
     * zoom out button is pressed
     */
    public double getZoomOutFactor() {
	return zoomOutFactor;
    }


    /**
     * Sets the Zoom Out Factor.
     * The factor must be &gt; 1.0 (otherwise it would turn ZoomOut into
     * ZoomIn).
     * @param factor the degree by which map scale should be multiplied.
     */
    public void setZoomOutFactor(double factor) {
	if (factor > 1.0d) {
	    zoomOutFactor=factor;
	    zoomOutButton.setToolTipText("zoom out X" +zoomOutFactor);
	}
	else {
	    throw new IllegalArgumentException(
		    "Zoom In factor too small (must be > 1.0)");
	}
    }


    /**
     * Add the named button to the panel.
     *
     * @param name GIF image name
     * @param info ToolTip text
     * @param command String command name
     *
     */
    protected JButton addButton(String name, String info, String command) {
	URL url = ZoomPanel.class.getResource(name + ".gif");
	JButton b = new JButton(new ImageIcon(url, info));
	b.setToolTipText(info);
	b.setMargin(new Insets(0,0,0,0));
        b.setActionCommand(command);
	b.addActionListener(this);
	b.setBorderPainted(false);
	add(b);
	return b;
    }


    /**
     * Add a ZoomListener from the listener list.
     *
     * @param listener  The ZoomListener to be added
     */
    public synchronized void addZoomListener (ZoomListener listener) {
	zoomDelegate.addZoomListener(listener);
    }


    /**
     * Remove a ZoomListener from the listener list.
     *
     * @param listener  The ZoomListener to be removed
     */
    public synchronized void removeZoomListener (ZoomListener listener) {
	zoomDelegate.removeZoomListener(listener);
    }


    /**
     * ActionListener interface.
     * @param e ActionEvent
     */
    public void actionPerformed(java.awt.event.ActionEvent e) {
	String command = e.getActionCommand();

	if (command.equals(zoomInCmd)) {
	    zoomDelegate.fireZoom(ZoomEvent.RELATIVE, zoomInFactor);
	}
	else if (command.equals(zoomOutCmd)) {
	    zoomDelegate.fireZoom(ZoomEvent.RELATIVE, zoomOutFactor);
	}
    }

//     public Dimension getPreferredSize() {
// 	return new Dimension(100, 40);
//     }

//     public Dimension getMinimumSize() {
// 	return new Dimension(50, 40);
//     }


    /*
    public static void main(String args[]) {

	final JFrame frame = new JFrame("ZoomPanel");
	//	frame.setSize(100, 32);
	ZoomPanel zp = new ZoomPanel();
	zp.setZoomInFactor(0.9f);
	zp.setZoomOutFactor(4.5f);
	frame.setVisible(true);
	frame.getContentPane().add(zp);
	frame.setSize(200,100);
	
    }
    */
}

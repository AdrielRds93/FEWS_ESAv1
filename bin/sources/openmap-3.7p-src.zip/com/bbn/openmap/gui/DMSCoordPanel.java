/* **********************************************************************
 * 
 *  BBNT Solutions LLC, A part of GTE
 *  10 Moulton St.
 *  Cambridge, MA 02138
 *  (617) 873-2000
 * 
 *  Copyright (C) 1998, 2000
 *  This software is subject to copyright protection under the laws of 
 *  the United States and other countries.
 * 
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/gui/DMSCoordPanel.java,v $
 * $Revision: 1.7 $
 * $Date: 2000/05/08 14:22:12 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */


package com.bbn.openmap.gui;

import com.bbn.openmap.LatLonPoint;
import com.bbn.openmap.event.CenterListener;
import com.bbn.openmap.event.CenterSupport;

import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;
import java.awt.Dimension;
import java.io.Serializable;


/**
 *  CoordPanel is a simple gui with entry boxes and labels 
 *  for latitude and longitude. It sets the center
 *  of a map with the entered coordinates by firing CenterEvents.
 */
public class DMSCoordPanel extends JPanel implements Serializable
{
    protected transient JTextField degLat, minLat, secLat, degLon, minLon, secLon;
    protected transient CenterSupport centerDelegate;

    /**
     *  Creates the panel.
     */
    public DMSCoordPanel () {
	centerDelegate = new CenterSupport(this);
	makeWidgets();
    }

    /**
     *  Creates the panel.
     */
    public DMSCoordPanel (CenterSupport support) {
	centerDelegate = support;
	makeWidgets();
    }

    /**
     *  Creates and adds the labels and entry fields for latitude and longitude
     */
    protected void makeWidgets () {
	setLayout(new BoxLayout(this, BoxLayout.X_AXIS));
	setBorder(new TitledBorder(new EtchedBorder(), "Deg Min Sec"));

	JPanel latPanel = new JPanel();
	latPanel.setLayout(new BoxLayout(latPanel, BoxLayout.X_AXIS));
	latPanel.setAlignmentX(LEFT_ALIGNMENT);
 	latPanel.setAlignmentY(BOTTOM_ALIGNMENT);
	degLat = new JTextField(4);
	minLat = new JTextField(2);
	secLat = new JTextField(2);

	
	JLabel latlabel = new JLabel("Latitude DMS: ");
	//latlabel.setLabelFor(degLat);
	latPanel.add(degLat);
	latPanel.add(minLat);
	latPanel.add(secLat);


	JPanel lonPanel = new JPanel();
	lonPanel.setLayout(new BoxLayout(lonPanel, BoxLayout.X_AXIS));
	lonPanel.setAlignmentX(LEFT_ALIGNMENT);
 	lonPanel.setAlignmentY(BOTTOM_ALIGNMENT);
	degLon = new JTextField(4);
	minLon = new JTextField(2);
	secLon = new JTextField(2);


	// Set the Max size of the degree fields to prevent the inexplicable
	// disapearance of the min fields when the panel is stretched
	Dimension dim = degLat.getPreferredSize();
	dim.width += 10;
	degLat.setMaximumSize(dim);
	degLon.setMaximumSize(dim);

	JLabel lonlabel = new JLabel("Longitude DMS: ");
	//lonlabel.setLabelFor(degLon);
	lonPanel.add(degLon);
	lonPanel.add(minLon);
	lonPanel.add(secLon);

	JPanel latlonPanel = new JPanel();
	latlonPanel.setLayout(new BoxLayout(latlonPanel, BoxLayout.Y_AXIS));
	latlonPanel.add(latPanel);
	latlonPanel.add(lonPanel);

 	JPanel labelPanel = new JPanel();
 	labelPanel.setLayout(new BoxLayout(labelPanel, BoxLayout.Y_AXIS));
 	labelPanel.add(latlabel);
 	labelPanel.add(lonlabel);


 	add(labelPanel);
	add(latlonPanel);
    }


    /**
     *  @return the LatLonPoint represented by contents of the entry boxes
     */
    public com.bbn.openmap.LatLonPoint getLatLon() {
	double deglat, minlat, seclat, deglon, minlon, seclon, lat, lon;
	try {
	    // Allow blank minutes and seconds fields to represent zero
	    deglat = Double.valueOf(degLat.getText()).floatValue();

	    minlat = minLat.getText().equals("") ? 0.0d :
	        Double.valueOf(minLat.getText()).floatValue();
	    seclat = secLat.getText().equals("") ? 0.0d :
	        Double.valueOf(secLat.getText()).floatValue();

	    deglon = Double.valueOf(degLon.getText()).floatValue();

	    minlon = minLon.getText().equals("") ? 0.0d :
	        Double.valueOf(minLon.getText()).floatValue();
	    seclon = secLon.getText().equals("") ? 0.0d :
	        Double.valueOf(secLon.getText()).floatValue();
	    
	} catch (NumberFormatException except) {
	    System.out.println(except.toString());
	    degLat.setText("");
	    minLat.setText("");
	    secLat.setText("");
	    degLon.setText("");
	    minLon.setText("");
	    secLon.setText("");
	    return null;
	}
	
	lat = (deglat + ((minlat * 60.0) + seclat)/3600);
	lon = (deglon + ((minlon * 60.0) + seclon)/3600);
//	System.out.println("lat: " +lat + "  lon: "+lon);
	return (new com.bbn.openmap.LatLonPoint(lat,lon));
    }

    /**
     *  Sets the contents of the latitude and longitude entry boxes
     *  @param llpoint the object containt the coordinates that should go in the boxes
     */
     public void setLatLon(com.bbn.openmap.LatLonPoint llpoint) {
// 	latitude.setText(""+llpoint.getLatitude());
// 	longitude.setText(""+llpoint.getLongitude());
     }

    /**
     *  Sets the center of the map to be the coordinates in the 
     *  latitude and logitude entry boxes
     */
    public boolean setCenter() {
	double lat, lon;
	
	LatLonPoint llp = getLatLon();
	if (llp == null)
	    return false;// invalid number

	//System.out.println("lat: " +lat + "  lon: "+lon);
	centerDelegate.fireCenter(llp.getLatitude(), llp.getLongitude());

	return true;
    }


    /**
     * Add a CenterListener to the listener list.
     *
     * @param listener  The CenterListener to be added
     */
    public void addCenterListener (CenterListener listener) {
	centerDelegate.addCenterListener(listener);
    }


    /**
     * Remove a CenterListener from the listener list.
     *
     * @param listener  The CenterListener to be removed
     */
    public void removeCenterListener (CenterListener listener) {
	centerDelegate.removeCenterListener(listener);
    }


    /*
    public static void main(String[] args) {
	JFrame frame = new JFrame("CoordBox");
	frame.setSize(200,150);
	DMSCoordPanel cp = new DMSCoordPanel();
	frame.getContentPane().add(cp);
	frame.setVisible(true);
    }
    */
}

/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/gui/NavigatePanel.java,v $
 * $Revision: 1.17 $
 * $Date: 2000/07/27 14:51:52 $
 * $Author: dietrick $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.gui;

import com.bbn.openmap.Environment;
import com.bbn.openmap.event.CenterListener;
import com.bbn.openmap.event.CenterSupport;
import com.bbn.openmap.event.PanListener;
import com.bbn.openmap.event.PanSupport;
import com.bbn.openmap.util.Debug;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionListener;
import java.io.Serializable;
import java.net.URL;


/**
 * A Navigation Rosette Bean.
 * This bean is a source for PanEvents and CenterEvents.
 */
public class NavigatePanel extends JPanel
    implements Serializable, ActionListener
{
    public final static transient String panNWCmd = "panNW";
    public final static transient String panNCmd = "panN";
    public final static transient String panNECmd = "panNE";
    public final static transient String panECmd = "panE";
    public final static transient String panSECmd = "panSE";
    public final static transient String panSCmd = "panS";
    public final static transient String panSWCmd = "panSW";
    public final static transient String panWCmd = "panW";
    public final static transient String centerCmd = "center";

    protected static transient JButton nwButton = null;
    protected static transient JButton nButton = null;
    protected static transient JButton neButton = null;
    protected static transient JButton eButton = null;
    protected static transient JButton seButton = null;
    protected static transient JButton sButton = null;
    protected static transient JButton swButton = null;
    protected static transient JButton wButton = null;
    protected static transient JButton cButton = null;

    // default icon names
    protected static transient String nwName = "nw.gif";
    protected static transient String nName = "n.gif";
    protected static transient String neName = "ne.gif";
    protected static transient String eName = "e.gif";
    protected static transient String seName = "se.gif";
    protected static transient String sName = "s.gif";
    protected static transient String swName = "sw.gif";
    protected static transient String wName = "w.gif";
    protected static transient String cName = "center.gif";

    protected PanSupport panDelegate;
    protected CenterSupport centerDelegate;
    protected boolean useTips = false;
    protected double panFactor = 1d;

    protected int height = 0; // calculated
    protected int width = 0; // calculated


    /**
     * Construct the NavigationPanel.
     */
    public NavigatePanel() {
	super();
	panDelegate = new PanSupport(this);
	centerDelegate = new CenterSupport(this);

// 	GridLayout layout = new GridLayout(3,3);
// 	layout.setHgap(20);
// 	layout.setVgap(20);
	setLayout(/*layout*/new GridLayout(3, 3));
// 	setAlignmentX(LEFT_ALIGNMENT);
// 	setAlignmentY(TOP_ALIGNMENT);

	int w, h;

	// begin top row
	ImageIcon nwIcon = addImageIcon(new ImageIcon(), nwName, "northwest");
	w = nwIcon.getIconWidth();
	h = nwIcon.getIconHeight();
	nwButton = new JButton(nwIcon);
	nwButton.setMargin(new Insets(0,0,0,0));
        nwButton.setActionCommand(panNWCmd);
	nwButton.addActionListener(this);
	nwButton.setMinimumSize(new Dimension(w+2,h+2));
	nwButton.setPreferredSize(new Dimension(w+2,h+2));
	nwButton.setBorderPainted(false);
	height += h+2;
	width += w+2;
	add(nwButton);

	ImageIcon nIcon = addImageIcon(new ImageIcon(), nName, "north");
	w = nIcon.getIconWidth();
	h = nIcon.getIconHeight();
	nButton = new JButton(nIcon);
	nButton.setMargin(new Insets(0,0,0,0));
        nButton.setActionCommand(panNCmd);
	nButton.addActionListener(this);
	nButton.setMinimumSize(new Dimension(w+2,h+2));
	nButton.setPreferredSize(new Dimension(w+2,h+2));
	nButton.setBorderPainted(false);
	width += w+2;
	add(nButton);

	ImageIcon neIcon = addImageIcon(new ImageIcon(), neName, "northeast");
	w = neIcon.getIconWidth();
	h = neIcon.getIconHeight();
	neButton = new JButton(neIcon);
	neButton.setMargin(new Insets(0,0,0,0));
        neButton.setActionCommand(panNECmd);
	neButton.addActionListener(this);
	neButton.setMinimumSize(new Dimension(w+2,h+2));
	neButton.setPreferredSize(new Dimension(w+2,h+2));
	neButton.setBorderPainted(false);
	width += w+2;
	add(neButton);

	// begin middle row
	ImageIcon wIcon = addImageIcon(new ImageIcon(), wName, "west");
	w = wIcon.getIconWidth();
	h = wIcon.getIconHeight();
	wButton = new JButton(wIcon);
	wButton.setMargin(new Insets(0,0,0,0));
        wButton.setActionCommand(panWCmd);
	wButton.addActionListener(this);
	wButton.setMinimumSize(new Dimension(w+2,h+2));
	wButton.setPreferredSize(new Dimension(w+2,h+2));
	wButton.setBorderPainted(false);
	height += h+2;
	add(wButton);

	ImageIcon cIcon = addImageIcon(new ImageIcon(), cName, "center");
	w = cIcon.getIconWidth();
	h = cIcon.getIconHeight();
	cButton = new JButton(cIcon);
	cButton.setMargin(new Insets(0,0,0,0));
        cButton.setActionCommand(centerCmd);
	cButton.addActionListener(this);
	cButton.setMinimumSize(new Dimension(w+2,h+2));
	cButton.setPreferredSize(new Dimension(w+2,h+2));
	cButton.setBorderPainted(false);
	add(cButton);

	ImageIcon eIcon = addImageIcon(new ImageIcon(), eName, "east");
	w = eIcon.getIconWidth();
	h = eIcon.getIconHeight();
	eButton = new JButton(eIcon);
	eButton.setMargin(new Insets(0,0,0,0));
        eButton.setActionCommand(panECmd);
	eButton.addActionListener(this);
	eButton.setMinimumSize(new Dimension(w+2,h+2));
	eButton.setPreferredSize(new Dimension(w+2,h+2));
	eButton.setBorderPainted(false);
	add(eButton);

	// begin bottom row
	ImageIcon swIcon = addImageIcon(new ImageIcon(), swName, "southwest");
	w = swIcon.getIconWidth();
	h = swIcon.getIconHeight();
	swButton = new JButton(swIcon);
	swButton.setMargin(new Insets(0,0,0,0));
        swButton.setActionCommand(panSWCmd);
	swButton.addActionListener(this);
	swButton.setMinimumSize(new Dimension(w+2,h+2));
	swButton.setPreferredSize(new Dimension(w+2,h+2));
	swButton.setBorderPainted(false);
	height += h+2;
	add(swButton);

	ImageIcon sIcon = addImageIcon(new ImageIcon(), sName, "south");
	w = sIcon.getIconWidth();
	h = sIcon.getIconHeight();
	sButton = new JButton(sIcon);
	sButton.setMargin(new Insets(0,0,0,0));
        sButton.setActionCommand(panSCmd);
	sButton.addActionListener(this);
	sButton.setMinimumSize(new Dimension(w+2,h+2));
	sButton.setPreferredSize(new Dimension(w+2,h+2));
	sButton.setBorderPainted(false);
	add(sButton);

	ImageIcon seIcon = addImageIcon(new ImageIcon(), seName, "southeast");
	w = seIcon.getIconWidth();
	h = seIcon.getIconHeight();
	seButton = new JButton(seIcon);
	seButton.setMargin(new Insets(0,0,0,0));
        seButton.setActionCommand(panSECmd);
	seButton.addActionListener(this);
	seButton.setMinimumSize(new Dimension(w+2,h+2));
	seButton.setPreferredSize(new Dimension(w+2,h+2));
	seButton.setBorderPainted(false);
	add(seButton);
    }


    /**
     * Create an ImageIcon.
     * @param imageIcon ImageIcon
     * @param imageName file name
     * @param imageTip text help
     * @return ImageIcon
     */
    protected ImageIcon addImageIcon(ImageIcon imageIcon, 
				     String imageName, 
				     String imageTip) {
	URL url = this.getClass().getResource(imageName);
	imageIcon = new ImageIcon(url, imageTip);
	return imageIcon;
    }


    /**
     * Add a CenterListener.
     * @param listener CenterListener
     */
    public synchronized void addCenterListener (CenterListener listener)
    {
	centerDelegate.addCenterListener(listener);
    }


    /**
     * Remove a CenterListener
     * @param listener CenterListener
     */
    public synchronized void removeCenterListener (CenterListener listener) {
	centerDelegate.removeCenterListener(listener);
    }


    /**
     * Add a PanListener.
     * @param listener PanListener
     */
    public synchronized void addPanListener (PanListener listener)
    {
	panDelegate.addPanListener(listener);
    }


    /**
     * Remove a PanListener
     * @param listener PanListener
     */
    public synchronized void removePanListener (PanListener listener) {
	panDelegate.removePanListener(listener);
    }


    /**
     * Fire a CenterEvent.
     * @param direction int
     */
    protected synchronized void fireCenterEvent (double lat, double lon) {
	centerDelegate.fireCenter(lat, lon);
    }


    /**
     * Fire a PanEvent.
     * @param az azimuth east of north
     */
    protected synchronized void firePanEvent (double az) {
	panDelegate.firePan(az);
    }


    /**
     * Get the useToolTips value.
     * @return boolean useTips
     */
    public boolean getUseToolTips() {
	return useTips;
    }

    /**
     * Return the sum of the heights of the icons.
     * @return height
     */
    public int getHeight(){
	return height;
    }

    /**
     * Return the sum of the widths of the icons.
     * @return width
     */
    public int getWidth(){
	return width;
    }

    /**
     * Set the useToolTips value.
     * @param tip useToolTips value.
     */
    public void setUseToolTips(boolean tip)
    {
	if (tip){
	    useTips = true;
	    nwButton.setToolTipText("Pan Northwest");
	    nButton.setToolTipText("Pan North");
	    neButton.setToolTipText("Pan Northeast");
	    wButton.setToolTipText("Pan West");
	    eButton.setToolTipText("Pan East");
	    swButton.setToolTipText("Pan Southwest");
	    sButton.setToolTipText("Pan South");
	    seButton.setToolTipText("Pan Southeast");
	    cButton.setToolTipText("Center Map at Starting Coords");
	}
	else {
	    useTips = false;
	    nwButton.setToolTipText("");
	    nButton.setToolTipText("");
	    neButton.setToolTipText("");
	    wButton.setToolTipText("");
	    eButton.setToolTipText("");
	    swButton.setToolTipText("");
	    sButton.setToolTipText("");
	    seButton.setToolTipText("");
	    cButton.setToolTipText("");
	}			
    }


    /**
     * Get the pan factor.
     * <p>
     * The panFactor is the amount of screen to shift
     * when panning in a certain direction: 0=none, 1=half-screen shift.
     * @return double panFactor (0.0 &lt;= panFactor &lt;= 1.0)
     */
    public double getPanFactor() {
	return panFactor;
    }


    /**
     * Set the pan factor.
     * <p>
     * This defaults to 1.0.  The panFactor is the amount of screen to shift
     * when panning in a certain direction: 0=none, 1=half-screen shift.
     * @param panFactor (0.0 &lt;= panFactor &lt;= 1.0)
     */
    public void setPanFactor(double panFactor) {
	if ((panFactor < 0d) || (panFactor > 1d))
	    throw new IllegalArgumentException(
		    "should be: (0.0 <= panFactor <= 1.0)");
	this.panFactor = panFactor;
    }


    /**
     * ActionListener Interface.
     * @param e ActionEvent
     */
    public void actionPerformed(java.awt.event.ActionEvent e) {

	String command = e.getActionCommand();

	Debug.message("navpanel", "NavigatePanel.actionPerformed(): " +
		      command);
	if (command.equals(panNWCmd)) {
	    firePanEvent(-45d);
	}
	else if (command.equals(panNCmd)) {
	    firePanEvent(0d);
	}
	else if (command.equals(panNECmd)) {
	    firePanEvent(45d);
	}
	else if (command.equals(panECmd)) {
	    firePanEvent(90d);
	}
	else if (command.equals(panSECmd)) {
	    firePanEvent(135d);
	}
	else if (command.equals(panSCmd)) {
	    firePanEvent(180d);
	}
	else if (command.equals(panSWCmd)) {
	    firePanEvent(-135d);
	}
	else if (command.equals(panWCmd)) {
	    firePanEvent(-90d);
	}
	else if (command.equals(centerCmd)) {
	    // go back to the center point
	    double lat = Environment.getDouble(Environment.Latitude, 0d);
	    double lon = Environment.getDouble(Environment.Longitude, 0d);
	    fireCenterEvent(lat, lon);
	}
    }
}

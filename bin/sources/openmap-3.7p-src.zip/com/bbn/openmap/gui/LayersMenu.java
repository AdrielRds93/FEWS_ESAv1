/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/gui/LayersMenu.java,v $
 * $Revision: 1.32 $
 * $Date: 2000/07/27 14:51:52 $
 * $Author: dietrick $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.gui;

import com.bbn.openmap.Environment;
import com.bbn.openmap.Layer;
import com.bbn.openmap.event.LayerSupport;
import com.bbn.openmap.util.Debug;
import com.bbn.openmap.util.PaletteHelper;

import javax.swing.JCheckBoxMenuItem;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JLayeredPane;
import javax.swing.JMenu;
import javax.swing.event.InternalFrameEvent;
import javax.swing.event.InternalFrameListener;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.io.Serializable;

/**
 * The LayersMenu is a JMenu which is a list of the layers of the map.
 * This list defaults to being checkbuttons which add and remove the named
 * layer to/from the Map.
 * You can also use an instance of this object to show/hide layer palettes.
 */
public class LayersMenu extends JMenu implements Serializable {

    /**
     * This menu turns layers on and off.
     */
    public static final transient int LAYERS_ON_OFF = 1;
    public static final transient int PALETTES_ON_OFF = 2;

    protected transient JLayeredPane desktop = null;
    protected transient LayerSupport layerDelegate;
    protected int menuType=-1;

    protected transient LayerHandler layerHandler;

    /**
     * Construct LayersMenu.
     * @param inLayers the Layers
     */
    public LayersMenu(LayerHandler lHandler) {
	this (lHandler, "Layers", LAYERS_ON_OFF);
	setMnemonic('L');//HMMMM
    }

    /**
     * Construct LayersMenu.
     * @param inLayers the Layers
     * @param menuName the name of the menu
     * @param menuType either LAYERS_ON_OFF, or PALETTES_ON_OFF
     */
    public LayersMenu(LayerHandler lHandler, String menuName, int menuType) {
	super(menuName);
	this.menuType = menuType;
	layerDelegate = new LayerSupport(this);
	
	layerHandler = lHandler;

	// Layers will be turned on by something else initially.
	setLayers(layerHandler.allLayers);
    }

    /**
     * Set the layers that are on the menu.  Calls setLayers(layers, true);
     * @param inLayers the array of layers.
     */
    public void setLayers(Layer[] inLayers){

	removeAll();

	// Set everything up for the new layers
	if (inLayers == null){
	    if(Debug.debugging("layersmenu")){
		Debug.error("LayersMenu.setLayers(): Layers are null.");
	    }
	} else {
	    for (int i=0; i<inLayers.length; i++) {
		LayerCheckBoxMenuItem cbs = 
		    new LayerCheckBoxMenuItem(inLayers[i]);
		add(cbs);
	    }
	}
    }

    /**
     * Sets the Desktop.
     * @param desktop the desktop on which to display the LayersPanel
     */
    public void setDesktop(JLayeredPane desktop) {
	this.desktop = desktop;
    }

    /**
     * Gets the Desktop.
     * @return JDesktop
     */
    public JLayeredPane getDesktop() {
	return desktop;
    }

    /**
     * Remove all the components from the menu.  Also calls cleanup()
     * on all the LayerCheckBoxMenuItems, so they can remove
     * themselves from their layers.  
     */
    public void removeAll(){
	Component[] components = getMenuComponents();

	if (components.length > 0){
	    Debug.message("layersmenu", "LayersMenu.removeAll(): purging menu");
	}

	for (int i = 0; i < components.length; i++){
	    if (components[i] instanceof LayerCheckBoxMenuItem){
		((LayerCheckBoxMenuItem)components[i]).cleanup();
	    }
	}
	super.removeAll();
    }

    /**
     * Update the layer names.
     */
    public synchronized void updateLayerLabels(){
	setLayers(layerHandler.allLayers);
    }

    /**
     * CheckBoxMenuItem that encapsulates a Layer.
     */
    class LayerCheckBoxMenuItem
	extends JCheckBoxMenuItem
	implements ActionListener, InternalFrameListener, ComponentListener
    {
        Layer layer;
	JInternalFrame paletteWindow;
	JFrame paletteWindow2;

        LayerCheckBoxMenuItem (Layer aLayer) {
           if (aLayer == null) {
               throw new IllegalArgumentException("null Layer");
           }
           layer = aLayer;
           setText(layer.getName());
	   setState(layer.isVisible());

           addActionListener(this);
	   layer.addComponentListener(this);
	}

	/** Get the layer for this checkbox. */      
        public Layer getLayer() {
	    return layer;
	}

	/** Disconnect all the listeners from the layer, clean up
	 *  other references. */
	public void cleanup(){
	    layer.removeComponentListener(this);
	    removeActionListener(this);
	    layer = null;
	}

	/** If this widget is being used for bringing up palettes,
	 *  bring up the layer's palette.*/
	protected void showPalette () {
	    if (Environment.getBoolean(Environment.UseInternalFrames)){
		// get the window
		paletteWindow = PaletteHelper.getPaletteInternalWindow(layer, this);

		// add the window to the desktop
		desktop.add(paletteWindow);
	    } else {
		if (paletteWindow2 == null)
		    paletteWindow2 = PaletteHelper.getPaletteWindow(layer, this);
		paletteWindow2.setVisible(true);
	    }
	}


	/** If this widget is being used for bringing up palettes,
	 *  hide the layer's palette.*/
	protected void hidePalette () {
	    if (Environment.getBoolean(Environment.UseInternalFrames)){
		if (paletteWindow == null)
		    return;
		
		// close the palette
		try { paletteWindow.setClosed(true); }
		catch (java.beans.PropertyVetoException evt) {
		    com.bbn.openmap.util.Assert.assertTrue(
			false, "LayersPanel.hidePalette(): " +
			"internal error!");
		}
	    } else {

		if (paletteWindow2 == null) return;
		else paletteWindow2.setVisible(false);
	    }
	}

	// ActionListener interface
	public void internalFrameActivated(InternalFrameEvent e){}
	public void internalFrameClosing(InternalFrameEvent e){}
	public void internalFrameDeactivated(InternalFrameEvent e){}
	public void internalFrameDeiconified(InternalFrameEvent e){}
	public void internalFrameIconified(InternalFrameEvent e){}
	public void internalFrameOpened(InternalFrameEvent e){}
	public void internalFrameClosed(InternalFrameEvent e) {
	    desktop.remove(paletteWindow);
	    desktop.repaint();
	    paletteWindow = null;
	    setState(false);
	}

	// Component Listener interface
	public void componentResized(ComponentEvent e){}
	public void componentMoved(ComponentEvent e){}
	public void componentShown(ComponentEvent e){
	    if (e.getComponent() == layer){
		if (getState() != true) {
		    setState(true);
		    if (Debug.debugging("layersmenu")){
			Debug.output("layersmenu.LCBMI: layer " + layer.getName() +
				     " is now visible.");
		    }
		}
	    }
	}
	public void componentHidden(ComponentEvent e){
	    if (e.getComponent() == layer){
		if (getState() != false){
		    setState(false);
		    if (Debug.debugging("layersmenu")){
			Debug.output("layersmenu.LCBMI: layer " + layer.getName() +
				     " is now hidden.");
		    }
		}
	    }
	}

        public void actionPerformed (ActionEvent e) {

            if (!this.equals(e.getSource())) {
	        System.err.println("Wiring is hopelessly wrong in LayersMenu");
	    }
	    switch (menuType) {
		case LAYERS_ON_OFF:
		    layerHandler.turnLayerOn(getState(), layer);
		    break;
		case PALETTES_ON_OFF:
		    if (getState())
			showPalette();
		    else
			hidePalette();
		    break;
		default:
		    System.err.println(
			    "LayersMenu: unknown menuType!");
	    }
	}
    }
}

/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/gui/OMToolSet.java,v $
 * $Revision: 1.7 $
 * $Date: 2000/07/27 19:30:48 $
 * $Author: dietrick $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.gui;

import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import java.io.Serializable;
import java.net.URL;

import javax.swing.*;
import javax.swing.border.*;

import com.bbn.openmap.*;
import com.bbn.openmap.event.*;
import com.bbn.openmap.proj.Projection;
import com.bbn.openmap.util.Debug;


/**
 * The OMToolSet bundles other control beans, and is a Tool used in
 * the OpenMap application.
 * <p>
 * It contains a NavigatePanel, which is the directional rosette used
 * to pan the MapBean, the ZoomPanel that has a zoom in and zoom out
 * button, and a scale text window.  To use the OMToolSet, create an
 * instance of it, and then call setupListeners() with the MapBean.
 * All the event handling is automatically set up.
 * <p>
 * The Tool Set also has a selection widget that displays the
 * MouseModes available for the MapBean.  These can be set with the
 * addMouseModes() method.
 * */
public class OMToolSet extends Tool
    implements Serializable, ActionListener, ProjectionListener
{

    public transient final static String setScaleCmd = "setScale";
    public transient final static String showLayersCmd = "showLayersPanel";
    public transient final static String popupNavPanel = "navigatePopup";
    public transient final static String editLayersCmd = "editLayers";

    protected transient JPanel face = null;

    protected transient JTextField scaleField = null;

    protected transient NavigatePanel navPanel = null;
    protected transient ZoomPanel zoomPanel=null;

    protected transient ZoomSupport zoomDelegate=null;

    protected transient OverviewMapHandler overviewMap = null;

    protected Projection projection;
    protected ProjectionSupport projectionSupport;

    protected transient java.text.DecimalFormat df = new java.text.DecimalFormat();

    /**
     * Create the OMToolSet.
     */
    public OMToolSet() {
	this(null);
    }

    public OMToolSet(LayerHandler lh) {

	super("omtoolset");
	Debug.message("omtoolset", "OMToolSet()");

	face = new JPanel(new FlowLayout(FlowLayout.LEFT));
	projectionSupport = new ProjectionSupport(this);

	zoomDelegate = new ZoomSupport(this);
	navPanel = new NavigatePanel();
	navPanel.setPreferredSize(new Dimension(navPanel.getWidth(), 
						navPanel.getHeight()));
	navPanel.setMaximumSize(new Dimension(navPanel.getWidth(), 
					      navPanel.getHeight()));
	navPanel.setUseToolTips(true);
	face.add(navPanel);

	zoomPanel = new ZoomPanel();
	face.add(zoomPanel);
	addScaleEntry(setScaleCmd, "Scale", ""); // scale
    }
    
    public Container getFace(){
	return face;
    }

    /**
     * Called to set the scale setting on the scale text object.
     */
    public synchronized void setProjection(Projection aProjection) {
	projection = aProjection;
	if (Debug.debugging("omtoolset")) {
	System.out.println("OMToolSet.setProjection(): scale is " +
			   projection.getScale() + " \"" +
			   String.valueOf(projection.getScale()) + "\"");
	}
	scaleField.setText(df.format(projection.getScale()));
    }

    /**
     * Add a ZoomListener to the listener list. 
     *
     * @param listener  The ZoomListener to be added
     */
    public synchronized void addZoomListener(ZoomListener listener) {
	zoomDelegate.addZoomListener(listener);
	zoomPanel.addZoomListener(listener);
    }

    /**
     * Remove a ZoomListener from the listener list.
     *
     * @param listener  The ZoomListener to be removed
     */
    public synchronized void removeZoomListener(ZoomListener listener) {
	zoomDelegate.removeZoomListener(listener);
	zoomPanel.removeZoomListener(listener);
    }
 
    /**
     * Add a CenterListener to the listener list.
     *
     * @param listener  The CenterListener to be added
     */
    public synchronized void addCenterListener(CenterListener listener) {
	navPanel.addCenterListener(listener);
    }

    /**
     * Remove a CenterListener from the listener list.
     *
     * @param listener  The CenterListener to be removed
     */
    public synchronized void removeCenterListener(CenterListener listener) {
	navPanel.removeCenterListener(listener);
    }

    /**
     * Add a PanListener to the listener list.
     *
     * @param listener  The PanListener to be added
     */
    public synchronized void addPanListener(PanListener listener) {
	navPanel.addPanListener(listener);
    }

    /**
     * Remove a PanListener from the listener list.
     *
     * @param listener  The PanListener to be removed
     */
    public synchronized void removePanListener(PanListener listener) {
	navPanel.removePanListener(listener);
    }

    /** Add a widget to the OMToolSet. */
    public void add(JComponent component){
	if (component != null){
	    face.add(component);
	}
    }

    /** Add a widget to the OMToolSet. */
    public void remove(JComponent component){
	if (component != null){
	    face.remove(component);
	}
    }

    /** 
     * Add a layers panel button to the OMToolSet.
     */
    public void addLayerPanelButton(LayerHandler lh){
	JButton layerButton = new JButton(new ImageIcon(OMToolSet.class.getResource("layers.gif"), "Layer Controls"));
	layerButton.setBorderPainted(false);
	layerButton.setToolTipText("Layer Controls");
	layerButton.setMargin(new Insets(0,0,0,0));
	layerButton.addActionListener(lh.getLayersPanelActionListener());
	add(layerButton);
    }

    /**
     * Return the overview map handler.  Returns null if it hasn't
     * been added to the OMToolSet.
     */
    public OverviewMapHandler getOverviewMapHandler(){
	return overviewMap;
    }

    /**
     * Create a overview map, and add a button to call it up to the OMToolSet.
     * @param props Properties to use to configure the overview map.
     */
    public void addOverviewMapButton(MapBean sourceMap, 
				     java.util.Properties props){
	try {
	    overviewMap = new OverviewMapHandler(props);
	} catch (Exception e){
	    return;
	}

	JButton overviewButton = new JButton(new ImageIcon(OMToolSet.class.getResource("overview.gif"), "Overview Map"));
	overviewButton.setBorderPainted(false);
	overviewButton.setToolTipText("Overview Map");
	overviewButton.setMargin(new Insets(0,0,0,0));
	
	overviewButton.addActionListener(overviewMap.getOverviewFrameActionListener(
	    sourceMap, true, "Overview"));
	add(overviewButton);
    }

    /**
     *  Creates and adds a MouseModePanel to the OMToolSet.
     *  @param md MouseDelegator
     */
    public void addMouseModes(MouseDelegator md) {
	if (md != null){
            MouseModePanel mmp = new MouseModePanel(md);
	    face.add(mmp);
	}
    }

    /**
     * Convenience function to set up listeners of the components.
     * If you are hooking the MapBean up to the OMToolSet, this is one
     * of two methods you need to call.  The other is addMouseModes(),
     * if the MapBean has more than one Mouse Mode.
     *
     * @param aMap a map object
     */
    public void setupListeners(MapBean aMap) {
 	// Wire up the beans for event passing

	addPanListener(aMap);

	addZoomListener(aMap);

	addCenterListener(aMap);

	aMap.addProjectionListener(this);

 	// set the scaleEntry
 	scaleField.setText(String.valueOf(aMap.getScale()));
    }

    /**
     * Get the ZoomPanel
     * @return the ZoomPanel
     */
    public ZoomPanel getZoomPanel(){
	return zoomPanel;
    }

    /**
     * Get the NavigatePanel.
     * @return the NaviationPanel (directional rosette)
     */
    public NavigatePanel getNavigatePanel() {
	return navPanel;
    }

    /**
     * Adds a text entry widget to tool panel.
     * @param command String command name
     * @param info ToolTip text
     * @param entry om entry
     */
    protected void addScaleEntry(String command, String info, String entry) {
	scaleField = new JTextField(entry, 10);
	Dimension dim = scaleField.getPreferredSize();
	dim.height = 25;
	scaleField.setPreferredSize(dim);
	scaleField.setPreferredSize(new Dimension(90, 25));
	scaleField.setMinimumSize(new Dimension(90, 25));
	scaleField.setMaximumSize(new Dimension(100, 25));

	scaleField.setToolTipText(info);
	scaleField.setMargin(new Insets(0,0,0,0));
        scaleField.setActionCommand(command);
	scaleField.addActionListener(this);
	face.add(scaleField);
    }

    /**
     * Add a button to the panel.
     * @param name image filename
     * @param info tool tip
     * @param al ActionListener
     */
    public void addButton(String name, String info, ActionListener al) {
	URL url = OMToolSet.class.getResource(name);
	JButton b = new JButton(new ImageIcon(url, info));
	b.setToolTipText(info);
	b.setMargin(new Insets(0,0,0,0));
	b.addActionListener(al);
	face.add(b);
    }

    /**
     * ActionListener interface.
     * @param e ActionEvent
     */
    public void actionPerformed(java.awt.event.ActionEvent e) {
// 	System.out.println("Action: " + e);

	String command = e.getActionCommand();

	Debug.message("omtoolset", "OMToolSet.actionPerformed(): " + command);
	if (command.equals(setScaleCmd)) {
	    setScale(scaleField.getText());
	}
    }

    protected void fireScaleChange (double scale) {
	zoomDelegate.fireZoom(ZoomEvent.ABSOLUTE, scale);
    }

    //set the scale of the map.
    private void setScale(String strscale) {
	double scale;

	try {
	    if (strscale.toLowerCase().endsWith("m")) {
		strscale = strscale.substring(0, strscale.length()-1);
		scale = df.parse(strscale).floatValue() * 1000000d;
		if (scale < 1d)
		    System.err.println("OMToolSet.applyScale(): problem");
		else
		    fireScaleChange(scale);
	    }
	    else if (strscale.toLowerCase().endsWith("k")) {
		strscale = strscale.substring(0, strscale.length()-1);
		scale = df.parse(strscale).floatValue() * 1000d;
		if (scale < 1d)
		    System.err.println("OMToolSet.applyScale(): problem");
		else
		    fireScaleChange(scale);
	    }
	    else if (strscale.trim().equals("")) {
		return;	// ignore empty string
	    }
	    else {
	        scale = df.parse(strscale).floatValue();
		if (scale < 1d)
		    System.err.println("OMToolSet.applyScale(): problem");
		else
		    fireScaleChange(scale);
	    }
	} catch (java.text.ParseException e) {
	    System.err.println("OMToolSet.setScale(): invalid scale: " +
			       strscale);
	} catch (NumberFormatException e) {
	    System.err.println("OMToolSet.setScale(): invalid scale: " +
			       strscale);
	}
    }

    //------------------------------------------------------------
    // ProjectionListener interface
    //------------------------------------------------------------

    /**
     * ProjectionListener interface method.
     * @param e ProjectionEvent
     */
    public void projectionChanged (ProjectionEvent e) {
	if (Debug.debugging("omtoolset")) {
	System.out.println("OMToolSet.projectionChanged()");
	}
	Projection newProj = e.getProjection();
	if (projection == null ||  (! projection.equals(newProj))) {
	    setProjection(newProj.makeClone());
	}
    }

    /*
    public static void main(String[] args) {
	// Create a window.  Use JFrame since this window will include 
	// lightweight components.
	JFrame frame = new JFrame("OMToolSet");


	WindowListener l = new WindowAdapter() {
	    public void windowClosing(WindowEvent e) {System.exit(0);}
	};
	frame.addWindowListener(l);
	OMToolSet tools = new OMToolSet();
	//Map map = new MapPanel();
	//tools.setMap(map);
	ZoomPanel zp = tools.getZoomPanel();
	zp.setZoomInFactor(0.9f);
	zp.setZoomOutFactor(4.5f);

	frame.getContentPane().add("Center", tools);
	frame.pack();
	frame.show();
    }
    */

}

/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/gui/LayersPanel.java,v $
 * $Revision: 1.33 $
 * $Date: 2000/08/17 21:42:53 $
 * $Author: dietrick $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.gui;

import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import java.io.Serializable;
import java.net.URL;

import javax.swing.*;
import javax.accessibility.*;

import com.bbn.openmap.util.Debug;
import com.bbn.openmap.*;
import com.bbn.openmap.event.LayerEvent;
import com.bbn.openmap.event.LayerListener;
import com.bbn.openmap.event.LayerSupport;

/**
 *  The LayersPanel displays the list of layers that OpenMap can display.
 *  The layer name is displayed accompanied by an on/off button and a
 *  tool palette button. Pressing the on/off button will cause the the
 *  map to display/remove the layer. Pressing the tool palette button 
 *  will cause a window to be displayed containing widgets specific to 
 *  that layer.
 *  <p>
 *  The order of the layers in the list reflects the order the layers
 *  are displayed on the map, with the bottom-most layer listed on the
 *  panel underneath all the the other layers displayed on the map.
 *  The order of the layers is originally determined by their order
 *  in the overlay table.
 *  <p>
 *  The order can be changed by selecting a layer
 *  by clicking on the layer's name (or on either of buttons), then
 *  clicking on one of the four buttons on the left side of the panel.
 *  The four buttons signify, from top to bottom:  Move the selected
 *  layer to the top; Move the selected layer up one position; Move
 *  the selected layer down one position; Move the selected layer to
 *  the bottom.
 *  
 */
public class LayersPanel extends JPanel
    implements Serializable, ActionListener
{
    // action commands
    public transient final static String LayerTopCmd = "LayerTopCmd";
    public transient final static String LayerBottomCmd = "LayerBottomCmd";
    public transient final static String LayerUpCmd = "LayerUpCmd";
    public transient final static String LayerDownCmd = "LayerDownCmd";
    
    // Properties
    public static final String LayersOrderProperty = "order";
    
    // Images
    protected static transient URL urlup;
    protected static transient ImageIcon upgif;
    protected static transient URL urlupc;
    protected static transient ImageIcon upclickedgif;
    protected static transient URL urltop;
    protected static transient ImageIcon topgif;
    protected static transient URL urltopc;
    protected static transient ImageIcon topclickedgif;
    protected static transient URL urldown;
    protected static transient ImageIcon downgif;
    protected static transient URL urldownc;
    protected static transient ImageIcon downclickedgif;
    protected static transient URL urlbottom;
    protected static transient ImageIcon bottomgif;
    protected static transient URL urlbottomc;
    protected static transient ImageIcon bottomclickedgif;

    protected transient LayerHandler layerHandler = null;

    // the layers
    protected transient LayerPane[] panes;
    protected transient JPanel panesPanel;
    protected transient JScrollPane scrollPane;
    protected transient ButtonGroup bg = new ButtonGroup();

    /**
     * Static default initializations.
     */
    static {
	urlup = LayersPanel.class.getResource("Up.gif");
	upgif = new ImageIcon(urlup, "Up");

	urlupc = LayersPanel.class.getResource("Up.gif");
	upclickedgif = new ImageIcon(urlupc, "Up (clicked)");

	urltop = LayersPanel.class.getResource("DoubleUp.gif");
	topgif = new ImageIcon(urltop, "Top");

	urltopc = LayersPanel.class.getResource("DoubleUp.gif");
	topclickedgif = new ImageIcon(urltopc, "Top (clicked)");

	urldown = LayersPanel.class.getResource("Down.gif");
	downgif = new ImageIcon(urldown, "Down");

	urldownc = LayersPanel.class.getResource("Down.gif");
	downclickedgif = new ImageIcon(urldownc, "Down (clicked)");

	urlbottom = LayersPanel.class.getResource("DoubleDown.gif");
	bottomgif = new ImageIcon(urlbottom, "Bottom");

	urlbottomc = LayersPanel.class.getResource("DoubleDown.gif");
	bottomclickedgif = new ImageIcon(urlbottomc, "Bottom (clicked)");
    }


    /**
     * Construct the LayersPanel.
     * <p>
     * The desktop is used to place the layer palette into the view
     * hierarchy when it is selected.
     * @param lHandler the LayerHandler controlling the layers
     */
    public LayersPanel(LayerHandler lHandler){
	super();
	this.layerHandler = lHandler;

	// lay out all widgets horizontally
	setLayout(new BoxLayout(this, BoxLayout.X_AXIS));
	setAlignmentX(LEFT_ALIGNMENT);
	setAlignmentY(TOP_ALIGNMENT);

	// create layer mover buttons
	JPanel buttonPanel = createButtonPanel();
  	add(buttonPanel);

	setLayers(layerHandler.getLayers());
    }

    /**
     * Set the layers that are in the LayersPanel.  This method
     * creates the on/off buttons, palette buttons, and layer labels.
     * Make sure that the layer[] is the same as that passed to any
     * other OpenMap component, like the LayersMenu.
     *
     * @param inLayers the array of layers.  
     */
    public void setLayers(Layer[] inLayers){
	Layer[] layers = inLayers;

	if (inLayers == null){
	    layers = new Layer[0];
	}

	if (Debug.debugging("layerspanel")){
	    Debug.output("LayersPanel.setLayers() with " + 
			 layers.length + " layers.");
	}

	if (panes == null || panes.length != layers.length){
	    // if the panel hasn't been created yet, or if someone has
	    // changed the layers on us, rebuild the panel.
	    createPanel(layers);
	    return;
	}

	for (int i = 0; i < layers.length; i++){
	    if (panes[i].getLayer() != layers[i]){
		// If the layer order sways at all, then we start over
		// and rebuild the panel
		createPanel(layers);
		return;
	    } else {
		panes[i].updateLayerLabel();
	    }

	    // Do this just in case someone has changed something
	    // somewhere else...
	    panes[i].setLayerOn(layers[i].isVisible());
	}
	//  If we get here, it means that what we had is what we
	//  wanted.
    }

    public void createPanel(Layer[] inLayers){
	Debug.message("layerspanel", "LayersPanel.createPanel()");

	if (scrollPane != null){
	    remove(scrollPane);
	}

	Layer[] layers = inLayers;
	if (layers == null){
	    layers = new Layer[0];
	}

	panes = new LayerPane[inLayers.length];

	panesPanel = new JPanel();
	panesPanel.setLayout(new BoxLayout(panesPanel, BoxLayout.Y_AXIS));
	panesPanel.setAlignmentX(LEFT_ALIGNMENT);
	panesPanel.setAlignmentY(BOTTOM_ALIGNMENT);

	// populate the arrays of CheckBoxs and strings used to fill the JTable
	for (int i = 0; i < inLayers.length; i++) {
	    panes[i] = new LayerPane(inLayers[i], layerHandler, bg);
	    panesPanel.add(panes[i]);
        }
	
	if (scrollPane != null){
	    remove(scrollPane);
	}

	scrollPane = new JScrollPane(panesPanel, 
				     ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
				     ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
	add(scrollPane);
	revalidate();
    }	

    // sets up the buttons used to move layers up and down
    protected JPanel createButtonPanel() {

  	JPanel buttonPanel = new JPanel();
  	buttonPanel.setAlignmentX(LEFT_ALIGNMENT);
  	buttonPanel.setAlignmentY(CENTER_ALIGNMENT);
  	buttonPanel.setLayout( 
  	    new BoxLayout(buttonPanel, BoxLayout.Y_AXIS));

  	JButton top = new JButton(topgif);
	top.setActionCommand(LayerTopCmd);
	top.setPressedIcon(topclickedgif);
	top.setToolTipText("Move selected layer to top");
	top.addActionListener(this);
  	buttonPanel.add(top);

  	JButton up = new JButton(upgif);
	up.setActionCommand(LayerUpCmd);
	up.setPressedIcon(upclickedgif);
	up.setToolTipText("Move selected layer up one");
	up.addActionListener(this);
  	buttonPanel.add(up);

  	JButton down = new JButton(downgif);
	down.setPressedIcon(downclickedgif);
	down.setActionCommand(LayerDownCmd);
	down.setToolTipText("Move selected layer down one");
	down.addActionListener(this);
  	buttonPanel.add(down);

  	JButton bottom = new JButton(bottomgif);
	bottom.setPressedIcon(bottomclickedgif);
	bottom.setActionCommand(LayerBottomCmd);
	bottom.setToolTipText("Move selected layer to bottom");
	bottom.addActionListener(this);
  	buttonPanel.add(bottom);
	return buttonPanel;
    }


    /**
     * ActionListener interface.
     * @param e ActionEvent
     */
    public void actionPerformed(java.awt.event.ActionEvent e) {

	String command = e.getActionCommand();

	if (Debug.debugging("layerspanel")){
	    Debug.output("LayersPanel.actionPerformed(): " + command);
	}

	if (command.equals(LayerTopCmd)) {
	    // Move layer selected layer to top
	    LayerPane lp=null;
	    int row=0;
	    for (int i=0; i < panes.length; i++) 
	    {
		if (panes[i].isSelected()) {
		    lp = panes[i];
		    break;
		}
		row++;
	    }
	    if (lp == null)
		return;
	    if (row==0)
		return;

	    LayerPane tempPanes[] = new LayerPane[panes.length];
	    tempPanes[0] = lp;
	    if (Debug.debugging("layerspanel")){
		Debug.output("LayersPanel - Moving row to top: " + 
			     lp.getLayer().getName());
	    }

	    int j;
	    for (int i=1; i < panes.length; i++) {
		if (i <= row)
		    tempPanes[i] = panes[i-1];
		else 
		    tempPanes[i] = panes[i];
	    }
	    panes = tempPanes;
	    rejiggerMapLayers();
	}
	else if (command.equals(LayerBottomCmd)) {
	    // Move layer selected layer to bottom
	    LayerPane lp=null;
	    int row=0;
	    for (int i=0; i < panes.length; i++) 
	    {
		if (panes[i].isSelected()) {
		    lp = panes[i];
		    break;
		}
		row++;
	    }
	    if (lp == null)
		return;

	    if (row == panes.length -1)
		return;

	    LayerPane tempPanes[] = new LayerPane[panes.length];
	    tempPanes[panes.length - 1] = lp;

	    int j;
	    for (int i=0; i < panes.length-1; i++) {
		if (i < row)
		    tempPanes[i] = panes[i];
		else
		    tempPanes[i] = panes[i+1];
	    }
	    // now reset the global arrays
	    panes = tempPanes;
	    rejiggerMapLayers();
	}
	else if (command.equals(LayerUpCmd)) {
	    // Move layer selected layer up one
	    LayerPane lp=null;
	    int row=0;
	    for (int i=0; i < panes.length; i++)
	    {
		if (panes[i].isSelected()) {
		    lp = panes[i];
		    break;
		}
		row++;
	    }
	    if (lp == null)
		return;

	    if (row == 0)
		return;

	    panes[row] = panes[row-1];
	    panes[row-1] = lp;
	    rejiggerMapLayers();
	}

	else if (command.equals(LayerDownCmd)) {
	    // Move layer selected layer up one
	    LayerPane lp=null;
	    int row=0;
	    for (int i=0; i < panes.length; i++)
	    {
		if (panes[i].isSelected()) {
		    lp = panes[i];
		    break;
		}
		row++;
	    }
	    if (lp == null)
		return;

	    if (row == panes.length - 1)
		return;
	    panes[row] = panes[row+1];
	    panes[row+1] = lp;
	    rejiggerMapLayers();
	}
    }

    /**
     * Makes a new layer cake of active layers to send to Map.setLayers().
     * Notifies listeners if the order of the layers (active or not) has
     * changed
     * @param neworder tells whether the order of the layers has changed
     * @param selectedRow the currently selected layer in the panel, used to
     * reset the scrollPane so that the row is visible (set to -1 if unknown).
     */
    protected void rejiggerMapLayers() {
	int selectedRow = -1;
	Layer[] newLayers = new Layer[panes.length];
	for (int i = 0; i < panes.length; i++){
	    newLayers[i] = panes[i].getLayer();
	    if (panes[i].isSelected()){
		selectedRow = i;
	    }
	}

	panesPanel.removeAll();
	for (int i=0; i< panes.length; i++) {
	    panesPanel.add(panes[i]);
	}
	scrollPane.validate();
	
	// Scroll up or down as necessary to keep selected row viewable
	if (selectedRow >= 0) {
	    int spheight = scrollPane.getHeight();
	    JScrollBar sb = scrollPane.getVerticalScrollBar();
	    int sv = sb.getValue();
	    int paneheight = panes[selectedRow].getHeight();
	    int rowvalue = selectedRow*paneheight;
	    // Don't reset scrollBar unless the selected row
	    // is not in the viewable range
	    if (!((rowvalue > sv) && (rowvalue < spheight+sv)))
		sb.setValue(rowvalue);
	}
	layerHandler.setLayers(newLayers);
    }

    /** 
     * Update the layer names - if a layer name has changed, tell the
     * LayerPanes to check with their layers to update their labels. 
     */
    public synchronized void updateLayerLabels(){
	for (int i = 0; i < panes.length; i++){
	    panes[i].updateLayerLabel();
	}
    }
}


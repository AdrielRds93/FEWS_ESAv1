/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/gui/CoordDialog.java,v $
 * $Revision: 1.10 $
 * $Date: 2000/05/08 14:22:12 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.gui;
import com.bbn.openmap.util.Debug;
import com.bbn.openmap.*;
import com.bbn.openmap.event.CenterListener;

import javax.swing.*;
import javax.accessibility.*;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.beans.*;
import java.io.Serializable;

/**
 *  A Dialog box wrapper for a CoordPanel
 */
public class CoordDialog extends JDialog 
    implements Serializable, ActionListener
{
    protected transient JButton closebutton;
    protected transient JButton applybutton;
    protected transient CoordPanel coordPanel;
    protected transient JTabbedPane tabPane;
    protected transient DMSCoordPanel dmsPanel;

    /** 
     *  Creates a Dialog Box with a CoordPanel and Apply and Close buttons
     */
    public CoordDialog() {
	super();
	setup();
    }


    /**
     *  Creates a CoordPanel (which has latitude and longitude entry boxes)
     *  and Apply and Close buttons
     */
    protected void setup() {
	Container contentPane = getContentPane();
	contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));

	setTitle("Go To Coordinates");
	
	JPanel bigPanel = new JPanel();
	JPanel titlePanel = new JPanel();
	titlePanel.setLayout(new BoxLayout(titlePanel, BoxLayout.X_AXIS));
	JLabel clarification = new JLabel("Set Center of Map to Coordinates:");
	titlePanel.add(clarification);
	bigPanel.add(titlePanel);

	bigPanel.setLayout(new BoxLayout(bigPanel, BoxLayout.Y_AXIS));
	coordPanel = new CoordPanel();
	dmsPanel = new DMSCoordPanel();
	tabPane = new JTabbedPane();
	tabPane.addTab("Dec Deg", coordPanel);
	tabPane.addTab("DMS", dmsPanel);
	bigPanel.add(tabPane);

	JPanel buttonPanel = new JPanel();
	buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
	closebutton = new JButton("Close");
	closebutton.addActionListener(this);
	applybutton = new JButton("Apply");
	applybutton.addActionListener(this);
	buttonPanel.add(applybutton);
	buttonPanel.add(closebutton);

	bigPanel.add(buttonPanel);
	contentPane.add(bigPanel);

// 	setSize(200, 150);
  	setSize(300, 210);

    }


    /**
     *  @return the LatLonPoint represented by contents of the 
     *  entry boxes in the CoordPanel
     */
    public com.bbn.openmap.LatLonPoint getLatLon() {

	return coordPanel.getLatLon();
    }

    /**
     *  Sets the contents of the latitude and longitude entry 
     *  boxes in CoordPanel
     *  @param llpoint the object containt the coordinates that should go in the boxes
     */
    public void setLatLon(com.bbn.openmap.LatLonPoint llpoint) {
        if (tabPane.getSelectedComponent() == coordPanel)
	    coordPanel.setLatLon(llpoint);
	else
	    dmsPanel.setLatLon(llpoint);

    }

    /**
     *  Tells the CoordPanel to set the center of the map
     */
    public boolean setCenter() {
        if (tabPane.getSelectedComponent() == coordPanel)
	    return coordPanel.setCenter();
	return dmsPanel.setCenter();
    }

    public void actionPerformed(java.awt.event.ActionEvent e) {

	if (e.getSource() == applybutton) {
	    if (tabPane.getSelectedComponent() == coordPanel)
	        coordPanel.setCenter();
	    else
	        dmsPanel.setCenter();
	}

	else if (e.getSource() == closebutton) {
	    setVisible(false);
	}
    }

    /**
     * Add a CenterListener to the listener list.
     *
     * @param listener  The CenterListener to be added
     */
    public synchronized void addCenterListener (CenterListener listener) {
	coordPanel.addCenterListener(listener);
	dmsPanel.addCenterListener(listener);
    }

    /**
     * Remove a CenterListener from the listener list.
     *
     * @param listener  The CenterListener to be removed
     */
    public synchronized void removeCenterListener (CenterListener listener) {
	coordPanel.removeCenterListener(listener);
	dmsPanel.removeCenterListener(listener);
    }


    /*
    public static void main(String[] args) {
	JFrame frame = new JFrame("CoordDialog");
	frame.setSize(240,90);
	CoordDialog cb = new CoordDialog();
	cb.setVisible(true);
	frame.setVisible(true);
	
    }
    */
}

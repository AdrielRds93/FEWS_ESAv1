/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/examples/simple/SimpleMap.java,v $
 * $Revision: 1.2 $
 * $Date: 2000/05/08 14:22:10 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.examples.simple;

import java.util.Properties;
import javax.swing.JFrame;

import com.bbn.openmap.MapBean;
import com.bbn.openmap.layer.shape.ShapeLayer;


/**
 * This is a simple application that uses the OpenMap MapBean to show
 * a map.
 * <p>
 * This example shows:
 * <ul>
 * <li>MapBean
 * <li>ShapeLayer with political data
 * </ul>
 */
public class SimpleMap {

    public static void main (String args[]) {

	// Create a Swing frame
	JFrame frame = new JFrame("Simple Map");

	// Size the frame appropriately
	frame.setSize(640, 480);

	// Create a MapBean
	MapBean mapBean = new MapBean();

	// Create a ShapeLayer to show world political boundaries.
	// Set the properties of the layer.  This assumes that the
	// datafiles "dcwpo-browse.shp" and "dcwpo-browse.ssx" are in
	// a path specified in the CLASSPATH variable.  These files
	// are distributed with OpenMap and reside in the toplevel
	// "share" subdirectory.
	ShapeLayer shapeLayer = new ShapeLayer();
	Properties shapeLayerProps = new Properties();
	shapeLayerProps.put("political.prettyName", "Political Solid");
	shapeLayerProps.put("political.lineColor", "000000");
	shapeLayerProps.put("political.fillColor", "BDDE83");
	shapeLayerProps.put("political.shapeFile", "dcwpo-browse.shp");
	shapeLayerProps.put("political.spatialIndex", "dcwpo-browse.ssx");
	shapeLayer.setProperties("political", shapeLayerProps);

	// Add the political layer to the map
	mapBean.add(shapeLayer);

	// Add the map to the frame
	frame.getContentPane().add(mapBean);

	// Display the frame
	frame.setVisible(true);
    }
}

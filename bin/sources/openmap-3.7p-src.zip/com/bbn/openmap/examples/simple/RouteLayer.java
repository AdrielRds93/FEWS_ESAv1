/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/examples/simple/RouteLayer.java,v $
 * $Revision: 1.2 $
 * $Date: 2000/05/08 14:22:10 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.examples.simple;

import com.bbn.openmap.Layer;
import com.bbn.openmap.event.ProjectionEvent;
import com.bbn.openmap.omGraphics.OMGraphic;
import com.bbn.openmap.omGraphics.OMGraphicList;
import com.bbn.openmap.omGraphics.OMLine;

import java.awt.Color;


/**
 * A Layer to display hypothetical transportation routes.
 * <p>
 * This example shows:
 * <ul>
 * <li>OMGraphicList use
 * <li>OMLine use
 * </ul>
 */
public class RouteLayer extends Layer
{

    /**
     *  A list of graphics to be painted on the map.
     */
    private OMGraphicList omgraphics;


    /**
     * Construct a default route layer.  Initializes omgraphics to
     * a new OMGraphicList, and invokes createGraphics to create
     * the canned list of routes.
     */
    public RouteLayer() {
	omgraphics = new OMGraphicList();
	createGraphics(omgraphics);
    }


    /**
     * Creates an OMLine from the given parameters.
     *
     * @param lat1 The line's starting latitude
     * @param lon1 The line's starting longitude
     * @param lat2 The line's ending latitude
     * @param lon2 The line's ending longitude
     * @param color The line's color
     *
     * @return An OMLine with the given properties
     */
    public OMLine createLine(double lat1, double lon1,
			     double lat2, double lon2,
			     Color color) {
	OMLine line = new OMLine(lat1, lon1, lat2, lon2,
				 OMGraphic.LINETYPE_GREATCIRCLE);
	line.setLineColor(color);
	return line;
    }


    /**
     * Clears and then fills the given OMGraphicList.  Creates
     * three lines for display on the map.
     *
     * @param graphics The OMGraphicList to clear and populate
     * @return the graphics list, after being cleared and filled
     */
    public OMGraphicList createGraphics(OMGraphicList graphics) {

	graphics.clear();


	graphics.addOMGraphic(createLine(42.0d, -71.0d, 35.5d, -120.5d,
					 Color.red));
	graphics.addOMGraphic(createLine(28.0d, -81.0d, 47.0d, -122.0d,
					 Color.green));
	graphics.addOMGraphic(createLine(22.6d, -101.0d, 44.0d, -70.0d,
					 Color.blue));

	return graphics;
    }
    




    //----------------------------------------------------------------------
    // Layer overrides
    //----------------------------------------------------------------------


    /**
     * Renders the graphics list.  It is important to make this
     * routine as fast as possible since it is called frequently
     * by Swing, and the User Interface blocks while painting is
     * done.
     */
    public void paint(java.awt.Graphics g) {
	omgraphics.render(g);
    }
    




    //----------------------------------------------------------------------
    // ProjectionListener interface implementation
    //----------------------------------------------------------------------


    /**
     * Handler for <code>ProjectionEvent</code>s.  This function is
     * invoked when the <code>MapBean</code> projection changes.  The
     * graphics are reprojected and then the Layer is repainted.
     * <p>
     * @param e the projection event
     */
    public void projectionChanged(ProjectionEvent e) {
	omgraphics.project(e.getProjection(), true);
	repaint();
    }
}

/* **********************************************************************
 *
 *  Ranching Systems Group
 *  Texas Agricultural Experiment Station
 *  Department of Rangeland Ecology and Management
 *  Mail Stop 212
 *  College Station, TX 77801
 *
 *  Copyright (C) 2000
 *  This software is subject to copyright protection under the laws of
 *  the United States and other countries.
 *
 * **********************************************************************
 * Fri Feb  4 10:20:34 CST 2000 Dan Schmitt (creation)
 * **********************************************************************
 */

package com.bbn.openmap.examples.cli;

import java.net.*;
import java.util.Properties;
import java.io.*;

import com.bbn.openmap.Environment;
import com.bbn.openmap.LatLonPoint;

import com.bbn.openmap.proj.Mercator;
import com.bbn.openmap.image.ImageServer;
import com.bbn.openmap.image.ImageReceiver;

/**
 * Create a image.  Properties look like:
 * <code><pre>
 * mapIt.fileName=pic.jpg
 * 
 * openmap.Width=480
 * openmap.Height=480
 * openmap.Scale=12500000d
 * openmap.Longitude=31.0d
 * openmap.Latitude=-100.0d
 * 
 * layers=rain land label
 * formatter=com.bbn.openmap.image.SunJPEGFormatter
 * 
 * label.class=com.bbn.openmap.layer.LabelLayer
 * label.geometry=-10+30
 * label.color.fg=FF0000
 * label.color.bg=FFFFFF
 * label.text=Oct 08 1999 02
 * 
 * rain.class=com.bbn.openmap.layer.nexrad.NexradLayer
 * rain.url=<path to nexrad data file>
 * 
 * land.class=com.bbn.openmap.layer.shape.ShapeLayer
 * land.lineColor=BDDE83
 * land.fillColor=B0D073
 * land.shapeFile=share/dcwpo-browse.shp
 * land.spatialIndex=share/dcwpo-browse.ssx
 * </pre></code>
 */
public class mapIt {

    private static String propertiesURLString = "mapIt.properties";

    private static String fileName = "pic.jpg";

    public static class hearAndSave implements ImageReceiver {

    public void receiveImageData(byte[] imageBytes) {
        try {
          FileOutputStream fo = new FileOutputStream(fileName);
	  fo.write(imageBytes);
          fo.close();
         } catch (Exception e) {
          e.printStackTrace();
         }
         System.exit(0);
       }
    }


    static void parseArgs(String[] args) {
	if (args.length == 0){
	    printHelp();
	}

        for (int i = 0; i < args.length; i++) {
            if (args[i].equalsIgnoreCase("-url")) {
                propertiesURLString = args[++i];
            } else if (args[i].equalsIgnoreCase("-h")) {
                printHelp();
            }
        }

        if (propertiesURLString == null) {
            printHelp();
        }
    }

    public static void printHelp() {
        System.err.println("usage: java mapIt -url "+
	"<URL for properties file>");
        System.exit(1);
    }

    public static void main(String args[]) {

        Properties props = System.getProperties();
        parseArgs(args);
        try {
            URL propsURL = new URL(propertiesURLString);
            try {
                InputStream propsIn = propsURL.openStream();
                props.load(propsIn);
            } catch (java.io.IOException e) {
            }
        } catch (MalformedURLException mul){
            System.out.println("GeneratorTester: properties URL not useful.");
            return;
        }

	fileName = props.getProperty("mapIt.fileName",fileName);
	Environment.init(props);

        ImageServer server = new ImageServer(props);

        ImageReceiver ir = new hearAndSave();

        Mercator pj = new Mercator(
		new LatLonPoint(
			Float.parseFloat(
				props.getProperty("openmap.Longitude","30.0")),
			Float.parseFloat(
				props.getProperty(
					"openmap.Latitude","-100.0"))),
			Float.parseFloat(
				props.getProperty("openmap.Scale","1280000")),
			Integer.parseInt(
				props.getProperty("openmap.Width","500")),
			Integer.parseInt(
				props.getProperty("openmap.Height","500")));
        server.createImage(pj, ir);

    }
}

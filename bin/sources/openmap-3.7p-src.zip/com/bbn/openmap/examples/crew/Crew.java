/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/examples/crew/Crew.java,v $
 * $Revision: 1.23 $
 * $Date: 2000/05/08 14:22:07 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

import java.awt.BorderLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.InputStream;
import java.net.URL;
import java.util.Properties;

import javax.swing.JFrame;

import com.bbn.openmap.LatLonPoint;
import com.bbn.openmap.Layer;
import com.bbn.openmap.MapBean;
import com.bbn.openmap.MouseDelegator;
import com.bbn.openmap.layer.shape.ShapeLayer;


/**
 * A sample application incorporating the <code>MapBean</code>.
 * <p>
 */
public class Crew extends JFrame {

    /** The name of the resource file. */
    public static String crewResources = "Crew.properties";

    /** The default location of the DCW data. */
    public static final String defaultDcwPath = "/usr/local/matt/data/dcw/";


    /**
     * The path to the DCW data.  This path is acquired from
     * the <bold><code>dcwPath</code></bold> property in the
     * resource file, or from the default value in <code>
     * defaultDcwPath</code>.
     *
     * @see #crewResources
     * @see #defaultDcwPath
     */
    public String dcwPath;

    /**
     * The properties acquired from the resource file.
     *
     * @see #crewResources
     */
    private Properties properties;


    /**
     * Create a default Crew instance.  The instance
     * will use the default properties.
     */
    public Crew () {
	this(new Properties());
    }



    /**
     * Create a Crew instance with the given properties.  The
     * properties override the defaults.
     *
     * @param props The override properties
     */
    public Crew (Properties props) {

	// Initialize the parent class (JFrame)
	super("Crew Example");

	// Use a Border layout manager
	getContentPane().setLayout(new BorderLayout());

	// Call quit when the window's close box is clicked.
	addWindowListener(new WindowAdapter() {
	    public void windowClosing(WindowEvent e) {
		quit();
	    }});

	// Store the given properties for later use
	properties = props;

	// Create a map
	MapBean map = createMap();

	if (map == null) {
	    // No point to the demo if map creation failed.
	    System.exit(0);
	}

	// Add the map to the JFrame
	getContentPane().add(map, BorderLayout.CENTER);

	// Add the controls to the JFrame
	SimpleControl controls = new SimpleControl();
	controls.addZoomListener(map);
	controls.addPanListener(map);
	getContentPane().add(controls, BorderLayout.SOUTH);
    }



    /**
     * Creates a map and its layers.
     * <p>
     * Creates the map, a mouse delegator for handling mouse
     * events on the map, a political background layer and
     * a route layer for overlay on top of the background.
     *
     * @return the newly created map or null if an error occurred
     */
    protected MapBean createMap () {

	// Create a MapBean
	MapBean mapBean = new MapBean();

	// Create a mouse delegator to handle mouse events on the map
	MouseDelegator md = new MouseDelegator(mapBean);

	// Tell the delegator to use the default modes: Navigation
	// and Selection
	md.setDefaultMouseModes();

	// Choose Selection as the active mode.
	md.setActiveMouseModeWithID("Gestures");

	// Set the map's center property
	mapBean.setCenter(new LatLonPoint(43.0d, -95.0d));


	// Create and add a Route Layer
	addLayer(mapBean, createRouteLayer());

	// Create and add a Political Background
	addLayer(mapBean, createPoliticalLayer());

	// return the map
	return mapBean;
    }



    /**
     * Adds a layer to a map.  Checks for null layers and maps.
     *
     * @param map the target map
     * @param layer the layer to be added
     */
    protected boolean addLayer (MapBean map, Layer layer) {

	if (map == null) {
	    // Indicate failure when a null map is passed.
	    return false;
	}

	if (layer == null) {
	    // Indicate failure when a null layer is passed.
	    return false;
	}

	// Add it to the map
	map.add(layer);

	// Return success
	return true;
    }



    /**
     * Creates a political boundary map layer.  Actually, this method
     * instantiates a DCW Layer (Digital Chart of the World), and sets
     * the layer's parameters so that it will render a political map.
     * <p>
     * Creation of the political layer is controlled by the <code><bold>
     * showPolitical</bold></code> property.  See the resource file
     * crew.properties for more information.
     *
     * @return the political layer, or null if an error occurred
     */
    protected Layer createPoliticalLayer () {
	Boolean showPolitical;
	showPolitical = new Boolean(properties.getProperty("showPolitical",
							   "true"));
	if (! showPolitical.booleanValue()) {
	    return null;
	}
	
	ShapeLayer politicalLayer = new ShapeLayer();
	politicalLayer.setProperties("political", properties);

	return politicalLayer;
    }



    /**
     * Creates a route layer to display great circle lines on
     * the map.
     *
     * @return the route layer
     * @see RouteLayer
     */
    protected Layer createRouteLayer () {
	return new RouteLayer();
    }

    /**
     * Exits the application.
     */
    protected void quit () {
	System.exit(0);
    }



    /**
     * Launches the application.  Reads the resource file, instantiates
     * a application, sizes it and displays it.
     *
     * @param args command line arguments -- ignored
     */
    public static void main (String[] args) {
	Crew crew;
	Properties crewProps = new Properties();
	InputStream propsIn = Crew.class.getResourceAsStream(crewResources);

	if (propsIn == null) {
	    System.err.println("Unable to locate resources: " + crewResources);
	    System.err.println("Using default resources.");
	} else {
	    try {
		crewProps.load(propsIn);
	    } catch (java.io.IOException e) {
		System.err.println("Caught IOException loading resources: " +
				   crewResources);
		System.err.println("Using default resources.");
	    }
	}

	crew = new Crew(crewProps);
	crew.setSize(700, 500);
	crew.setVisible(true);
    }
}

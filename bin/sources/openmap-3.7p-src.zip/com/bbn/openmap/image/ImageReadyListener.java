/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1999-2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/image/ImageReadyListener.java,v $
 * $Revision: 1.4 $
 * $Date: 2000/05/08 14:22:16 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.image;

/**
 * The interface that listens to the ImageGenerator to find out when
 * the java.awt.Image data is ready to be retrieved.  
 */
public interface ImageReadyListener {
    /**
     * The generator containing the layers, ready to paint the completed image.
     *
     * @param generator the ImageGenerator to contact to get the image.
     * @param requestID the identifier of the image for the
     * ImageReadyListener to use to figure out which image is ready.  
     */
    void imageReady(ImageGenerator generator, long requestID);
}

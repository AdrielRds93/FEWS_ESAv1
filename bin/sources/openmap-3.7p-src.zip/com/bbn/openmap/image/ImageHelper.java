/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/image/ImageHelper.java,v $
 * $Revision: 1.2 $
 * $Date: 2000/05/08 14:22:16 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.image;

import java.awt.image.*;

import com.bbn.openmap.util.Debug;

/**
 * A class that holds static functions that do things we tend to do
 * to images a lot.  
 */
public class ImageHelper {

    /**
     * Take a PixelGrabber and get the pixels out of it.
     * @param pg PixelGrabber
     * @return int[] of pixels, null if anything bad happens.
     */
    public static int[] grabPixels(PixelGrabber pg){

	// Get only the pixels you need.
	// Use a pixel grabber to get the right pixels.
	try {
	    pg.startGrabbing();
	    
	    boolean grabbed = pg.grabPixels();

	    if (!grabbed) {
		Debug.error("ImageHelper.grabPixels(): Error in loading image");
		return null;
	    }

	    int framebitCount = 0;
	    while (true) {
		int status = pg.getStatus();
		
		if (Debug.debugging("image")){
		    Debug.output("ImageHelper.grabPixels(): status = " + 
				 status);
		}
		
		if ((status & ImageObserver.ALLBITS) != 0) {
		    break;
		}
		if ((status & ImageObserver.FRAMEBITS) != 0) {
		    // Give some cycles to be sure - some times it seems
		    // to not really be ready,
		    if (framebitCount < 20) {
			framebitCount++;
		    }
		    break;
		}
		if ((status & ImageObserver.ERROR) != 0) {
		    Debug.error("ImageHelper.grabPixels(): Error in loading image");
		    return null;
		}
		Thread.sleep(100);
	    }
	    return (int[])pg.getPixels();
	    
	} catch (InterruptedException ie){
	    return null;
	}
    }
}

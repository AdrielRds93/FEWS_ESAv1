/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1999-2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/image/SunJPEGFormatter.java,v $
 * $Revision: 1.6 $
 * $Date: 2000/05/25 21:51:45 $
 * $Author: dietrick $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.image;

import com.bbn.openmap.util.Debug;
import com.bbn.openmap.layer.util.LayerUtils;

import java.util.*;
import java.awt.image.BufferedImage;

public class SunJPEGFormatter extends AbstractImageFormatter {

    public static final String QualityProperty = "imagequality";

    protected float imageQuality;

    public SunJPEGFormatter(){}

    public void setProperties(String prefix, Properties props){
	imageQuality = LayerUtils.floatFromProperties(props,
						      (prefix == null?"":prefix) + QualityProperty,
						      .8f);
	if (Debug.debugging("image")){
	    Debug.output("SunJPEGFormatter setting image quality to: " +
			 imageQuality);
	}
    }

    public ImageFormatter makeClone(){
	SunJPEGFormatter formatter =  new SunJPEGFormatter();
	formatter.setImageQuality(getImageQuality());
	return formatter;
    }

    public float getImageQuality(){
	return imageQuality;
    }

    /** For this formatter, image quality is a number in the 0-1 range. */
    public void setImageQuality(float quality){
	imageQuality = quality;
    }

    public byte[] formatImage(BufferedImage bi){
	try{
	    return JPEGHelper.encodeJPEG(bi, imageQuality);
	} catch (java.io.IOException ioe){
	    Debug.error("SunJPEGFormatter caught IOException formatting image!");
	    return new byte[0];
	}
    }
}

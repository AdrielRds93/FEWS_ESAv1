/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/image/BufferedImageHelper.java,v $
 * $Revision: 1.2 $
 * $Date: 2000/05/08 14:22:15 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.image;

import com.sun.image.codec.jpeg.*;
import java.io.*;
import java.awt.*;
import javax.swing.*;
import java.awt.image.*;
import java.net.URL;

import com.bbn.openmap.util.Debug;

/**
 * This class provides some utility methods for creating a BufferedImage.
 */
public class BufferedImageHelper {

    /**
     * This class has only static methods, so there is no need to
     * construct anything.
     */
    private BufferedImageHelper() {};

    /**
     * Return a BufferedImage loaded from a URL.
     * @param url the source URL
     * @param x x start pixel
     * @param y y start pixel
     * @param w crop width (-1 uses image width)
     * @param h crop height (-1 uses image height)
     */
    public static BufferedImage getBufferedImage(URL url,
						 int x, int y,
						 int w, int h) 
	throws InterruptedException {
	ImageIcon ii = new ImageIcon(url);
	Image image = ii.getImage();
	return getBufferedImage(image, x, y, w, h);
    }

    /**
     * Return a BufferedImage loaded from an image file path.
     * @param path file path to the image
     * @param x x start pixel
     * @param y y start pixel
     * @param w crop width (-1 uses image width)
     * @param h crop height (-1 uses image height)
     */
    public static BufferedImage getBufferedImage(String path,
						 int x, int y,
						 int w, int h) 
	throws InterruptedException {
	ImageIcon ii = new ImageIcon(path);
	Image image = ii.getImage();
	return getBufferedImage(image, x, y, w, h);
    }

    /**
     * Return a BufferedImage loaded from a Image.
     * @param image the source Image
     * @param x x start pixel
     * @param y y start pixel
     * @param w crop width (-1 uses image width)
     * @param h crop height (-1 uses image height)
     */
    public static BufferedImage getBufferedImage(Image image,
						 int x, int y,
						 int w, int h) 
	throws InterruptedException {

	PixelGrabber pg = new PixelGrabber(image, x, y, w, h, true);
	int[] pixels = ImageHelper.grabPixels(pg);

	if (pixels == null){
	    return null;
	}

	w = pg.getWidth();
	h = pg.getHeight();
	pg = null;
	
	BufferedImage bi = new BufferedImage(w, h,
					     BufferedImage.TYPE_INT_RGB);
	if (Debug.debugging("imagehelper")){
	    Debug.output("BufferedImageHelper.getBufferedImage(): Got buffered image...");
	}
	
	bi.setRGB(0, 0, w, h, pixels, 0, w);

	if (Debug.debugging("imagehelper")){
	    Debug.output("BufferedImageHelper.getBufferedImage(): set pixels in image...");
	}

	return bi;
    }
    
}

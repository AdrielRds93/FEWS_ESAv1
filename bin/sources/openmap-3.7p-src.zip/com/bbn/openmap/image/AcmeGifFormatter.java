/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1999-2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/image/AcmeGifFormatter.java,v $
 * $Revision: 1.5 $
 * $Date: 2000/08/02 14:27:33 $
 * $Author: dietrick $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.image;

import com.bbn.openmap.util.Debug;

import java.util.*;
import java.awt.image.BufferedImage;

/**
 * This formatter requires the Acme.JPM.Encoders package.  That code
 * can be found at <a href="http://www.acme.com/java">http://www.acme.com/java</a>.
 */
public class AcmeGifFormatter extends AbstractImageFormatter {

    public AcmeGifFormatter(){}

    public void setProperties(String prefix, Properties props){}

    public ImageFormatter makeClone(){
	return new AcmeGifFormatter();
    }

    public byte[] formatImage(BufferedImage bi){
	try{
	    return AcmeGifHelper.encodeGif(bi);
	} catch (java.io.IOException ioe){
	    Debug.error("AcmeGifFormatter caught IOException formatting image!\n  "+ ioe);
	    return new byte[0];
	}
    }
}

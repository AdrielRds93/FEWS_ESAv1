/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1999-2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/image/ImageReceiver.java,v $
 * $Revision: 1.3 $
 * $Date: 2000/05/08 14:22:16 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.image;

/** 
 * The interface describing the object that receives the formatted
 * image from the ImageServer.  
 */
public interface ImageReceiver {
    /**
     * Receive the bytes from a image.
     *
     * @param imageBytes the formatted image.
     */
    public void receiveImageData(byte[] imageBytes);
}

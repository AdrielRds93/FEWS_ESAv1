/* **********************************************************************
 * 
 *  BBNT Solutions LLC, A part of GTE
 *  10 Moulton St.
 *  Cambridge, MA 02138
 *  (617) 873-2000
 * 
 *  Copyright (C) 1998, 2000
 *  This software is subject to copyright protection under the laws of 
 *  the United States and other countries.
 * 
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/Layer.java,v $
 * $Revision: 1.43 $
 * $Date: 2000/07/27 15:03:08 $
 * $Author: dietrick $
 * 
 * **********************************************************************
 */

package com.bbn.openmap;

import java.awt.*;
import java.awt.event.*;
import java.util.Vector;
import javax.swing.*;

import com.bbn.openmap.ProjectionPainter;
import com.bbn.openmap.event.*;
import com.bbn.openmap.proj.Projection;
import com.bbn.openmap.util.Debug;

/**
 * Layer objects are components which can be added to the MapBean to
 * make a map.
 * <p>
 * Layers implement the ProjectionListener interface to listen for
 * ProjectionEvents.  When the projection changes, they may need to
 * refetch, regenerate their graphics, and then repaint themselves
 * into the new view.
 */
public abstract class Layer
    extends JComponent
    implements ProjectionListener, ProjectionPainter
{

    /**
     * Precaches the swing package.  Computed based on the package of
     * <code>JComponent</code>.
     */
    protected static final String SWING_PACKAGE = getPackage(JComponent.class);

    /**
     * The listeners to the Layer that respond to requests for
     * information displays, like messages, requests for URL displays,
     * etc.
     */
    protected Vector IDListeners = null;

    /**
     * List of LayerStatusListeners.
     */
    protected Vector lsListeners = null;

    /**
     * Arguments modified by the Layer, or set by the Bean, at
     * runtime.
     */
    protected String dynamicArgs = null;

    /** 
     * Flag to indicate whether a AWTToolkit is available. Almost
     * always should be left alone, unless you are doing something
     * without a display available.  This flag, when false, redirects
     * the repaint() method to fire a LayerStatusEvent.FINISH_WORKING
     * instead.
     */
    protected static boolean AWTAvailable = true;
    
    /**
     * Token uniquely identifying this layer in the application
     * properties.
     */
    protected String markerName = null;

    /**
     * Set AWTAvailable flag.
     * Your layer should not need to call this.
     * @param value boolean
     */
    public static void setAWTAvailable(boolean value){
	AWTAvailable = value;
    }

    /**
     * Check AWTAvailable flag.
     * @return boolean
     */
    public static boolean isAWTAvailable(){
	return AWTAvailable;
    }

    /**
     * Returns the package of the given class as a string.
     *
     * @param c a class
     */
    protected static String getPackage (Class c) {
	String className = c.getName();
	int lastDot = className.lastIndexOf('.');
	return className.substring(0, lastDot);
    }


    /**
     * Override to only allow swing package listeners.  If Listeners
     * get added to the Layers, the mouse events don't make it to the
     * map.  Ever.
     * <p>
     * Swing popup menus, like <code>JPopupMenu</code> grab the
     * JComponent by adding themselves as <code>MouseListener</code>s.
     * So this method allows instances of classes in the xxx.swing
     * package to be added as <code>MouseListener</code>s, and no one
     * else.
     *
     * @param l a mouse listener.
     */
    public final void addMouseListener (MouseListener l) {
	String pkg = getPackage(l.getClass());
	if (java.beans.Beans.isDesignTime()) {
	    super.addMouseListener(l);
	} else if (pkg.equals(SWING_PACKAGE)) {
	    // Do nothing.  The menus work fine at the moment (5/19,
	    // JDK 1.1.6, Swing 1.0.2), but may break in the future.
	} else if (pkg.startsWith(SWING_PACKAGE)) {
	    // Do nothing.  This enables the menus to work
	    // in JDK 1.2rc1, where the MouseListener is in
	    // package javax.swing.plaf.basic and the SWING_PACKAGE
	    // is javax.swing.
	} else {
	    throw new IllegalArgumentException(
	            "This operation is disallowed because the package \""
		    + pkg + "\" is not in the swing package (\"" +
		    SWING_PACKAGE + "\").");
	}
    }

    /**
     * Interface Layer method to get the dynamic args.
     * @return String args
     */
    public String getArgs () {
        return dynamicArgs;
    }

    /**
     * Interface Layer method to set the dynamic args.
     * @param args String
     */
    public void setArgs (String args) {
	dynamicArgs = args;
    }

    /**
     * Interface Layer method to receive layer arguments.
     * @param argv String[]
     */
    public void setArgs (String argv[]) {
    }

    /**
     * Accessor for the marker associated with this layer.  This is
     * the marker that uniquely identifies this layer in the
     * application properties.
     */
    public String getMarker() {
	return markerName;
    }

    /**
     * Sets the properties for the <code>Layer</code>.  This allows
     * <code>Layer</code>s to get a richer set of parameters than the
     * <code>setArgs</code> method.
     * Layers which override this method should do something like:
     * <code><pre>
     * public void setProperties (String prefix, Properties props) {
     *     super.setProperties(prefix, props);
     *     // do local stuff
     * }
     * </pre></code>
     * @param prefix the token to prefix the property names
     * @param props the <code>Properties</code> object
     * @see #setArgs
     */
    public void setProperties(String prefix, java.util.Properties props) {
	setName(props.getProperty(prefix + ".prettyName", "Anonymous"));
	markerName = prefix;
    }

    /**
     * Returns the MapMouseListener object that handles the mouse
     * events.  This method is IGNORED in this class: it returns null.
     * Derived Layers should return the appropriate object if they
     * desire to receive MouseEvents.  The easiest thing for a Layer
     * to do in order to receive MouseEvents is to implement the
     * MapMouseListener interface and return itself.  A code snippet:
     * <code><pre>
     *  public MapMouseListener getMapMouseListener() {
     *	    return this;
     *  }
     *  public String[] getMouseModeServiceList() {
     *	    return new String[] {
     *	        SelectMouseMode.modeID
     *	    };
     *  }
     * </pre></code>
     * @return null
     */
    public synchronized MapMouseListener getMapMouseListener()
    {
	return null;
    }
 
    /**
     * Set the MapMouseListener for the layer.
     * This method is IGNORED in this class.
     * @param mml the object that will handle the mouse events for the
     * layer.
     * @deprecated this is an unnecessary function.  The Layer is
     * responsible for handling MouseEvents as it chooses.
     */ 
    public synchronized void setMapMouseListener(MapMouseListener mml)
    {
    }

    /**
     * Gets the gui controls associated with the layer.
     * This default implementation returns null indicating
     * that the layer has no gui controls.
     *
     * @return java.awt.Component or null
     */
    public java.awt.Component getGUI() {
	return null;
    }


    ///////////////////////////////////////////////////
    //  InfoDisplay Handling Setup and Firing

    /**
     * Adds a listener for <code>InfoDisplayEvent</code>s.
     *
     * @param aInfoDisplayListener the listener to add
     */
    public synchronized void addInfoDisplayListener (
	InfoDisplayListener aInfoDisplayListener){
	if (IDListeners == null) {
	    IDListeners = new java.util.Vector();
	}
	IDListeners.addElement(aInfoDisplayListener);
    }

    /**
     * Removes an InfoDisplayListener from this Layer.
     *
     * @param aInfoDisplayListener the listener to remove
     */
    public synchronized void removeInfoDisplayListener (
	InfoDisplayListener aInfoDisplayListener){
	if (IDListeners == null) {
	    return;
	}
	IDListeners.removeElement(aInfoDisplayListener);
    }

    /**
     * Sends a request to the InfoDisplayListener to show the information in
     * the InfoDisplay event on an single line display facility. 
     * @param evt the InfoDisplay event carrying the string.
     */
    public void fireRequestInfoLine(InfoDisplayEvent evt){
	InfoDisplayListener temp[] = getSynchronizedListeners();
	if (temp != null){
	    for (int i = 0; i < temp.length; i++){
		temp[i].requestInfoLine(evt);
	    }
	}
	else Debug.message("Layer", getName() + 
			   "|Layer.fireRequestInfoLine(): no info request listener!");
    }

    /**
     * Sends a request to the InfoDisplay listener to display the information
     * on an single line display facility.
     * The InfoDisplayEvent is created inside this function.
     * @param infoLine the string to put in the InfoDisplayEvent.  
     */
    public void fireRequestInfoLine(String infoLine){
	fireRequestInfoLine(new InfoDisplayEvent(this, infoLine));
    }

    /**
     * Sends a request to the InfoDisplay listener to display the information
     * in the InfoDisplay event in a Browser.
     * @param evt the InfoDisplayEvent holding the contents to put in the
     * Browser.
     */
    public void fireRequestBrowserContent(InfoDisplayEvent evt){
	InfoDisplayListener temp[] = getSynchronizedListeners();
	if (temp != null){
	    for (int i = 0; i < temp.length; i++){
		temp[i].requestBrowserContent(evt);
	    }
	}
	else Debug.message("Layer", getName() + 
			   "|Layer.fireRequestBrowserContent(): no info request listener!");
    }

    /**
     * Sends a request to the InfoDisplayListener to display the information
     * in a Browser.
     * The InfoDisplayEvent is created here holding the browserContent
     * @param browserContent the contents to put in the Browser.
     */
    public void fireRequestBrowserContent(String browserContent){
	fireRequestBrowserContent(new InfoDisplayEvent(this, browserContent));
    }

    /**
     * Sends a request to the InfoDisplayListener to display a URL given in
     * the InfoDisplay event in a Browser. 
     * @param evt the InfoDisplayEvent holding the url location to give to
     * the Browser.
     */
    public void fireRequestURL(InfoDisplayEvent evt){
	InfoDisplayListener temp[] = getSynchronizedListeners();
	if (temp != null){
	    for (int i = 0; i < temp.length; i++){
		temp[i].requestURL(evt);
	    }
	}
	else Debug.message("Layer", getName() + 
			   "|Layer.fireRequestURL(): no info request listener!");
    }

    /**
     * Sends a request to the InfoDisplayListener to display a URL in a
     * browser.
     * The InfoDisplayEvent is created here, and the URL location is put
     * inside it.
     * @param url the url location to give to the Browser.
     */
    public void fireRequestURL(String url){
	fireRequestURL(new InfoDisplayEvent(this, url));
    }

    /**
     * Sends a request to the InfoDisplayListener to show a specific cursor
     * over its component area.
     * @param cursor the cursor to use.
     */
    public void fireRequestCursor(java.awt.Cursor cursor){
	InfoDisplayListener temp[] = getSynchronizedListeners();
	if (temp != null){
	    for (int i = 0; i < temp.length; i++){
		temp[i].requestCursor(cursor);
	    }
	}
	else Debug.message("Layer", getName() + 
			   "|Layer.fireRequestCursor(): no info request listener!");
    }

    /**
     * Sends a request to the InfoDisplayListener to put the information in
     * the InfoDisplay event in a dialog window. 
     * @param evt the InfoDisplayEvent holding the message to put into
     * the dialog window.
     */
    public void fireRequestMessage(InfoDisplayEvent evt){
	InfoDisplayListener[] temp = getSynchronizedListeners();
	if (temp != null){
	    for (int i = 0; i < temp.length; i++){
		temp[i].requestMessage(evt);
	    }
	}
	else Debug.message("Layer", getName() + 
			   "|Layer.fireRequestMessage(): no info request listener!");
    }

    /**
     * Sends a request to the InfoDisplayListener to display the information
     * in a dialog window.
     * The InfoDisplayEvent is created here, and the URL location is put
     * inside it.
     * @param message the message to put in the dialog window.
     */
    public void fireRequestMessage(String message){
	fireRequestMessage(new InfoDisplayEvent(this, message));
    }

    /**
     * Get the InfoDisplayListeners.
     * Provides an internal InfoDisplayListener that is synchronized at the
     * time of the check for null, so that we won't attempt to use it
     * later where there might have been an opportunity for it to have
     * been deleted.  Huh?
     * @return a personal copy of the InfoDisplayListener
     */
    protected InfoDisplayListener[] getSynchronizedListeners(){
	// use this for freakin' thread safety
	InfoDisplayListener[] temp = null;
	synchronized (this) {
	    if (IDListeners == null) return temp;
	    int numListeners = IDListeners.size();
	    temp =  new InfoDisplayListener[numListeners];
	    for (int i = 0; i < numListeners; i++){
	       temp[i] = (InfoDisplayListener)IDListeners.elementAt(i);
	    }
	}
	return temp;
    }


    ///////////////////////////////////////////////////
    //  LayerStatus Handling Setup and Firing

    /**
     * Returns an array of all the LayerStatusListeners.
     * @return LayerStatusListener[]
     */
    protected LayerStatusListener[] getSynchronizedStatusListeners(){
	// use this for freakin' thread safety
	LayerStatusListener[] temp = null;
	synchronized (this) {
	    if (lsListeners == null) return temp;
	    int numListeners = lsListeners.size();
	    temp =  new LayerStatusListener[numListeners];
	    for (int i = 0; i < numListeners; i++){
	       temp[i] = (LayerStatusListener)lsListeners.elementAt(i);
	    }
	}
	return temp;
    }

    /**
     * Adds a listener for <code>LayerStatusEvent</code>s.
     *
     * @param aLayerStatusListener LayerStatusListener
     */
    public synchronized void addLayerStatusListener (
	LayerStatusListener aLayerStatusListener)
    {
	if (lsListeners == null) {
	    lsListeners = new java.util.Vector();
	}
	lsListeners.addElement(aLayerStatusListener);
    }

    /**
     * Removes a LayerStatusListene from this Layer.
     *
     * @param aLayerStatusListener the listener to remove
     */
    public synchronized void removeLayerStatusListener (
	LayerStatusListener aLayerStatusListener){

	if (lsListeners == null) {
	    return;
	}
	lsListeners.removeElement(aLayerStatusListener);
    }

    /**
     * Sends a status update to the LayerStatusListener.
     * @param evt LayerStatusEvent
     */
    public void fireStatusUpdate(LayerStatusEvent evt){
	if (AWTAvailable){
	    LayerStatusListener[] temp = getSynchronizedStatusListeners();
	    if (temp != null){
		for (int i = 0; i < temp.length; i++){
		    temp[i].updateLayerStatus(evt);
		}
	    }
	    else Debug.message("Layer", getName() + 
			       "|Layer.fireStatusUpdate(): no LayerStatusListener!");
	}
    }

    /**
     * Sends a status update to the LayerStatusListener.
     * @param evt LayerStatusEvent
     */
    public void fireStatusUpdate(int status) {
	fireStatusUpdate(new LayerStatusEvent(this, status));
    }

    /**
     * Repaint the layer.
     * You should not need to override this.
     */
    public void repaint(){
	if (AWTAvailable) super.repaint();
	else {
	    // This looks like a fireStatusUpdate, right?  But that is
	    // disabled if !AWTAvailable.  The only way to fire the
	    // status is finished is by calling a repaint.  Doing
	    // anything else confuses the GIFMapBean.  The firing of
	    // this status update may be redundant for layers that use
	    // the status updates already, but we have to play smart
	    // for all layers, especially for those who don't play
	    // nice.
	    LayerStatusEvent evt = new LayerStatusEvent(this, LayerStatusEvent.FINISH_WORKING);
	    LayerStatusListener[] temp = getSynchronizedStatusListeners();
	    if (temp != null){
		for (int i = 0; i < temp.length; i++){
		    temp[i].updateLayerStatus(evt);
		}
	    }
	}
    }

    /**
     * Repaint the layer.
     * If you are using BufferedMapBean for your application,
     * WE STRONGLY RECOMMEND THAT YOU DO NOT OVERRIDE THIS METHOD.
     * This method marks the layer buffer so that it will be refreshed.
     * If you override this method, and don't call super.repaint(),
     * the layers will not be repainted.
     */
    public void repaint(long tm, int x, int y, int width, int height) {
        Component p = getParent();
	if(p instanceof BufferedMapBean) {
	    ((BufferedMapBean)p).setRequestPaint(true);
	    if (Debug.debugging("basic")) {
		Debug.output(getName() +"|Layer: repaint(tm=" + tm + 
				   ", x=" + x + 
				   ", y=" + y + 
				   ", width=" + width + 
				   ", height=" + height + ")");
	    }
	}
	super.repaint(tm, x, y, width, height);
    }

    /**
     *  This method is here to provide a default action for Layers as
     *  they act as a ProjectionPainter.  Normally, ProjectionPainters
     *  are expected to receive the projection, gather/create
     *  OMGraphics that apply to the projection, and render them into
     *  the Graphics provided.  This is supposed to be done in the
     *  same thread that calls this function, so the caller knows that
     *  when this method returns, everything that the
     *  ProjectionPainter needed to do is complete.<P> If the layer
     *  doesn't override this method, then the paint(Graphics) method
     *  will be called.
     *
     * @param proj Projection of the map.
     * @param g java.awt.Graphics to draw into.  
     */
    public void renderDataForProjection(Projection proj, Graphics g){
	paint(g);
    }


    /**
     * This method is called when the layer is added to the MapBean
     * @param cont Container
     */
    public void added(Container cont)
    {
    }

    /**
     * This method is called after the layer is removed from the
     * MapBean and when the projection changes.  We recommend that
     * Layers override this method and nullify memory-intensive
     * variables.
     * @param cont Container
     */
    public void removed(Container cont)
    {
    }

    /**
     *  Part of a layer hack to notify the component listener when the
     *  component is hidden.  These components don't receive the
     *  ComponentHidden notification.  Remove when it works.
     */
    protected Vector localHackList;
    /**
     *  Part of a layer hack to notify the component listener when the
     *  component is hidden.  These components don't receive the
     *  ComponentHidden notification.  Remove when it works. Set to
     *  false to test.
     */
    protected boolean doHack = true;
    /**
     *  Part of a layer hack to notify the component listener when the
     *  component is hidden.  These components don't receive the
     *  ComponentHidden notification.  Remove when it works.
     */
    public void hide(){
	super.hide();
	if (doHack) notifyHideHack();
    }	

    /**
     *  Part of a layer hack to notify the component listener when the
     *  component is hidden.  These components don't receive the
     *  ComponentHidden notification.  Remove when it works.
     */
    public void addComponentListener(ComponentListener cl){
	super.addComponentListener(cl);
	if (localHackList == null){
	    localHackList = new Vector();
	}
	localHackList.add(cl);
    }

    /**
     *  Part of a layer hack to notify the component listener when the
     *  component is hidden.  These components don't receive the
     *  ComponentHidden notification.  Remove when it works.
     */
    public void removeComponentListener(ComponentListener cl){
	super.removeComponentListener(cl);
	if (localHackList != null){
	    localHackList.remove(cl);
	}
    }

    /**
     *  Part of a layer hack to notify the component listener when the
     *  component is hidden.  These components don't receive the
     *  ComponentHidden notification.  Remove when it works.
     */
    public void notifyHideHack(){
	java.util.Vector targets;
	synchronized (this) {
	    if (localHackList == null) {
	    	return;
	    }
	    targets = (java.util.Vector) localHackList.clone();
	}
	ComponentEvent ce = new ComponentEvent(this, ComponentEvent.COMPONENT_HIDDEN);
	for (int i = 0; i < targets.size(); i++) {
	    ComponentListener target = (ComponentListener)targets.elementAt(i);
	    target.componentHidden(ce);
	}
    }
}

/* **********************************************************************
 *
 *    Use, duplication, or disclosure by the Government is subject to
 *           restricted rights as set forth in the DFARS.
 *
 *                         BBNT Solutions LLC
 *                            A Part of
 *                               GTE
 *                        10 Moulton Street
 *                       Cambridge, MA 02138
 *                          (617) 873-3000
 *
 *        Copyright 1998, 2000 by BBNT Solutions LLC,
 *              A part of GTE, all rights reserved.
 *
 * **********************************************************************
 *
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/LatLonPoint.java,v $
 * $Revision: 1.18 $
 * $Date: 2000/08/23 22:16:58 $
 * $Author: dietrick $
 *
 * **********************************************************************
 *
 * formatted with JxBeauty (c) johann.langhofer@nextra.at
 */


package  com.bbn.openmap;

import com.bbn.openmap.proj.ProjMath;
import com.bbn.openmap.util.Assert;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.Serializable;


/**
 * Encapsulates latitude and longitude coordinates in decimal degrees.
 * Normalizes the internal representation of latitude and longitude.
 * <p>
 * <strong>Normalized Latitude:</strong><br>
 * &minus;90&deg; &lt;= &phi; &lt;= 90&deg;
 * <p>
 * <strong>Normalized Longitude:</strong><br>
 * &minus;180&deg; &le; &lambda; &le; 180&deg;
 *
 */
public class LatLonPoint
        implements Cloneable, Serializable {
    // SOUTH_POLE <= phi <= NORTH_POLE
    // -DATELINE <= lambda <= DATELINE
    public final static double NORTH_POLE = 90.0d;
    public final static double SOUTH_POLE = -NORTH_POLE;
    public final static double DATELINE = 180.0d;
    public final static double LON_RANGE = 360.0d;
    // initialize to something sane
    protected double lat_ = 0.0d;
    protected double lon_ = 0.0d;

    /**
     * Construct a default LatLonPoint.
     */
    public LatLonPoint () {
    }

    /**
     * Construct a LatLonPoint from raw double lat/lon in decimal degrees.
     *
     * @param lat latitude in decimal degrees
     * @param lon longitude in decimal degrees
     */
    public LatLonPoint (double lat, double lon) {
        lat_ = normalize_latitude(lat);
        lon_ = wrap_longitude(lon);
        radlat_ = ProjMath.degToRad(lat_);
        radlon_ = ProjMath.degToRad(lon_);
    }

    /**
     * Construct a LatLonPoint from raw double lat/lon in radians.
     *
     * @param lat latitude in radians
     * @param lon longitude in radians
     * @param isRadian placeholder indicates radians
     */
    public LatLonPoint (double lat, double lon, boolean isRadian) {
        radlat_ = lat;
        radlon_ = lon;
        lat_ = normalize_latitude(ProjMath.radToDeg(radlat_));
        lon_ = wrap_longitude(ProjMath.radToDeg(radlon_));
    }

    /**
     * Copy construct a LatLonPoint.
     *
     * @param pt LatLonPoint
     */
    public LatLonPoint (LatLonPoint pt) {
        lat_ = pt.lat_;
        lon_ = pt.lon_;
        radlat_ = pt.radlat_;
        radlon_ = pt.radlon_;
    }

    /* uncomment to see how many are being used and thrown away...
     protected void finalize() {
     Debug.output("finalized " + this);
     }
     */

    /**
     * Returns a string representation of the object.
     * @return String representation
     */
    public String toString () {
        return  "LatLonPoint[lat=" + lat_ + ",lon=" + lon_ + "]";
    }

    /**
     * Clone the LatLonPoint.
     * @return clone
     */
    public Object clone () {
        try {
            return  super.clone();
        } catch (CloneNotSupportedException e) {
            Assert.assertTrue(false, "LatLonPoint: internal error!");
            return  null;       // statement not reached
        }
    }

    /**
     * Set latitude.
     * @param lat latitude in decimal degrees
     */
    public void setLatitude (double lat) {
        lat_ = normalize_latitude(lat);
        radlat_ = ProjMath.degToRad(lat_);
    }

    /**
     * Set longitude.
     * @param lon longitude in decimal degrees
     */
    public void setLongitude (double lon) {
        lon_ = wrap_longitude(lon);
        radlon_ = ProjMath.degToRad(lon_);
    }

    /**
     * Set latitude and longitude.
     * @param lat latitude in decimal degrees
     * @param lon longitude in decimal degrees
     */
    public void setLatLon (double lat, double lon) {
        lat_ = normalize_latitude(lat);
        lon_ = wrap_longitude(lon);
        radlat_ = ProjMath.degToRad(lat_);
        radlon_ = ProjMath.degToRad(lon_);
    }

    /**
     * Set latitude and longitude.
     * @param lat latitude in radians
     * @param lon longitude in radians
     * @param isRadian placeholder indicates radians
     */
    public void setLatLon (double lat, double lon, boolean isRadian) {
        radlat_ = lat;
        radlon_ = lon;
        lat_ = normalize_latitude(ProjMath.radToDeg(radlat_));
        lon_ = wrap_longitude(ProjMath.radToDeg(radlon_));
    }

    /**
     * Set LatLonPoint.
     * @param llpt LatLonPoint
     */
    public void setLatLon (LatLonPoint llpt) {
        lat_ = llpt.lat_;
        lon_ = llpt.lon_;
        radlat_ = ProjMath.degToRad(lat_);
        radlon_ = ProjMath.degToRad(lon_);
    }

    /**
     * Get normalized latitude.
     * @return double latitude in decimal degrees
     * (&minus;90&deg; &le; &phi; &le; 90&deg;)
     */
    public double getLatitude () {
        return  lat_;
    }

    /**
     * Get wrapped longitude.
     * @return double longitude in decimal degrees
     * (&minus;180&deg; &le; &lambda; &le; 180&deg;)
     */
    public double getLongitude () {
        return  lon_;
    }

    /**
     * Determines whether two LatLonPoints are equal.
     * @param obj Object
     * @return Whether the two points are equal up to a tolerance of
     * 10<sup>-5</sup> degrees in latitude and longitude.
     */
    public boolean equals (Object obj) {
        final double TOLERANCE = 0.00001d;
        if (obj instanceof LatLonPoint) {
            LatLonPoint pt = (LatLonPoint)obj;
            return  (MoreMath.approximately_equal(lat_, pt.lat_, TOLERANCE)
                    && MoreMath.approximately_equal(lon_, pt.lon_,
                    TOLERANCE));
        }
        return  false;
    }

    /**
     * Hash the lat/lon value.
     * <p>
     * @return int hash value
     */
    public int hashCode () {
        return  ProjMath.hashLatLon(lat_, lon_);
    }

    /**
     * Write object.
     * @param s DataOutputStream
     */
    public void write (DataOutputStream s) throws IOException {
        // Write my information
        s.writeDouble(lat_);
        s.writeDouble(lon_);
    }

    /**
     * Read object.
     * @param s DataInputStream
     */
    public void read (DataInputStream s) throws IOException {
        // HMMM.  do we really need to be safe here?
        lat_ = normalize_latitude(s.readFloat());
        lon_ = wrap_longitude(s.readFloat());
        radlat_ = ProjMath.degToRad(lat_);
        radlon_ = ProjMath.degToRad(lon_);
    }

    /**
     * Sets latitude to something sane.
     * @param lat latitude in decimal degrees
     * @return double normalized latitude in decimal degrees
     * (&minus;90&deg; &le; &phi; &le; 90&deg;)
     */
    final public static double normalize_latitude (double lat) {
        if (lat > NORTH_POLE) {
            lat = NORTH_POLE;
        }
        if (lat < SOUTH_POLE) {
            lat = SOUTH_POLE;
        }
        return  lat;
    }

    /**
     * Sets longitude to something sane.
     * @param lon longitude in decimal degrees
     * @return double wrapped longitude in decimal degrees
     * (&minus;180&deg; &le; &lambda; &le; 180&deg;)
     */
    final public static double wrap_longitude (double lon) {
        if ((lon < -DATELINE) || (lon > DATELINE)) {
            //System.out.print("LatLonPoint: wrapping longitude " + lon);
            lon += DATELINE;
            lon = lon%LON_RANGE;
            lon = (lon < 0) ? DATELINE + lon : -DATELINE + lon;
            //Debug.output(" to " + lon);
        }
        return  lon;
    }

    /**
     * Check if latitude is bogus.
     * Latitude is invalid if lat &gt; 90&deg; or if lat &lt; &minus;90&deg;.
     * @param lat latitude in decimal degrees
     * @return boolean true if latitude is invalid
     */
    public static boolean isInvalidLatitude (double lat) {
        return  ((lat > NORTH_POLE) || (lat < SOUTH_POLE));
    }

    /**
     * Check if longitude is bogus.
     * Longitude is invalid if lon &gt; 180&deg; or if lon &lt; &minus;180&deg;.
     * @param lon longitude in decimal degrees
     * @return boolean true if longitude is invalid
     */
    public static boolean isInvalidLongitude (double lon) {
        return  ((lon < -DATELINE) || (lon > DATELINE));
    }

    /**
     * Calculate the <code>radlat_</code> and <code>radlon_</code>
     * instance variables upon deserialization.
     * Also, check <code>lat_</code> and <code>lon_</code> for safety;
     * someone may have tampered with the stream.
     * @param stream Stream to read <code>lat_</code> and <code>lon_</code> from.
     */
    private void readObject (java.io.ObjectInputStream stream) throws IOException,
            ClassNotFoundException {
        stream.defaultReadObject();
        lat_ = normalize_latitude(lat_);
        lon_ = wrap_longitude(lon_);
        radlat_ = ProjMath.degToRad(lat_);
        radlon_ = ProjMath.degToRad(lon_);
    }
    /**
     * Used by the projection code for read-only quick access.
     * This is meant for quick backdoor access by the projection library.
     * Modify at your own risk!
     * @see #lat_
     */
    public transient double radlat_ = 0.0d;
    /**
     * Used by the projection code for read-only quick access.
     * This is meant for quick backdoor access by the projection library.
     * Modify at your own risk!
     * @see #lon_
     */
    public transient double radlon_ = 0.0d;
}




/* **********************************************************************
 *
 *  BBNT Solutions LLC, A part of GTE
 *  10 Moulton St.
 *  Cambridge, MA 02138
 *  (617) 873-2000
 *
 *  Copyright (C) 1998-2000
 *  This software is subject to copyright protection under the laws of
 *  the United States and other countries.
 *
 * **********************************************************************
 *
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/MapBean.java,v $
 * $Revision: 1.66 $
 * $Date: 2000/08/24 16:02:37 $
 * $Author: bmackiew $
 *
 * **********************************************************************
 */

package com.bbn.openmap;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import com.bbn.openmap.util.Debug;
import com.bbn.openmap.event.*;
import com.bbn.openmap.proj.*;
import com.bbn.openmap.LatLonPoint;


/**
 * The MapBean is the main component of the OpenMap Development Kit.
 * It is a Java Bean that manages and displays a map.  A map is
 * comprised of a projection and a list of layers, and this class has
 * methods that allow you to control the projection parameters and to
 * add and remove layers.  Layers that are part of the map receive
 * dynamic notifications of changes to the underlying view and
 * projection.
 * <p>
 * Most of the methods in the MapBean are called from the Java AWT and
 * Swing code.  These methods make the MapBean a good "Swing citizen"
 * to its parent components, and you should not need to invoke them.
 * In general there are only two reasons to call MapBean methods:
 * controlling the projection, and adding or removing layers.
 * <p>
 * When controlling the MapBean projection, simply call the method
 * that applies - setCenter, pan, zoom, etc.  NOTE: If you are setting
 * more than one parameter of the projection, it's more efficient to
 * getProjection(), directly set the parameters of the projection
 * object, and then call setProjection() with the modified projection.
 * That way, each ProjectionListener of the MapBean (each layer) will
 * only receive one projectionChanged() method call, as opposed to
 * receiving one for each projection adjustment.
 * <p>
 * To add or remove layers, use the add() and remove() methods that
 * the MapBean inherits from java.awt.Container.  The add() method can
 * be called with an integer that indicates its desired position in
 * the layer list.
 *
 * @see Layer
 */
public class MapBean extends JComponent
    implements ComponentListener, ContainerListener,
	       ProjectionListener, PanListener,
	       ZoomListener, LayerListener,
	       CenterListener
{
    public static final String LayersProperty = "layers";
    public static final String CursorProperty = "cursor";

    /**
     * OpenMap title.
     */
    public static final String title = "OpenMap(tm)";

    /**
     * OpenMap version.
     */
    public static final String version = "3.6.2";

    /**
     * Suppress the copyright message on initialization.
     * But remember, the OpenMap License says you can't do this!
     */
    public static boolean suppressCopyright = false;

    private static final boolean DEBUG_TIMESTAMP = false;
    private static final boolean DEBUG_THREAD = true;

    private static final String copyrightNotice =
	"OpenMap(tm) Version " + version + "\r\n" +
	"  Copyright 1998-2000, BBNT Solutions LLC, a part of GTE.\r\n" +
	"  See http://openmap.bbn.com/ for details.\r\n";

    protected double defaultCenterLat = 0.0d;
    protected double defaultCenterLon = 0.0d;
    protected double defaultScale = Double.MAX_VALUE;//zoomed all the way out
    protected int   defaultWidth = 640;
    protected int   defaultHeight = 480;

    protected Proj projection = new Mercator(
	    new LatLonPoint(defaultCenterLat, defaultCenterLon),
	    defaultScale, defaultWidth, defaultHeight);
    protected ProjectionSupport projectionSupport;
    protected Vector removedLayers = new Vector(0);
    protected Vector addedLayers = new Vector(0);

    /**
     * Return the OpenMap Copyright message.
     * @return String Copyright
     */
    public static String getCopyrightMessage() {
	return copyrightNotice;
    }

    /**
     * Construct a MapBean.
     */
    public MapBean () {
	if (Debug.debugging("mapbean")) {
	    debugmsg("MapBean()");
	}
	if (! suppressCopyright) {
	    Debug.output(copyrightNotice);
	}

	super.setLayout(new OverlayLayout(this));
	projectionSupport = new ProjectionSupport(this);
	addComponentListener(this);
	addContainerListener(this);

	//----------------------------------------
	// In a builder tool it seems that the OverlayLayout
	// makes the MapBean fail to resize.  And since it has
	// no children by default, it has no size.  So I add
	// a null Layer here to give it a default size.
	//----------------------------------------
	if (java.beans.Beans.isDesignTime()) {
	    add(new Layer() {
		public void projectionChanged (ProjectionEvent e) {}
		public Dimension getPreferredSize() {
		    return new Dimension(100, 100);
		}
		});
	}
    }

    /**
     * Return a stringified representation of the MapBean.
     * @return String
     */
    public String toString() {
	return getClass().getName() + "@" + Integer.toHexString(hashCode());
    }

    /*----------------------------------------------------------------------
     * Window System overrides
     *----------------------------------------------------------------------*/

    /**
     * Adds additional constraints on possible children components.
     * The new component must be a Layer.  This method included as
     * a good container citizen, and should not be called directly.
     * Use the add() methods inherited from java.awt.Container instead.
     * @param comp Component
     * @param constraints Object
     * @param index int location
     */
    protected final void addImpl (Component comp,
				  Object constraints,
				  int index) {
	if (comp instanceof Layer) {
	    super.addImpl(comp, constraints, index);
	} else {
	    throw new IllegalArgumentException("only Layers can be added to a MapBean");
	}
    }

    /**
     * Prevents changing the LayoutManager.
     * Don't let anyone change the LayoutManager!  This is called by
     * the parent component and should not be called directly.
     */
    public final void setLayout(LayoutManager mgr) {
	throw new IllegalArgumentException("cannot change layout of Map");
    }

    /**
     * Return the minimum size of the MapBean window.
     * Included here to be a good citizen.
     */
    public Dimension getMinimumSize()
    {
	return new Dimension(defaultWidth, defaultHeight);
    }

    /**
     * Get the Insets of the MapBean.
     * This returns 0-length Insets.
     * <p>
     * This makes sure that there will be no +x,+y offset when drawing
     * graphics.  This is ok since any borders around the MapBean will get
     * drawn afterwards on top.
     * @return Insets 0-length Insets
     */
    public final Insets getInsets() {
	return insets;
    }

    private final transient static Insets insets = new Insets(0,0,0,0);

    /*----------------------------------------------------------------------
     * ComponentListener implementation
     *----------------------------------------------------------------------*/

    /**
     * ComponentListener interface method.
     * Should not be called directly. Included in order to be a good citizen.
     * Invoked when component has been resized.
     * @param e ComponentEvent
     */
    public void componentResized(ComponentEvent e) {
	if (Debug.debugging("mapbean"))
	    debugmsg("Size changed: " + getWidth() + " x " + getHeight());
	projection.setWidth(getWidth());
	projection.setHeight(getHeight());
	fireProjectionChanged();
    }

    /**
     * ComponentListener interface method.
     * Should not be called directly. Included in order to be a good citizen.
     * Invoked when component has been moved.
     * @param e ComponentEvent
     */
    public void componentMoved(ComponentEvent e) {
    }

    /**
     * ComponentListener interface method.
     * Should not be called directly. Included in order to be a good citizen.
     * Invoked when component has been shown.
     * @param e ComponentEvent
     */
    public void componentShown(ComponentEvent e) {
    }

    /**
     * ComponentListener interface method.
     * Should not be called directly. Included in order to be a good citizen.
     * Invoked when component has been hidden.
     * @param e ComponentEvent
     */
    public void componentHidden(ComponentEvent e) {
    }

    /*----------------------------------------------------------------------
     *
     *----------------------------------------------------------------------*/

    /**
     * Add a ProjectionListener to the MapBean.
     * You do not need to call this method to add layers as
     * ProjectionListeners.  This method is called for the layer when it is
     * added to the MapBean.  Use this method for other objects that you want
     * to know about the MapBean's projection.
     * @param l ProjectionListener
     */
    public synchronized void addProjectionListener (ProjectionListener l) {
	projectionSupport.addProjectionListener(l);
	// Assume that it wants the current projection
	l.projectionChanged(new ProjectionEvent(this, getProjection()));
    }

    /**
     * Remove a ProjectionListener from the MapBean.
     * You do not need to call this method to remove layers that are
     * ProjectionListeners.  This method is called for the layer when it is
     * removed from the MapBean.  Use this method for other objects that you
     * want to remove from receiving projection events.
     * @param l ProjectionListener
     */
    public synchronized void removeProjectionListener (ProjectionListener l) {
	projectionSupport.removeProjectionListener(l);
    }

    /**
     * Called from within the MapBean when its projection listeners
     * need to know about a projection change.
     */
    protected void fireProjectionChanged () {
	projectionSupport.fireProjectionChanged(getProjection());

	// Tell any layers that have been removed that they have
	// been removed
	if (removedLayers.size() == 0)
	    return;
	for (int i=0; i<removedLayers.size(); i++) {
	    ((Layer)removedLayers.elementAt(i)).removed(this);
	}
	removedLayers.removeAllElements();

    }

    /*----------------------------------------------------------------------
     * Properties
     *----------------------------------------------------------------------*/

    /**
     * Gets the scale of the map.
     * @return double the current scale of the map
     * @see Projection#getScale
     */
    public double getScale () {
	return projection.getScale();
    }

    /**
     * Sets the scale of the map.
     * The Projection may silently disregard this setting, setting it to a
     * <strong>maxscale</strong> or <strong>minscale</strong> value.
     * @param newScale the new scale
     * @see Proj#setScale
     */
    public void setScale (double newScale) {
	projection.setScale(newScale);
	fireProjectionChanged();
    }

    /**
     * Gets the center of the map in the form of a LatLonPoint.
     *
     * @return the center point of the map
     * @see Projection#getCenter
     */
    public LatLonPoint getCenter () {
	return projection.getCenter();
    }

    /**
     * Sets the center of the map.
     * @param newCenter the center point of the map
     * @see Proj#setCenter(LatLonPoint)
     */
    public void setCenter (LatLonPoint newCenter) {
	projection.setCenter(newCenter);
	fireProjectionChanged();
    }

    /**
     * Sets the center of the map.
     * @param lat the latitude of center point of the map in decimal degrees
     * @param lon the longitude of center point of the map in decimal degrees
     * @see Proj#setCenter(double, double)
     */
    public void setCenter (double lat, double lon) {
	projection.setCenter(lat, lon);
	fireProjectionChanged();
    }

    /**
     * Get the type of the projection.
     *
     * @return int type
     * @see Projection#getProjectionType
     */
    public int getProjectionType () {
	return projection.getProjectionType();
    }

    /**
     * Set the type of the projection.
     * If different from the current type, this installs a new
     * projection with the same center, scale, width, and height of
     * the previous one.
     * @param int type
     */
    public void setProjectionType (int newType) {
	int oldType = projection.getProjectionType();
	if (oldType != newType) {
	    LatLonPoint ctr = projection.getCenter();
	    projection = (Proj)(ProjectionFactory.makeProjection(newType,
							  ctr.getLatitude(),
							  ctr.getLongitude(),
							  projection.getScale(),
							  projection.getWidth(),
							  projection.getHeight()
							  ));
	    Color customColor = getCustomBackgroundColor();
	    if (customColor != null){
		projection.setBackgroundColor(customColor);
	    }
	    fireProjectionChanged();
	}
    }

    /**
     * Get the projection property.
     * @return Projection
     */
    public Projection getProjection() {
	return projection;
    }

    /**
     * Set the projection.
     * @param aProjection Projection
     */
    public void setProjection(Projection aProjection) {
	projection = (Proj)aProjection;
	Color customColor = getCustomBackgroundColor();
	if (customColor != null){
	    projection.setBackgroundColor(customColor);
	}
	fireProjectionChanged();
    }

    /**
     * Checks the Environment to see if a BackgroundColor string, set
     * as a hex ARGB string, has been set.  If it hasn't or if it
     * doesn't represent a valid color number, then null is returned,
     * which should be interpreted as an excuse to use the default
     * pretty blue embedded in the projection.
     */
    protected Color getCustomBackgroundColor(){
	String colorRep = Environment.get(Environment.BackgroundColor);
	if (colorRep == null) {
	    return null;
	} else {
	    try {
		return com.bbn.openmap.layer.util.LayerUtils.parseColor(colorRep);
	    } catch (NumberFormatException nfe){
		return null;
	    }
	}
    }

    //------------------------------------------------------------
    // CenterListener interface
    //------------------------------------------------------------

    /**
     * Handles incoming <code>CenterEvents</code>.
     *
     * @param evt the incoming center event
     */
    public void center (CenterEvent evt) {
	setCenter(evt.getLatitude(), evt.getLongitude());
    }

    //------------------------------------------------------------
    // PanListener interface
    //------------------------------------------------------------

    /**
     * Handles incoming <code>PanEvents</code>.
     *
     * @param evt the incoming pan event
     */
    public void pan (PanEvent evt) {
	if (Debug.debugging("mapbean"))
	    debugmsg("PanEvent: " + evt);

	double az = evt.getAzimuth();
	double c = evt.getArcDistance();
	if (Double.isNaN(c)) {
	    projection.pan(az);
	} else {
	    projection.pan(az, c);
	}

	fireProjectionChanged();
    }

    //------------------------------------------------------------
    // ZoomListener interface
    //------------------------------------------------------------

    /**
     * Zoom the Map.
     * Part of the ZoomListener interface.  Sets the scale of the
     * MapBean projection, based on a relative or absolute amount.
     *
     * @param evt the ZoomEvent describing the new scale.
     */
    public void zoom (ZoomEvent evt) {
	double newScale;
	if (evt.isAbsolute()) {
	    newScale = evt.getAmount();
	} else if (evt.isRelative()) {
	    newScale = getScale() * evt.getAmount();
	} else {
	    return;
	}
	setScale(newScale);
    }

    //------------------------------------------------------------
    // ContainerListener interface
    //------------------------------------------------------------

    protected transient Layer[] currentLayers = new Layer[0];

    protected transient boolean doContainerChange = true;

    /**
     * ContainerListener Interface method.
     * Should not be called directly.  Part of the ContainerListener
     * interface, and it's here to make the MapBean a good Container
     * citizen.
     * @param value boolean
     */
    public void setDoContainerChange(boolean value) {
	// if changing from false to true, call changeLayers()
        if (!doContainerChange &&  value) {
	    doContainerChange = value;
	    changeLayers(null);
	} else
	    doContainerChange = value;

    }

    /**
     * ContainerListener Interface method.
     * Should not be called directly.  Part of the ContainerListener
     * interface, and it's here to make the MapBean a good Container
     * citizen.
     * @return boolean
     */
    public boolean getDoContainerChange() {
        return doContainerChange;
    }

    /**
     * ContainerListener Interface method.
     * Should not be called directly.  Part of the ContainerListener
     * interface, and it's here to make the MapBean a good Container
     * citizen.
     * @param e ContainerEvent
     */
    public void componentAdded(ContainerEvent e) {
	// Blindly cast.  addImpl has already checked to be
	// sure the child is a Layer.
	addProjectionListener((Layer)e.getChild());
	changeLayers(e);

	// If the new layer is in the queue to have removed() called on it
	// take it off the queue, and don't add it to the added() queue.
	// Otherwise, add it to the queue to have added() called on it.
 	if (!removedLayers.removeElement(e.getChild()))
 	    addedLayers.addElement(e.getChild());
    }

    /**
     * ContainerListener Interface method.
     * Should not be called directly.  Part of the ContainerListener
     * interface, and it's here to make the MapBean a good Container
     * citizen.
     * @param e ContainerEvent
     */
    public void componentRemoved(ContainerEvent e) {
	// Blindly cast.  addImpl has already checked to be
	// sure the child is a Layer.
	removeProjectionListener((Layer)e.getChild());
	changeLayers(e);

	// Add this layer to the queue to be notified that it has been removed
	removedLayers.addElement(e.getChild());
    }

    /**
     * ContainerListener Interface method.
     * Should not be called directly.  Part of the ContainerListener
     * interface, and it's here to make the MapBean a good Container
     * citizen.
     * @param e ContainerEvent
     */
    protected void changeLayers (ContainerEvent e) {
        // Container Changes can be disabled to speed adding/removing multiple layers
        if (!doContainerChange) return;
	Component[] comps = this.getComponents();
	int ncomponents = comps.length;
	Layer[] newLayers = new Layer[ncomponents];
	System.arraycopy(comps, 0, newLayers, 0, ncomponents);
	if (Debug.debugging("mapbean"))
	    debugmsg("changeLayers() - firing change");
	firePropertyChange(LayersProperty, currentLayers, newLayers);

	// Tell the new layers that they have been added
	for (int i=0; i<addedLayers.size(); i++) {
	    ((Layer)addedLayers.elementAt(i)).added(this);
	}
	addedLayers.removeAllElements();

	currentLayers = newLayers;

    }

    //------------------------------------------------------------
    // ProjectionListener interface
    //------------------------------------------------------------

    /**
     * ProjectionListener interface method.
     * Should not be called directly.
     * @param e ProjectionEvent
     */
    public void projectionChanged (ProjectionEvent e) {
	Projection newProj = e.getProjection();
	if (! projection.equals(newProj)) {
	    setProjection(newProj);
	}
    }

    /**
     * Set the Mouse cursor over the MapBean component.
     * @param newCursor Cursor
     */
    public void setCursor(Cursor newCursor){
	firePropertyChange(CursorProperty, this.getCursor(), newCursor);
	super.setCursor(newCursor);
    }

    private final void debugmsg (String msg) {
	Debug.output(this.toString() +
		     (DEBUG_TIMESTAMP?(" [" + System.currentTimeMillis() + "]"):"") +
		     (DEBUG_THREAD?(" [" + Thread.currentThread() + "]"):"") +
		     ": " + msg);
    }

    //------------------------------------------------------------
    // LayerListener interface
    //------------------------------------------------------------

    /**
     * LayerListener interface method.
     * A list of layers will be added, removed, or replaced based on
     * on the type of LayerEvent.
     * @param evt a LayerEvent
     */
    public void setLayers(LayerEvent evt) {
        Layer[] layers = evt.getLayers();
	int type = evt.getType();

	// @HACK is this cool?:
	if (layers == null) {
	    System.err.println("MapBean.setLayers(): layers is null!");
	    return;
	}

	boolean oldChange = getDoContainerChange();
	setDoContainerChange(false);

	// use LayerEvent.REPLACE when you want to remove all current layers
	// add a new set
	if (type==LayerEvent.REPLACE)
	{
	    if (Debug.debugging("mapbean"))
		debugmsg("Replacing all layers");
  	    removeAll();

	    for (int i=0; i<layers.length; i++) {
		// @HACK is this cool?:
		if (layers[i] == null) {
		    System.err.println(
			    "MapBean.setLayers(): layer " + i + " is null");
		    continue;
		}

		if (Debug.debugging("mapbean"))
		    debugmsg("Adding layer[" +i+"]= " +layers[i].getName());
		add(layers[i]);
		layers[i].setVisible(true);
	    }
	}

	// use LayerEvent.ADD when adding and/or reshuffling layers
	else if (type == LayerEvent.ADD) {
	    if (Debug.debugging("mapbean"))
		debugmsg("Adding new layers");
	    for (int i=0; i<layers.length; i++) {
		if (Debug.debugging("mapbean"))
		    debugmsg("Adding layer[" +i+"]= " +layers[i].getName());
		add(layers[i]);
		layers[i].setVisible(true);
	    }
	}

	// use LayerEvent.REMOVE when you want to delete layers from the map
	else if (type == LayerEvent.REMOVE) {
	    if (Debug.debugging("mapbean"))
		debugmsg("Removing layers");
	    for (int i=0; i<layers.length; i++) {
		if (Debug.debugging("mapbean"))
		    debugmsg("Removing layer[" +i+"]= " +layers[i].getName());
		remove(layers[i]);
	    }
	}

	setDoContainerChange(oldChange);
	repaint();
	revalidate();
    }
}

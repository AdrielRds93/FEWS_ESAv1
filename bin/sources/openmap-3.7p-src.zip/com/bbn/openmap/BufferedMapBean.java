/* **********************************************************************
 * 
 *  BBNT Solutions LLC, A part of GTE
 *  10 Moulton St.
 *  Cambridge, MA 02138
 *  (617) 873-2000
 * 
 *  Copyright (C) 1998, 2000
 *  This software is subject to copyright protection under the laws of 
 *  the United States and other countries.
 * 
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/BufferedMapBean.java,v $
 * $Revision: 1.14 $
 * $Date: 2000/06/28 23:32:29 $
 * $Author: dietrick $
 * 
 * **********************************************************************
 */


package com.bbn.openmap;
import java.awt.Graphics;
import java.awt.event.*;

import com.bbn.openmap.util.Debug;

/**
 * The BufferedMapBean extends the MapBean by adding (you guessed it)
 * buffering.
 * <p>
 * Specifically, the layers are stored in a java.awt.Image so that the
 * frequent painting done by Swing on lightweight components will not cause
 * the layers to do unnecessary work rerendering themselves each time.
 */
public class BufferedMapBean extends MapBean
{
    protected boolean needToRenderLayers = true;
    protected java.awt.Image drawingBuffer = null;

    /**
     * Set the layers of the MapBean.
     * @param evt LayerEvent
     */
    public void setLayers(com.bbn.openmap.event.LayerEvent evt) {

        needToRenderLayers = true;
	super.setLayers(evt);
    }


    /**
     * Invoked when component has been resized.
     * Layer buffer is nullified. and super.componentResized(e) is called.
     * @param e ComponentEvent
     */
    public void componentResized(ComponentEvent e) {
        // reset drawingBuffer
	boolean bad = false;
	try {
	    drawingBuffer=createImage(getWidth(), getHeight());
	} catch (java.lang.NegativeArraySizeException nae){
	    bad = true;
	} catch (java.lang.IllegalArgumentException iae){
	    bad = true;
	}

	if (bad){
	    Debug.message("mapbean", 
			  "BufferedMapBean: component resizing is not valid for buffer.");
	    drawingBuffer=createImage(1, 1);
	}	    

	super.componentResized(e);
    }


    /**
     *  Paint the child components of this component.
     *  <p>
     *  WE STRONGLY RECOMMEND THAT YOU DO NOT OVERRIDE THIS METHOD
     *  The map layers are buffered in an Image which is drawn to
     *  the screen. The buffer is refreshed after repaint() is called on a
     *  layer.
     *  <p>
     *  In our view, paint() is called on the MapBean
     *  excessively, such as when tool tips are displayed and removed 
     *  on the LayerPanel, or on when menu items are highlighted. This
     *  method should greatly reduce the number of times Layers are rendered.
     *  @param g Graphics
     */
    public void paintChildren (Graphics g) {

	// if a layer has requested a render, then we render all of them into
	// a drawing buffer
	if (needToRenderLayers) {
	    needToRenderLayers = false;

	    int w = getWidth();
	    int h = getHeight();

            if (drawingBuffer == null) {
                drawingBuffer = createImage (w, h);
            }

	    // draw the old image
	    Graphics gr = drawingBuffer.getGraphics();
	    gr.setClip(0, 0, w, h);
	    // gr.drawImage(drawingBuffer,0,0,null);

	    // set the clip and draw the layers
	    // java.awt.Rectangle clipRect = g.getClipBounds();
	    // gr.setClip(clipRect);
	    drawBackgroundColor(gr);
	    super.paintChildren(gr);

	    // reset the clip to full map
	    // gr.setClip(0, 0, w, h);
	    gr.dispose();
	}

 	// draw the buffer to the screen
	g.drawImage(drawingBuffer,0,0,null);

	// border gets overwritten accidentally, so redraw it now    
	paintBorder(g);
    }


    /**
     * Marks the image buffer as dirty if value is false.
     * On the next <code>paintChildren()</code>, we will call
     * <code>paint()</code> on all Layer components.
     * @param value boolean
     */
    public void setRequestPaint(boolean value) {
        needToRenderLayers = value;
    }


    /**
     * Checks whether the image buffer should be repainted.
     * @return boolean whether the layer buffer is dirty
     */
    public boolean isRequestPaint() {
        return needToRenderLayers;
    }


    /**
     * Draw the background color.
     * @param g Graphics
     */
    protected void drawBackgroundColor(Graphics g) {
	projection.drawBackground(g);
    }
}

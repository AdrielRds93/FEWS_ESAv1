/* **********************************************************************
 * 
 *  BBNT Solutions LLC, A part of GTE
 *  10 Moulton St.
 *  Cambridge, MA 02138
 *  (617) 873-2000
 * 
 *  Copyright (C) 1998, 2000
 *  This software is subject to copyright protection under the laws of 
 *  the United States and other countries.
 * 
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/plotLayer/GLOBEData.java,v $
 * $Revision: 1.5 $
 * $Date: 2000/05/08 14:22:43 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.plotLayer;

import java.net.*;
import java.lang.*;
import java.io.*;

public abstract class GLOBEData {
    
    public GLOBEData() {}


    public void loadData(InputStream instream) 
	throws IOException
    {
	readDataFromStream(instream);
    }


    protected abstract void parseDataFromStream(String line);


    public void readDataFromStream(InputStream istream)
	throws IOException
    {
	int lines_read = 0;
	BufferedReader buffstream = 
	    new BufferedReader(new InputStreamReader(istream), 65536);

	while (true)
	{ 
	    String line = buffstream.readLine();
	    if (line == null)
		break;
	    line.trim();
	    // ignore comments
	    if (line.equals("") || line.startsWith("#")) {
		continue;
	    }
	    parseDataFromStream(line);
	    lines_read++;
//  	    if (lines_read % 1000 == 0) {
//  		System.out.println("Read " + lines_read + " lines");
//  	    }
	}
//  	System.out.println("Read " + lines_read + " total lines");
    }


    /*
    public static void main (String argv[]) 
    {
	try {
	    System.out.println("Getting URL: " + argv[0]);
	    GLOBEData datafile = new GLOBEData(argv[0]);
	    datafile.loadData();
	}
	catch (IOException e) {
	    System.err.println(e);
	}
    }
    */

}

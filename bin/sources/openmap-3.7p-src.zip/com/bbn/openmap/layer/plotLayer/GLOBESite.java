/* **********************************************************************
 * 
 *  BBNT Solutions LLC, A part of GTE
 *  10 Moulton St.
 *  Cambridge, MA 02138
 *  (617) 873-2000
 * 
 *  Copyright (C) 1998, 2000
 *  This software is subject to copyright protection under the laws of 
 *  the United States and other countries.
 * 
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/plotLayer/GLOBESite.java,v $
 * $Revision: 1.5 $
 * $Date: 2000/05/08 14:22:43 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.plotLayer;
 

import java.lang.*;
import java.util.*;
import java.awt.Color;
import com.bbn.openmap.omGraphics.*;


public class GLOBESite {

    private double longitude_, latitude_;

    private double max_year_ = -9999;
    private double min_year_ = 99999;
    private double max_temp_ = -99999;
    private double min_temp_ = 99999;
    
    private Hashtable temp_table_ = null;
//     private Hashtable max_temp_table_ = null;
//     private Hashtable min_temp_table_ = null;

    private String name_;
    

    private static final byte[] default_bits_ = {
	(byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x70, 
	(byte)0x00, (byte)0xf8, (byte)0x00, (byte)0xfc, (byte)0x01, 
	(byte)0xfc, (byte)0x01, (byte)0xfc, (byte)0x01, (byte)0xf8, 
	(byte)0x00, (byte)0x70, (byte)0x00, (byte)0x00, (byte)0x00, 
	(byte)0x00, (byte)0x00
    };
  
    private OMGraphic graphic_;


    public GLOBESite(double lat, double lon)
    {
	longitude_ = lon;
	latitude_ = lat;
	
	name_ = "(" + latitude_ + ", " + longitude_ + ")";

	//	graphic_ = new OMCircle(lat, lon, 5,5, 11, 11, default_bits_);
	graphic_ = new OMCircle(lat, lon, 5,5 );
	graphic_.setLineColor(Color.red);
	graphic_.setFillColor(Color.red);
	graphic_.setSelectColor(Color.yellow);
	graphic_.setAppObject(this);
	
	temp_table_ = new Hashtable();
// 	max_temp_table_ = new Hashtable();
// 	min_temp_table_ = new Hashtable();
    }

    public String hash() {return name_;}
    
    public void addCurrentTemp(double year, double temp)
    {temp_table_.put(new Double(year), new Double(temp));}
    public double getCurrentTemp(double year)
    {return ((Number)temp_table_.get(new Double(year))).floatValue();}

//     public void addMaxTemp(double year, double temp)
//     {max_temp_table_.put(new Double(year), new Double(temp));}
//     public double getMaxTemp(double year)
//     {return ((Number)max_temp_table_.get(new Double(year))).floatValue();}

//     public void addMinTemp(double year, double temp)
//     {min_temp_table_.put(new Double(year), new Double(temp));}
//     public double getMinTemp(double year)
//     {return ((Number)min_temp_table_.get(new Double(year))).floatValue();}

    public double getLatitude() { return latitude_; }
    public double getLongitude() { return longitude_; }

    public final OMGraphic getGraphic(){return graphic_;}
    public String getName() {return name_;} 

    public Enumeration getAllYears(){
	return temp_table_.keys();
    }
    
    public double getMaxTemp() { return max_temp_; }
    public double getMinTemp() { return min_temp_; }
    public double getMaxYear() { return max_year_; }
    public double getMinYear() { return min_year_; }
   
   public double  getValueForYear(double year) {
      if ( temp_table_.containsKey(new Double(year)) ){
	 return ((Double)temp_table_.get(new Double(year))).floatValue();
      }
      return -99;
   }
   
    private void recalcLimits(){
	Enumeration all_years = temp_table_.keys();
	while ( all_years.hasMoreElements() ){
	    double year = ((Double)all_years.nextElement()).floatValue();
	    double temp = ((Double)temp_table_ .get(new Double(year))).floatValue();
	    if ( year > max_year_ ) max_year_ = year;
	    if ( year < min_year_ ) min_year_ = year;
	    
	    if ( temp > max_temp_ ) max_temp_ = temp;
	    if ( temp < min_temp_ ) max_temp_ = temp;
	}
    }

    public String getInfo()
    {
	int numpoints = temp_table_.size();
	return name_ + " -- " + numpoints + " datapoints available";
    }


}

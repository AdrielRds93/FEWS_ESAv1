/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 *
 * The meat of this code is based on source code provided by
 * The MITRE Corporation, through the browse application source
 * code.  Many thanks to Nancy Markuson who provided BBN with the
 * software, and to Theron Tock, who wrote the software, and
 * Daniel Scholten, who revised it - (c) 1994 The MITRE
 * Corporation for those parts, and used with permission.
 *
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/nitf/NitfHeader.java,v $
 * $Revision: 1.7 $
 * $Date: 2000/05/08 14:22:41 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.nitf;

import java.io.File;
import java.io.IOException;
import java.io.FileNotFoundException;

import com.bbn.openmap.util.Debug;
import com.bbn.openmap.util.BinaryBufferedFile;
import com.bbn.openmap.util.FormatException;

/** The NitfHeader reads the header information in a NITF (National
* Imagery Transmission Format) and makes the section location
* information available.
* */
public class NitfHeader {

    public final static int NITF_IMAGE_DES_SIZE = 16;
    public final static int NITF_SYMBOLS_DES_SIZE = 10;
    public final static int NITF_LABELS_DES_SIZE = 7;
    public final static int NITF_TEXT_DES_SIZE = 9;
    public final static int NITF_DATAEXT_DES_SIZE = 13;
    public final static int NITF_RESEXT_DES_SIZE = 11;
    public final static int NITF_USERDEF_SIZE = 19;

    public String FHDR;// [9]   /*File type and Version*/
    public String CLEVEL;// [2]	/*Compliance Level*/
    public String STYPE;// [3]	/*System Type*/
    public String OSTAID;// [10]/*Originating Station ID*/
    public String FDT;// [14]	/*File Date and Time*/
    public String FTITLE;//[80] /*File Title*/
    public String FSCLAS;// [1]	/*File Security Classification*/
    public String FSCODE;// [40]/*File Codewords*/
    public String FSCTLH;// [40]/*File Control and Handling*/
    public String FSREL;// [40]	/*File Releasing Instructions*/
    public String FSCAUT;// [20]/*File Classification Authority*/
    public String FSCTLN;// [20]/*File Security Control Number*/
    public String FSDWNG;// [6]	/*File Security Downgrade*/
    public String FSDEVT;// [40]/*File Downgrading Event*/
    public String FSCOP;// [5]  /*Message Copy Number*/
    public String FSCPYS;// [5] /*Message Number of Copies*/
    public String ENCRYP;// [1]	/*Encryption*/
    public String ONAME;// [27]	/*Originator's Name*/
    public String OPHONE;// [18]/*Originator's Phone Number*/
    public String FL;// [12]	/*File Length*/
    public String HL;// [6]     /*NITF File Header Length*/
    
    NitfHeaderAmounts nha;
    NitfUserDef nud;

    public NitfHeader(){
	nha = new NitfHeaderAmounts();
	nud = new NitfUserDef();
    }

    static public class NitfHeaderAmounts {
	public String NUMI;// [3] /*Number of Images*/
	public String NUMS;// [3] /*Number of Symbols*/
	public String NUML;// [3] /*Number of Labels*/
	public String NUMT;// [3] /*Number of Text Files*/
	public String NUMDES;// [3] /*Number of Data Extensions*/
	public String NUMRES;// [3] /*Number of Reserved Extensions*/
    }
    
    static public class NitfImageDescription {
	public String LISH;// [6]
	public String LI;// [10]
    }
    
    static public class NitfSymbolsDescription {
	public String LSSH;// [4]
	public String LS;// [6]
    }
    
    static public class NitfLabelDescription {
	public String LLSH;// [4]
	public String LL;// [3]
    }
    
    static public class NitfTextDescription {
	public String LTSH;// [4]
	public String LT;// [5]
    }

    static public class NitfDataExtDescription {
	public String LDSH;// [4]
	public String LD;// [9]
    }
    
    static public class NitfResExtDescription {
	public String LRSH;// [4]
	public String LR;// [7]
    }
    
    static public class NitfUserDef {
	public String UDHDL;// [5]
	public String UDHOFL;// [3]
	public String RETAG;// [6]
	public String REL;// [5]
    }
    
    /** Reads the header part of the file. Will seek automatically to
     * the beginning of the file.
     * @param binFile BinaryBufferedFile, opened on the NITF file.
     * */
    public boolean read(BinaryBufferedFile binFile){
	
	try{
	    binFile.seek(0);
	    FHDR = binFile.readFixedLengthString(9);
	    if(!FHDR.startsWith("NITF")) return false; /*Not an NITF file*/
	    
	    CLEVEL = binFile.readFixedLengthString(2);
	    STYPE = binFile.readFixedLengthString(4);
	    OSTAID = binFile.readFixedLengthString(10);
	    FDT = binFile.readFixedLengthString(14);
	    FTITLE = binFile.readFixedLengthString(80);
	    FSCLAS = binFile.readFixedLengthString(1);
	    FSCODE = binFile.readFixedLengthString(40);
	    FSCTLH = binFile.readFixedLengthString(40);
	    FSREL = binFile.readFixedLengthString(40);
	    FSCAUT = binFile.readFixedLengthString(20);
	    FSCTLN = binFile.readFixedLengthString(20);
	    FSDWNG = binFile.readFixedLengthString(6);
	    
	    if (FSDWNG.startsWith("999998"))
		FSDEVT = binFile.readFixedLengthString(40); 
	    
	    FSCOP = binFile.readFixedLengthString(5);
	    FSCPYS = binFile.readFixedLengthString(5);
	    ENCRYP = binFile.readFixedLengthString(1);
	    ONAME = binFile.readFixedLengthString(27);
	    OPHONE = binFile.readFixedLengthString(18);
	    FL = binFile.readFixedLengthString(12);
	    HL = binFile.readFixedLengthString(6);

	    nha = readSectionInfo(binFile);

	    nud.UDHDL = binFile.readFixedLengthString(5);// [5]
	    nud.UDHOFL = binFile.readFixedLengthString(3);// [3]
	    nud.RETAG = binFile.readFixedLengthString(6);// [6]
	    nud.REL = binFile.readFixedLengthString(5);// [5]

	} catch (IOException e){
	    System.err.println("NitfHeader: File IO Error while reading header information:");
	    System.err.println(e);
	    return false;
	} catch (FormatException f){
	    System.err.println("NitfHeader: File IO Format error while reading header information:");
	    System.err.println(f);
	    return false;
	}

	return true;
    }
    
    protected NitfHeaderAmounts readSectionInfo(BinaryBufferedFile binFile){

	try{
	    nha.NUMI = binFile.readFixedLengthString(3);
	    binFile.seek(binFile.getFilePointer() + 
			 (Integer.parseInt(nha.NUMI) * NITF_IMAGE_DES_SIZE));
	    
	    nha.NUMS = binFile.readFixedLengthString(3);
	    binFile.seek(binFile.getFilePointer() + 
			 (Integer.parseInt(nha.NUMS) * NITF_SYMBOLS_DES_SIZE));
	    
	    nha.NUML = binFile.readFixedLengthString(3);
	    binFile.seek(binFile.getFilePointer() + 
			 (Integer.parseInt(nha.NUML) * NITF_LABELS_DES_SIZE));
	    
	    nha.NUMT = binFile.readFixedLengthString(3);
	    binFile.seek(binFile.getFilePointer() + 
			 (Integer.parseInt(nha.NUMT) * NITF_TEXT_DES_SIZE));
	    
	    nha.NUMDES = binFile.readFixedLengthString(3);
	    binFile.seek(binFile.getFilePointer() + 
			 (Integer.parseInt(nha.NUMDES) * 
			  NITF_DATAEXT_DES_SIZE));
	    
	    nha.NUMRES = binFile.readFixedLengthString(3);
	} catch (IOException e){
	    System.err.println("NitfHeader: File IO Error while reading header information:");
	    System.err.println(e);
	    return null;
	} catch (FormatException f){
	    System.err.println("NitfHeader: File IO Format error while reading header information:");
	    System.err.println(f);
	    return null;
	}

	return nha;
    }
	
    public String toString(){
	StringBuffer s = new StringBuffer();
	s.append("\n\nNITF Information about " + FTITLE + "\n");
	s.append("-------------------\n");
	s.append("File Type: " + FHDR + "\n");
	s.append("Compliance Level: " + CLEVEL + "\n");
	s.append("System Type: " + STYPE + "\n");
	s.append("Originating Station: " + OSTAID + "\n");
	s.append("File Date and Time: " + FDT + "\n");
	s.append("Originator's Name: " + ONAME + "\n");
	s.append("File Length: " + FL + "\n\n");
	
	s.append(nha.NUMI + " image\n");
	s.append(nha.NUMS + " symbol\n");
	s.append(nha.NUML + " label\n");
	s.append(nha.NUMT + " text\n");
	s.append(nha.NUMDES + " dataext\n");
	s.append(nha.NUMRES + " resext\n");
	return s.toString();
    }

    public final static void main(String[] args){
	if (args.length != 1){
	    System.out.println("Usage: java NitfHeader <path to NITF file>");
	    return;
	}

	File file = new File(args[0]);
	BinaryBufferedFile binFile = null;
	try {
	    binFile = new BinaryBufferedFile(file);
	} catch (FileNotFoundException e) {
	    System.err.println("NitfHeader: file "+args[0]+" not found");
	    System.exit(1);
	} catch (IOException ioe){
	    System.err.println("NitfHeader: File IO Error while handling NITF header:");
	    System.err.println(ioe);
	} 

	NitfHeader header = new NitfHeader();
	if (header.read(binFile)) {
	    System.out.println(header);
	}
	else System.out.println("NitfHeader: NOT read sucessfully!");
    
    }
}


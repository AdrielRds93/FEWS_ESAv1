/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/EarthquakeLayer.java,v $
 * $Revision: 1.11 $
 * $Date: 2000/05/25 22:15:10 $
 * $Author: dietrick $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer;

import java.awt.Color;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.MouseEvent;
import java.io.*;
import java.net.Socket;
import java.net.URL;
import java.util.StringTokenizer;
import java.util.Vector;
import java.util.Properties;
import java.util.NoSuchElementException;

import javax.swing.JPanel;
import javax.swing.JButton;

import com.bbn.openmap.LatLonPoint;
import com.bbn.openmap.Layer;
import com.bbn.openmap.layer.util.LayerUtils;
import com.bbn.openmap.event.LayerStatusEvent;
import com.bbn.openmap.event.MapMouseListener;
import com.bbn.openmap.event.ProjectionEvent;
import com.bbn.openmap.event.InfoDisplayEvent;
import com.bbn.openmap.omGraphics.*;
import com.bbn.openmap.proj.Projection;
import com.bbn.openmap.util.Debug;
import com.bbn.openmap.util.SwingWorker;
import com.bbn.openmap.util.PaletteHelper;


/**
 * Get data about recent earthquakes from the USGS finger sites and
 * display it.
 * <p>
 * Debugging information is printed when the OpenMap Viewer is launch
 * with -Ddebug.earthquake flag.<P>
 * # Properties for the Earthwuake Layer
 * earthquake.sites=<finger site> <finger site> ...
 * # in seconds
 * earthquake.queryinterval=300
 */
public class EarthquakeLayer extends Layer
    implements MapMouseListener, ComponentListener
{

    public final static transient String fingerSitesProperty = ".sites";
    public final static transient String queryIntervalProperty = ".queryInterval";

    /**
     * Sites to finger user the user `quake'.
     */
    protected String fingerSites[] = {
	"gldfs.cr.usgs.gov",
	"scec.gps.caltech.edu",
	"andreas.wr.usgs.gov",
	"geophys.washington.edu",
	"giseis.alaska.edu",
	"seismo.unr.edu",
	"eqinfo.seis.utah.edu",
	"sisyphus.idbsu.edu",
	"info.seismo.usbr.gov",
	"mbmgsun.mtech.edu",
	"quake.eas.slu.edu",
	"vtso.geol.vt.edu",
	"tako.wr.usgs.gov",
	"ldeo.columbia.edu"
    };

    /**
     * Sites that are actively being queried.
     */
    protected boolean activeSites[] = new boolean [fingerSites.length];

    /** Default to 5 minutes. */
    private long fetchIntervalMillis = 300 * 1000;

    // lat-lon data of the earthquakes
    protected double llData[] = new double[0];

    // floating information about the earthquakes
    protected String infoData[] = new String[0];
    // floating information about the earthquakes
    protected String drillData[] = new String[0];

    private long lastDataFetchTime = 0;
    protected OMGraphicList omgraphics = new OMGraphicList();
    protected Color lineColor = Color.red;
    protected boolean showingInfoLine = false;
    protected boolean working = false;
    protected boolean cancelled = false;
    protected QuakeWorker currentWorker = new QuakeWorker();
    /** The layer GUI. */
    protected JPanel gui = null;
    /** Reference to the current map projection. */
    protected Projection projection;

    /**
     * Construct an EarthquakeLayer.
     */
    public EarthquakeLayer () {
	activeSites[0] = true;
    }

    /**
     * Set the properties of the EarthquakeLayer.
     * @param prefix String
     * @param props Properties
     */
    public void setProperties(String prefix, Properties props) {
	super.setProperties(prefix, props);

	// list of sites
	String sites = props.getProperty(prefix + fingerSitesProperty);
	if (sites != null) {
	    Vector v = new Vector();
	    String str; StringTokenizer tok = new StringTokenizer(sites);
	    while ((str = tok.nextToken()) != null) {
		v.addElement(str);
	    }
	    int len = v.size();
	    fingerSites = new String[len];
	    activeSites = new boolean[len];
	    activeSites[0] = true;
	    for (int i=0; i<len; i++) {
		fingerSites[i] = (String)v.elementAt(i);
	    }
	}

	fetchIntervalMillis = 
	    LayerUtils.intFromProperties(props, prefix + queryIntervalProperty, 300) * 1000;
    }

    /** 
     * Implementing the ProjectionPainter interface.
     */
    public synchronized void renderDataForProjection(com.bbn.openmap.proj.Projection proj, 
						     java.awt.Graphics g){

	if (proj == null){
	    Debug.error("EarthquakeLayer.renderDataForProjection: null projection!");
	    return;
	} else if(!proj.equals(projection)){
	    projection = proj.makeClone();

	    if (needToRefetchData()) {
		try {
		    parseData(getEarthquakeData());
		} catch (Throwable t) {
		    omgraphics = null;
		    t.printStackTrace();
		    return;
		}
	    }
	    generateGraphics();
	}
	paint(g);
    }

    /**
     * ProjectionListener interface method.
     * @param e ProjectionEvent
     */
    public void projectionChanged (ProjectionEvent e) {

	Projection newP = e.getProjection();
	if (newP.equals(projection)) {// projection not really different
	    repaint();
	    return;
	}
	projection = newP.makeClone();

	computeLayer();
    }

    /**
     * Paints the layer.
     * @param g the Graphics context for painting
     */
    public synchronized void paint (java.awt.Graphics g) {
	if (omgraphics != null){
	    omgraphics.render(g);
	}
    }

    /**
     * Bring the layer into sync with the current state of the map.
     */
    protected synchronized void computeLayer () {
	if (projection == null) return;

	// only do work if the layer is visible
	if (isVisible()) {
	    if (needToRefetchData()) {
		// Start the worker thread if it's not doing anything
		if (!working) {
		    working = true;
		    currentWorker.execute();
		} else {
		    cancelled = true;
		    currentWorker.interrupt();
		}
	    }

	    generateGraphics();
	    repaint();
	}
    }

    /**
     * Invoked when the worker thread finishes.
     * @param worker QuakeWorker
     */
    protected synchronized void workerComplete (QuakeWorker worker) {
	try {
	    if (!cancelled) {
		parseData((Vector)worker.get());
		generateGraphics();
		working = false;
		repaint();
	    } else {
		cancelled = false;
		currentWorker.execute();
	    }
	} catch (Throwable t) {
	    omgraphics = null;
	    String msg = "EarthquakeLayer.workerComplete(): " + t;
	    Debug.error(msg);
	    t.printStackTrace();
	    fireRequestMessage(new InfoDisplayEvent(this, msg));
	}
    }

    /**
     * Fetches data if it hasn't been fetched in a while.
     */
    protected boolean needToRefetchData () {
	long now = System.currentTimeMillis();
	long last = lastDataFetchTime;

	if ((last + fetchIntervalMillis) < now) {
	    lastDataFetchTime = now;
	    return true;
	}
	return false;
    }

    /**
     * Create the graphics.
     */
    protected void generateGraphics () {
	OMCircle circ;
	OMText text;

	int circle_w = 5;
	int circle_h = 5;

	if (omgraphics.size() == 0) {
	    for (int i=0, j=0; i<llData.length; i+=2, j++) {

		// grouping
		OMGraphicList group = new OMGraphicList(2);

		// XY-Circle at LatLonPoint
		circ = new OMCircle(llData[i], llData[i+1], circle_w, circle_h);
		circ.setLineColor(lineColor);
		group.add(circ);

		// Info
		text = new OMText(llData[i], llData[i+1], 0, circle_h+10, infoData[j],
			java.awt.Font.decode("SansSerif"), OMText.JUSTIFY_CENTER);
		text.setLineColor(lineColor);
		group.add(text);

		group.setAppObject(new Integer(j));//remember index
		omgraphics.add(group);
	    }
	}

	omgraphics.generate(projection, false);
    }

    /**
     * Parse the finger site data.
     * @param data Vector
     */
    protected void parseData (Vector data) {
	int nLines = data.size();
	llData = new double[2*nLines];
	infoData = new String[nLines];
	drillData = new String[nLines];
 	String sdate, stime, slat, slon, sdep, smag, squal, q, scomment;
	double flat=0, flon=0;
	int south, west;

	for (int i=0, j=0, k=0; i<nLines; i++) {
	    String line = (String)data.elementAt(i);

	    // Read a line of input and break it down
	    StringTokenizer tokens = new StringTokenizer(line);
	    sdate = tokens.nextToken();
	    stime = tokens.nextToken();
	    slat  = tokens.nextToken();
	    slon  = tokens.nextToken();
	    if (slon.startsWith("NWSE"))// handle ` ' in LatLon data
		slon = tokens.nextToken();
	    sdep  = tokens.nextToken();
	    if (sdep.startsWith("NWSE"))// handle ` ' in LatLon data
		sdep = tokens.nextToken();
	    smag  = tokens.nextToken();
	    q = tokens.nextToken();
	    scomment = tokens.nextToken("\r\n");
	    if (q.length() > 1) {
		scomment = q+" "+scomment;
	    }

	    infoData[j] = smag;
	    drillData[j++] = sdate+" "+stime+" (UTC)  "+slat+" "+slon+" "+smag+" "+scomment;
	    
	    // Remove NESW from lat and lon before converting to double
	    west = slon.indexOf("W");
	    south = slat.indexOf("S");

	    if (west >= 0)
		slon = slon.replace('W', '\0');
	    else 
		slon = slon.replace('E', '\0');
	    if (south >= 0)
		slat = slat.replace('S', '\0');
	    else 
		slat = slat.replace('N', '\0');
	    slon = slon.trim();
	    slat = slat.trim();

	    try {
		flat = new Double(slat).floatValue();
		flon = new Double(slon).floatValue();
	    } catch (NumberFormatException e) {
		Debug.error(
			"EarthquakeLayer.parseData(): " + e +
			" line: "+ line);
	    }
	    
	    // replace West and South demarcations with minus sign
	    if (south >= 0)
		flat = -flat;
	    if (west >= 0)
		flon = -flon;

	    llData[k++] = flat;
	    llData[k++] = flon;
	}
	omgraphics.clear();
    }

    /**
     * Get the earthquake data from the USGS.
     * This is called from the SwingWorker thread.
     * @return Vector
     */
    protected Vector getEarthquakeData() {
	Vector linesOfData = new Vector();
	Socket quakefinger= null;
	PrintWriter output= null;
	BufferedReader input = null;
        String line;
	
	for (int i=0; i<activeSites.length; i++) {
	    // skip sites which aren't on the active list
	    if (!activeSites[i])
		continue;

	    try {
		if (Debug.debugging("earthquake")) {
		    Debug.output("Opening socket connection to " + fingerSites[i]);
		}
		quakefinger = new Socket(fingerSites[i], 79);//open connection to finger port
		quakefinger.setSoTimeout(120*1000);// 2 minute timeout
		output = new PrintWriter(new OutputStreamWriter(quakefinger.getOutputStream()),true);
		input = new 
		    BufferedReader(new InputStreamReader(quakefinger.getInputStream()), 1);
		output.println("/W quake");// use `/W' flag for long output
	    } catch (IOException e) {
		Debug.error(
			"EarthquakeLayer.getEarthquakeData(): " +
			"can't open or write to socket: " + e);
		continue;
	    }

	
	    try {
		// add data lines to list
		while ((line = input.readLine()) != null) {
		    if (Debug.debugging("earthquake")) {
			Debug.output("EarthquakeLayer.getEarthQuakeData(): "+line);
		    }
		    if (line.length() == 0)
			continue;
		    if (!Character.isDigit(line.charAt(0)))
			continue;

		    line = hackY2K(line);
		    if (line == null)
			continue;
		    linesOfData.addElement(line);
		}
	    } catch (IOException e) {
		Debug.error(
			"EarthquakeLayer.getEarthquakeData(): " +
			"can't read from the socket: " + e);
		if (cancelled) {
		    return null;
		}
	    }

	    try {
		quakefinger.close();
	    } catch (IOException e) {
		Debug.error(
			"EarthquakeLayer.getEarthquakeData(): " +
			"error closing socket: " + e);
	    }
	}

//   	int nQuakes = linesOfData.size();
//   	for (int i=0; i<nQuakes; i++) {
//   	    Debug.output((String)linesOfData.elementAt(i));
//   	}
	return linesOfData;
    }

    // This is the USGS's date problem, not ours (of course when they
    // change their format, we'll have to update this).
    // Note that also this could just be a bogus line (not a dataline)
    // beginning with a number, so we've got to deal with it here.
    private String hackY2K (String date) {
	StringTokenizer tok = new StringTokenizer(date, "/");
	String year, month, day;
	try {
	    year = tok.nextToken();
	    month = tok.nextToken();
	    day = tok.nextToken();
	} catch (NoSuchElementException e) {
	    Debug.error(
		    "EarthquakeLayer: unparsable date: " + date);
	    return null;
	}
	if (year.length() == 2) {
	    int y;
	    try {
		y = Integer.parseInt(year);
	    } catch (NumberFormatException e) {
		Debug.error(
			"EarthquakeLayer: invalid year: " + year);
		return null;
	    }
	    // Sliding window technique...
	    if (y > 70) {
		date = "19";
	    } else {
		date = "20";
	    }
	} else if (year.length() != 4) {
	    Debug.error(
		    "EarthquakeLayer: unparsable year: " + year);
	    return null;
	}

	date = date + year + "/" + month + "/" + day;
	return date;
    }

    /**
     * Gets the gui controls associated with the layer.
     * @return java.awt.Component
     */
    public java.awt.Component getGUI () {
	JPanel p;
	if (gui == null) {
	    gui = PaletteHelper.createVerticalPanel("Earthquakes");

	    GridBagLayout gridbag = new GridBagLayout();
	    GridBagConstraints constraints = new GridBagConstraints();
	    gui.setLayout(gridbag);
	    constraints.fill = GridBagConstraints.HORIZONTAL; // fill horizontally
	    constraints.gridwidth = GridBagConstraints.REMAINDER; //another row
	    constraints.anchor = GridBagConstraints.EAST; // tack to the left edge

	    ActionListener al = new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    int index = Integer.parseInt(
			    e.getActionCommand(), 10);
		    activeSites[index] = !activeSites[index];
		}
	    };
	    p = PaletteHelper.createCheckbox(
		"Sites", fingerSites, activeSites, al);
	    gridbag.setConstraints(p, constraints);
	    gui.add(p);

	    JButton b = new JButton("Query Now");
	    b.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    // force refetch of data
		    lastDataFetchTime=0;
		    computeLayer();
		}
	    });
	    gridbag.setConstraints(p, constraints);
	    gui.add(b);

	}
	return gui;
    }

    /**
     * Returns the MapMouseListener object that handles the mouse
     * events.
     * @return the MapMouseListener for the layer, or null if none
     */
    public MapMouseListener getMapMouseListener() {
	return this;
    }

    //----------------------------------------------------------------
    // MapMouseListener interface methods
    //----------------------------------------------------------------

    /**
     * Return a list of the modes that are interesting to the
     * MapMouseListener.  The source MouseEvents will only get sent to
     * the MapMouseListener if the mode is set to one that the
     * listener is interested in.
     * Layers interested in receiving events should register for
     * receiving events in "select" mode:
     * <code>
     * <pre>
     *	return new String[] {
     *	    SelectMouseMode.modeID
     *	};
     * </pre>
     * <code>
     * @return String[] of modeID's
     * @see com.bbn.openmap.event.NavMouseMode#modeID
     * @see com.bbn.openmap.event.SelectMouseMode#modeID
     * @see com.bbn.openmap.event.NullMouseMode#modeID
     */
    public String[] getMouseModeServiceList() {
	return new String [] {
	    com.bbn.openmap.event.SelectMouseMode.modeID
	};
    }

    /**
     * Invoked when a mouse button has been pressed on a component.
     * @param e MouseEvent
     * @return true if the listener was able to process the event.
     */
    public boolean mousePressed(MouseEvent e) {
	return false;
    }
 
    /**
     * Invoked when a mouse button has been released on a component.
     * @param e MouseEvent
     * @return true if the listener was able to process the event.
     */
    public boolean mouseReleased(MouseEvent e) {
	OMGraphic obj = omgraphics.findClosest(e.getX(), e.getY(), 4);
	if (obj != null) {
	    int id = ((Integer)obj.getAppObject()).intValue();
	    fireRequestInfoLine(drillData[id]);
	    showingInfoLine = true;
	    return true;
	}
	return false;
    }

    /**
     * Invoked when the mouse has been clicked on a component.
     * The listener will receive this event if it successfully
     * processed <code>mousePressed()</code>, or if no other listener
     * processes the event.  If the listener successfully processes
     * mouseClicked(), then it will receive the next mouseClicked()
     * notifications that have a click count greater than one.
     * @param e MouseEvent
     * @return true if the listener was able to process the event.
     */
    public boolean mouseClicked(MouseEvent e) {
	return false;
    }

    /**
     * Invoked when the mouse enters a component.
     * @param e MouseEvent
     */
    public void mouseEntered(MouseEvent e) {
    }
 
    /**
     * Invoked when the mouse exits a component.
     * @param e MouseEvent
     */
    public void mouseExited(MouseEvent e) {
    }

    /**
     * Invoked when a mouse button is pressed on a component and then 
     * dragged.  The listener will receive these events if it
     * successfully processes mousePressed(), or if no other listener
     * processes the event.
     * @param e MouseEvent
     * @return true if the listener was able to process the event.
     */
    public boolean mouseDragged(MouseEvent e) {
	return false;
    }

    /**
     * Invoked when the mouse button has been moved on a component
     * (with no buttons down).
     * @param e MouseEvent
     * @return true if the listener was able to process the event.
     */
    public boolean mouseMoved(MouseEvent e) {
	// clean up display
	if (showingInfoLine) {
	    showingInfoLine = false;
	    fireRequestInfoLine("");
	}
	return false;
    }

    /**
     * Handle a mouse cursor moving without the button being pressed.
     * This event is intended to tell the listener that there was a
     * mouse movement, but that the event was consumed by another
     * layer.  This will allow a mouse listener to clean up actions
     * that might have happened because of another motion event
     * response.
     */
    public void mouseMoved() {
    }

    //----------------------------------------------------------------
    // SwingWorker implementation
    //----------------------------------------------------------------

    /**
     * Worker thread class.
     */
    protected class QuakeWorker extends SwingWorker {

	/**
	 * Construct a QuakeWorker.
	 */
	public QuakeWorker () {
	    super();
	}

	/** 
	 * Compute the value to be returned by the <code>get</code> method. 
	 * This method runs in its own Thread.
	 */
	public Object construct() {
	    fireStatusUpdate(LayerStatusEvent.START_WORKING);

	    if (Debug.debugging("earthquake")) {
		Debug.output(
		    "EarthquakeLayer.QuakeWorker.construct(): Refetching data...");
	    }

	    try {
		return getEarthquakeData();
	    } catch (Throwable t) {
		omgraphics = null;
		String msg = "EarthquakeLayer.QuakeWorker.construct(): " + t;
		Debug.error(msg);
		t.printStackTrace();
		fireRequestMessage(new InfoDisplayEvent(this, msg));
		fireStatusUpdate(LayerStatusEvent.FINISH_WORKING);
		return null;
	    }
	}

	/**
	 * Called on the event dispatching thread (not on the worker thread)
	 * after the <code>construct</code> method has returned.
	 */
	public void finished() {
	    fireStatusUpdate(LayerStatusEvent.FINISH_WORKING);
	    workerComplete(this);
	}
    }

    //----------------------------------------------------------------
    // ComponentListener implementation
    //----------------------------------------------------------------

    /**
     * Empty.
     */
    public void componentResized(ComponentEvent e) {}

    /**
     * Empty.
     */
    public void componentMoved(ComponentEvent e) {}

    /**
     * When component gets shown, compute the data.
     * @param e ComponentEvent
     */
    public void componentShown(ComponentEvent e) {
	computeLayer();
    }

    /**
     * Empty.
     */
    public void componentHidden(ComponentEvent e) {}
}

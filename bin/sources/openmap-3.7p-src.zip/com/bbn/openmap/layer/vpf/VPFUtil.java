/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998-2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/vpf/VPFUtil.java,v $
 * $Revision: 1.6 $
 * $Date: 2000/05/08 14:23:12 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.vpf;

import java.util.Hashtable;
import com.bbn.openmap.layer.util.http.HttpServer;
import com.bbn.openmap.util.Debug;

/**
 * Miscellaneous utility functions in dealing with VPF data.
 */
public class VPFUtil {
    private VPFUtil() {}; // common static function wrapper
  
    /** returns a string with the elements of v separated by spaces
     * @param v the vector to stringize
     * @return the string version of the vector
     */
    public static final String vectorToString(java.util.Vector v) {
	StringBuffer row = new StringBuffer();
	for (int i = 0; i < v.size(); i++) {
	    row.append(v.elementAt(i).toString()).append(" ");
	}
	return(row.toString());
    }
    
    /** get the value contained in the object.
     * @param val returns the value of Shorts and Integers as an int.  VPF
     * null values get returned as Integer.MIN_VALUE, as do all other types
     * @return the value contained in val
     */
    public static final int objectToInt(Object val) {
	int v = Integer.MIN_VALUE;
	if (val instanceof Integer) {
	    v = ((Integer)val).intValue();
	    if (v == Integer.MIN_VALUE+1)
		v = Integer.MIN_VALUE;
	} else if (val instanceof Short) {
	    v = ((Short)val).shortValue();
	    if (v == Short.MIN_VALUE+1)
		v = Integer.MIN_VALUE;
	}
	return v;
    }

    public final static String Edge = "Edge";
    public final static String Edges = "Edges";
    public final static String Text = "Text";
    public final static String Area = "Area";
    public final static String Point = "Point";

    /**
     * Parses dynamic args passed by specialist client.  A
     * <code>Hashtable</code> is returned as a unified holder
     * of all dynamic arguments.
     */

    public static Hashtable parseDynamicArgs (String args) {
	Hashtable dynArgs = new Hashtable();
	if (args != null) {
	    String lowerArgs = args.toLowerCase();

	    dynArgs.put(Edges, new Boolean(lowerArgs.indexOf(Edges) != -1));
	    dynArgs.put(Text, new Boolean(lowerArgs.indexOf(Text) != -1));
	    dynArgs.put(Area, new Boolean(lowerArgs.indexOf(Area) != -1));
	}
	return dynArgs;
    }

    /**
     * If <code>arg</code> maps to a <code>Boolean</code> in the Hashtable,
     * that value is returned,  <code>false</code> otherwise.
     * @param dynArgs the Hashtable to look in
     * @param arg the argument to return
     */
    public static boolean getHashedValueAsBoolean (Hashtable dynArgs,
						   String arg) {
	Object obj = dynArgs.get(arg);
	if (obj == null)
	    return false;
	else if (obj instanceof Boolean)
	    return ((Boolean)obj).booleanValue();
	else
	    return false;
    }
}

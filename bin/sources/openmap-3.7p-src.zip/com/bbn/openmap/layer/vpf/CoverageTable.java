/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998-2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/vpf/CoverageTable.java,v $
 * $Revision: 1.9 $
 * $Date: 2000/05/08 14:23:10 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.vpf;

import java.io.*;
import java.util.Vector;
import java.util.Hashtable;
import java.util.Properties;
import com.bbn.openmap.util.Debug;
import com.bbn.openmap.LatLonPoint;
import com.bbn.openmap.omGraphics.OMGraphicList;
import com.bbn.openmap.util.FormatException;

/**
 * Encapsulate a VPF coverage directory.  This class handles requests
 * that happen for a particular coverage type (political boundary,
 * road, etc.) for a particular library (north america, browse, etc.).
 */
public class CoverageTable {
  
    /** name of the VPF integer value description table */
    public final static String intVDT = "int.vdt";
    /** name of the VPF character value description table */
    public final static String charVDT = "char.vdt";

    /** our coverage type - such as "po", "bnd", "hydro" */
    final public String covtype;
    /** the directory for our coverage type */
    final private File tablepath;
    /** a table to cache int.vdt information */
    final private Hashtable intvdtrec = new Hashtable();
    /** a table to cache char.vdt information */
    final private Hashtable charvdtrec = new Hashtable();

    public int cachedLineSchema[] = null; //used by edgetable
    public FeatureClassInfo lineinfo[] = new FeatureClassInfo[0];
    public int cachedAreaSchema[] = null; //used by areatable
    public FeatureClassInfo areainfo[] = new FeatureClassInfo[0];
    public int cachedTextSchema[] = null; //used by texttable
    public FeatureClassInfo textinfo[] = new FeatureClassInfo[0];
    public int cachedPointSchema[] = null;
    public FeatureClassInfo pointinfo[] = new FeatureClassInfo[0];
    /** do we need to append a '.' to three-character file names */
    public boolean appendDot = false;

    public CoverageTable(File dcwpath, String covtype) {
	this.covtype = covtype;
	tablepath = new File(dcwpath, covtype);

	try {
	    File foo = new File(tablepath, "fcs");
	    if (!foo.canRead()) {
		foo = new File(tablepath, "fcs.");
		appendDot = true;
	    }
	    DcwRecordFile fcs = new DcwRecordFile(foo);
	    final Vector v = new Vector(fcs.getColumnCount());
	    while (fcs.parseRow(v)) {
		internSchema(v);
	    }
	    fcs.close();
	} catch (FormatException f) {
	    System.out.println("CoverageTable: " + f.getMessage());
	}
	//System.out.println("Load int vdt");
	loadIntVDT();
	//System.out.println("done\nLoad char vdt");
	loadCharVDT();
	//System.out.println("done");
    }

    /** expected schema types for int.vdt files */
    private final static char intVDTschematype[] = {'I', 'T', 'T', 'i', 'T'};
    /** expected schema lengths for int.vdt files */
    private final static int intVDTschemalength[] = {1, -1 /*12*/, -1 /*16*/,
						     1, -1 /*50*/};
    
    private void loadIntVDT() {
	try {
	    File vdt = new File(tablepath, intVDT);
	    if (vdt.canRead()) {
		DcwRecordFile intvdt = new DcwRecordFile(vdt);
		intvdt.assertSchema(intVDTschematype,
				    intVDTschemalength, false);
	
		final Vector v = new Vector(intvdt.getColumnCount());
		while (intvdt.parseRow(v)) {
		    String tab = (String)(v.elementAt(1));
		    String attr = (String)(v.elementAt(2));
		    int val = ((Number)(v.elementAt(3))).intValue();
		    intvdtrec.put(new CoverageIntVdt(tab, attr, val),
                    v.elementAt(4));
		}
		intvdt.close();
	    }
	} catch (FormatException f) {
	}

    }
    
    /** expected schema types for char.vdt files */
    private final static char charVDTschematype[] = {'I', 'T', 'T', 'T', 'T'};
    /** expected schema lengths for char.vdt files */
    private final static int charVDTschemalength[] = {1, -1 /*12*/, -1 /*16*/,
						      -1 /*2*/, -1 /*50*/};
    private void loadCharVDT() {
	try {
	    File vdt = new File(tablepath, charVDT);
	    if (vdt.canRead()) {
		DcwRecordFile charvdt = new DcwRecordFile(vdt);
		charvdt.assertSchema(charVDTschematype,
				     charVDTschemalength, false);

		final Vector v = new Vector(charvdt.getColumnCount());
		while (charvdt.parseRow(v)) {
// 		    System.out.println("ct3");  // TCMDBG
		    String tab = (String)(v.elementAt(1));
		    String attr = (String)(v.elementAt(2));
		    String val = (String)v.elementAt(3);
		    String mapsto = ((String)v.elementAt(4)).intern();
		    charvdtrec.put(new CoverageCharVdt(tab, attr, val), mapsto);
		}
		charvdt.close();
	    }
	} catch (FormatException f) {
	}
    }
    
    private FeatureClassInfo[] internSchema(FeatureClassInfo[] fti,
					    String foreign_key,
					    String tablename)
	throws FormatException
    {
	FeatureClassInfo rv[] = new FeatureClassInfo[fti.length + 1];
	System.arraycopy(fti, 0, rv, 0, fti.length);
	rv[fti.length] = new FeatureClassInfo(this, foreign_key.intern(),
					      tablepath, tablename.intern());
	return rv;
    }

    private void internSchema(Vector v) {
	String feature_class = ((String)v.elementAt(1)).toLowerCase();
	String table1 = ((String)v.elementAt(2)).toLowerCase();
	String foreign_key = ((String)v.elementAt(3)).toLowerCase();
	String table2 = ((String)v.elementAt(4)).toLowerCase();
	String primary_key = ((String)v.elementAt(5)).toLowerCase();
    
	try {
	    if (table1.equals("fac")) {
		areainfo = internSchema(areainfo, foreign_key, table2);
	    } else if (table1.equals("edg")) {
		lineinfo = internSchema(lineinfo, foreign_key, table2);
	    } else if (table1.equals("end")) {
		pointinfo = internSchema(pointinfo, foreign_key, table2);
	    } else if (table1.equals("txt")) {
		textinfo = internSchema(textinfo, foreign_key, table2);
	    } else {
	        //there shouldn't be anything else, but its not an error...
	    }
	} catch (FormatException f) {
	    System.out.println("internSchema: " + f.getMessage());
	}
    }
  
    /**
     * Get the path for this coverage
     */
    public File getDataPath() {
        return tablepath;
    }
  
    public String getDescription(String t, String a, int v) {
	CoverageIntVdt civ = new CoverageIntVdt(t,a,v);
	return((String)(intvdtrec.get(civ)));
    }
  
    public String getDescription(String t, String a, String v) {
	CoverageCharVdt civ = new CoverageCharVdt(t,a,v);
	return((String)(charvdtrec.get(civ)));
    }

    private String getDescription(Vector id, FeatureClassInfo fti[], MutableInt ret) {
	if ((fti == null) || (fti.length == 0))
	    return null;
	StringBuffer foo = null;
	for (int i = 0; i < fti.length; i++) {
	    String desc = fti[i].getDescription(id, ret);
	    if (desc != null) {
		if (foo == null)
		    foo = new StringBuffer(desc);
		else
		    foo.append(";; ").append(desc);
	    }
	}
	return((foo == null)?null:foo.toString());
    }

    public String getLineDescription(Vector lineid, MutableInt retval) {
	return getDescription(lineid, lineinfo, retval);
    }

    public String getTextDescription(Vector textid, MutableInt retval) {
	return getDescription(textid, textinfo, retval);
    }

    public String getPointDescription(Vector pointid, MutableInt retval) {
	return getDescription(pointid, pointinfo, retval);
    }

    public String getAreaDescription(Vector areaid, MutableInt retval) {
	return getDescription(areaid, areainfo, retval);
    }

    public void drawTile(TileDirectory drawtd,
			 VPFGraphicWarehouse warehouse,
			 LatLonPoint ll1, LatLonPoint ll2,
			 double dpplat, double dpplon)
    {
        boolean drawedge = warehouse.drawEdgeFeatures();
	boolean drawtext = warehouse.drawTextFeatures();
	boolean drawarea = warehouse.drawAreaFeatures();

	File tilePath = new File(tablepath, drawtd.toString());
	if (Debug.debugging("vpf.tile")) {
	    Debug.out.println("Drawtile for " + tilePath);
	}
	EdgeTable edg = null;

	try {
	    if (drawedge || drawarea) {
		edg= new EdgeTable(this, tilePath, appendDot);
	    }
	} catch (FormatException f) {
	    if (Debug.debugging("vpf.FormatException")) {
		Debug.out.println("EdgeTable: " + f.getClass()
				  + " " + f.getMessage());
	    }
	}
	TextTable tft = null;
	try {
	    if (drawtext) {
		tft = new TextTable(this, tilePath, appendDot);
	    }
	} catch (FormatException f) {
	    if (Debug.debugging("vpf.FormatException")) {
		Debug.out.println("TextTable: " + f.getClass()
				  + " " + f.getMessage());
	    }
	}
	AreaTable aft = null;
	try {
	    if (drawarea && (edg != null)) {
		aft = new AreaTable(this, edg, tilePath, appendDot);
	    }
	} catch (FormatException f) {
	    if (Debug.debugging("vpf.FormatException")) {
		Debug.out.println("AreaTable: " + f.getClass()
				  + " " + f.getMessage());
	    }
	}

	if ((aft != null) && drawarea) {
	    for (int i = 0; i < areainfo.length; i++) {
		areainfo[i].findYourself(aft);
	    }
	    aft.drawTile(warehouse, dpplat, dpplon, ll1, ll2, 
		    (tablepath.getPath().indexOf("browse") >= 0));
	}
	if ((tft != null) && drawtext) {
	    for (int i = 0; i < textinfo.length; i++) {
		textinfo[i].findYourself(tft);
	    }
 	    tft.drawTile(warehouse, dpplat, dpplon, ll1, ll2);
	}
	if ((edg != null) && drawedge) {
	    for (int i = 0; i < lineinfo.length; i++) {
		lineinfo[i].findYourself(edg);
	    }
 	    edg.drawTile(warehouse, dpplat, dpplon, ll1, ll2);
	}
//	if (Debug.On && Debug.debugging("vpf.tile"))
// 	    Debug.out.println(drawtd.toString() + " " + edgecount[0] +
// 			      " polys with " + edgecount[1] +
// 			      " points (cumulative)\n" +
// 			      drawtd.toString() + " " + textcount[0] +
// 			      " texts with " + textcount[1] +
// 			      " points (cumulative)\n" +
// 			      drawtd.toString() + " " + areacount[0] +
// 			      " areas with " + areacount[1] +
// 			      " points (cumulative)");

	if (edg != null) {
	    edg.close();
	}
	if (tft != null) {
	    tft.close();
	}
	if (aft != null) {
	    aft.close();
	}
    }

    public static void main(String [] args) {
        System.out.println("This main() is just assorted test code.");
	File f = new File("/usr/local/matt/data/vmap/disk4/vmaplv0/sasaus");
	CoverageTable ct = new CoverageTable(f ,"hydro");
	String desc = ct.getDescription(args[0], args[1], 
					Integer.parseInt(args[2]));
	System.out.println(desc);
    }
}

/**
 * A utility class used to map information from a VPF feature table to
 * its associated value in an int.vdt file.
 */
class CoverageIntVdt {
    /** the name of the table we are looking up (table is interned) */
    final String table;
    /** the name of the attribute we are looking up (attribute is interned) */
    final String attribute;
    /** the integer value we are looking up */
    final int value;
  
    /** 
     * Construct a new object
     * @param t value for the table member
     * @param a the value for the attribute member
     * @param v the value for the value member */
    public CoverageIntVdt(String t, String a, int v) {
	table = t.toLowerCase().intern();
	attribute = a.toLowerCase().intern();
	value = v;
    }

    /**
     * Override the equals method. Two CoverageIntVdts are equal if
     * and only iff their respective table, attribute and value
     * members are equal.
     */
    public boolean equals(Object o) {
	if (o instanceof CoverageIntVdt) {
	    CoverageIntVdt civ = (CoverageIntVdt)o;
	    //we can use == rather than String.equals(String) since
	    //table and attribute are interned.
	    return((table == civ.table) && (attribute == civ.attribute) &&
		   (value == civ.value));
	} else {
	    return false;
	}
    }
    
    /**
     * Override hashcode.  Compute a hashcode based on our member
     * values, rather than our (base class) object identity.
     **/
    public int hashCode() {
	return((table.hashCode() ^ attribute.hashCode()) ^ value);
    }
}

/**
 * A utility class used to map information from a VPF feature table to
 * its associated value in an char.vdt file.
 */
class CoverageCharVdt {
    /** the name of the table we are looking up (table is interned) */
    final String table;
    /** the name of the attribute we are looking up (attribute is interned) */
    final String attribute;
    /** the character value we are looking up (value is interned) */
    final String value;
  
    /**
     * Construct a new object
     * @param t value for the table member
     * @param a the value for the attribute member
     * @param v the value for the value member
     */
    public CoverageCharVdt(String t, String a, String v) {
	table = t.toLowerCase().intern();
	attribute = a.toLowerCase().intern();
	value = v.intern();;
    }

    /**
     * Override the equals method. Two CoverageIntVdts are equal if
     * and only iff their respective table, attribute and value
     * members are equal.
     */
    public boolean equals(Object o) {
        if (o instanceof CoverageCharVdt) {
	    CoverageCharVdt civ = (CoverageCharVdt)o;
	    //we can use == rather than String.equals(String) since
	    //table, attribute, and value are interned.
	    return((table == civ.table) && (attribute == civ.attribute) &&
		   (value == civ.value));
	} else {
	    return false;
	}
    }

    /**
     * Override hashcode.  Compute a hashcode based on our member
     * values, rather than our (base class) object identity.
     */
    public int hashCode() {
	return((table.hashCode() ^ attribute.hashCode()) ^ value.hashCode());
    }
}

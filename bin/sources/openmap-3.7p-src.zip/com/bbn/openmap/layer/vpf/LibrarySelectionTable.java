/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998-2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/vpf/LibrarySelectionTable.java,v $
 * $Revision: 1.10 $
 * $Date: 2000/05/08 14:23:11 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.vpf;

import java.io.File;
import java.util.Vector;
import java.util.Enumeration;
import java.util.Hashtable;
import com.bbn.openmap.LatLonPoint;
import com.bbn.openmap.util.FormatException;
import com.bbn.openmap.util.Debug;

/**
 * Reads the VPF LibraryAttribute table and constructs
 * CoverageAttributeTables for each of the library coverages (north
 * america, browse, etc) that exist.
 *
 * <p>NOTE: This class maintains a whole bunch of cached information, and
 * also hangs onto references to classes that cache even more information.
 * When using this class, you are much better off sharing an instance of 
 * this class, rather than creating multiple instantiations of it for the
 * same VPF data directory.
 *
 * @see CoverageAttributeTable
 */
public class LibrarySelectionTable { 

    /** cutoff scale for browse coverage.*/
    public final transient static int BROWSE_CUTOFF=31000000;

    /** the names of the VPF libraries listed in the library attribute table */
    private String libraryname[] = null;  //library [i]
    /** the bounding rectablge of the respective libraries */
    private Hashtable boundrec = new Hashtable();//bounding rect as [W,S,E,N]
    /** the CoverageAttributeTables corresponding to the different libs */
    private Hashtable CATs = new Hashtable();
    /** the expected schema types for the library attribute table */
    final private static char LATschematype[] = {'I', 'T', 'F', 'F', 'F', 'F'};
    /** the expected schema lengths for the library attribute table */
    final private static int LATschemalength[] = {1, -1 /*8*/, 1, 1, 1, 1};
    /** the name of the database */
    private String databaseName;
    /** the database description of itself */
    private String databaseDesc;

    /** 
     * Construct a LibrarySelectionTable without a path to data.
     */
    public LibrarySelectionTable() {
    }
  
    /**
     * Construct a LibrarySelectionTable with a path to data.
     *
     * @param vpfpath the path to the base data directory; the file opened
     * is <code>vpfpath</code>/lat.
     * @exception FormatException some error was encountered while trying to 
     * handle the file.
     */
    public LibrarySelectionTable(File vpfpath) throws FormatException {
      addDataPath(vpfpath);
    }

    /**
     * Construct a LibrarySelectionTable with a path to data.
     *
     * @param vpfpath the path to the base data directory; the file opened
     * is <code>vpfpath</code>/lat.
     * @exception FormatException some error was encountered while trying to 
     * handle the file.
     */
    public LibrarySelectionTable(String vpfpath) throws FormatException {
      addDataPath(new File(vpfpath));
    }
  
    /**
     * Construct a LibrarySelectionTable with multiple paths to data.
     *
     * @param vpfpath the paths to the data directories, the file opened
     * is <code>vpfpath</code>/lat.
     * @exception FormatException some error was encountered while trying to 
     * handle the file.
     */
    public LibrarySelectionTable(File vpfpaths[]) throws FormatException {
        for (int i = 0; i < vpfpaths.length; i++) {
	    addDataPath(vpfpaths[i]);
	}
    }

    /**
     * Construct a LibrarySelectionTable with a path to data.
     *
     * @param vpfpath the paths to the data directories; the file opened
     * is <code>vpfpath</code>/lat.
     * @exception FormatException some error was encountered while trying to 
     * handle the file.
     */
    public LibrarySelectionTable(String vpfpaths[]) throws FormatException {
        for (int i = 0; i < vpfpaths.length; i++) {
 	    addDataPath(new File(vpfpaths[i]));
	}
    }

    /**
     * add a path to LibrarySelectionTable.  Adding different types of 
     * VPF libraries to the same LST is likely to cause trouble.  (e.g.
     * it would be bad to add both DCW and VMAP paths to the same LST.
     * adding each DCW disk separately is why this method exists.)
     * 
     * @param vpfpath the path to the base DCW directory; the file opened
     * is <code>vpfpath</code>/lat.
     * @exception FormatException some error was encountered while trying to 
     * handle the file.
     */
    public void addDataPath(File vpfpath) throws FormatException {
	File latf = new File(vpfpath, "lat");
	File dhtf = new File(vpfpath, "dht");
	if (!latf.canRead()) {
	    latf = new File(vpfpath, "lat.");
	    dhtf = new File(vpfpath, "dht.");
	}
	DcwRecordFile latrf = new DcwRecordFile(latf);
	DcwRecordFile dhtrf = new DcwRecordFile(dhtf);

	Vector databaseVec = dhtrf.parseRow();
	int dcol = dhtrf.whatColumn("database_name");
	if (dcol != -1) {
	    databaseName = (String)databaseVec.elementAt(dcol);
	}
	dcol = dhtrf.whatColumn("database_desc");
	if (dcol != -1) {
	    databaseDesc = (String)databaseVec.elementAt(dcol);
	}
	dhtrf.close();
	dhtrf = null;
	
	latrf.assertSchema(LATschematype, LATschemalength, false);
	Vector v = new Vector(latrf.getColumnCount());
	while (latrf.parseRow(v)) {
	    String lname = ((String)v.elementAt(1)).toLowerCase();
	    double br[] = new double[4];
	    br[0] = ((Double)v.elementAt(2)).floatValue();
	    br[1] = ((Double)v.elementAt(3)).floatValue();
	    br[2] = ((Double)v.elementAt(4)).floatValue();
	    br[3] = ((Double)v.elementAt(5)).floatValue();
	    try {
	        CoverageAttributeTable table = new CoverageAttributeTable(vpfpath, lname);
		CATs.put(lname, table);
		boundrec.put(lname, br);
		if (Debug.debugging("vpf")) {
  		    Debug.out.println(lname + " "  + br[0] + " " + br[1] + " "
				      + br[2] + " " + br[3]);
		}
	    } catch (FormatException fe) {
	        System.err.println("Couldn't create CoverageAttributeTable for " + vpfpath + " " + lname + " " + fe.getMessage());
	    }
	}
	latrf.close();
	latrf=null;
    }
    
    /**
     * Return the list of libraries that this database has.
     * @return the list of libraries.  for DCW, this is typically NOAMER, 
     * BROWSE, etc.
     */
    public String[] getLibraryNames() {
	String[] retval = new String[CATs.size()];
	int i = 0;
	for (Enumeration e = CATs.keys(); e.hasMoreElements();) {
	    retval[i++] = (String)e.nextElement();
	}
	return retval;
    }

    /**
     * Return the name of the database we are reading from.
     */
    public String getDatabaseName() {
        return databaseName;
    }

    /**
     * Return the description of the database we are reading from.
     */
    public String getDatabaseDescription() {
        return databaseDesc;
    }

    /**
     * Return the coverage attribute table (list of coverages available
     * for the given library) for the given library name.
     *
     * @param library the name of the library to get the CAT for
     * @return the CoverageAttributeTable requested (null if the library 
     *   requested doesn't exist in the database)
     * @exception FormatException exceptions from opening the CAT for 
     *   the library
     */
    public CoverageAttributeTable getCAT(String library)
	throws FormatException {
        return (CoverageAttributeTable)CATs.get(library);
    }


    /**
     *
     */
    public void drawTile(int scale, int screenwidth, int screenheight,
			 String covname, VPFGraphicWarehouse warehouse,
			 LatLonPoint ll1, LatLonPoint ll2)
    {
	if (Debug.debugging("vpf")) {
	    Debug.out.println("Library selection table coverage: " + covname);
	    Debug.out.println("Library selection table - edges: " +
			      warehouse.drawEdgeFeatures());
	    Debug.out.println("Library selection table - text: " +
			      warehouse.drawTextFeatures());
	    Debug.out.println("Library selection table - areas: " +
			      warehouse.drawAreaFeatures());
	    Debug.out.println("Warehouse: " + warehouse);
	}

	// handle Dateline
	if ((scale < BROWSE_CUTOFF) && (ll1.getLongitude() > ll2.getLongitude())) {
	    drawTile(scale, screenwidth, screenheight, covname, warehouse,
		    ll1,
		    new LatLonPoint(ll2.getLatitude(), 180d-.00001d)//180-epsilon
		    );
	    drawTile(scale, screenwidth, screenheight, covname, warehouse,
		    new LatLonPoint(ll1.getLatitude(), -180d), ll2);
	    return;
	}

	if (Debug.debugging("vpf")) {
	    Debug.out.println("drawTile with scale of " + scale);
	}

	double dpplat = Math.abs((ll1.getLatitude() - ll2.getLatitude())
				/ screenheight);
	double dpplon = Math.abs((ll1.getLongitude() - ll2.getLongitude())
				/ screenwidth);
	
	int inArea = 0;
	CoverageTable redrawUntiled = null;
	for (Enumeration enumeration = CATs.elements(); enumeration.hasMoreElements();) {
	    CoverageAttributeTable cat = (CoverageAttributeTable) enumeration.nextElement();
	    Vector v = cat.tilesInRegion(ll1.getLatitude(),
					 ll2.getLatitude(),
					 ll2.getLongitude(),
					 ll1.getLongitude());
	    if (v == null) {
		redrawUntiled = cat.getCoverageTable(covname);
	    } else if ((v.size() > 0) && (scale < BROWSE_CUTOFF)){
		CoverageTable c = cat.getCoverageTable(covname);
		if (c == null) {
		    System.out.println("Couldn't get coverage table for " +
				       covname + " " + cat.getLibraryName());
		} else {
		    inArea++;
		    if (Debug.debugging("vpf")) {
			Debug.out.println("Using coverage table for "
					  + covname + " " 
					  + cat.getLibraryName());
		    }
		    for (Enumeration ev = v.elements(); ev.hasMoreElements();)
			c.drawTile((TileDirectory)ev.nextElement(), warehouse,
				   ll1, ll2, dpplat, dpplon);
		}
	    }
	}
	if ((redrawUntiled != null) && (inArea == 0)) {
	    redrawUntiled.drawTile(new TileDirectory(), warehouse, ll1, ll2,
				   dpplat, dpplon);
	}
    }
  

    /**
     * Just a test main to parse vpf datafiles
     * param args files to parse, plus other command line flags
     * 
     * @param args command line arguments args[0] is a path to the VPF root
     */
    public static void main (String[] args) {
        File dcwbase = null;
        if (args.length > 0) {
	    dcwbase = new File(args[0]);
	} else {
	    System.out.println("Need a path to the VPF lat. file");
	}

	try {
	    LibrarySelectionTable lst = new LibrarySelectionTable(dcwbase);
	    String liblist[] = lst.getLibraryNames();
	    for (int j = 0; j < liblist.length; j++) {
		System.out.println("Library " + liblist[j]);
		lst.getCAT(liblist[j]);
	    }
	} catch (FormatException f) { 
	    System.err.println("*****************************************"); 
	    System.err.println("*---------------------------------------*"); 
	    System.err.println("Format error in dealing with LST");
	    System.err.println(f.getMessage()); 
	    System.err.println("*---------------------------------------*"); 
	    System.err.println("*****************************************"); 
	} 
    }
}

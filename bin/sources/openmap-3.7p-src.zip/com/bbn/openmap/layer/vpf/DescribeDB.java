/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/vpf/DescribeDB.java,v $
 * $Revision: 1.4 $ * $Date: 2000/05/24 17:31:25 $
 * $Author: wjeuerle $
 * **********************************************************************
 */

package com.bbn.openmap.layer.vpf;

import java.io.File;
import java.util.Vector;
import java.util.Enumeration;
import java.util.Hashtable;
import com.bbn.openmap.util.FormatException;

/**
 * This class will print out some basic information about a VPF database.
 * <pre>
 * Usage:
 * java com.bbn.openmap.layer.vpf.DescribeDB /path/to/vpf/database
 * </pre>
 * It will then print out a description of the coverages for the database
 * to the command line. (no GUI) 
 */

public class DescribeDB {
    /**
     * Prints a string to System.out with a newline
     * @param s the string to print
     */
    public static void println(String s) {
        System.out.println(s);
    }
    /**
     * Prints two strings to System.out with a newline
     * @param s1 the string to print
     * @param s2 the string to print
     */
    public static void println(String s1, String s2) {
        println(s1 + s2);
    }
    /**
     * Prints two strings to System.out without a newline
     * @param s1 the string to print
     * @param s2 the string to print
     */
    public static void print(String s1, String s2) {
        print(s1);
	print(s2);
    }
    /**
     * Prints a string to System.out without a newline
     * @param s the string to print
     */
    public static void print(String s) {
        System.out.print(s);
    }

    /**
     * The main program.  Takes path arguments, and prints the DB it finds
     * @param args the paths to print
     */
     public static void main(String[] args) throws FormatException {
         for (int argsi = 0; argsi < args.length; argsi++) {
	     File rootpath = new File(args[argsi]);
	     LibrarySelectionTable lst = new LibrarySelectionTable(rootpath);
	     println("Path to database: " + rootpath);
	     println("Database Name: " + lst.getDatabaseName());
	     println("Database Description: " + lst.getDatabaseDescription());
	     String[] libraries = lst.getLibraryNames();
	     print("Database Libraries: ");
	     for (int i = 0; i < libraries.length; i++) {
	         print(libraries[i], " ");
	     }
	     println("");
	     println("");
	     for (int i = 0; i < libraries.length; i++) {
	         String prefix = libraries[i] + ":";
		 printLibrary(prefix, lst.getCAT(libraries[i]));
		 println("");
	     }
	 }
     }
  
    /**
     *  Prints a VPF Library
     * @param prefix lines get printed with this prefix
     * @param cat the CoverageAttributeTable (Library) to print
     */
    public static void printLibrary(String prefix, CoverageAttributeTable cat){
        if (cat == null) {
	    println(prefix, "Library doesn't exist");
	    return;
	}
	println(prefix);
	String[] coverages = cat.getCoverageNames();
	println(prefix, "uses " + (cat.isTiledData() ? "tiled" : "untiled") + " data");
	print(prefix, "Coverage names:");
	for (int i = 0; i < coverages.length; i++) {
	    print(coverages[i]);
	    print(" ");
	}
	println("");
	for (int i = 0; i < coverages.length; i++) {
	  printCoverage(prefix + coverages[i] + ":", cat, coverages[i]);
	}
    }
  
    /**
     *  Prints a VPF Coverage
     * @param prefix lines get printed with this prefix
     * @param covname the name of the coverage to print
     * @param cat the CoverageAttributeTable to get the Coverage from
     */
    public static void printCoverage(String prefix, CoverageAttributeTable cat, String covname){
        println(prefix, "Coverage Description: " + cat.getCoverageDescription(covname));
	//add topology level
	CoverageTable ct = cat.getCoverageTable(covname);
	print(prefix, "FeatureClassNames: ");
	printFeatureClassInfo(ct.areainfo);
	printFeatureClassInfo(ct.lineinfo);
	printFeatureClassInfo(ct.textinfo);
	printFeatureClassInfo(ct.pointinfo);
	println("");
	File path = ct.getDataPath();
	File fca = new File(path, "fca");
	if (!fca.exists()) {
	    fca = new File(path, "fca.");
	}
	if (!fca.canRead()) {
	    return;
	}
	try {
	    DcwRecordFile fcadesc = new DcwRecordFile(fca);
	    int fclass = fcadesc.whatColumn("fclass");
	    int type = fcadesc.whatColumn("type");
	    int descr = fcadesc.whatColumn("descr");
	    Vector v;
	    while ((v = fcadesc.parseRow()) != null) {
	        String name = (String)v.elementAt(fclass);
		String t = (String)v.elementAt(type);
		String desc = (String)v.elementAt(descr);
		String tstring = "[unknown] ";
		if (t.equals("T")) {
		    tstring = "[text feature] ";
		} else if (t.equals("L")) {
		    tstring = "[edge feature] ";
		} else if (t.equals("A")) {
		    tstring = "[area feature] ";
		} else if (t.equals("P")) {
		    tstring = "[point feature] ";
		}
		println(prefix, name + ": " + tstring + desc);
	    }
	} catch (FormatException fe) {
	    //nevermind, skip it
	}
    }
  
    /**
     * Print some featureclass names 
     * @param fcis an array of FeatureClassInfo objects whose names get
     * printed
     */
    public static void printFeatureClassInfo(FeatureClassInfo[] fcis) {
        for (int i = 0; i < fcis.length; i++) {
	  //	    print(fcis[i].getFeatureClassName(), " ");
	}
    }
}

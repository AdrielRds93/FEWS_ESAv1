/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/vpf/DcwSpatialIndex.java,v $
 * $Revision: 1.4 $
 * $Date: 2000/05/08 14:23:10 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.vpf;

import java.io.File;
import java.io.IOException;
import java.io.EOFException;
import java.util.Vector;
import java.util.BitSet;
import com.bbn.openmap.MoreMath;
import com.bbn.openmap.util.FormatException;
import com.bbn.openmap.util.BinaryFile;
import com.bbn.openmap.util.BinaryBufferedFile;

/** Read a VPF spatial index file.  (VPF *.?si files) */
public class DcwSpatialIndex {
  
    private BinaryFile inputFile = null;
    final private int numberOfPrimitives;
    final private double boundingRectx1;
    final private double boundingRecty1;
    final private double boundingRectx2;
    final private double boundingRecty2;
    final private int nodesInTree;
  
    public DcwSpatialIndex(File filename, boolean border)
	throws FormatException {
	try {
	    inputFile = new BinaryBufferedFile(filename);
	} catch (IOException e) {
	    throw new FormatException("Can't open file " + filename + ": " +
				      e.getMessage());
	}
	System.out.println("opened the file " + filename);
	inputFile.byteOrder(border);

	try {
	    numberOfPrimitives = inputFile.readInteger();
	    boundingRectx1 = inputFile.readFloat();
	    boundingRecty1 = inputFile.readFloat();
	    boundingRectx2 = inputFile.readFloat();
	    boundingRecty2 = inputFile.readFloat();
	    nodesInTree = inputFile.readInteger();

	    System.out.println("NumberOfPrimitives = " + numberOfPrimitives);
	    System.out.println("Bounding Rect = (" + boundingRectx1 +
			       ", " +    boundingRecty1 +
			       ") - (" + boundingRectx2 +
			       ", " +    boundingRecty2 + ")");
	    System.out.println("Nodes in Tree = " + nodesInTree);

	    int nodeinfo[][] = new int[nodesInTree][2]; //offset, count
      
	    for (int i = 0; i < nodesInTree; i++) {
		nodeinfo[i][0] = inputFile.readInteger();
		nodeinfo[i][1] = inputFile.readInteger();
	    }

	    int baseOffset = 24 + nodesInTree * 8;
	    BitSet b = new BitSet(nodesInTree);
	    int actprimcnt = 0;
	    b.set(0);
	    for (int i = 0; i < nodesInTree; i++) {
		if ((baseOffset + nodeinfo[i][0]) != inputFile.getFilePointer())
		    throw new FormatException("SI Input appears to be out-of-sync");
		StringBuffer pr = new StringBuffer("i=" + (i+1));
		pr.append(" offset=" + nodeinfo[i][0]);
		pr.append(" count=" + nodeinfo[i][1]);
		for (int j = 0; j < nodeinfo[i][1]; j++) {
		    actprimcnt++;
		    byte foo[] = inputFile.readBytes(4, false); //x1 y1 x2 y2
		    int primid = inputFile.readInteger();
		    //print as "primid: x1 x2 y1 y2"
		    pr.append("\n\t(" + primid + ": \t" + MoreMath.signedToInt(foo[0]));
		    pr.append(" \t" + MoreMath.signedToInt(foo[2]));
		    pr.append(" \t" + MoreMath.signedToInt(foo[1]));
		    pr.append(" \t" + MoreMath.signedToInt(foo[3]));
		    pr.append(")");
		}
		if (nodeinfo[i][1] != 0) {
		    if ((i < 15) || ((i+1) == nodesInTree))
			System.out.println(pr);
		    b.set(i+1);
		    if (!b.get((i+1)/2))
			throw new FormatException("Bill's condition failed");
		}
	    }
	    if (actprimcnt == numberOfPrimitives) {
		System.out.println("Got the right number of primitives");
	    } else {
		System.out.println("!!Got the wrong number of primitives");
	    }
	    if (inputFile.available() != 0)
		throw new FormatException("Bytes left at end of file " + inputFile.available());
	} catch (EOFException e) {
	    throw new FormatException("Hit Premature EOF in thematic index");
	} catch (IOException i) {
	    throw new FormatException("Encountered IO Exception: " + i.getMessage());
	}
    }
    private int ReadIndexWithFieldType(char ft)
	throws EOFException, FormatException {
	switch (ft) {
	case 'S':
	    return (int)inputFile.readShort();
	case 'I':
	    return inputFile.readInteger();
	}
	throw new FormatException("Unrecognized FieldTypeOfIndex");
    }

    private Object ReadIndexField(char dts, int textlen)
	throws EOFException, FormatException {
	switch (dts) {
	case 'I':
	    return new Integer(inputFile.readInteger());
	case 'T':
	    return inputFile.readFixedLengthString(textlen);
	case 'S':
	    return new Short(inputFile.readShort());
	case 'F':
	    return new Double(inputFile.readFloat());
	case 'R':
	    return new Double(inputFile.readDouble());
	}
	throw new FormatException("Unrecognized field index type");
    }

    private String stripafternul(String s) {
	StringBuffer ns = new StringBuffer();
	char foo[] = s.toCharArray();
	for (int i = 0; i < foo.length; i++) {
	    if (foo[i] == 0)
		break;
	    ns.append(foo[i]);
	}
	return ns.toString();
    }

    public void close() {
	try {
	    inputFile.close();
	} catch (IOException i) {
	    System.out.println("Caught ioexception " + i.getClass() + " " + i.getMessage());
	}
    }
}

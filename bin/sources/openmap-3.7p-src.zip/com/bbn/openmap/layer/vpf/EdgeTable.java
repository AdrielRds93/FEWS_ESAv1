/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998-2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/vpf/EdgeTable.java,v $
 * $Revision: 1.11 $
 * $Date: 2000/05/08 14:23:11 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.vpf;

import java.awt.Color;
import java.io.File;
import java.util.Vector;

import com.bbn.openmap.LatLonPoint;
import com.bbn.openmap.util.Debug;
import com.bbn.openmap.util.FormatException;

/**
 * Read VPF format edge tables to generate polyline graphics for
 * OpenMap.
 */
public class EdgeTable extends DcwRecordFile {

    /** a reference to the coveragetable this edge tile is in, so that
     * we can look up topology information. */
    private CoverageTable covtable;

    public EdgeTable(CoverageTable cov, File tilePath, boolean appendDot) throws FormatException{
	super(tilePath, (appendDot?"edg.":"edg"));
	if (Debug.debugging("vpf")) {
	    Debug.out.println("EdgeTable(): " + filename.getPath()
			      + com.bbn.openmap.Environment.get("file.separator")
			      + filename.getName());
	}
	covtable = cov;
	if (cov.cachedLineSchema == null) {
	    cov.cachedLineSchema = new int[8];
	    cov.cachedLineSchema[0] = whatColumn("id");
	    cov.cachedLineSchema[1] = whatColumn("start_node");
	    cov.cachedLineSchema[2] = whatColumn("end_node");
	    cov.cachedLineSchema[3] = whatColumn("right_face");
	    cov.cachedLineSchema[4] = whatColumn("left_face");
	    cov.cachedLineSchema[5] = whatColumn("right_edge");
	    cov.cachedLineSchema[6] = whatColumn("left_edge");
	    cov.cachedLineSchema[7] = whatColumn("coordinates");
	}
    }

    public final int getId(Vector v) {
	return ((Number)v.elementAt(covtable.cachedLineSchema[0])).intValue();
    }
    public final int getStartNode(Vector v) {
	return ((Number)v.elementAt(covtable.cachedLineSchema[1])).intValue();
    }
    public final int getEndNode(Vector v) {
	return ((Number)v.elementAt(covtable.cachedLineSchema[2])).intValue();
    }
    public final DcwCrossTileID getRightFace(Vector v) {
	return (DcwCrossTileID)v.elementAt(covtable.cachedLineSchema[3]);
    }
    public final DcwCrossTileID getLeftFace(Vector v) {
	return (DcwCrossTileID)v.elementAt(covtable.cachedLineSchema[4]);
    }
    public final DcwCrossTileID getRightEdge(Vector v) {
	return (DcwCrossTileID)v.elementAt(covtable.cachedLineSchema[5]);
    }
    public final DcwCrossTileID getLeftEdge(Vector v) {
	return (DcwCrossTileID)v.elementAt(covtable.cachedLineSchema[6]);
    }
    public final CoordFloatString getCoordinates(Vector v) {
	return (CoordFloatString)v.elementAt(covtable.cachedLineSchema[7]);
    }

    /** get the topology level of the edge table
     * @return the vpf topology level
     */
    public int topologyLevel() {
	if (covtable.cachedLineSchema[1] == -1) //no start_node, topology level 0
	    return 0;
	if (covtable.cachedLineSchema[3] == -1) //no right_face, level 1 or 2
	    return 2;
	return 3;
    }

    /**
     * get the coverage table that this edge is in 
     */
    public CoverageTable getCoverageTable() {
        return covtable;
    }


    public void drawTile(VPFGraphicWarehouse warehouse,
			 double dpplat, double dpplon,
			 LatLonPoint ll1, LatLonPoint ll2)
    {
	if (warehouse == null) return;

	try {
	    seekToRow(1);
	    Vector v = new Vector();
	    while (parseRow(v)) {
		//int id = getId(v);

		CoordFloatString coords = getCoordinates(v);

		warehouse.createEdge(covtable, this, v, ll1, ll2,
				     dpplat, dpplon, coords);

	    }
	} catch (FormatException f) {
	    System.out.println(
		    "Exception: " + f.getClass() + " " + f.getMessage());
	}
    }
}

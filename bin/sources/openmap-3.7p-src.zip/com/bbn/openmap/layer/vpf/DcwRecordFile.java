/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998-2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/vpf/DcwRecordFile.java,v $
 * $Revision: 1.10 $
 * $Date: 2000/05/08 14:23:10 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.vpf;

import java.io.*;
import java.util.Vector;
import com.bbn.openmap.MoreMath;
import com.bbn.openmap.util.FormatException;
import com.bbn.openmap.util.BinaryFile;
import com.bbn.openmap.util.BinaryBufferedFile;

/**
 * Read and encapsulate VPF table files.
 */
public class DcwRecordFile {
  
    /** input is read from this file */
    protected BinaryFile inputFile = null;
    /** the description of the table [read from the file] */
    protected String tableDescription = null;
    /** the name of another table that describes what this one is for */
    protected String documentationFileName = null;
    /** number of bytes consumed by the table header */
    private int headerLength = 4; //for the 4 bytes of the headerlength field
    /** big-endian (<code>true</code>) or little-endian (<code>false</code>) */
    protected boolean MSBFirst = false;
    /** ordered set of columns (read from table header) */
    protected DcwColumnInfo[] columnInfo = null;
    /** length of a record (<code>-1</code> indicates variable-length record */
    protected int recordLength = 0;
    /** for tables with variable-length records, the corresponding
     * variable-length index */
    protected DcwVariableLengthIndexFile vli = null;
    /** the name of the file */
    final protected File filename;
    /** the name of the table */
    protected String tablename = null;

    /** Open a DcwRecordFile and completely initialize it
     * @param file the file to use for input
     * @exception FormatException some problem was encountered dealing with
     *	the file
     */
    public DcwRecordFile(File file) throws FormatException {
	this(file, false);
    }
    
    /** Open a DcwRecordFile and completely initialize it.  This constructor
     * is equivelent to DcwRecordFile(new File(path, name)).
     * @param path the path of the file for input
     * @param name the name of the file to open
     * @exception FormatException some problem was encountered dealing with
     *	the file
     */
    public DcwRecordFile(File path, String name) throws FormatException {
	this(new File(path, name), false);
    }
    
    /** Open a DcwRecordFile
     * @param file the file to use for input
     * @param deferInit if <code>true</code>, don't actually open files and
     *	initialize the object.  In this state, the only method that
     *	should be called is finishInitialization.
     * @exception FormatException some problem was encountered dealing with
     *	the file
     * @see #finishInitialization()
     */
    public DcwRecordFile(File file, boolean deferInit) throws FormatException {
	this.filename = file;
	if (!deferInit) {
	    finishInitialization();
	}
    }

    /** Open a DcwRecordFile.  This constructor is equivelent to 
     * DcwRecordFile(new File(path, name), deferInit).
     * @param path the path of the file for input
     * @param name the name of the file to open
     * @param deferInit if <code>true</code>, don't actually open files and
     *	initialize the object.  In this state, the only method that
     *	should be called is finishInitialization.
     * @exception FormatException some problem was encountered dealing with
     *	the file
     * @see #finishInitialization()
     */
    public DcwRecordFile(File path, String name, boolean deferInit) 
        throws FormatException {
	this(new File(path, name), deferInit);
    }

    /**
     * Strip the tablename out of the filename.  Strips both path information
     * and the trailing '.', if it exists.
     */
    private void internTableName() {
	String file = filename.getName();
	int strlen = file.length();
	int lastchar = file.endsWith(".")?strlen-1:strlen;
	tablename = file.substring(0, lastchar).toLowerCase().intern();
    }

    /** 
     * return the name of the table
     */
    public String getTableName() {
      return tablename;
    }
  
    /** Complete initialization of this object.  This function should only
     * be called once, and only if the object was constructed with defered
     * initialization.
     * @exception FormatException some problem was encountered dealing with
     *	the file */
    public synchronized void finishInitialization() throws FormatException {
	internTableName();
	try {
	    inputFile = new BinaryBufferedFile(filename);
	} catch (IOException e) {
	    throw new FormatException(e.toString());
	}
	//System.out.println("opened the file " + filename);
	try {
	    byte preHeaderLen[] = inputFile.readBytes(4, false);
	    
	    char delim = inputFile.readChar();
	    switch (delim) {
	    case 'L': case 'l':
		delim = inputFile.readChar();
		//Intentional fall through to set byteorder
	    case ';': //default is LSB first
		inputFile.byteOrder(false);
		break;
	    case 'M': case 'm': //alternatively, it can be MSB first
		inputFile.byteOrder(true);
		delim = inputFile.readChar();
		break;
	    default:
		throw new FormatException("Invalid Byte Encoding Format");
	    }
	    headerLength += MoreMath.BuildInteger(preHeaderLen,
						  inputFile.byteOrder());
	    if (delim != ';') //Sanity check the input
		throw new FormatException("Unexpected character in header");
	    
	    tableDescription = inputFile.readToDelimiter(';');
	    documentationFileName = inputFile.readToDelimiter(';');
	    
	    Vector tmpcols = new Vector();
	    try {
		while (true) {
		    DcwColumnInfo dci = new DcwColumnInfo(inputFile);
		    int collen = dci.fieldLength();
		    if ((collen == -1) || (recordLength == -1)) {
		        recordLength = -1;
		    } else {
		        recordLength += collen;
		    }
		    tmpcols.addElement(dci);
		}
	    } catch (EOFException e) {
	    }
	    
	    columnInfo = new DcwColumnInfo[tmpcols.size()];
	    tmpcols.copyInto(columnInfo);
	} catch (EOFException e) {
	    throw new FormatException("Caught EOFException: " +
				      e.getMessage());
	}
    }


    /** make a claim as to what you expect the table to look like
     * @param types in order that you expect the columns [from VPF spec]
     * @param length array of lengths of the respective columns (-1 for a
     *        variable length column)
     * @param strictlength false means that variable length columns can be
     *        fixedlength instead
     * @exception FormatException the table does not match the specified schema
     */
    public void assertSchema(char type[], int length[], boolean strictlength) throws FormatException {
        if (type.length != columnInfo.length) {
	    throw new FormatException("assertSchema: column count incorrect");
	}
	for (int i = 0; i < type.length; i++) {
	    columnInfo[i].assertSchema(type[i], length[i], strictlength);
	}
    }
    
    /** Good for looking at the contents of a data file, this method dumps
     * a bunch of rows to System.out.  It parses all the lines of the file.
     * @exception FormatException some kind of data format error was
     *    encountered while parsing the file */
    public void parseAllRowsAndPrintSome() throws FormatException {
	Vector v;
	String vectorString = null;
	int rowcount = 0;
	while ((v = parseRow()) != null) {
	    rowcount++;
	    int cnt = ((Integer)(v.elementAt(0))).intValue();
	    if (cnt != rowcount) {
		System.out.println("Non-consecutive row number.  Expected " +
				   rowcount + " got " + cnt);
	    }
	    vectorString = VPFUtil.vectorToString(v);
	    if ((rowcount < 20) || (rowcount % 100 == 0))
		System.out.println(vectorString);
	}
	if (rowcount > 20)
	    System.out.println(vectorString);
    }

    /**
     * Good for looking at the contents of a data file, this method
     * dumps a bunch of rows to System.out.  (Using seekToRow to move between
     * records
     *
     * @exception FormatException some kind of data format error was
     *   encountered while parsing the file
     */
    public void parseSomeRowsAndPrint() throws FormatException {
	Vector v;
	int rowcount = getRecordCount();
	for (int i=1; i <= rowcount; i++) {
	    if ((i > 10) && ((i%100) != 0) && (i != rowcount))
		continue;
	    seekToRow(i);
	    v = parseRow();
	    int cnt = ((Integer)(v.elementAt(0))).intValue();
	    if (cnt != i)
		System.out.println("Possible incorrect seek for row number " +
				   i + " got " + cnt);
	    System.out.println(VPFUtil.vectorToString(v));
	}
    }

    /** return a row from the table.  repeatedly calling parseRow gets 
     * consecutive rows.
     * @return a vector of fields read from the table
     * @exception FormatException an error was encountered reading the row
     */
    public synchronized Vector parseRow() throws FormatException {
//  	System.out.println("parseRow consing"); // TCMDBG
	Vector retval = new Vector(getColumnCount());
	try {
	    for (int i = 0; i < columnInfo.length; i++) {
		Object newobj = columnInfo[i].parseField(inputFile);
		//System.out.println(newobj.toString());
		retval.addElement(newobj);
	    }
	    return retval;
	} catch (FormatException f) {
	    throw new FormatException("parserow: " + f.getMessage());
	} catch (EOFException e) {
	    if (retval.size() != 0)
		throw new FormatException("EOF when vector = " +
					  VPFUtil.vectorToString(retval));
	    try {
		if (inputFile.available() != 0) 
		    throw new FormatException("EOF with available = " +
					      inputFile.available());
	    } catch (IOException i) {
		throw new FormatException("IOException calling available()");
	    }
	    return null;
	}
    }

    /** return a row from the table.  repeatedly calling parseRow gets 
     * consecutive rows.
     * @param retval append the fields from a row in the table. 
     * removeAllElements() is called before any real work is done.
     * @return true is we read a row, false if no more rows are available
     * @exception FormatException an error was encountered reading the row
     * @see java.util.Vector#removeAllElements()
     */
    public synchronized boolean parseRow(final Vector retval)
	throws FormatException {
        retval.removeAllElements();
	try {
	    for (int i = 0; i < columnInfo.length; i++) {
		Object newobj = columnInfo[i].parseField(inputFile);
		retval.addElement(newobj);
	    }
	    return true;
	} catch (FormatException f) {
	    throw new FormatException("parserow on table " + filename + ": " + f.getMessage());
	} catch (EOFException e) {
	    if (retval.size() != 0)
		throw new FormatException("EOF when vector = " +
					  VPFUtil.vectorToString(retval));
	    try {
		if (inputFile.available() != 0) 
		    throw new FormatException("EOF with available = " +
					      inputFile.available());
	    } catch (IOException i) {
		throw new FormatException("IOException calling available()");
	    }
	    return false;
	}
    }

    /** get the length of a single record
     * @return -1 indicates a variably sized record */
    public int getRecordLength() {
	return recordLength;
    }

    /**
     * Gets the number of records in the table.
     *
     * @return the number of records
     * @exception FormatException some problem was encountered dealing with
     *	the file
     */
    public int getRecordCount() throws FormatException {
	try {
	    if (recordLength == -1)
		return vli().getRecordCount();
	    else
		return (int)(inputFile.length() - headerLength) / recordLength;
	} catch (IOException i) {
	    System.out.println("RecordCount: io exception " + i.getMessage());
	}
	return -1;
    }

    final private DcwVariableLengthIndexFile vli() throws FormatException {
        if (vli == null) {
	    openVLI();
	}
	return vli;
    }

    /** opens the associated variable length index for the file
     * @exception FormatException an error. */
    private void openVLI() throws FormatException {
	String realfname = filename.toString();
	boolean endwithdot = realfname.endsWith(".");
	String fopen;
	if (endwithdot) {
	    StringBuffer newf = new StringBuffer(realfname.substring(0, realfname.length()-2));
	    fopen = newf.append("x.").toString();
	} else {
	    StringBuffer newf = new StringBuffer(realfname.substring(0, realfname.length()-1));
	    fopen = newf.append("x").toString();
	}
	vli = new DcwVariableLengthIndexFile(new File(fopen),
					     inputFile.byteOrder());
    }

    /** parses the row specified by rownumber
     * @arg rownumber the number of the row to return [1..recordCount]
     * @return the values contained in the row
     * @exception FormatException data format errors */
    public synchronized Vector getRow(int rownumber) throws FormatException {
	if (inputFile == null)
	    reopen(rownumber);
	else
	    seekToRow(rownumber);
// 	System.out.println("drf1");  // TCMDBG
	return parseRow();
    }

    /**
     * parses the row specified by rownumber
     * @param rownumber the number of the row to return [1..recordCount]
     * @param retval values contained in the row
     * @exception FormatException data format errors
     * @see #parseRow()
     */
    public synchronized boolean getRow(final Vector retval,
				       final int rownumber)
	throws FormatException {
	if (inputFile == null)
	    reopen(rownumber);
	else
	    seekToRow(rownumber);
	return parseRow(retval);
    }

    /** moves the input cursor to the specified row [affects subsequent calls
     * parseRow.]
     * @arg recordNumber the number of the row to seek to
     * @exception FormatException data format errors
     * @exception IllegalArgumentException recordNumber less than 1
     */
    public synchronized void seekToRow(int recordNumber) throws FormatException {
	if (recordNumber <= 0)
	    throw new IllegalArgumentException("DcwRecordFile: seekToRow(" +
					       recordNumber + "," + getRecordCount() + "," +
					       filename+ ")");
	int offset;
	if ((recordLength == -1) && (recordNumber != 1)) {
	    offset = vli().recordOffset(recordNumber);
	} else {
	    offset = (recordLength * (recordNumber - 1)) + headerLength;
	}
	try {
	    inputFile.seek(offset);
	} catch (IOException io) {
	    throw new FormatException("SeekToRow IOException " +
				      io.getMessage() +
				      " offset: " + offset + " " +
				      tablename + " " +filename);
	}
    }

    /** returns the index into columnInfo of the column with the specified name
     * @arg columnname the column name to match
     * @return an index into columnInfo (-1 indicates no such column)
     */
    public int whatColumn(String columnname) {
        for (int i = 0; i < columnInfo.length; i++) {
	    if (columnInfo[i].getColumnName().equals(columnname)) {
		return i;
	    }
	}
	return -1;
    }
    
    /** returns the name of a column
     * @arg index the column to get the name for
     * @return the columnName */
    public String getColumnName(int index) {
	return columnInfo[index].getColumnName();
    }
    
    /**
     * Prints the table information to System.out.
     *
     * @exception FormatException some problem was encountered dealing with
     *	the file
     */
    public void printSchema() throws FormatException {
	System.out.println("File Name: " + filename +
			   "\nTable name: " + tablename +
			   "\nTable Description: " + tableDescription +
			   "\nDocumentation File Name: " + documentationFileName +
			   "\nRecord Length: " + recordLength +
			   " Record Count: " + getRecordCount());
	for (int i = 0; i < columnInfo.length; i++) {
	    System.out.print("Column " + i + " " +
			     columnInfo[i].toString() + "\n");
	}
	System.out.flush();
    }

    /** Closes the associated input file. (may later get reopened) */
    public synchronized void close() {
	try {
	    if (inputFile != null) {
		inputFile.close();
	    }
	    inputFile = null;
	} catch (IOException i) {
	    System.out.println("Caught ioexception " + i.getMessage());
	}
    }

    /** Reopen the associated input file.
     * @param seekRow the row to seek to upon reopening the file.  If seekRow
     * is invalid (less than 1), then the input stream is in an undefined
     * location, and seekToRow (or getRow(int)) must be called before parseRow
     * @exception FormatException some error was encountered in reopening
     *  file or seeking to the desired row.
     * @see #parseRow()
     * @see #getRow(int)
     * @see #close()
     */
    public synchronized void reopen(int seekRow) throws FormatException {
	try {
	    if (inputFile == null) {
		inputFile = new BinaryBufferedFile(filename);
	    }
	    if (seekRow > 0) {
		seekToRow(seekRow);
	    }
	} catch (IOException i) {
	    throw new FormatException(i.getClass() + ": " + i.getMessage());
	}
    }

    /**
     * Returns the number of columns this table has
     */
    final public int getColumnCount() {
        return columnInfo.length;
    }
  
    /**
     * Return the column info for this table. <p>
     * NOTE: modifying this array is likely to cause problems...
     */
    final public DcwColumnInfo[] getColumnInfo() {
	return columnInfo;
    }

    /** releases associated resources */
    public void finalize() {
	close();
    }

    public static void main(String args[]) {
	for (int i = 0; i < args.length; i++) {
	    System.out.println(args[i]);
	    try {
		DcwRecordFile foo = new DcwRecordFile(new File(args[i]));
		foo.printSchema();
		foo.close();
		foo.reopen(1);
		Vector v;
		while ((v = foo.parseRow()) != null) {
		    System.out.println(VPFUtil.vectorToString(v));
		}
		foo.close();
	    } catch (Exception e) {
		e.printStackTrace();
	    }
	}
    }
}

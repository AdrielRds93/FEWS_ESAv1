/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/vpf/CoordDoubleString.java,v $
 * $Revision: 1.5 $
 * $Date: 2000/05/08 14:23:10 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.vpf;
import com.bbn.openmap.util.BinaryFile;
import com.bbn.openmap.util.FormatException;

import java.io.EOFException;

/**
 * Encapsulate the VPF Double Coordinate String primitive datatype.
 */

public class CoordDoubleString implements CoordTupleString {

    /** where we store the data */
    final private double vals[][];

    /**
     * Construct a CoordDoubleString from a file input
     *
     * @param tuplecount the number of tuples to read from the input stream
     * @param tuplesize the number of doubles in the tuple
     * @param input the input stream to read everything from
     * @exception FormatException if we have IO errors or premature end-of-file
     */
    public CoordDoubleString(int tuplecount, int tuplesize, BinaryFile input)
        throws FormatException {
	try {
	    vals = new double[tuplecount][tuplesize];
	    for (int i = 0; i < tuplecount; i++)
		for (int j = 0; j < tuplesize; j++)
		    vals[i][j] = input.readDouble();
	} catch (EOFException e) {
	    throw new FormatException("CoordDoubleString EOFException");
	}
    }

    /** The maximum indexable tuple value
     * @return the maximum valid tuple index */
    public int maxIndex() {
	return vals.length;
    }

    /** Accessor for the underlying primitive type
     * @return a Double, since that's what we manage */
    public Number getPrimitiveType() {
	return new Double(0.0);
    }

    /** A pretty formatter for the doublestring
     * @return a pretty string of the tuple */
    public String toString() {
	StringBuffer retval = new StringBuffer("CDS:" + vals.length + "[");

	for (int i=0; i < vals.length; i++) {
	    retval.append("(");
	    for (int j=0; j < vals[i].length; j++)
		retval.append(vals[i][j]+", ");
	    retval.append(") ");
	}
	retval.append("]");
	return retval.toString();
    }

    /** Get the first value of a tuple
     * @param tuple the index of the tuple
     * @return the first value of the tuple given by <code>tuple</code> */
    public double getXasFloat(int tuple) {
	return vals[tuple][0];
    }
    /** Get the first value of a tuple
     * @param tuple the index of the tuple
     * @return the first value of the tuple given by <code>tuple</code> */
    public double getXasDouble(int tuple) {
	return vals[tuple][0];
    }

    /** Get the second value of a tuple
     * @param tuple the index of the tuple
     * @return the second value of the tuple given by <code>tuple</code> */
    public double getYasFloat(int tuple) {
	return vals[tuple][1];
    }
    /** Get the second value of a tuple
     * @param tuple the index of the tuple
     * @return the second value of the tuple given by <code>tuple</code> */
    public double getYasDouble(int tuple) {
	return vals[tuple][1];
    }
  
    /** Get the third value of a tuple
     * @param tuple the index of the tuple
     * @return the third value of the tuple given by <code>tuple</code> */
    public double getZasFloat(int tuple) {
	if (vals[tuple].length >= 3)
	    return vals[tuple][2];
	return 0.0d;
    }
    /** Get the third value of a tuple
     * @param tuple the index of the tuple
     * @return the third value of the tuple given by <code>tuple</code> */
    public double getZasDouble(int tuple) {
	if (vals[tuple].length >= 3)
	    return vals[tuple][2];
	return 0.0;
    }

    /** Get a tuple
     * @param tuple the index of the tuple
     * @return the tuple given by <code>tuple</code> */
    public double[] getasFloat(int tuple) {
	int tusize = vals[tuple].length;
	double rv[] = new double[tusize];
	for (int i=0; i < tusize; i++)
	    rv[i] = vals[tuple][i];
	return rv;
    }
    /** Get a tuple
     * @param tuple the index of the tuple
     * @return the tuple given by <code>tuple</code> */
    public double[] getasDouble(int tuple) {
	return vals[tuple];
    }

    /** Get a value in a tuple
     * @param tuple the index of the tuple
     * @param val the index of the value
     * @return the tuple given by <code>tuple</code> */
    public double getasFloat(int tuple, int val) {
	return vals[tuple][val];
    }

    /** Get a value in a tuple
     * @param tuple the index of the tuple
     * @param val the index of the value
     * @return the tuple given by <code>tuple</code> */
    public double getasDouble(int tuple, int val) {
	return vals[tuple][val];
    }
}

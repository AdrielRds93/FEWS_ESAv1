/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/vpf/TileDirectory.java,v $
 * $Revision: 1.4 $
 * $Date: 2000/05/08 14:23:12 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.vpf;

import java.io.File;
import java.util.Enumeration;
import java.util.NoSuchElementException;

/** This class maps latitudes and longitudes to a particular tile directory. */
public class TileDirectory {

    /** the name of the subdirectory */
    final private String tilename;
    /** the boundaries */
    final private double westlon, southlat, eastlon, northlat;

    /** construct a TileDirectory with a path and boundaries
     * @param path the directory path
     * @param n the northern boundary
     * @param s the southern boundary
     * @param e the eastern boundary
     * @param w the western boundary */
    public TileDirectory(String path, double n, double s, double e, double w) {
	StringBuffer strbuf = new StringBuffer(path.toLowerCase());
	strbuf.append(File.separator);
	tilename = strbuf.toString().intern();
	if (e < w)
	    e += 360.0;
	westlon = w;
	eastlon = e;
	northlat = n;
	southlat = s;
    }
  
    /** contruct an untiled TileDirectory.  Since this object does not
     * have valid boundaries, it is an error to call inRegion on it
     * @see #inRegion(double, double, double, double) */
    public TileDirectory() {
	tilename = "";
	westlon = eastlon = northlat = southlat = Double.NaN;
    }
    
    /** return a string describing ourselves
     * @return a string usable as a directory path component */
    public String toString() {
	return(tilename);
    }

    /** figure out if our region overlaps the passed in region
     * @return <code>true</code> if the regions overlap
     * @param n the northern boundary
     * @param s the southern boundary
     * @param e the eastern boundary
     * @param w the western boundary */
    public boolean inRegion(double n, double s, double e, double w) {
	// take care of the easy case first...
	if ((s > northlat) || (n < southlat))
	    return false;
	if (e < w)
	    e += 360.0d;
	if ((w > eastlon) || (e < westlon))
	    return false;
	return true;
    }
}

/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998-2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/vpf/FeatureClassInfo.java,v $
 * $Revision: 1.8 $
 * $Date: 2000/08/03 14:46:20 $
 * $Author: dietrick $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.vpf;

import java.io.File;
import java.util.Vector;
import com.bbn.openmap.util.Debug;
import com.bbn.openmap.util.FormatException;
import com.bbn.openmap.util.BinaryFile;

/**
 *  This class wraps a feature type file (potext.tft, bndryln.lft, etc) from
 * VPF.  It maintains sufficient information about the table it is indexed from
 * so that it can take a vector of values, rather than a single value.  It
 * also knows about its containing CoverageTable so it can look up 
 * information in int.vdt and char.vdt.
 */
class FeatureClassInfo
    extends DcwRecordFile
    implements TerminatingRunnable, com.bbn.openmap.util.Closable {

    /** the table to look up .vdt info from */
    final private CoverageTable ctable;
    /** the name of our column from the primitive table (e.g. potext.tft_id) */
    final private String columnname;
    /** the column number in the primitive table for columnname */
    private int mycolumn = -1;
    /** true means the object has run(), false otherwise */
    private boolean fullInit = false;
    
    /** things constructed with deferred initialization get queued here */
    final private static RunQueue tq = new RunQueue(true, Thread.MIN_PRIORITY, true);

    /** temporary vector for use in getDescription() */
    final private Vector tmpVec = new Vector();

    /** Construct a FeatureClassInfo.
     * @param cthis the CoverageTable to use for vdt lookups
     * @param colname the column name from the primitive table
     * @param tablepath the directory of the feature table
     * @param ftname the name of the feature type
     * @exception FormatException some error was encountered */
    public FeatureClassInfo(CoverageTable cthis, String colname,
			    File tablepath, String ftname)
        throws FormatException {
	super(new File(tablepath, ftname), true); //defer initialization
	ctable = cthis;
	columnname = colname.toLowerCase().intern();
	tq.enqueue(this);
    }
    
    /**
     * Complete the initialization of the FeatureClassInfo.  This function
     * can be called more than once.
     */
    public synchronized void run() {
	if (fullInit == true) //run already ran, or the file didn't exist
	    return;
	
	try {
	    fullInit = true;
	    finishInitialization(); //finish initialization of table
	    BinaryFile.addClosable(this);
	} catch (FormatException f) {
	    close(); //invalidate some stuff
	}
    }
    
    public boolean close(boolean done) {
	close();
	return true;
    }

    /**
     * Probe the DcwRecordFile looking for what column we are in. (Info
     * needed later to getDescription with the data vector.)
     * @param rf the primitive data table we'll get rows from
     */
    public void findYourself(DcwRecordFile rf) {
	mycolumn = rf.whatColumn(columnname);
    }
    
    /**
     * Given a row from the primitive table, this function returns a
     * full string description of the row
     * @param v the record vector from the primitive table
     * @param type the first integral type
     * @return the description string for the vector
     */
    public synchronized String getDescription(Vector v, MutableInt type) {
	if (fullInit == false){
	    if (Debug.debugging("vpf")) {
		Debug.out.println("getDescription forcing init "
				  + columnname + " " + tablename);
	    }
	    run();
	}
	if (mycolumn == -1)
	    return null;
	int i = VPFUtil.objectToInt(v.elementAt(mycolumn));
	if (i <= 0)
	    return null;
	return getDescription(i, type);
    }
    
    /** 
     * Given an primary key (row id) for the feature table, return the
     * string description.  If made public, this function would need to
     * be synchronized and check for proper initialization.  But since it
     * is always called from a method that does that, its okay.
     * @param ftid the row id for our feature table
     * @param type the first integral type
     * @return the description string for the vector 
     */
    private synchronized String getDescription(int ftid, MutableInt type) {
	StringBuffer retval = null;
	try {
	    if (!getRow(tmpVec, ftid))
		return null;
	    int cvdtindex = 0;
	    int ivdtindex = 0;
	    for (int i=0; i < columnInfo.length; i++) {
		DcwColumnInfo dci = columnInfo[i];
		String s = null;
		String dciVDT = dci.getVDT();
		if (dciVDT == CoverageTable.intVDT) {
		    int val = VPFUtil.objectToInt(tmpVec.elementAt(i));
		    if (val == Integer.MIN_VALUE) //VPF null
			continue;
		    if (ivdtindex == 0) {
			type.value = (short)val;
		    }
		    s =ctable.getDescription(tablename,
					     dci.getColumnName(), val);
		    ivdtindex++;
		} else if (dciVDT == CoverageTable.charVDT) {
		    String val = (String)tmpVec.elementAt(i);
		    s =ctable.getDescription(tablename,
					     dci.getColumnName(), val);
		    cvdtindex++;
		} else if (dci.isNonKey()) {
		    s = tmpVec.elementAt(i).toString();
		}
		if (s != null) {
		    if (retval == null)
			retval = new StringBuffer(s);
		    else 
			retval.append("; ").append(s);
		}
	    }
	} catch (FormatException e) {
	    if (Debug.debugging("vpf")){
		e.printStackTrace();
	    }
	}
	//clean up after ourselves
	tmpVec.removeAllElements();
	return((retval==null)?null:retval.toString());
    }
}

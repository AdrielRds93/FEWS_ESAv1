/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/vpf/CoordFloatString.java,v $
 * $Revision: 1.5 $
 * $Date: 2000/05/08 14:23:10 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.vpf;
import com.bbn.openmap.util.BinaryFile;
import com.bbn.openmap.util.FormatException;

import java.io.EOFException;

/**
 * Encapsulate the VPF Double Coordinate String primitive datatype.
 */
public class CoordFloatString {

    /** the number of tuples */
    public int tcount;
    /** the number of elements in a tuple */
    public int tsize;
    /** where we store the data as x1,y1,z1,x2,y2,z2,... */
    public double vals[];

    /**
     * Construct a CoordFloatString from a file input
     *
     * @param tuplecount the number of tuples to read from the input stream
     * @param tuplesize the number of floats in the tuple
     * @param input the input stream to read everything from
     * @exception FormatException if we have IO errors or premature end-of-file
     */
    public CoordFloatString(int tuplecount, int tuplesize, BinaryFile input)
	throws FormatException {
	tcount = tuplecount;
	tsize = tuplesize;
	int totallen = tcount * tsize;
	vals = new double[totallen];
	try {
        for (int i = 0; i < vals.length; i++) {
            vals[i] = input.readDouble();
        }
	} catch (EOFException e) {
	    throw new FormatException("CoordFloatString EOFException");
	}
    }

    /** The maximum indexable tuple value
     * @return the maximum valid tuple index */
    public int maxIndex() {
	return tcount;
    }

    /** A pretty formatter for the floatstring
     * @return a pretty string of the tuple */
    public String toString() {
	StringBuffer retval = new StringBuffer("CFS:" + vals.length + "[");

	if (vals.length > 0) {
	    retval.append("(");
	    for (int j=0; j < tsize; j++) {
		retval.append(vals[j]+", ");
	    }
	    retval.append(") ");
	}
	if (vals.length > 1) {
	    retval.append("... (");
	    for (int j=tsize; j > 0; j--) {
		retval.append(vals[vals.length-j]+", ");
	    }
	    retval.append(") ");
	}

	retval.append("]");
	return retval.toString();
    }
 
    /** Get the first value of a tuple
     * @param tuple the index of the tuple
     * @return the first value of the tuple given by <code>tuple</code> */
    public double getXasFloat(int tuple) {
	return vals[tuple*tsize];
    }

    /** Get the second value of a tuple
     * @param tuple the index of the tuple
     * @return the second value of the tuple given by <code>tuple</code> */
    public double getYasFloat(int tuple) {
	return vals[tuple*tsize+1];
    }
  
    /** Get the third value of a tuple
     * @param tuple the index of the tuple
     * @return the third value of the tuple given by <code>tuple</code> */
    public double getZasFloat(int tuple) {
	return vals[tuple*tsize+2];
    }

    /** Get a tuple
     * @param tuple the index of the tuple
     * @return the tuple given by <code>tuple</code> */
    public double[] getasFloatV(int tuple) {
	double rv[] = new double[tsize];
	for (int i = 0 ; i < tsize; i++) {
	    rv[i] = vals[tsize * tuple + i];
	}
	return rv;
    }

    /** Get a value in a tuple
     * @param tuple the index of the tuple
     * @param val the index of the value
     * @return the tuple given by <code>tuple</code> */
    public double getasFloat(int tuple, int val) {
	return vals[tuple*tsize + val];
    }

}

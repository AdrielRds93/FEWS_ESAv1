/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998-2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/vpf/AreaTable.java,v $
 * $Revision: 1.15 $
 * $Date: 2000/05/08 14:23:09 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.vpf;

import java.io.File;
import java.util.Vector;
import com.bbn.openmap.util.Debug;
import com.bbn.openmap.LatLonPoint;
import com.bbn.openmap.util.FormatException;


/**
 * Read VPF format edge, face, and ring tables to generate filled
 * polygon graphics for OpenMap.
 */
public class AreaTable extends DcwRecordFile {

    /** @HACK around antarctica display problem. */
    final transient private static double antarcticaThreshold = -89.9d;

    /** the name of VPF Face Tables */
    final private static String faceTableName = "fac";

    /** the name of VPF Ring tables */
    final private static String ringTableName = "rng";

    /** the name of the VPF column that HAS to contain the start of an edge */
    final private static String startEdgeColName = "start_edge";

    /** the name of the VPF column that has to be a face identifier */
    final private static String faceIDColName = "face_id";

    /** the coverage table that we are working for */
    final private CoverageTable covtable;

    /** the ring table for the tile we are working on */
    final private DcwRecordFile rings;

    /** the edge table for the tile we are working on */
    final private EdgeTable edges;

    /** the column number of our ring ID column */
    final private int ringIDColumn;

    /** the column number of our face ID column */
    final private int faceIDColumn;

    /** the column number of our start_edge column */
    final private int ringStartColumn;

    /**
     * Construct an AreaTable
     *
     * @param cov the coverage table that is our "parent"
     * @param edg the edge table for the same tile as us
     * @param tilePath the (full) path to our tile directory
     * @param appendDot true mean me append a period to the filename
     * @exception FormatException if something goes wrong reading the area
     */
    public AreaTable(CoverageTable cov, EdgeTable edg,
		     File tilePath, boolean appendDot) throws FormatException{
	super(tilePath, faceTableName + (appendDot ? "." : ""));

	ringIDColumn = whatColumn("ring_ptr");
	covtable = cov;
	edges = edg;

	if (edges.topologyLevel() != 3) {
	    throw new FormatException("AreaTable: need level 3 topology: "
				      + edges.topologyLevel());
	}

	rings = new DcwRecordFile(tilePath,
				  ringTableName + (appendDot ? "." : ""));

	if ((ringStartColumn = rings.whatColumn(startEdgeColName)) == -1) {
	    throw new FormatException("ring has no start edge: "
				      + rings.filename);
	}

	if ((faceIDColumn = rings.whatColumn(faceIDColName)) == -1) {
	    throw new FormatException("ring has no face_id: "
				      + rings.filename);
	}
    }

    /**
     * Close the files associated with this tile.
     */
    public void close() {
	rings.close();
	super.close();
    }
  
    /**
     * 
     */
    public void finalize() {
	close();
    }

    /**
     *
     * @exception FormatException may throw FormatExceptions
     */
    public int computeEdgePoints(Vector facevec, Vector allLLPoints)
        throws FormatException {
        int ring_ptr = ((Number)facevec.elementAt(ringIDColumn)).intValue();
	final Vector ring1 = new Vector(rings.getColumnCount());
        rings.getRow(ring1, ring_ptr);
	int fac_id = ((Number)ring1.elementAt(faceIDColumn)).intValue();
	
	int startedgeid =((Number)ring1.elementAt(ringStartColumn)).intValue();
	if (startedgeid <= 0) {
	    return 0;
	}
	int nextedgeid = startedgeid;
	boolean firsttime = true;
	allLLPoints.removeAllElements();
	int polySize = 0;
	int prev_node = -1;
	final Vector edge = new Vector(edges.getColumnCount());
	do {
	    edges.getRow(edge, nextedgeid);
	    int start_node = edges.getStartNode(edge);
	    int end_node = edges.getEndNode(edge);
	    int rht_face = edges.getRightFace(edge).currentTileKey;
	    int lft_face = edges.getLeftFace(edge).currentTileKey;
	    DcwCrossTileID right_edge = edges.getRightEdge(edge);
	    DcwCrossTileID left_edge = edges.getLeftEdge(edge);
	    if (firsttime) {
	        prev_node = start_node;
		firsttime = false;
	    }
	  
	    //Debug.message("dcwSpecialist",
	    //              "edge: " + nextedgeid + " start->end: "
	    //              + start_node + "->" + end_node);
	    CoordFloatString cfs = edges.getCoordinates(edge);
	    
	    if ((fac_id == rht_face) && (fac_id == lft_face)) {
	        if (start_node == prev_node) {
		    nextedgeid = right_edge.currentTileKey;
		    prev_node = end_node;
		} else if (end_node == prev_node) {
		    nextedgeid = left_edge.currentTileKey;
		    prev_node = start_node;
		} else {
		    throw new FormatException(" node matching assertion failed ");
		}
	    } else if (fac_id == rht_face) {
	        nextedgeid = right_edge.currentTileKey;
		prev_node = end_node;
		polySize += cfs.tcount;
		allLLPoints.addElement(cfs);
	    } else if (fac_id == lft_face) { //reverse direction
	        nextedgeid = left_edge.currentTileKey;
		prev_node = start_node;
		polySize += cfs.tcount;
		cfs.tcount *= -1;// flag reverse
		allLLPoints.addElement(cfs);
	    } else {
	        throw new FormatException("Node Assertion failed");
	    }
	} while (nextedgeid != startedgeid);
	return polySize;
    }

    /**
     *
     */
    public void drawTile(VPFGraphicWarehouse warehouse,
			 double dpplat, double dpplon,
			 LatLonPoint ll1, LatLonPoint ll2,
			 boolean doAntarcticaWorkaround)
    {
	final Vector v = new Vector(getColumnCount());

	try {
	    while (parseRow(v)) {
// 		if (Debug.debugging("vpf")) {
// 		    Debug.out.println("creating area in warehouse");
// 		}
		warehouse.createArea(covtable, this, v, ll1, ll2,
				     dpplat, dpplon,
				     doAntarcticaWorkaround);
	    }
	} catch (FormatException f) {
	    System.out.println("Exception: " + f.getClass() + 
			       " " + f.getMessage());
	}
    }

}

/* **********************************************************************
 * 
 *  BBNT Solutions LLC, A part of GTE
 *  10 Moulton St.
 *  Cambridge, MA 02138
 *  (617) 873-2000
 * 
 *  Copyright (C) 1998, 2000
 *  This software is subject to copyright protection under the laws of 
 *  the United States and other countries.
 * 
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/vpf/VPFGraphicWarehouse.java,v $
 * $Revision: 1.8 $
 * $Date: 2000/05/08 14:23:12 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.vpf;

import java.util.Vector;
import com.bbn.openmap.LatLonPoint;

/**
 * Define an interface for a Graphic Factory for graphics read from VPF.
 */
public interface VPFGraphicWarehouse {

    /**
     * Return true if we may draw some edge features.
     */
    public boolean drawEdgeFeatures();

    /**
     * Return true if we may draw some text features.
     */
    public boolean drawTextFeatures();

    /**
     * Return true if we may draw some area features.
     */
    public boolean drawAreaFeatures();

    /**
     * Return true if we may draw some point features.
     */
    public boolean drawPointFeatures();


    /**
     * Method called by the VPF reader code to construct an area feature.
     */
    public void createArea(CoverageTable c, AreaTable a, Vector v,
			   LatLonPoint ll1,
			   LatLonPoint ll2,
			   double dpplat,
			   double dpplon,
			   boolean doAntarcticaWorkaround
			   );

    /**
     * Method called by the VPF reader code to construct an edge feature.
     */
     public void createEdge(CoverageTable c, EdgeTable e, Vector v,
			    LatLonPoint ll1,
			    LatLonPoint ll2,
			    double dpplat,
			    double dpplon,
			    CoordFloatString coords
			    );

    /**
     * Method called by the VPF reader code to construct a text feature.
     */
    public void createText(CoverageTable c, TextTable t, Vector v,
			   double latitude, double longitude,
			   String text);
}

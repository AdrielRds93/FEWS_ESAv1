/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/vpf/CoordTupleString.java,v $
 * $Revision: 1.4 $
 * $Date: 2000/05/08 14:23:10 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.vpf;
/**
 * Describe a common schema for accessing either double or double based
 * coordinate tuple strings (arrays of tuples).
 */
public interface CoordTupleString {

    /** Accessor for the max tuple index
     * @return the max tuple index */
    public abstract int maxIndex();

    /** Accessor to determine the actual type managed.
     * @return a Number the most directly corresponds to the underlying
     * managed type (Double for a double tuplestring, Double for a double
     * tuplestring, etc)
     */
    public abstract Number getPrimitiveType();

    /** Accessor to retrieve a tuple
     * @param tuple the tuple to retrieve (the first tuple is index 0)
     * @return the tuple at index <code>tuple</code>, coereced into a double[]
     */
    public abstract double[] getasFloat(int tuple);
    /** Accessor to retrieve a tuple
     * @param tuple the tuple to retrieve (the first tuple is index 0)
     * @return the tuple at index <code>tuple</code>, coereced into a double[]
     */
    public abstract double[] getasDouble(int tuple);

    /** Accessor to retrieve a single value in a tuple
     * @param tuple the tuple to retrieve (the first tuple is index 0)
     * @param val the index of the value in the tuple (the first val is index 0)
     * @return the tuple at index <code>tuple</code>, coereced into a double
     */
    public abstract double getasFloat(int tuple, int val);

    /** Accessor to retrieve a single value in a tuple
     * @param tuple the tuple to retrieve (the first tuple is index 0)
     * @param val the index of the value in the tuple (the first val is index 0)
     * @return the tuple at index <code>tuple</code>, coereced into a double
     */
    public abstract double getasDouble(int tuple, int val);
}

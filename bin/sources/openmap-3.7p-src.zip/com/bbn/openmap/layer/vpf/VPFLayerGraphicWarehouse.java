/* **********************************************************************
 * 
 *  BBNT Solutions LLC, A part of GTE
 *  10 Moulton St.
 *  Cambridge, MA 02138
 *  (617) 873-2000
 * 
 *  Copyright (C) 1998, 2000
 *  This software is subject to copyright protection under the laws of 
 *  the United States and other countries.
 * 
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/vpf/VPFLayerGraphicWarehouse.java,v $
 * $Revision: 1.16 $
 * $Date: 2000/07/27 23:46:18 $
 * $Author: dietrick $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.vpf;

import java.awt.Color;
import java.util.Vector;
import com.bbn.openmap.LatLonPoint;
import com.bbn.openmap.omGraphics.*;
import com.bbn.openmap.proj.ProjMath;
import com.bbn.openmap.util.Debug;
import java.util.StringTokenizer;
import com.bbn.openmap.util.FormatException;

/**
 * Implement a graphic factory that builds OMGraphics.
 * 
 * @see com.bbn.openmap.omGraphics.OMGraphic
 */
public class VPFLayerGraphicWarehouse 
    extends LayerGraphicWarehouseSupport {

    /** the properties file string that tells us what area features to draw */
    String areaFeatures = null;
    /** one of these columns must be non-null to draw area features */
    int areaSkipFeatures[] = null;
    /** the properties file string that tells us what edge features to draw */
    String edgeFeatures = null;
    /** one of these columns must be non-null to draw edge features */
    int edgeSkipFeatures[] = null;
    /** the properties file string that tells us what text features to draw */
    String textFeatures = null;
    /** one of these columns must be non-null to draw text features */
    int textSkipFeatures[] = null;

    /**
     *
     */
    public VPFLayerGraphicWarehouse() {
        super();
    }

    /**
     * Set properties of the warehouse.
     * @param prefix the prefix to use for looking up properties.
     * @param props the properties file to look at.
     */
    public void setProperties(String prefix, java.util.Properties props) {
        super.setProperties(prefix, props);

	areaFeatures = props.getProperty(prefix + ".area");
	if (areaFeatures == null) {
	    areaSkipFeatures = new int[0];
	} else {
	    areaSkipFeatures = null;
	}
	  
	textFeatures = props.getProperty(prefix + ".text");
	if (textFeatures == null) {
	    textSkipFeatures = new int[0];
	} else {
	    textSkipFeatures = null;
	}

	edgeFeatures = props.getProperty(prefix + ".edge");
	if (edgeFeatures == null) {
	    edgeSkipFeatures = new int[0];
	} else {
	    edgeSkipFeatures = null;
	}
    }

    /**
     * Build an array that lists the columns we require the record to have.
     * @param featureString the (space-separated) list of required columns
     * @param table the table we use to find the column numbers
     * @param colAppend the (possibly null) string we append to the entries
     * in featureString to build the real column name
     */
    protected int[] getSkipArray(String featureString, DcwRecordFile table,
				 String colAppend) {
        Vector tmpvec = new Vector();
	StringTokenizer t = new StringTokenizer(featureString);
	while (t.hasMoreTokens()) {
	    String colname = t.nextToken();
	    if (colAppend != null) {
	        colname += colAppend;
	    }
	    int colnum = table.whatColumn(colname);
	    if (colnum != -1) {
	        tmpvec.addElement(new Integer(colnum));
	    }
	}
	int []retval = new int[tmpvec.size()];
	for (int i = 0; i < retval.length; i++) {
	    retval[i] = ((Integer)tmpvec.elementAt(i)).intValue();
	}
	return retval;
    }

    /**
     * Determine if this primitive should be drawn or skipped.
     * @param primvec the vector for the primitive feature object.
     * @param skipArray a list of columns.
     * @return true if any of the columns listed in skipArray is non-null.
     */
    protected boolean createFeature(Vector primvec, int[] skipArray) {
        //length==0  --> user wants everything
        if (skipArray.length == 0) {
	    return true;
	}
	for (int i = 0; i < skipArray.length; i++) {
	    int val = VPFUtil.objectToInt(primvec.elementAt(skipArray[i]));
	    if (val != Integer.MIN_VALUE) {
	        return true;
	    }
	}
	return false;
    }

    final transient static java.awt.Color aaronscolor =
      new java.awt.Color(0xBDDE83);
							
    /**
     *
     */
    public void createArea(CoverageTable covtable, AreaTable areatable,
			   Vector facevec,
			   LatLonPoint ll1,
			   LatLonPoint ll2,
			   double dpplat,
			   double dpplon,
			   boolean doAntarcticaWorkaround)
    {
        if (areaSkipFeatures == null) {
	    areaSkipFeatures = getSkipArray(areaFeatures, areatable,
					    ".aft_id");
	}
	
	if (!createFeature(facevec, areaSkipFeatures)) {
	    return;
	}
	  
	Vector ipts = new Vector();

	int totalSize = 0;
        try {
	    totalSize = areatable.computeEdgePoints(facevec, ipts);
	} catch (FormatException f) {
 	    Debug.out.println("FormatException in computeEdgePoints: " + f);
	    return;
	}
	if (totalSize == 0) {
	  //System.out.println("No edged: " + descript);
	  return;
	}

	OMPoly py = createAreaOMPoly(ipts, totalSize, ll1, ll2, 
				     dpplat, dpplon, doAntarcticaWorkaround);

//  	final MutableInt areatype = new MutableInt(-1);
//  	String descript = covtable.getAreaDescription(facevec, areatype);
//  	if (areatype.value == -1) {
//  	    areatype.value = 0;
//  	}

	drawingAttributes.setOMGraphicAttributes(py);
	graphics.add(py);

	// HACK this is a workaround for broken VMAP feature tables
	// that don't match among disc sets...
//	areaSkipFeatures = null;
    }

    /**
     *
     */
    public void createEdge(CoverageTable c, EdgeTable edgetable,
			   Vector edgevec,
			   LatLonPoint ll1,
			   LatLonPoint ll2,
			   double dpplat,
			   double dpplon,
			   CoordFloatString coords)
    {
        if (edgeSkipFeatures == null) {
	    edgeSkipFeatures = getSkipArray(edgeFeatures, edgetable,
					    ".lft_id");

	}

	// HACK remove crufty dateline.  This HACK may require
	// additional hackage in FeatureClassInfo.java  In particular,
	// you may need to initialize the class during construction.
	/*
	FeatureClassInfo[] lineinfo = c.lineinfo;
	int len = lineinfo.length;
	for (int i=0; i<len; i++) {
	    String ftname = lineinfo[i].getTableName();
	    ftname.trim();
	    if (ftname.equals("polbndl.lft")) {
		int col = edgetable.whatColumn("polbndl.lft_id");
		int row = ((Integer)edgevec.elementAt(col)).intValue();
		if (row == Integer.MIN_VALUE)
		    continue;
		Vector fvec=null;
		try {
		    fvec = lineinfo[i].getRow(row);
		} catch (FormatException f) {
		    f.printStackTrace();
		    continue;
		}
		String str = (String)fvec.elementAt(lineinfo[i].whatColumn("f_code"));
		str.trim();
		if (str.equals("FA110")) {
		    System.out.println("ignoring dateline");
		    return;
		}
	    }
	}
	*/

	if (!createFeature(edgevec, edgeSkipFeatures)) {
	    return;
	}
	
	OMPoly py = createEdgeOMPoly(coords, ll1, ll2, dpplat, dpplon);
	drawingAttributes.setOMGraphicEdgeAttributes(py);
	graphics.add(py);

	// HACK this is a workaround for broken VMAP feature tables
	// that don't match among disc sets...
//	edgeSkipFeatures = null;
    }

    /**
     *
     */
    public void createText(CoverageTable c, TextTable texttable,
			   Vector textvec,
			   double latitude,
			   double longitude,
			   String text)
    {
        if (textSkipFeatures == null) {
	    textSkipFeatures = getSkipArray(textFeatures, texttable,
					    ".tft_id");
	}
	    
	if (!createFeature(textvec, textSkipFeatures)) {
	    return;
	}

	OMText txt = createOMText(text, latitude, longitude);

	drawingAttributes.setOMGraphicEdgeAttributes(txt);
	graphics.add(txt);

	// HACK this is a workaround for broken VMAP feature tables
	// that don't match among disc sets...
//	textSkipFeatures = null;
    }


    public static void main(String argv[]) {
	new VPFLayerGraphicWarehouse();
    }
}

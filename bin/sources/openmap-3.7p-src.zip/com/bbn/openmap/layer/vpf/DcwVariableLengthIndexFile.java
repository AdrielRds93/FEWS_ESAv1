/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/vpf/DcwVariableLengthIndexFile.java,v $
 * $Revision: 1.5 $
 * $Date: 2000/05/08 14:23:10 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.vpf;

import java.io.IOException;
import java.io.EOFException;
import java.io.File;
import java.util.Vector;
import com.bbn.openmap.MoreMath;
import com.bbn.openmap.util.FormatException;
import com.bbn.openmap.util.BinaryFile;
import com.bbn.openmap.util.BinaryBufferedFile;

/**
 * Read in a VPF variable length index file, and allows access to
 * individual records.
 */
public class DcwVariableLengthIndexFile {
    /** holds all the offset,size pairs */
    final private int offsettable[];

    /** Construct a new index file
     * @param filename the name of the file to read in
     * @param msbfirst the byte order of the file to be read
     * @exception FormatException some error was encountered in trying to
     * read the file
     */
    public DcwVariableLengthIndexFile(File filename, boolean msbfirst) throws FormatException {
	try {
	    BinaryFile inputstream = new BinaryBufferedFile(filename);
	    inputstream.byteOrder(msbfirst);

	    int NumberOfEntries = inputstream.readInteger();
	    int HeaderLength = inputstream.readInteger();
	    offsettable = new int[NumberOfEntries * 2];
	    inputstream.readIntegerArray(offsettable, 0, NumberOfEntries * 2);

	    if (inputstream.available() != 0) {
		throw new FormatException("File bytes remaining: " +
					  inputstream.available());
	    }
	    inputstream.close();
	} catch (IOException i) {
	    throw new FormatException("IOException with " + filename + ": " +
				      i.getMessage());
	}
    }

    /** 
     * get the offset byte offset of the record in the associated table file
     * @param recordNumber the record to retrieve the offset for
     */
    public int recordOffset(int recordNumber) {
	return offsettable[(recordNumber-1) * 2];
    }

    /** get the size of the record in the associated table file
     * @param recordNumber the record to retrieve the offset for */
    public int recordSize(int recordNumber) {
	return offsettable[(recordNumber-1) * 2 + 1];
    }

    /** get the number of records in the index file */
    public int getRecordCount() {
	return offsettable.length / 2;
    }

    /** close the associated input file */
    public void close() {
    }
}

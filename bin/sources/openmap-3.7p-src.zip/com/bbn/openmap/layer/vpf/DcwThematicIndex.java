/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/vpf/DcwThematicIndex.java,v $
 * $Revision: 1.4 $
 * $Date: 2000/05/08 14:23:10 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.vpf;

import java.io.IOException;
import java.io.EOFException;
import java.io.File;
import java.util.Vector;
import java.util.BitSet;
import com.bbn.openmap.util.FormatException;
import com.bbn.openmap.util.BinaryFile;
import com.bbn.openmap.util.BinaryBufferedFile;

/** Read a VPF thematic index file.  (VPF *.?ti files) */
public class DcwThematicIndex {
  
    private BinaryFile inputFile = null;
    final private int headerSize;
    final private int numberOfCodes;
    final private int numberOfRows;
    final private char typeOfIndex; // T hematic
    final private char fieldTypeOfIndex;
    final private int numberOfDataElement;
    final private char dataTypeSpecifier;
    final private String tableIndexed;
    final private String columnIndexed;
  
    public DcwThematicIndex(File filename, boolean border)
	throws FormatException {
	try {
	    inputFile = new BinaryBufferedFile(filename);
	} catch (IOException e) {
	    throw new FormatException("Can't open file " + filename + ": " +
				      e.getMessage());
	}
	System.out.println("opened the file " + filename);
	inputFile.byteOrder(border);

	try {
	    headerSize = inputFile.readInteger();
	    numberOfCodes = inputFile.readInteger();
	    numberOfRows = inputFile.readInteger();
	    typeOfIndex = inputFile.readChar();
	    fieldTypeOfIndex = inputFile.readChar();
	    numberOfDataElement = inputFile.readInteger();
	    dataTypeSpecifier = inputFile.readChar();
	    tableIndexed = stripafternul(inputFile.readFixedLengthString(12));
	    columnIndexed = stripafternul(inputFile.readFixedLengthString(25));
	    inputFile.readInteger();
    
	    if (inputFile.getFilePointer() != 60)
		throw new FormatException("Invalid Header Size for Thematic Index file.  Should be 60, was " + headerSize);
	
	    System.out.println("HeaderSize = " + headerSize);
	    System.out.println("Number of Codes = " + numberOfCodes);
	    System.out.println("Number of Rows = " + numberOfRows);
	    System.out.println("Type of Index = " + typeOfIndex);
	    if (typeOfIndex != 'T')
		System.out.println(" *** Strange - dcw spec says it will be T ***");
	    System.out.println("Field Type of Index = " + fieldTypeOfIndex);
	    System.out.println("Number of Data Element = " + numberOfDataElement);
	    System.out.println("Data Type Specifier = " + dataTypeSpecifier);
	    System.out.println("Table Indexed  = " + tableIndexed);
	    System.out.println("Column Indexed = " + columnIndexed);

	    //       StringBuffer pr = new StringBuffer();
	    Vector[] readdata = new Vector[numberOfCodes];
	    for (int i = 0; i < numberOfCodes; i++) {
		readdata[i] = new Vector();
		Object indexed = readIndexField(fieldTypeOfIndex, numberOfDataElement);
		readdata[i].addElement(indexed);
		int offset = inputFile.readInteger();
		readdata[i].addElement(new Integer(offset));
		int numits = inputFile.readInteger();
		readdata[i].addElement(new Integer(numits));
		// 	pr = new StringBuffer("i = " + i);
		// 	pr.append("; val = " + indexed.toString());
		// 	pr.append("; offset = " + offset);
		// 	pr.append("; number of elts = " + numits);
		// 	if (i < 40)
		// 	  System.out.println(pr.toString());
	    }
	    //       if (NumberOfCodes > 40)
	    // 	System.out.println(pr.toString());

	    System.out.println("*** Finished Header Read ***");
	    if ((typeOfIndex == 'T') || (typeOfIndex == 'I')) {
		System.out.println("Normal Inverted Index Format");
		for (int i = 0; i < readdata.length; i++) {
		    Vector v = readdata[i];
		    int offset = ((Integer)(v.elementAt(1))).intValue();
		    int numvals = ((Integer)(v.elementAt(2))).intValue();
		    if ((numvals != 0) && (inputFile.getFilePointer() != offset))
			throw new FormatException("Assertion Failed, file out of sync, at " + inputFile.getFilePointer() + " expected " + offset);
		    // 	  pr = new StringBuffer();
		    // 	  pr.append("i=" + i).append(": numvals=" + numvals);
		    // 	  pr.append(": offset=" + offset + " ");
		    for (int j = 0; j < numvals; j++) {
			int index = readIndexWithFieldType(dataTypeSpecifier);
			// 	    if (j < 5)
			// 	      pr.append(index).append(", ");
			// 	    else
			// 	      pr.append('.');
		    }
		    // 	  if (i < 10)
		    // 	    System.out.println(pr);
		}
		// 	if (NumberOfCodes > 10)
		// 	  System.out.println(pr);
	    } else if ((typeOfIndex == 'B') || (typeOfIndex == 'G')) {
		System.out.println("Scary Bitmap Index Format");
		for (int i = 0; i < readdata.length; i++) {
		    Vector v = readdata[i];
		    int offset = ((Integer)(v.elementAt(1))).intValue();
		    int numvals = ((Integer)(v.elementAt(2))).intValue();
		    if (inputFile.getFilePointer() != offset)
			throw new FormatException("Assertion Failed, file out of sync: " + inputFile.getFilePointer());
		    int shortread = numberOfRows / 16;
		    if ((numberOfRows % 16) != 0)
			shortread++;
		    System.out.println("Reading a bunch of shorts: " + shortread);
		    System.out.println("Starting at offset: " + inputFile.getFilePointer());
		    BitSet bits = new BitSet(numberOfRows);
		    int cnt = 0;
		    for (int shortcnt = 0; shortcnt < shortread; shortcnt++) {
			short s = inputFile.readShort();
			for (int k = 0; k < 16; k++) {
			    cnt++;
			    if ((s & 0x1) == 1)
				bits.set(cnt);
			    s >>= 1;
			}
		    }
		    // 	  StringBuffer prt = new StringBuffer();
		    // 	  for (int j = 1; j <= bits.size(); j++) {
		    // 	    if (bits.get(j))
		    // 	      prt.append(", " + j);
		    // 	  }
		    // 	  System.out.println(prt);
	    
		}
	
	    } else {
		throw new FormatException("Unidentied TMI format");
	    }
	    if (inputFile.available() != 0)
		throw new FormatException("Data left in file: " + inputFile.available());
	
	} catch (EOFException e) {
	    throw new FormatException("Hit Premature EOF in thematic index");
	} catch (IOException i) {
	    throw new FormatException("Encountered IO Exception: " + i.getMessage());
	}
    }
    private int readIndexWithFieldType(char ft)
	throws EOFException, FormatException {
	switch (ft) {
	case 'S':
	    return (int)inputFile.readShort();
	case 'I':
	    return inputFile.readInteger();
	}
	throw new FormatException("Unrecognized FieldTypeOfIndex");
    }

    private Object readIndexField(char dts, int textlen)
	throws EOFException, FormatException {
	switch (dts) {
	case 'I':
	    return new Integer(inputFile.readInteger());
	case 'T':
	    return inputFile.readFixedLengthString(textlen);
	case 'S':
	    return new Short(inputFile.readShort());
	case 'F':
	    return new Double(inputFile.readFloat());
	case 'R':
	    return new Double(inputFile.readDouble());
	}
	throw new FormatException("Unrecognized field index type");
    }

    private String stripafternul(String s) {
	StringBuffer ns = new StringBuffer();
	char foo[] = s.toCharArray();
	for (int i = 0; i < foo.length; i++) {
	    if (foo[i] == 0)
		break;
	    ns.append(foo[i]);
	}
	return ns.toString();
    }

    public void close() {
	try {
	    inputFile.close();
	} catch (IOException i) {
	    System.out.println("Caught ioexception " + i.getClass() + " " + i.getMessage());
	}
    }
}

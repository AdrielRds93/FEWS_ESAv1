/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998-2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/vpf/DcwColumnInfo.java,v $
 * $Revision: 1.5 $
 * $Date: 2000/05/08 14:23:10 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.vpf;

import com.bbn.openmap.MoreMath;
import java.io.EOFException;
import com.bbn.openmap.util.FormatException;
import com.bbn.openmap.util.BinaryFile;

/**
 * Encapsulate the information about a particular column in a vpf table.
 * This class can read both VPF V1 (MIL-STD-600006, dated 1992) and
 * VPF V2 (MIL-STD-2407, dated 1996, supercedees V1)
 */
public class DcwColumnInfo {
    /** the name of the column */
    final private String columnName;
    /** the fieldtype of the contained data */
    final private char fieldType;
    /** the number of values (-1 indicates variable) */
    final private int numberOfElements;
    /** the keytype (primary key, non-key, foreign key) */
    final private char keyType;
    /** optional text description of what the column is for */
    final private String columnDescription;
    /** optional table that provides descriptions of what the values in this 
     * column are */
    private String valueDescriptionTable = null;
    /** name of the optional thematic index created for this column */
    private String thematicIndexName = null;
    /** name of the optional narrative table for this column */
    private String narrativeTable = null;

    /**
     * Construct a DcwColumnInfo from the specified input stream.
     * @param in the filestream to construct from
     * @exception EOFException when the first character read is a ';',
     * indicating that we've reached the end of the column list; also thrown
     * for an end of file
     * @exception FormatException some error was detected while reading the
     * info for the column.
     */
    public DcwColumnInfo(BinaryFile inputFile) 
        throws EOFException, FormatException {
	char delim  = inputFile.readChar();
	if (delim == ';')
	    throw new EOFException();

	StringBuffer buildstring = new StringBuffer();
	do {
	  buildstring.append(Character.toLowerCase(delim));
	} while ((delim = inputFile.readChar()) != '=');
	columnName = buildstring.toString().intern();

	fieldType = inputFile.readChar();
	
	delim = inputFile.readChar();
	if (delim != ',') { //only legal delimiter
	    if (delim != ' ') { //one DCW file uses this instead
	        throw new com.bbn.openmap.util.InvalidCharException("Illegal delimiter character", delim);
	    }
	}

	buildstring = new StringBuffer();
	while ((delim = inputFile.readChar()) != ',') {
 	    // field length occasionally has trailing whitespace...
	    if (!Character.isWhitespace(delim)) {
		buildstring.append(delim); //assumes not like "1  4"
	    }
	}
	String nEls = buildstring.toString();
	numberOfElements = (nEls.equals("*")) ? -1 : Integer.parseInt(nEls);
    
	// Sanity check the column schema... a few VPF primitives are not
	// allowed to show up in arrays.  complain about that now...
	if (numberOfElements != 1) {
	    switch (fieldType) {
	    case 'F': 
	    case 'R': 
	    case 'S': 
	    case 'I': 
	    case 'D': 
	    case 'X': 
	    case 'K': 
	        throw new FormatException("Illegal array type: " + fieldType + "for column " + columnName);
	    default:
	        //legal
	        break;
	    }
	}

	String tmpkeyType = readColumnText(inputFile);
	if (tmpkeyType == null)
	    throw new FormatException("keyType is required column info");
	tmpkeyType = tmpkeyType.trim();
	if (tmpkeyType.length() == 1)
	    keyType = tmpkeyType.charAt(0);
	else
	    throw new FormatException("keyType is supposed to be 1 character");
	
	columnDescription = readColumnText(inputFile);
	if (columnDescription == null) {
	    return;
	}

	valueDescriptionTable = readColumnTextLowerCase(inputFile);
	if (valueDescriptionTable == null) {
	    return;
	}
	if (valueDescriptionTable.equals("-")) {
	    valueDescriptionTable = null;
	} else {
	    valueDescriptionTable=valueDescriptionTable.intern();
	}

	thematicIndexName = readColumnTextLowerCase(inputFile);
	if (thematicIndexName == null) {
	    return;
	}
	if (thematicIndexName.equals("-")) {
	    thematicIndexName = null;
	} else {
	    thematicIndexName = thematicIndexName.intern();
	}

	narrativeTable = readColumnTextLowerCase(inputFile);
	if (narrativeTable == null) {
	    return;
	}
	if (narrativeTable.equals("-")) {
	    narrativeTable = null;
	} else {
	    narrativeTable = narrativeTable.intern();
	}

	inputFile.assertChar(':');
    }

    /**
     * Reads a string until the field separator is detected, the
     * column record separator is detected, or and end-of-file is hit.
     *
     * @return the string read from the file
     * @param inputFile the file to read the field from
     * @param toLower convert the string to lower-case
     * @exception FormatException ReadChar IOExceptions rethrown as
     * FormatExceptions
     */
    private String readColumnText(BinaryFile inputFile)
        throws FormatException {
	StringBuffer buildretval = new StringBuffer();
	boolean skipnext = false;
	char tmp;
	try {
	    while ((tmp = inputFile.readChar()) != ',') {
	        if ((tmp == ':') && !skipnext) {
		    return null;
		}
		if (tmp == '\\') {
		    skipnext = true;
		} else {
		    skipnext = false;
		    buildretval.append(tmp);
		}
	    }
	} catch (EOFException e) {
	    //allowable
	}
	return buildretval.toString();
    }


    /**
     * Reads a string until the field separator is detected, the
     * column record separator is detected, or and end-of-file is hit,
     * and converts in to lowercase.
     *
     * @return the string read from the file, all in lowercase
     * @param inputFile the file to read the field from
     * @param toLower convert the string to lower-case
     * @exception FormatException ReadChar IOExceptions rethrown as
     * FormatExceptions
     */
    private String readColumnTextLowerCase(BinaryFile inputFile)
        throws FormatException {
	StringBuffer buildretval = new StringBuffer();
	boolean skipnext = false;
	char tmp;
	try {
	    while ((tmp = inputFile.readChar()) != ',') {
	        if ((tmp == ':') && !skipnext) {
		    return null;
		}
		if (tmp == '\\') {
		    skipnext = true;
		} else {
		    skipnext = false;
		    buildretval.append(Character.toLowerCase(tmp));
		}
	    }
	} catch (EOFException e) {
	    //allowable
	}
	return buildretval.toString();
    }

    /** Claim that the column has a particular schema
     * @param type the FieldType (datatype) this column is expected to contain
     * legal values are specified by the VPF standard.  the non-standard value
     * 'i' is also accepted (equivalent to 'I' or 'S), indicating an integral
     * type.
     * @param length the number of elements in this column
     * @param strictlength false means that variable length columns can be
     * fixed length instead
     * @exception FormatException the column is not of the particular
     * type/length
     */
    public void assertSchema(char type, int length, boolean strictlength) throws FormatException {
	if ((type != fieldType) && 
	    !((type == 'i') && ((fieldType == 'I') || (fieldType == 'S')))) {
	    throw new FormatException("AssertSchema failed on fieldType!");
	}
	if ((strictlength && (length != numberOfElements)) ||
	    (!strictlength && (length != -1) && (length != numberOfElements)))
	    throw new FormatException("AssertSchema failed on length!");
    }
  
    /** the number of bytes a field of this type takes in the input file
     * @return the number of bytes (-1 for a variable-length field)
     * @exception FormatException the FieldType of this Column is not a
     * valid VPF fieldtype
     */
    public int fieldLength() throws FormatException {
        if (numberOfElements == -1) {
	    return -1;
	}
    
	switch (fieldType) {
	case 'T': //text strings
	    return numberOfElements;
	case 'F': //floats
	    return 4;
	case 'R': //doubles
	    return 8;
	case 'S': //shorts
	    return 2;
	case 'I': //ints
	    return 4;
	case 'C': //2-coord floats
	    return numberOfElements * 8;
	case 'B': //2-coord doubles
	    return numberOfElements * 16;
	case 'Z': //3-coord floats
	    return numberOfElements * 12;
	case 'Y': //3-coord doubles
	    return numberOfElements * 24;
	case 'D': //dates
	    return 20;
	case 'X': //nulls
	    return 0;
	case 'K': //cross-tile identifiers
	    return -1; //variable length
	default: {
		throw new FormatException("Unknown field type: " + fieldType);
	    }
	}
	//unreached
    }

    /**
     * get the name of the column
     *
     * @return the name of the column
     */
    public String getColumnName() {
	return columnName;
    }
    /**
     * get the VPF datatype of the column
     * 
     * @return the VPF datatype
     */
    public char getFieldType() {
	return fieldType;
    }
    /**
     * get the number of elements
     *
     * @return the number of elements
     */
    public int getNumberOfElements() {
	return numberOfElements;
    }
    /**
     * get the VPF key type ('P' primary, 'F' foreign, 'N' non-key)
     * 
     * @return the vpf key type
     */
    public char getKeyType() {
	return keyType;
    }
    /**
     * return <code>true</code> if this column is a primary key. For
     * any valid column, exactly one of isPrimaryKey, isForeignKey and
     * isNonKey will be <code>true</code>.
     * 
     * @return <code>true</code> for a primary key, <code>false</code>
     * otherwise.
     * @see #isForeignKey()
     * @see #isNonKey()
     */
    public boolean isPrimaryKey() {
	return (keyType == 'P');
    }
    /**
     * return <code>true</code> if this column is a foreign key.  For
     * any valid column, exactly one of isPrimaryKey, isForeignKey and
     * isNonKey will be <code>true</code>.
     * 
     * @return <code>true</code> for a foreign key, <code>false</code>
     * otherwise.
     * @see #isPrimaryKey()
     * @see #isNonKey() */
    public boolean isForeignKey() {
	return (keyType == 'F');
    }
    /**
     * return <code>true</code> if this column is not a key column. For any
     * valid column, exactly one of isPrimaryKey, isForeignKey and isNonKey
     * will be <code>true</code>.
     *
     * @return <code>false</code> for a primary or foreign key,
     * <code>true</code> otherwise.
     * @see #isForeignKey()
     * @see #isPrimaryKey() */
    public boolean isNonKey() {
	return (keyType == 'N');
    }

    /**
     * get the column description
     *
     * @return the column description (possibly <code>null</code>)
     */
    public String getColumnDescription() {
	return columnDescription;
    }
    /**
     * get the name of the value description table
     * 
     * @return the name of the value description table
     * (possibly <code>null</code>). The same as getVDT()
     * @see #getVDT()
     */
    public String getValueDescriptionTable() {
	return valueDescriptionTable;
    }
    /**
     * get the name of the value description table
     * 
     * @return the name of the value description table
     * (possibly <code>null</code>). The same as getValueDescriptionTable
     * @see #getValueDescriptionTable()
     */
    public String getVDT() {
	return valueDescriptionTable;
    }
    /**
     * get the name of the thematic index
     * 
     * @return the thematic index name (possibly <code>null</code>)
     */
    public String getThematicIndexName() {
	return thematicIndexName;
    }
    /**
     * get the name of the narrative table
     * 
     * @return the name of the narrative table (possibly <code>null</code>)
     */
    public String getNarrativeTable() {
	return narrativeTable;
    }

    /**
     * read an element of the type specified by the column
     *
     * @return the value read from the input file
     * @exception EOFException an end-of-file was encountered before reading
     * any of the field
     * @exception FormatException some data-consistency check failed while
     * reading the data, or an end-of-file condition popped up in the middle
     * of reading a field (partial read)
     */
    public Object parseField(BinaryFile inputFile)
        throws EOFException, FormatException {
	// See table 56, p 79 of MIL-STD-600006 (1992 VPF Standard)
	boolean haveElements = (numberOfElements != -1);
	int numels = numberOfElements;

	switch (fieldType) {
	case 'T': {
	    if (!haveElements) //Variable length string
		numels = inputFile.readInteger();
	    String s = inputFile.readFixedLengthString(numels);
	    if (haveElements) //Fixed Length Strings loose trailing whitespace.
		s = s.trim();
	    return s;
	}
	case 'F': {
	    return new Double(inputFile.readFloat());
	}
	case 'R': {
	    return new Double(inputFile.readDouble());
	}
	case 'S': {
	    return new Short(inputFile.readShort());
	}
	case 'I': {
	    return new Integer(inputFile.readInteger());
	}
	case 'C': { //2-coord floats
	    if (!haveElements)
		numels = inputFile.readInteger();
	    return new CoordFloatString(numels, 2, inputFile);
	}
	case 'B': { //2-coord doubles
	    if (!haveElements)
		numels = inputFile.readInteger();
	    return new CoordDoubleString(numels, 2, inputFile);
	}
	case 'Z': { //3-coord floats
	    if (!haveElements)
		numels = inputFile.readInteger();
	    return new CoordFloatString(numels, 3, inputFile);
	}
	case 'Y': { //3-coord doubles
	    if (!haveElements)
		numels = inputFile.readInteger();
	    return new CoordDoubleString(numels, 3, inputFile);
	}
	case 'D': {
	    inputFile.readBytes(20, false);
	    return "[skipped date]";
	}
	case 'X': {
	    return "[Null Field Type]";
	}
	case 'K': {
	    return new DcwCrossTileID(inputFile);
	}
	default: {
	    throw new FormatException("Unknown field type: " + fieldType);
	}
	}
	//unreached
    }

    /**
     * produce a nice printed version of all our contained information
     *
     * @return a nice little string
     */
    public String toString() {
	StringBuffer output = new StringBuffer();
	output.append(columnName + " " + fieldType + " ");
	output.append(numberOfElements).append(" ");
	output.append(keyType).append(" ");
	output.append(columnDescription + " " + valueDescriptionTable + " ");
	output.append(thematicIndexName + " " + narrativeTable);
	return output.toString();
    }

}

/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998-2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/vpf/CoverageAttributeTable.java,v $
 * $Revision: 1.13 $
 * $Date: 2000/05/08 14:23:10 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.vpf;

import java.io.File;
import java.util.Vector;
import java.util.Hashtable;
import java.util.Enumeration;
import com.bbn.openmap.util.Debug;
import com.bbn.openmap.util.FormatException;

/**
 * Handle the library level VPF directory.  "noamer" in DCW is an
 * example of the library level data.  This class loads the associated
 * tiling information, and the coverage types, and make them available
 * to the client.
 */
public class CoverageAttributeTable {

    /** the name of the library (e.g. noamer) we are */
    final protected String libraryname;
    /** the path to our directory */
    final protected File dirpath;
    /** are we tiled or untiled coverage */
    private boolean isTiled = false;
    /** coverage name to CoverageEntry map */
    final private Hashtable coverages = new Hashtable();
    /** the tiles that compose our coverage area */
    private TileDirectory containedTiles[];

    /** expected schema types for the cat. file */
    private final static char CATschematype[] = {'I', 'T', 'T', 'i'};
    /** expected schema lengths for cat. file */
    private final static int CATschemalength[] = {1, -1 /*8*/, -1 /*50*/, 1};
  

    /**
     * Construct a new coverage attribute table
     *
     * @param libname the name of the library
     * @param dcwpath the path to the library
     * @exception FormatException may throw FormatExceptions
     */
    public CoverageAttributeTable(File dcwpath, String libname)
        throws FormatException {
	libraryname = libname;
	dirpath = new File(dcwpath, libraryname);
	File cat = new File(dirpath, "cat");
	if (!cat.canRead()) {
	    cat = new File(dirpath, "cat.");
	}

	DcwRecordFile rf = new DcwRecordFile(cat);
	rf.assertSchema(CATschematype, CATschemalength, false);

	final Vector v = new Vector(rf.getColumnCount());
	while (rf.parseRow(v)) {
	    int topL = ((Number)v.elementAt(3)).intValue();
	    String desc = (String)v.elementAt(2);
	    String covtype = ((String)v.elementAt(1)).toLowerCase().intern();
	    coverages.put(covtype, new CoverageEntry(topL, desc));
	}
	rf.close();
	rf = null;

	doTileRefStuff(new File(dirpath, "tileref"));
    }

    /**
     * is this library tiled
     *
     * @return <code>true</code> for tiled coverage.  <code>false</code> else
     */
    public final boolean isTiledCoverage() {
	return isTiled;
    }

    /**
     * the name of the library
     *
     * @return the name of the library
     */
    public String getLibraryName() {
	return libraryname;
    }

    /**
     * an internal function to load the tiling information
     * 
     * @param pathname the path to the tile directory
     */
    private void doTileRefStuff(File pathname) {
	String faceIDColumnName = null;
	//read fcs to figure out what column in tileref.aft we need to use to
	//read the fbr (face bounding rectangle) table
	try {
	    File fcsFile = new File(pathname, "fcs");
	    if (!fcsFile.canRead()) {
		fcsFile = new File(pathname, "fcs.");
	    }
	    DcwRecordFile fcs = new DcwRecordFile(fcsFile);
	    final Vector fcsv = new Vector(fcs.getColumnCount());
	    while (fcs.parseRow(fcsv)) {
		String fclass = ((String)fcsv.elementAt(1)).toLowerCase();
		String table1 = ((String)fcsv.elementAt(2)).toLowerCase();
		if ((fclass.equals("tileref")) &&
		    (table1.equals("tileref.aft"))) {
		    faceIDColumnName = (String)fcsv.elementAt(3);
		    break;
		}
	    }
	    fcs.close();
	} catch (FormatException f) {
	    return;  //file didn't exist, not found, corrupted.  abort
	}
	if (faceIDColumnName == null) {
	    return;  //won't be able to read the tiling info.  abort
	}
	isTiled = true;

	//Okay, we've got info on what column we use from tileref.aft to index
	//into the fbr.
	try {
	    DcwRecordFile aft = new DcwRecordFile(pathname, "tileref.aft");
	    int faceIDColumn = aft.whatColumn(faceIDColumnName.toLowerCase());
	    if (faceIDColumn == -1) {
		aft.close();
		return;
	    }

	    File fbrFile = new File(pathname, "fbr");
	    if (!fbrFile.canRead()) {
		fbrFile = new File(pathname, "fbr.");
	    }
	    DcwRecordFile fbr = new DcwRecordFile(fbrFile);
	    final Vector aftv = new Vector(aft.getColumnCount());
	    final Vector fbrv = new Vector(fbr.getColumnCount());
	    containedTiles = new TileDirectory[aft.getRecordCount()];
	    int cnt = 0;
	    while (aft.parseRow(aftv)) {
		int fac_num =((Number)aftv.elementAt(faceIDColumn)).intValue();
		fbr.getRow(fbrv, fac_num); //mutates fbrv
		int tileid = ((Number)aftv.elementAt(0)).intValue();
		String tilename = (String)aftv.elementAt(1);

		char chs[] = tilename.toCharArray();
		boolean goodTile = false;
		for (int i = 0; i < chs.length; i++) {
		    if ((chs[i] != '\\') && (chs[i] != ' ')) {
			goodTile = true;
		    }
		    if (chs[i] == '\\') {
			chs[i] = File.separatorChar;
		    }
		}
		tilename = new String(chs);
		if (!goodTile) {
		    continue;
		}
		double westlon = ((Double)fbrv.elementAt(1)).floatValue();
		double southlat = ((Double)fbrv.elementAt(2)).floatValue();
		double eastlon = ((Double)fbrv.elementAt(3)).floatValue();
		double northlat = ((Double)fbrv.elementAt(4)).floatValue();

		containedTiles[cnt++] = new TileDirectory(tilename,
							  northlat, southlat,
							  eastlon, westlon);
	    }
	    aft.close();
	    fbr.close();
	    if (cnt != containedTiles.length) {
		TileDirectory tmp[] = new TileDirectory[cnt];
		System.arraycopy(containedTiles, 0, tmp, 0, cnt);
		containedTiles = tmp;
	    }
	} catch (FormatException f) {
	    //probably (hopefully?) untiled coverage...
	    containedTiles = null;
	}
    }

    /**
     * Get the description of a coverage type
     * @param covname the name of the coverage type
     * @return the coverage description from the VPF database.  A null
     * return value indicates an unknown coverage type
     */
    public String getCoverageDescription(String covname) {
        CoverageEntry ce = (CoverageEntry)coverages.get(covname);
	return (ce == null) ? null : ce.getDescription();
    }
    

    /**
     * Get the CoverageTable for a particular coverage type
     * 
     * @param covname the name of the coverage type
     * @return the associated coverage table (possibly null)
     */
    public CoverageTable getCoverageTable(String covname) {
        CoverageEntry ce = (CoverageEntry)coverages.get(covname);
	if (ce != null) {
	    if (ce.getCoverageTable() == null) {
		ce.setCoverageTable(new CoverageTable(dirpath,
						      covname.intern()));
		if (Debug.debugging("vpf")) {
		    Debug.out.println("Created new coveragetable for " +
				      covname + ": " + ce.description);
		}
	    } else {
		if (Debug.debugging("vpf")) {
		    Debug.out.println("Using cached coveragetable for " +
				      covname + ": " + ce.description);
		}
	    }
	    return ce.getCoverageTable();
	}
	return null;
    }

    /**
     * get a list of tiles in the bounding region
     *
     * @param n northern boundary
     * @param s southern boundary
     * @param e eating foundry
     * @param w wheat bread
     * @return a vector of TileDirectories
     */
    public Vector tilesInRegion(double n, double s, double e, double w) {
	if (containedTiles == null)
	    return null;
	Vector retval = new Vector();
	for (int i = 0; i < containedTiles.length; i++)
	    if (containedTiles[i].inRegion(n,s,e,w))
		retval.addElement(containedTiles[i]);
	return retval;
    }
  
    /**
     * Find out if this library uses tiled data
     * @return true for tiled data
     */
    public boolean isTiledData() {
      return (containedTiles != null);
      
    }

    /**
     * Return the list of coverages this library has
     * @return the list of coverages  (DCW would include "po", "dn"; VMAP
     * would have "bnd", "tran", etc.)
     */
    public String[] getCoverageNames() {
	String[] retval = new String[coverages.size()];
	int i = 0;
	for (Enumeration e = coverages.keys(); e.hasMoreElements();) {
	    retval[i++] = (String)e.nextElement();
	}
	return retval;
    }

    /**
     * A utility class to hold information about one coverage type.  Only
     * the associated coverage table may be modified after construction.
     */
    public static class CoverageEntry {
        /** the VPF topology level of this coverage type */
        private final int tLevel;
        /** the VPF description string of this coverage type */
        private final String description;
        /** the CoverageTable for this coverage type */
        private CoverageTable covtable;
        /**
	 * Create a coverage entry without a coverage table
	 * @param topologyLevel the topology level for this coverageentry
	 * @param desc the description for this entry
	 */
        public CoverageEntry(int topologyLevel, String desc) {
	    this(topologyLevel, desc, null);
	}
        /**
	 * Create a coverage entry with an initial coverage table
	 * @param topologyLevel the topology level for this coverageentry
	 * @param desc the description for this entry
	 * @param covtable the coveragetable for this entry
	 */
        public CoverageEntry(int topologyLevel, String desc,
			     CoverageTable covtable) {
	    this.tLevel = topologyLevel;
	    this.description = desc;
	    this.covtable = covtable;
	}
        /**
	 * Get the topology level for this entry
	 */
        public int getTopologyLevel() {
	    return tLevel;
	}
        /**
	 * Get the description for this entry
	 */
        public String getDescription() {
	    return description;
	}
        /**
	 * Get the associated coveragetable
	 */
        public CoverageTable getCoverageTable() {
	    return covtable;
	}
        /**
	 * Set the associated coveragetable
	 * @param covtable the new coveragetable
	 */
        /*package*/ void setCoverageTable(CoverageTable covtable) {
	    this.covtable = covtable;
	}
    }
}

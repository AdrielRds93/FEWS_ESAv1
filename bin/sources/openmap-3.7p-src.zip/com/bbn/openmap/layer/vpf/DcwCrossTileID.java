/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/vpf/DcwCrossTileID.java,v $
 * $Revision: 1.5 $
 * $Date: 2000/05/08 14:23:10 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.vpf;

import com.bbn.openmap.MoreMath;
import java.io.EOFException;
import com.bbn.openmap.util.FormatException;
import com.bbn.openmap.util.BinaryFile;

/**
 * Encapsulate the VPF Cross-Tile identifier primitive datatype.  The
 * cross-tile identifier relates map features that cross multiple
 * tiles.<br>
 * Note: Mil-Std-2407 cross tile id's have a fourth, unused field.
 * This class will read that field, but does not use it.
 */
public class DcwCrossTileID {
    /** the 1-byte length specifier for the rest of the values... */
    //private int funkyDcwKeyValue = -1;
    /** the key for this tile */
    final public int currentTileKey;
    /** the id for the connected tile */
    final public int nextTileID;
    /** the key in the adjoining tile */
    final public int nextTileKey;
    /** unused value in VPF... */
    //private int unusedDcwKey = -1;

    /**
     * Construct a DcwCrossTileID from the specified input stream.
     *
     * @param in the filestream to construct from
     * @exception FormatException some error was detected while reading
     * the info for the column.
     * @exception EOFException EOF was encountered before reading any data
     */
    public DcwCrossTileID(BinaryFile in) 
	throws FormatException, EOFException {
	byte foo[] = in.readBytes(1, false);

	byte b = foo[0];
	//funkyDcwKeyValue = MoreMath.signedToInt(b);
					     
	try {
	    currentTileKey = readIntegerByKey(in, (byte)(b >> 6));
	    nextTileID = readIntegerByKey(in, (byte)(b >> 4));
	    nextTileKey = readIntegerByKey(in, (byte)(b >> 2));
	    int unusedDcwKey = readIntegerByKey(in, b);
	} catch (EOFException e) {
	    throw new FormatException("DcwCrossTileID: unexpected EOD " + e.getMessage());
	}
    }

    /**
     * Reads an integer from the input stream
     * @param in the stream to read from
     * @param key specifies the number of bytes to read (based on bottom 2
     * bits)
     * @return the integer read.  (-1 for a zero-length field)
     * @exception FormatException internal consistency failure
     * @exception EOFException hit end-of-file while reading data
     */
    private int readIntegerByKey(BinaryFile in, byte key) 
	throws FormatException, EOFException {
	switch (key & 0x3) {
	case 0:
	    return(-1);
	case 1:
	    byte foo[] = in.readBytes(1, false);
	    return(MoreMath.signedToInt(foo[0]));
	case 2:
	    return(MoreMath.signedToInt(in.readShort()));
	case 3:
	    return(in.readInteger());
	}
	throw new FormatException("This can't happen");
    }
      
    /**
     * produce a nice printed version of all our contained information
     * @return a nice little string
     */
    public String toString() {
	StringBuffer output = new StringBuffer();
	//output.append(Integer.toString(funkyDcwKeyValue,4)).append("-");
	output.append(currentTileKey).append("-");
	if (nextTileID != -1)
	    output.append(nextTileID).append("-");
	if (nextTileKey != -1)
	    output.append(nextTileKey).append("-");
// 	if (unusedDcwKey != -1) 
// 	    output.append(unusedDcwKey);
	return output.toString();
    }

}

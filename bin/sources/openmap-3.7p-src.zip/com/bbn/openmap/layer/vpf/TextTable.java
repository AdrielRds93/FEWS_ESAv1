/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998-2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/vpf/TextTable.java,v $
 * $Revision: 1.12 $
 * $Date: 2000/05/08 14:23:11 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.vpf;

import java.io.File;
import java.util.Vector;
import com.bbn.openmap.LatLonPoint;
import com.bbn.openmap.util.FormatException;

/**
 * Read VPF format text tables to generate text graphics for OpenMap.
 */
public class TextTable extends DcwRecordFile {

    /** the coveragetable this text tile is in, so that we can look up
     * topology information. */
    final private CoverageTable covtable;

    /** the column that our coordinates are in */
    final private int coordColumn;

    /** the column that the text info is in */
    final private int textColumn;

    /**
     *
     * @exception FormatException if something goes wrong reading the text
     */
    public TextTable(CoverageTable cov, File tilePath, boolean appendDot)
	throws FormatException
    {
	super(tilePath, (appendDot?"txt.":"txt"));
	covtable = cov;
	if ((coordColumn = whatColumn("shape_line")) == -1)
	    throw new FormatException("texttable couldn't get "
				      + "shape_line column"); 
	if ((textColumn = whatColumn("string")) == -1)
	    throw new FormatException("texttable couldn't get "
				      + "string column"); 
    }

    /**
     *
     */
    public void drawTile(VPFGraphicWarehouse warehouse,
			 double dpplat, double dpplon,
			 LatLonPoint ll1, LatLonPoint ll2) {

	double ll1lat = ll1.getLatitude();
	double ll1lon = ll1.getLongitude();
	double ll2lat = ll2.getLatitude();
	double ll2lon = ll2.getLongitude();

	Vector v = new Vector();
	try {
	    while (parseRow(v)) {
		String textval = (String)(v.elementAt(textColumn));

		CoordFloatString coords = (CoordFloatString)(v.elementAt(coordColumn));

		LatLonPoint pts = new LatLonPoint(coords.getYasFloat(0),
						  coords.getXasFloat(0));
		if ((pts.getLatitude() < ll2lat)
		    || (pts.getLatitude() > ll1lat)
		    || (pts.getLongitude() < ll1lon)
		    || (pts.getLongitude() > ll2lon)) {
		    continue;
		}

		warehouse.createText(covtable, this, v,
				     pts.getLatitude(),
				     pts.getLongitude(),
				     textval);
	    }
	} catch (FormatException f) {
	    System.out.println("Exception: " + f.getClass() + " " + f.getMessage());
	}
    }
}

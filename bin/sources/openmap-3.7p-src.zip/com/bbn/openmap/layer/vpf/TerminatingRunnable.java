/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/vpf/TerminatingRunnable.java,v $
 * $Revision: 1.3 $
 * $Date: 2000/05/08 14:23:11 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.vpf;

/** Classes that implement this interface are Runnable (in the Thread
 * sense), but have run() methods that will terminate in a bounded amount
 * of time.
 * @see java.lang.Thread
 * @see java.lang.Runnable#run()
 */
public interface TerminatingRunnable
    extends Runnable
{
}

/* **********************************************************************
 * 
 *  BBNT Solutions LLC, A part of GTE
 *  10 Moulton St.
 *  Cambridge, MA 02138
 *  (617) 873-2000
 * 
 *  Copyright (C) 1998, 2000
 *  This software is subject to copyright protection under the laws of 
 *  the United States and other countries.
 * 
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/vpf/VPFLayerDCWWarehouse.java,v $
 * $Revision: 1.5 $
 * $Date: 2000/07/27 23:46:18 $
 * $Author: dietrick $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.vpf;

import java.awt.Color;
import java.util.Vector;
import com.bbn.openmap.LatLonPoint;
import com.bbn.openmap.omGraphics.*;
import com.bbn.openmap.proj.ProjMath;
import com.bbn.openmap.util.Debug;
import java.util.StringTokenizer;
import com.bbn.openmap.util.FormatException;

/**
 * Implement a graphic factory that builds OMGraphics.
 * 
 * @see com.bbn.openmap.omGraphics.OMGraphic
 */
public class VPFLayerDCWWarehouse 
    extends LayerGraphicWarehouseSupport {

    /**
     *
     */
    public VPFLayerDCWWarehouse() {
        super();
    }

    /**
     *
     */
    public void createArea(CoverageTable covtable, AreaTable areatable,
			   Vector facevec,
			   LatLonPoint ll1,
			   LatLonPoint ll2,
			   double dpplat,
			   double dpplon,
			   boolean doAntarcticaWorkaround)
    {
	Vector ipts = new Vector();

	final MutableInt areatype = new MutableInt(-1);
	String descript = covtable.getAreaDescription(facevec, areatype);
	
	if (areatype.value == 0) {//topology artifact
	    return;
	}
	
	if (areatype.value == 2) {
	    if (Debug.debugging("vpf")) {
	        Debug.output("Skipping open ocean: " + descript);
	    }
	    return;
	}

	int totalSize = 0;
        try {
	    totalSize = areatable.computeEdgePoints(facevec, ipts);
	} catch (FormatException f) {
 	    Debug.output("FormatException in computeEdgePoints: " + f);
	    return;
	}
	if (totalSize == 0) {
	    return;
	}
	    
	OMPoly py = createAreaOMPoly(ipts, totalSize, ll1, ll2, 
				     dpplat, dpplon, doAntarcticaWorkaround);

	if (areatype.value == -1) {
	    areatype.value = 0;
	}

	drawingAttributes.setOMGraphicAttributes(py);

	graphics.add(py);
    }

    /**
     *
     */
    public void createEdge(CoverageTable covtable, EdgeTable edgetable,
			   Vector edgevec,
			   LatLonPoint ll1,
			   LatLonPoint ll2,
			   double dpplat,
			   double dpplon,
			   CoordFloatString coords)
    {
	//  Kept these here to keep in mind that it may be possible to
	//  further figure out what exactly we have here.
//  	MutableInt lineType = new MutableInt(-1);
//  	String desc = covtable.getLineDescription(edgevec, lineType);

	OMPoly py = createEdgeOMPoly(coords, ll1, ll2, dpplat, dpplon);
	drawingAttributes.setOMGraphicEdgeAttributes(py);
	graphics.add(py);
    }

    /**
     *
     */
    public void createText(CoverageTable covtable, TextTable texttable,
			   Vector textvec,
			   double latitude,
			   double longitude,
			   String text)
    {
	//  Kept these here to keep in mind that it may be possible to
	//  further figure out what exactly we have here.
//  	MutableInt textType = new MutableInt(-1);
//  	String desc = covtable.getTextDescription(textvec, textType);

	OMText txt = createOMText(text, latitude, longitude);
	drawingAttributes.setOMGraphicEdgeAttributes(txt);
	graphics.add(txt);
    }
}

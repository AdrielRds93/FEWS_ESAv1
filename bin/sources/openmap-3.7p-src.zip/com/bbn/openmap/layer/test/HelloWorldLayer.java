/* **********************************************************************
 * 
 *  BBNT Solutions LLC, A part of GTE
 *  10 Moulton St.
 *  Cambridge, MA 02138
 *  (617) 873-2000
 * 
 *  Copyright (C) 1998, 2000
 *  This software is subject to copyright protection under the laws of 
 *  the United States and other countries.
 * 
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/test/HelloWorldLayer.java,v $
 * $Revision: 1.2 $
 * $Date: 2000/05/08 14:22:58 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.test;

import com.bbn.openmap.Layer;
import com.bbn.openmap.event.ProjectionEvent;
import com.bbn.openmap.omGraphics.OMGraphic;
import com.bbn.openmap.omGraphics.OMGraphicList;
import com.bbn.openmap.omGraphics.OMPoly;

import java.awt.Color;
import java.awt.Graphics;


/**
 * Layer objects are components which can be added to the MapBean to
 * make a map.
 * <p>
 * Layers implement the ProjectionListener interface to listen for
 * ProjectionEvents.  When the projection changes, they may need to
 * refetch, regenerate their graphics, and then repaint themselves
 * into the new view.
 */
public class HelloWorldLayer extends Layer {

    protected OMGraphicList graphics;

    /**
     * Construct the layer.
     */
    public HelloWorldLayer () {
	super();
	graphics = new OMGraphicList(10);
	createGraphics(graphics);
    }

    /**
     * Sets the properties for the <code>Layer</code>.  This allows
     * <code>Layer</code>s to get a richer set of parameters than the
     * <code>setArgs</code> method.
     * @param prefix the token to prefix the property names
     * @param props the <code>Properties</code> object
     */
    public void setProperties(String prefix, java.util.Properties props) {
	super.setProperties(prefix, props);
    }

    /**
     * Invoked when the projection has changed or this Layer has been
     * added to the MapBean.
     * @param e ProjectionEvent
     */    
    public void projectionChanged (ProjectionEvent e) {
	graphics.generate(e.getProjection());
	repaint();
    }

    /**
     * Paints the layer.
     * @param g the Graphics context for painting
     */
    public void paint (Graphics g) {
	graphics.render(g);
    }

    /**
     * Create graphics.
     */
    protected void createGraphics (OMGraphicList list) {
	// NOTE: all this is very non-optimized...

	OMPoly poly;

	// H
	poly = new OMPoly(
		new double [] {
		    10d, -150d, 35d, -150d,
		    35d, -145d, 25d, -145d,
		    25d, -135d, 35d, -135d,
		    35d, -130d, 10d, -130d,
		    10d, -135d, 20d, -135d,
		    20d, -145d, 10d, -145d,
		    10d, -150d
		},
		OMGraphic.DECIMAL_DEGREES,
		OMGraphic.LINETYPE_RHUMB, 32);
	poly.setLineColor(Color.black);
	poly.setFillColor(Color.green);
	list.add(poly);

	// E
	poly = new OMPoly(
		new double [] {
		    10d, -120d, 35d, -120d,
		    35d, -100d, 30d, -100d,
		    30d, -115d, 25d, -115d,
		    25d, -105d, 20d, -105d,
		    20d, -115d, 15d, -115d,
		    15d, -100d, 10d, -100d,
		    10d, -120d
		},
		OMGraphic.DECIMAL_DEGREES,
		OMGraphic.LINETYPE_RHUMB, 32);
	poly.setLineColor(Color.black);
	poly.setFillColor(Color.green);
	list.add(poly);

	// L
	poly = new OMPoly(
		new double [] {
		    10d, -90d, 35d, -90d,
		    35d, -85d, 15d, -85d,
		    15d, -75d, 10d, -75d,
		    10d, -90d
		},
		OMGraphic.DECIMAL_DEGREES,
		OMGraphic.LINETYPE_RHUMB, 32);
	poly.setLineColor(Color.black);
	poly.setFillColor(Color.green);
	list.add(poly);

	// L
	poly = new OMPoly(
		new double [] {
		    10d, -70d, 35d, -70d,
		    35d, -65d, 15d, -65d,
		    15d, -55d, 10d, -55d,
		    10d, -70d
		},
		OMGraphic.DECIMAL_DEGREES,
		OMGraphic.LINETYPE_RHUMB, 32);
	poly.setLineColor(Color.black);
	poly.setFillColor(Color.green);
	list.add(poly);

	// O
	poly = new OMPoly(
		new double [] {
		    10d, -50d, 35d, -50d,
		    35d, -30d, 10d, -30d,
		    10d, -50d
		},
		OMGraphic.DECIMAL_DEGREES,
		OMGraphic.LINETYPE_RHUMB, 32);
	poly.setLineColor(Color.black);
	poly.setFillColor(OMGraphic.clear);
	list.add(poly);
	poly = new OMPoly(
		new double [] {
		    15d, -45d, 30d, -45d,
		    30d, -35d, 15d, -35d,
		    15d, -45d
		},
		OMGraphic.DECIMAL_DEGREES,
		OMGraphic.LINETYPE_RHUMB, 32);
	poly.setLineColor(Color.black);
	poly.setFillColor(OMGraphic.clear);
	list.add(poly);
	poly = new OMPoly(
		new double [] {
		    10d, -50d, 35d, -50d,
		    35d, -30d, 10d, -30d,
		    10d, -45d, 15d, -45d,
		    15d, -35d, 30d, -35d,
		    30d, -45d, 10d, -45d,
		    10d, -50d
		},
		OMGraphic.DECIMAL_DEGREES,
		OMGraphic.LINETYPE_RHUMB, 32);
	poly.setLineColor(OMGraphic.clear);
	poly.setFillColor(Color.green);
	list.add(poly);

	// W
	poly = new OMPoly(
		new double [] {
		    -35d, -5d, -10d, -5d,
		    -10d, 0d, -25d, 0d,
		    -25d, 5d, -20d, 5d,
		    -20d, 10d, -25d, 10d,
		    -25d, 15d, -10d, 15d,
		    -10d, 20d, -35d, 20d,
		    -35d, 10d, -30d, 10d,
		    -30d, 5d, -35d, 5d,
		    -35d, -5d
		},
		OMGraphic.DECIMAL_DEGREES,
		OMGraphic.LINETYPE_RHUMB, 32);
	poly.setLineColor(Color.black);
	poly.setFillColor(Color.green);
	list.add(poly);

	// O
	poly = new OMPoly(
		new double [] {
		    -35d, 30d, -10d, 30d,
		    -10d, 50d, -35d, 50d,
		    -35d, 30d
		},
		OMGraphic.DECIMAL_DEGREES,
		OMGraphic.LINETYPE_RHUMB, 32);
	poly.setLineColor(Color.black);
	poly.setFillColor(OMGraphic.clear);
	list.add(poly);
	poly = new OMPoly(
		new double [] {
		    -30d, 35d, -15d, 35d,
		    -15d, 45d, -30d, 45d,
		    -30d, 35d,
		},
		OMGraphic.DECIMAL_DEGREES,
		OMGraphic.LINETYPE_RHUMB, 32);
	poly.setLineColor(Color.black);
	poly.setFillColor(OMGraphic.clear);
	list.add(poly);
	poly = new OMPoly(
		new double [] {
		    -35d, 30d, -10d, 30d,
		    -10d, 50d, -35d, 50d,
		    -35d, 35d, -30d, 35d,
		    -30d, 45d, -15d, 45d,
		    -15d, 35d, -35d, 35d,
		    -35d, 30d
		},
		OMGraphic.DECIMAL_DEGREES,
		OMGraphic.LINETYPE_RHUMB, 32);
	poly.setLineColor(OMGraphic.clear);
	poly.setFillColor(Color.green);
	list.add(poly);

	// R
	poly = new OMPoly(
		new double [] {
		    -35d, 60d, -10d, 60d,
		    -10d, 75d, -20d, 75d,
		    -25d, 70d, -30d, 80d,
		    -35d, 80d, -35d, 75d,
		    -30d, 70d, -30d, 65d,
		    -35d, 65d, -35d, 60d
		},
		OMGraphic.DECIMAL_DEGREES,
		OMGraphic.LINETYPE_RHUMB, 32);
	poly.setLineColor(Color.black);
	poly.setFillColor(OMGraphic.clear);
	list.add(poly);
	poly = new OMPoly(
		new double [] {
		    -20d, 65d, -15d, 65d,
		    -15d, 70d, -20d, 70d,
		    -20d, 65d
		},
		OMGraphic.DECIMAL_DEGREES,
		OMGraphic.LINETYPE_RHUMB, 32);
	poly.setLineColor(Color.black);
	poly.setFillColor(OMGraphic.clear);
	list.add(poly);
	poly = new OMPoly(
		new double [] {
		    -35d, 60d, -10d, 60d,
		    -10d, 75d, -20d, 75d,
		    -25d, 70d, -30d, 80d,
		    -35d, 80d, -35d, 75d,
		    -30d, 70d, -30d, 65d,
		    -20d, 65d, -20d, 70d,
		    -15d, 70d, -15d, 65d,
		    -35d, 65d, -35d, 60d
		},
		OMGraphic.DECIMAL_DEGREES,
		OMGraphic.LINETYPE_RHUMB, 32);
	poly.setLineColor(OMGraphic.clear);
	poly.setFillColor(Color.green);
	list.add(poly);

	// L
	poly = new OMPoly(
		new double [] {
		    -35d, 90d, -10d, 90d,
		    -10d, 95d, -30d, 95d,
		    -30d, 105d, -35d, 105d,
		    -35d, 90d
		},
		OMGraphic.DECIMAL_DEGREES,
		OMGraphic.LINETYPE_RHUMB, 32);
	poly.setLineColor(Color.black);
	poly.setFillColor(Color.green);
	list.add(poly);

	// D
	poly = new OMPoly(
		new double [] {
		    -35d, 110d, -10d, 110d,
		    -10d, 125d, -15d, 130d,
		    -30d, 130d, -35d, 125d,
		    -35d, 110d
		},
		OMGraphic.DECIMAL_DEGREES,
		OMGraphic.LINETYPE_RHUMB, 32);
	poly.setLineColor(Color.black);
	poly.setFillColor(OMGraphic.clear);
	list.add(poly);
	poly = new OMPoly(
		new double [] {
		    -30d, 115d, -15d, 115d,
		    -15d, 120d, -20d, 125d,
		    -25d, 125d, -30d, 120d,
		    -30d, 115d
		},
		OMGraphic.DECIMAL_DEGREES,
		OMGraphic.LINETYPE_RHUMB, 32);
	poly.setLineColor(Color.black);
	poly.setFillColor(OMGraphic.clear);
	list.add(poly);
	poly = new OMPoly(
		new double [] {
		    -35d, 110d, -10d, 110d,
		    -10d, 125d, -15d, 130d,
		    -30d, 130d, -35d, 125d,
		    -35d, 115d, -30d, 115d,
		    -30d, 120d, -25d, 125d,
		    -20d, 125d, -15d, 120d,
		    -15d, 115d, -35d, 115d,
		    -35d, 110d
		},
		OMGraphic.DECIMAL_DEGREES,
		OMGraphic.LINETYPE_RHUMB, 32);
	poly.setLineColor(OMGraphic.clear);
	poly.setFillColor(Color.green);
	list.add(poly);
    }
}

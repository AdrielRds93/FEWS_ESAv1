/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/util/html/ListElement.java,v $
 * $Revision: 1.4 $
 * $Date: 2000/05/08 14:23:03 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.util.html;
import java.util.*;

/** A basic html container type */
public class ListElement implements ContainerElement {
    
    /** An ordered vector of elements */
    protected Vector v = new Vector();
    
    /** Construct a new ListElement */
    public ListElement() {
    }
    
    /** Add an element to the end of the list
     * @param e the element to add */
    public void addElement(Element e) {
	v.addElement(e);
    }
    
    /** convert representation to html and write it out
     * @param out the output Writer
     * @exception java.io.IOException an IO error occurred accessing out
     */
    public void generate(java.io.Writer out) throws java.io.IOException {
	for (Enumeration e = v.elements(); e.hasMoreElements(); )
	    ((Element)e.nextElement()).generate(out);
    }
}

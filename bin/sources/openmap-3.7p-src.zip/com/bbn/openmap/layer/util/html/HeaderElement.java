/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/util/html/HeaderElement.java,v $
 * $Revision: 1.4 $
 * $Date: 2000/05/08 14:23:03 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.util.html;

/** This class provides easy access to the html header tags */
public class HeaderElement extends WrapElement {
    
    /** Construct a header
     * @param headLevel the level of the header (should be a small integer)
     * @param e the element in the header
     * @exception IllegalArgumentException headLevel was invalid */
    public HeaderElement(int headLevel, Element e) {
	super("h"+headLevel, e);
	if (headLevel < 1)
	    throw new IllegalArgumentException("HeaderElement: headLevel = " + headLevel);
    }

    /** Construct a header
     * @param headLevel the level of the header (should be a small integer)
     * @param s the string in the header
     * @exception IllegalArgumentException headLevel was invalid */
    public HeaderElement(int headLevel, String s) {
	this(headLevel, new StringElement(s));
    }
}

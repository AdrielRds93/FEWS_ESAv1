/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/util/html/WrapElement.java,v $
 * $Revision: 1.4 $
 * $Date: 2000/05/08 14:23:04 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.util.html;

/** This class is used for html tags that are begin/end paired.  For example,
 * the html <code>&lt;code&gt;wrapped element&lt;/code&gt;</code> would have
 * a wrapString of code, and an element of "wrapped element" */
public class WrapElement implements Element {

    /** the html tag to "wrap" around the contained element */
    protected String wrapString;
    /** the element that gets wrapped */
    protected Element e;

    /** Construct a WrapElement with just a wrapping string
     * @param wrapString the html tag that gets wrapped around the element
     */
    public WrapElement(String wrapString) {
	this.wrapString = wrapString;
    }
    
    /** Construct a WrapElement with a wrapping string and element
     * @param wrapString the html tag that gets wrapped around the element
     * @param e the element that gets contained
     */
    public WrapElement(String wrapString, Element e) {
	this.wrapString = wrapString;
	this.e = e;
    }
    
    /** Writer for the Element attribute
     * @param e the new element value */
    public void setElement(Element e) {
	this.e = e;
    }
    
    /** Accessor for the element attribute
     @return the contained element */
    public Element getElement() {
	return e;
    }
    
    /** convert representation to html and write it out
     * @param out the output Writer
     * @exception java.io.IOException an IO error occurred accessing out
     */
    public void generate (java.io.Writer out) throws java.io.IOException {
	out.write("<"+wrapString+">");
	e.generate(out);
	out.write("</"+wrapString+">\n");
    }
}

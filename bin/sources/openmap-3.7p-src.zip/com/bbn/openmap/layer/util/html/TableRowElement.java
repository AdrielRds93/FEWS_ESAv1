/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/util/html/TableRowElement.java,v $
 * $Revision: 1.4 $
 * $Date: 2000/05/08 14:23:04 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.util.html;

/** This class implements an entire row of an html table */
public class TableRowElement extends WrapElement implements ContainerElement {

    /** Constuct an empty row */
    public TableRowElement() {
	super("tr", new ListElement());
    }
  
    /** Add a column to the row
     * @param ne add the element wrapped inside a TableDataElement
     * @see TableDataElement */
    public void addElement(Element ne) {
	((ListElement)e).addElement(new TableDataElement(ne));
    }
    
    /** Add a column to the row
     * @param s add the element wrapped inside a TableDataElement
     * @see TableDataElement */
    public void addElement(String s) {
	((ListElement)e).addElement(new TableDataElement(s));
    }
    
    /** Add a column to the row
     * @param c adds the cell to the row (doesn't wrap it) */
    public void addElement(TableCellElement c) {
	((ListElement)e).addElement(c);
    }
}

/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/util/http/HttpConnection.java,v $
 * $Revision: 1.4 $
 * $Date: 2000/05/08 14:23:06 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.util.http;

import java.io.*;
import java.net.*;



/**
 * HttpConnection handles the communication with an HTTP client in
 * its own thread.  An instance of this class is created by the
 * <code>HttpServer</code> each time a connection is made.  The instance
 * exists only long enough to fulfill the request, then dies.
 *
 * @author Tom Mitchell
 * @version 1.1, 06/17/97
 * @see HttpServer
 */
public class HttpConnection extends Thread {

    protected HttpServer server;
    protected Socket client;
    protected BufferedReader in;
    protected Writer out;



    /**
     * Initialize the input <code>Reader</code> and output <code>Writer</code>
     * and start the connection thread.
     *
     * @param client_socket the client's socket
     * @param server the server object
     */
    public HttpConnection(Socket client_socket, HttpServer server) {
        client = client_socket;
	this.server = server;
	InputStreamReader isr;
	OutputStreamWriter osr;
	
        try { 
	    isr = new InputStreamReader(client.getInputStream());
	    in = new BufferedReader(isr);
	    osr = new OutputStreamWriter(client.getOutputStream());
	    out = new BufferedWriter(osr);
        }
        catch (IOException e) {
            try { client.close(); } catch (IOException e2) { ; }
            System.err.println("Exception while getting socket streams: " + e);
            return;
        }
        this.start();
    }
    


    /**
     * The running thread simply reads all the lines of input and hands
     * each line off to be parsed.
     */
    public void run() {
        String line;
        StringBuffer revline;
        int len;

        try {
            while (true) {
                // read in a line
                line = in.readLine();
                if (line == null) break;
		processLine(line);
            }
        }
        catch (IOException e) { ; }
        finally { try {client.close();} catch (IOException e2) {;} }
    }



    /**
     * Processes a line of an HTTP request.  The only interesting line
     * we really look at is a GET command, which starts with "GET".
     *
     * @param line one line of an HTTP request
     */
    protected void processLine (String line) throws IOException {
	if (line.startsWith("GET")) {
	    processGetCommand(line);
	}
    }



    /**
     * Process a "GET" HTTP command.  The leading "GET " and the
     * trailing HTTP version information are stripped off and a
     * HttpRequestEvent is fired via the HttpServer.
     *
     * @param line a "GET" HTTP command
     */
    protected void processGetCommand (String cmd) throws IOException {
	// Command looks like: "GET /thisURL HTTP/1.0"
	String location = cmd.substring(4); // remove the "GET "
	int locationEnd = location.indexOf(" "); // end at first space
	location = location.substring(0, locationEnd);
	StringWriter outBuf = new StringWriter();
	server.fireHttpRequestEvent(location, outBuf);
	String result = outBuf.toString();
	
	// Figure out what type of file to figure Content-type string contents
	String contentType;
	if (location.endsWith(".gif") || location.endsWith(".GIF"))
	  contentType="image/gif";
	else if (location.endsWith(".htm") || location.endsWith(".html")
		 || location.endsWith(".HTM") || location.endsWith(".HTML"))
	  contentType="text/html";
	else if (location.endsWith(".jpg") || location.endsWith(".JPG")
		 || location.endsWith(".jpeg") || location.endsWith(".JPEG"))
	  contentType="image/jpeg";
	else if (location.endsWith(".mov") || location.endsWith(".MOV"))
	  contentType="video/quicktime";
	else contentType="text/plain";

	out.write("HTTP/1.0 200 \n"); // return status
	out.write("Content-type: " + contentType + "\n"); // important!
	out.write("Content-Length: " + result.length() + "\n");	// important!
	out.write("\n");
	out.write(result);
	out.flush();
    }
}

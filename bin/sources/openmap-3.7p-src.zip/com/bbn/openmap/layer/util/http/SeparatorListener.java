/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/util/http/SeparatorListener.java,v $
 * $Revision: 1.4 $
 * $Date: 2000/05/08 14:23:06 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.util.http;

import java.io.Writer;
import java.io.IOException;

/**
 * An HttpRequestListener that writes a HTML separator ("<HR>")
 * to the client.
 *
 * @author Tom Mitchell
 * @version 1.0, 06/13/97
 */
public class SeparatorListener implements HttpRequestListener {
    public SeparatorListener () {
    }

    /**
     * Ignore the request, just write the separator.
     */
    public void httpRequest (HttpRequestEvent e) throws IOException {
	e.getWriter().write("<HR>");
    }
}

/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/util/http/HttpRequestEvent.java,v $
 * $Revision: 1.4 $
 * $Date: 2000/05/08 14:23:06 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.util.http;

import java.io.Writer;


/**
 * An event corresponding to a single HTTP request ("GET" command).
 *
 * @author Tom Mitchell
 * @version 1.0, 06/13/97
 */
public class HttpRequestEvent extends java.util.EventObject {

    protected String request;
    protected java.io.Writer writer;


    /**
     * Creates an http request event.
     *
     * @param source  the source object
     * @param request the parsed target of the "GET" command
     * @param writer  the http client output stream
     */
    public HttpRequestEvent (Object source,
			     String request,
			     java.io.Writer writer) {
	super(source);
	this.request = request;
	this.writer = writer;
    }


    /**
     * Gets the http request, which is the target of the "GET" command.
     * <p>
     * For the URL <code>http://www.bbn.com/openmap/docs/index.html</code>
     * <p>
     * the request string is <code>/openmap/docs/index.html</code>
     *
     * @return the request string
     */
    public String getRequest () {
	return request;
    }


    /**
     * Gets the output stream connected to the http client.
     *
     * @return the writer associated with the http client
     * @see java.io.Writer
     */
    public Writer getWriter () {
	return writer;
    }
}

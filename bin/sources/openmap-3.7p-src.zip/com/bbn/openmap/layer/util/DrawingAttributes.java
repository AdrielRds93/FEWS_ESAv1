/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyrightf 1998-1999 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/util/DrawingAttributes.java,v $
 * $Revision: 1.2 $
 * $Date: 2000/08/02 16:11:15 $
 * $Author: dietrick $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.util;


/*  Java Core  */
import com.bbn.openmap.image.BufferedImageHelper;
import com.bbn.openmap.omGraphics.OMColor;
import com.bbn.openmap.omGraphics.OMGraphic;
import com.bbn.openmap.omGraphics.OMGraphic2D;
import com.bbn.openmap.omGraphics.OMText;
import com.bbn.openmap.util.Debug;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Image;
import java.awt.Paint;
import java.awt.Rectangle;
import java.awt.Stroke;
import java.awt.TexturePaint;
import java.awt.image.BufferedImage;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.NoSuchElementException;
import java.util.Properties;
import java.util.StringTokenizer;

/* OpenMap */

/** 
 * DrawingAttributes provides a mechanism for loading and managing
 * different drawing attributes that may be used.  Several layers need
 * to be able to have Properties define how objects for them should be
 * drawn, and the list of these drawing attributes tend to be the
 * same.  The DrawingAttributes class fishes out the applicable
 * properties for you, creates the objects needed, and then lets you
 * get those objects when needed.
 */
public class DrawingAttributes {

    /** The name of the property that holds the line color of the graphics. */
    public final static String lineColorProperty = "lineColor";
    /** The name of the property that holds the text color for Text,
     *  in case that should be different for labels, etc.. */
    public final static String textColorProperty = "textColor";
    /** The name of the property that holds the fill color of the graphics. */
    public final static String fillColorProperty = "fillColor";
    /** The name of the property that holds the select color of the
     *  graphics, which is the line color that gets set with the
     *  default OMGraphic.select() action. */
    public final static String selectColorProperty = "selectColor";
    /** The property that specifies an URL or file a image file to be
     *  used to construct the Paint object for a texture fill pattern.
     *  If the fillPattern is null, the fillColor will be used. */
    public static final String fillPatternProperty = "fillPattern";
    /** The name of the property that holds the lineWidth of the graphics. */
    public final static String lineWidthProperty = "lineWidth";
    /** The name of the property that holds a dashed pattern for
     *  lines. This will be used to build the stroke object for
     *  lines. This pattern should be two space-separated numbers, the
     *  first representing the pixel length of the line in the dash,
     *  the second being the space pixel length of the dash. */
    public final static String dashPatternProperty = "dashPattern";
    /** The name of the property that holds a dashed phase for
     *  lines. This will be used to build the stroke object for
     *  lines. */
    public final static String dashPhaseProperty = "dashPhase";
    /** The base scale to use for the image provided for the fill
     *  pattern.  As the scale of the map changes, the base scale can
     *  be used as a reference to change the resolution of the
     *  pattern. This scale will also be used for strokes. */
    public static final String baseScaleProperty = "baseScale";
    
    public final static int NONE = -1;

    /** The default line color. (black) */
    public final static String defaultLineColorString = "0"; // black
    /** The default fill color. (none) */
    public final static String defaultFillColorString = "-1"; // none
    /** The default fill color. (none) */
    public final static String defaultSelectColorString = "0"; // black
    /** The default line width */
    public final static float defaultLineWidth = 1f;
    /** The default dash phase, which is zero. */
    public final static float defaultDashPhase = 0f;
    /** The defaule dash length, for opaque and transparent parts. */
    public final static float defaultDashLength = 5f;

    /** The color to outline the shapes. */
    protected Color lineColor = Color.black;
    /** The color for text.  Default to black. */
    protected Color textColor = lineColor;
    /** The select color for the shapes. */
    protected Color selectColor = Color.black;
    /** The color to fill the shapes. */
    protected Color fillColor = OMColor.clear;
    /** The line width of the graphics. If there is a stroke object
     *  defined, then the line width from the Stroke object will be
     *  returned. */
    protected float lineWidth = defaultLineWidth;
    /** The line stroke, for dashes, etc. */
    protected BasicStroke stroke = null;
    /** The fill pattern image. */
    protected TexturePaint fillPattern = null;
    /** The base scale for scaling the fill pattern image. If NONE,
     *  then the resolution of the raw image will always be used. */
    protected float baseScale = NONE;

    /** 
     * Create a DrawingAttributes with the default settings - clear
     * fill color and pattern, sold black edge line of width 1.  
     */
    public DrawingAttributes(){}

    /**
     * Create the DrawingAttributes and call init without a prefix for
     * the properties.  Call init without a prefix for the properties.
     * @param props the Properties to look in.  
     */
    public DrawingAttributes(Properties props){
	init(null, props);
    }

    /**
     * Create the DrawingAttributes and call init with a prefix for
     * the properties.  
     * @param prefix the prefix marker to use for a property, like
     * prefix.propertyName.  The period is added in this function.
     * @param props the Properties to look in.  
     */
    public DrawingAttributes(String prefix, Properties props){
	init(prefix, props);
    }

    /**
     * Call init without a prefix for the properties.
     * @param props the Properties to look in.  
     */
    public void init(Properties props){
	init(null, props);
    }

    /**
     * Look at the Properties, and fill in the drawing attributes
     * based in it's contents.  If a property is not in the
     * properties, it's set to its default setting. 
     * @param prefix the prefix marker to use for a property, like
     * prefix.propertyName.  The period is added in this function.
     * @param props the Properties to look in.  
     */
    public void init(String prefix, Properties props){
	String realPrefix;
	if (prefix != null){
	    realPrefix = prefix + ".";
	} else {
	    realPrefix = "";
	}
	
	//  Set up the drawing attributes.
	lineColor =
	    LayerUtils.parseColorFromProperties(
		props, realPrefix + lineColorProperty,
		defaultLineColorString);
	
	if (props.getProperty(realPrefix + textColorProperty) != null){
	    textColor =
		LayerUtils.parseColorFromProperties(
		    props, realPrefix + textColorProperty,
		    defaultLineColorString);
	} else {
	    textColor = lineColor;
	}

	fillColor =
	    LayerUtils.parseColorFromProperties(
		props, realPrefix + fillColorProperty,
		defaultFillColorString);
	
	lineWidth =
	    LayerUtils.floatFromProperties(
		props, realPrefix + lineWidthProperty,
		defaultLineWidth);
	
	baseScale =
	    LayerUtils.floatFromProperties(
		props, realPrefix + baseScaleProperty,
		baseScale);
	
	// Look for a dash pattern properties to come up with a stroke
	String dPattern = props.getProperty(realPrefix + dashPatternProperty);
	if (dPattern != null){
	    float dashOn, dashOff;
	    float dashPhase;

	    // OK, it exists, come up with a stroke.
	    try {
		StringTokenizer t = new StringTokenizer(dPattern);
		String first = t.nextToken();
		String second = t.nextToken();
		dashOn = Float.valueOf(first).floatValue();
		dashOff = Float.valueOf(second).floatValue();
	    } catch (NoSuchElementException nsee){
		Debug.error("DrawingAttributes.init: dash pattern attributes wrong - should be dashPattern=(number pixels on) (number pixels off)");
		dashOn = defaultDashLength;
		dashOff = defaultDashLength;
	    } catch (NumberFormatException nfe){
		Debug.error("DrawingAttributes.init: Number format exception for dashPattern");
		dashOn = defaultDashLength;
		dashOff = defaultDashLength;
	    } catch (NullPointerException npe){
		Debug.error("DrawingAttributes.init: Caught null pointer exception - probably resulting from non-float number format exception for dashPattern");
		dashOn = defaultDashLength;
		dashOff = defaultDashLength;

	    }

	    float[] lineDash = new float[2];
	    lineDash[0] = dashOn;
	    lineDash[1] = dashOff;

	    String dPhase = props.getProperty(realPrefix + dashPhaseProperty);
	    if (dPhase != null){
		try {
		    dashPhase = Float.valueOf(dPhase).floatValue();
		} catch (NumberFormatException nfe){
		    Debug.error("DrawingAttributes.init: Number format exception for dashPhase");
		    dashPhase = defaultDashPhase;
		}
	    } else {
		dashPhase = defaultDashPhase;
	    }
	    stroke = new BasicStroke(lineWidth, 
				     BasicStroke.CAP_BUTT, 
				     BasicStroke.JOIN_MITER, 10.0f,
				     lineDash, dashPhase);
	}

	//  OK, Fill pattern next...
	String fPattern = props.getProperty(realPrefix + fillPatternProperty);
	if (fPattern != null){

	    try {

		URL textureImageURL = 
		    LayerUtils.getResourceOrFileOrURL(this, fPattern);

		if (textureImageURL != null){

		    BufferedImage bi = 
			BufferedImageHelper.getBufferedImage(textureImageURL, 
							     0, 0, -1, -1);
		    
		    fillPattern = 
			new TexturePaint(bi, new Rectangle(0,0, bi.getWidth(), 
							   bi.getHeight()));
		} 
	    } catch (MalformedURLException murle){
		Debug.error("DrawingAttributes.init: bad texture URL - \n     " + 
			    realPrefix + fillPatternProperty);
		fillPattern = null;
	    } catch (InterruptedException ie){
		Debug.error("DrawingAttributes.init: bad problems getting texture URL - \n" + ie);
		fillPattern = null;
	    }
	}
    }

    /**
     * Set the Stroke to use for the edge of a graphic.
     */
    public void setStroke(BasicStroke stroke){
	this.stroke = stroke;
    }

    /**
     * Get the Stroke used for the lines of a graphic.
     */
    public Stroke getStroke(){
	return stroke;
    }

    /**
     * Get the Stroke object, scaled for comparison to the base
     * scale. If the base scale equals NONE, it's the same as
     * getStroke().
     * @param scale scale to compare to the base scale.  
     */
    public Stroke getStrokeForScale(float scale){
	if (baseScale != NONE && stroke != null){
	    float[] dash = stroke.getDashArray();
	    float scaleFactor = scale/baseScale;
	    for (int i = 0; i < dash.length; i++){
		dash[i] *= scaleFactor;
	    }

	    return new BasicStroke(lineWidth, 
				   BasicStroke.CAP_BUTT, 
				   BasicStroke.JOIN_MITER, 10.0f,
				   dash, stroke.getDashPhase());
	}
	return stroke;
    }

    /**
     * Set the TexturePaint to use for the fill pattern.
     */
    public void setFillPattern(TexturePaint paint){
	fillPattern = paint;
    }

    /**
     * Get the TexturePaint to use for the fill pattern.
     */
    public Paint getFillPattern(){
	return fillPattern;
    }

    /**
     * Get the TexturePaint for these attributes, and scale it for the
     * scale compaired to the base scale set.  If the base scale
     * equals NONE, it's the same as getFillPattern().  
     * @param scale scale to compare to the base scale.
     */
    public Paint getFillPatternForScale(float scale){
	if (baseScale != NONE && fillPattern != null){
	    BufferedImage bi = fillPattern.getImage();
	    float scaleFactor = scale/baseScale;
	    Image image = bi.getScaledInstance((int)(bi.getWidth()*scaleFactor), 
					       (int)(bi.getHeight()*scaleFactor),
					       Image.SCALE_SMOOTH);
	    try {
		bi = BufferedImageHelper.getBufferedImage(image, 0, 0, -1, -1);
		
		return new TexturePaint(bi, new Rectangle(0,0, bi.getWidth(), 
							  bi.getHeight()));
	    } catch (InterruptedException ie){
		Debug.error("DrawingAttributes: Interrupted Exception scaling texture paint");
		return fillPattern;
	    }
	}

	return fillPattern;
    }

    /**
     * Set the edge color for the graphics created for the coverage
     * type.
     * @param lColor the color.  
     */
    public void setLineColor(Color lColor){
	lineColor = lColor;
    }

    /**
     * Get the line color for the graphics created for the coverage
     * type.
     * @return the line color to use for the edges.
     */
    public Color getLineColor(){
	return lineColor;
    }

    /**
     * Set the selected edge color for the graphics created for the coverage
     * type.
     * @param sColor the color.  
     */
    public void setSelectColor(Color sColor){
	selectColor = sColor;
    }

    /**
     * Get the line color for the graphics created for the coverage
     * type.
     * @return the select line color to use for the edges.
     */
    public Color getSelectColor(){
	return selectColor;
    }

    /**
     * Set the fill color for the graphics created for the coverage
     * type.
     * @param fColor the color.  
     */
    public void setFillColor(Color fColor){
	fillColor = fColor;
    }

    /**
     * Set the fill color for the graphics created for the coverage
     * type.
     * @return the fill color to use for the areas.
     */
    public Color getFillColor(){
	return fillColor;
    }

    /**
     * Set the line width for the graphics created for the coverage
     * type.
     * @param width the line width to use for the edges.
     */
    public void setLineWidth(float width){
	lineWidth = width;
    }

    /**
     * Get the line width for the graphics created for the coverage
     * type.
     * @return the line width to use for the edges.
     */
    public float getLineWidth(){
	return lineWidth;
    }

    /**
     *  Set the base scale to use for the texture paint and stroke.
     *  If this is set to a negative number, then no scaling of the
     *  paint or stroke will be performed.
     * @param bScale the base scale to use - 1:bScale.
     */
    public void setBaseScale(float bScale){
	if (bScale > 0){
	    baseScale = bScale;
	} else {
	    baseScale = NONE;
	}
    }

    /**
     * Get the base scale that the texture paint and dashes are set
     * for.  If the texture paint and stroke are asked for with a
     * scale, those values will be adjusted accordingly.
     * @return base scale for paint and stroke.  
     */
    public float getBaseScale(){
	return baseScale;
    }

    /**
     * Set all the attributes for the graphic that are contained
     * within this DrawingAttributes class.
     * 
     * @param graphic OMGraphic.  
     */
    public void setOMGraphicAttributes(OMGraphic graphic){

	setOMGraphicEdgeAttributes(graphic);

	if (graphic instanceof OMGraphic2D){
	    OMGraphic2D graphic2d = (OMGraphic2D) graphic;
	    if (fillPattern != null){
		graphic2d.setPaint(fillPattern);
	    } else {
		graphic.setFillColor(fillColor);
	    }
	} else {
	    graphic.setFillColor(fillColor);
	}
    }

    /**
     * Set the graphic attributes that only pertain to boundaries.
     * This is good for polylines, where setting the fill color will
     * close up the polyline making it a polygon.  So if you want to
     * color edge data, use this function.  Sets line color, line
     * width, and stroke if graphic is a OMGraphic2D 
     * @param graphic OMGraphic
     */
    public void setOMGraphicEdgeAttributes(OMGraphic graphic){
	if (graphic instanceof OMText){
	    graphic.setLineColor(textColor);
	} else {
	    graphic.setLineColor(lineColor);
	}
	graphic.setSelectColor(selectColor);

	if (graphic instanceof OMGraphic2D){
	    OMGraphic2D graphic2d = (OMGraphic2D) graphic;
	    if (stroke != null){
		graphic2d.setStroke(stroke);
	    } else {
		graphic.setLineWidth(lineWidth);
	    }
	} else {
	    graphic.setLineWidth(lineWidth);
	}
    }

    /**
     * Set all the attributes for the graphic that are contained
     * within this DrawingAttributes class.  Get the TexturePaint for
     * these attributes, and scale it for the scale compaired to the
     * base scale set.  If the base scale equals NONE, the fill
     * pattern is not changed with relation to scale.
     * @param graphic OMGraphic.  
     * @param scale scale to compare to the base scale.  
     */
    public void setOMGraphicAttributesForScale(OMGraphic graphic, float scale){
	setOMGraphicEdgeAttributesForScale(graphic, scale);

	if (graphic instanceof OMGraphic2D){
	    OMGraphic2D graphic2d = (OMGraphic2D) graphic;
	    if (fillPattern != null){
		graphic2d.setPaint(getFillPatternForScale(scale));
	    } else {
		graphic.setFillColor(fillColor);
	    }
	} else {
	    graphic.setFillColor(fillColor);
	}
    }

    /**
     * Set the graphic attributes that only pertain to boundaries.
     * This is good for polylines, where setting the fill color will
     * close up the polyline making it a polygon.  So if you want to
     * color edge data, use this function.  Sets line color, line
     * width, and stroke if graphic is a OMGraphic2D 
     * The stroke, if the base scale is set, is adjusted accordingly.
     * @param graphic OMGraphic.  
     * @param scale scale to compare to the base scale.  
     */
    public void setOMGraphicEdgeAttributesForScale(OMGraphic graphic, float scale){

	if (graphic instanceof OMText){
	    graphic.setLineColor(textColor);
	} else {
	    graphic.setLineColor(lineColor);
	}
	graphic.setSelectColor(selectColor);

	if (graphic instanceof OMGraphic2D){
	    OMGraphic2D graphic2d = (OMGraphic2D) graphic;
	    if (stroke != null){
		graphic2d.setStroke(getStrokeForScale(scale));
	    } else {
		graphic.setLineWidth(lineWidth);
	    }
	} else {
	    graphic.setLineWidth(lineWidth);
	}
    }
}

// **********************************************************************
// 
//  BBNT Solutions LLC, A part of GTE
//  10 Moulton St.
//  Cambridge, MA 02138
//  (617) 873-2000
// 
//  Copyright (C) 1997, 2000
//  This software is subject to copyright protection under the laws of 
//  the United States and other countries.
// 
// **********************************************************************
// $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/util/cacheHandler/CacheObject.java,v $
// $Revision: 1.4 $ * $Date: 2000/07/31 21:21:12 $ * $Author: wjeuerle $
// **********************************************************************


package com.bbn.openmap.layer.util.cacheHandler;

public class CacheObject {

  public Object obj = null;
  public int cachedTime = 0;
  public String id = null;
  
  /** New object, set the local clock to zero
   */
  public CacheObject(String identifier, Object cachedObject){
      id = identifier;
      obj = cachedObject;
  }

  public boolean match(String queryID){
    return (queryID.equals(id));
  }

  public boolean older(int time){
    return (cachedTime < time);
  }
}


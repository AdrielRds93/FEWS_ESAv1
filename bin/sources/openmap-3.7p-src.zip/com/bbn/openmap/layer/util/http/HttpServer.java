/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/util/http/HttpServer.java,v $
 * $Revision: 1.4 $
 * $Date: 2000/05/08 14:23:06 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.util.http;

import java.io.*;
import java.net.*;
import java.util.Vector;
import java.util.Enumeration;



/**
 * A simple HTTP Server implementing HTTP/0.9 protocols.
 *
 * Cobbled together from a server originally written by David Flanagan
 * for the book <bold>Java in a Nutshell</bold>, Copyright(c) 1996
 * O'Reilly & Associates.
 *
 * Modified to use JDK 1.1 Readers, and Writers.
 * Further modified to use the JDK 1.1 Event model.
 *
 * @author Tom Mitchell
 * @version 1.0, 06/13/97
 */
public class HttpServer extends Thread {

    /**
     * The default port.  A port of 0 (zero) causes the system to
     * allocate any unused port.  With any other number the system
     * will attempt to open that port, and throw an exception if it
     * is in use.
     */
    public final static int DEFAULT_PORT = 0;

    protected int port;
    protected ServerSocket listen_socket;
    protected Vector listeners;
    
    /**
     * Creates an Http Server on the indicated port, and then starts
     * a thread that listens to that port.  The thread will not be
     * a daemon thread.
     *
     * @param port the port to open
     * @see java.net.ServerSocket
     */
    public HttpServer(int port) throws IOException {
	this(port, false);
    }


    /**
     * Creates an Http Server on the indicated port, and then starts
     * a thread that listens to that port.  The thread will be a daemon
     * thread of asDaemon is true.
     *
     * @param port the port to open
     * @param asDaemon whether to make thread a daemon
     * @see java.net.ServerSocket
     */
    public HttpServer (int port, boolean asDaemon)
	throws IOException
    {
        this.port = port;
	listeners = new Vector();
	listen_socket = new ServerSocket(port);
	this.setDaemon(asDaemon);
        this.start();
    }
    


    /**
     * Creates an Http Server on any free port, and then starts
     * a thread that listens to that port.
     *
     * @param port the port to open
     * @see java.net.ServerSocket
     */
    public HttpServer() throws IOException {
	this(DEFAULT_PORT);
    }



    /**
     * The body of the server thread.  Loop forever, listening for and
     * accepting connections from clients.  For each connection, 
     * create a HttpConnection object to handle communication through the
     * new Socket.
     *
     * @see HttpConnection
     * @see java.net.Socket
     */
    public void run() {
        try {
            while(true) {
                Socket client_socket = listen_socket.accept();
                HttpConnection c = new HttpConnection(client_socket, this);
            }
        }
        catch (IOException e) { 
	    System.err.println("Exception while listening for connections");
	    e.printStackTrace();
        }
    }
    
    /**
     * Gets the port associate with this server.
     *
     * @return the server's port
     */
    public int getPort () {
	return listen_socket.getLocalPort();
    }


    /**
     * Creates a HttpRequestEvent and sends it to all registered listeners.
     *
     * @param request the parsed http request
     * @param w     the Writer associated with the request's client connection
     * @see java.io.Writer
     * @see HttpRequestListener
     * @see HttpRequestEvent
     */
    public void fireHttpRequestEvent (String request, Writer w)
	 throws IOException {
	     HttpRequestListener listener;
	     HttpRequestEvent event = new HttpRequestEvent(this, request, w);

	     // Make a copy of the list and fire the events using that copy.
	     // This means that listeners can be added or removed from the
	     // original list in response to this event.
	     Vector list = (Vector) listeners.clone();
	     Enumeration e = list.elements();
	     while (e.hasMoreElements()) {
		 listener = (HttpRequestListener)e.nextElement();
		 listener.httpRequest(event);
	     }
    }



    /**
     * Adds a new http request listener.
     *
     * @param l the listener
     * @see HttpRequestListener
     */
    public void addHttpRequestListener (HttpRequestListener l) {
	listeners.addElement(l);
    }



    /**
     * Removes an http request listener.
     *
     * @param l a listener
     * @see HttpRequestListener
     */
    public void removeHttpRequestListener (HttpRequestListener l) {
	listeners.removeElement(l);
    }



    /**
     * A main routine for unit testing.  Starts a HttpServer,
     * adds several HttpRequestListeners, and waits for connections.
     * <p>
     * Usage: java com.bbn.openmap.layer.util.http.HttpServer [port] <p>
     * If no port is specified, the default port is used. <p>
     * If port zero is specified, the system chooses the port.<p>
     * If a port other than zero is specified, the http server will
     * attempt to open that port, or fail if it is in use.
     * <p>
     * Examples: <p>
     * java com.bbn.openmap.layer.util.http.HttpServer <p>
     * java com.bbn.openmap.layer.util.http.HttpServer 8000 <p>
     * java com.bbn.openmap.layer.util.http.HttpServer 0 <p>
     *
     * @param args command line args
     */
    public static void main(String[] args) {
        int port = 0;
        if (args.length == 1) {
            try { port = Integer.parseInt(args[0]);  }
            catch (NumberFormatException e) { port = 0; }
        }
	try {
	    HttpServer server = new HttpServer(port);
	    server.addHttpRequestListener(new SeparatorListener());
	    server.addHttpRequestListener(new SieveListener());
	    server.addHttpRequestListener(new SeparatorListener());
	    server.addHttpRequestListener(new ReverseListener());
	    server.addHttpRequestListener(new SeparatorListener());
	    System.out.println("Server listening on port " + server.getPort());
	}
	catch (IOException e) {
	    System.err.println("Unable to start http server:");
	    e.printStackTrace();
	}
    }
}

/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/util/html/TableHeaderElement.java,v $
 * $Revision: 1.4 $
 * $Date: 2000/05/08 14:23:04 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.util.html;

/** This class is used for Column/Row head elements in html tables */
public class TableHeaderElement extends WrapElement implements TableCellElement {
    /** Construct a column header with an element
     * @param e the element to put in the cell */
    public TableHeaderElement(Element e) {
	super("th", e);
    }

    /** Construct a column header with a string
     * @param s the string to put in the cell */
    public TableHeaderElement(String s) {
	super("th", new StringElement(s));
    }
}

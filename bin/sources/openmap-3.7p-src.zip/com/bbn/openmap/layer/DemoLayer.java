/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/DemoLayer.java,v $
 * $Revision: 1.7 $
 * $Date: 2000/05/25 22:15:09 $
 * $Author: dietrick $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer;

import com.bbn.openmap.Layer;
import com.bbn.openmap.event.LayerStatusEvent;
import com.bbn.openmap.event.MapMouseListener;
import com.bbn.openmap.layer.location.Location;
import com.bbn.openmap.layer.location.URLRasterLocation;
import com.bbn.openmap.omGraphics.OMBitmap;
import com.bbn.openmap.omGraphics.OMGraphic;
import com.bbn.openmap.omGraphics.OMGraphicList;
import com.bbn.openmap.proj.Projection;

import javax.swing.Box;
import java.awt.Color;
import java.awt.event.MouseEvent;
import java.util.Properties;

/**

 * This layer demonstrates interactive capabilities of OpenMap.
 * Instantiating this layer should show an icon loaded using HTTP
 * Protocol, which represents Boston, MA in USA.  Above Boston it
 * should show a square that would change color when mouse is moved
 * over it in 'Gesture' mode.  Also clicking once brings up a message
 * box and more than once brings up browser.  
 */

public class DemoLayer extends Layer implements MapMouseListener{

    Projection oldProjection;
    OMGraphicList omList = new OMGraphicList();
    OMBitmap omb;

    public void init(){
	Location loc = new URLRasterLocation(42.3583d,-71.06d,"Boston,Massachusetts,USA","http://javamap.bbn.com:4711/appletimages/city.gif");
	//loc.setLocationColor(Color.blue);
	loc.setShowLocation(true);
	loc.setShowName(true);
	//loc.setDetails("Details");
	omList.add(loc);
	int bytearrsize = (16*16)/8;
	byte[] bytearr = new byte[bytearrsize];
	
	for(int i=0;i<bytearr.length;i++){
	    bytearr[i] = (byte)0xffffffff;
	}
	omb = new OMBitmap(45.3583d,-71.06d,16,16,bytearr);
	omb.setLineColor(Color.red);
	omb.setFillColor(null);
	omb.setSelectColor(Color.blue);
	omList.add(omb);
    }

    public void setProperties(String prefix, Properties props) {
	super.setProperties(prefix,props);
	init();
    }
    
    public void paint(java.awt.Graphics g) {    
	omList.render(g);      
    }
    
    /** 
     * Implementing the ProjectionPainter interface.
     */
    public synchronized void renderDataForProjection(Projection proj, java.awt.Graphics g){
	if (proj != null && !proj.equals(oldProjection)){
	    oldProjection = proj.makeClone();
	    omList.generate(proj);
	}
	paint(g);
    }

    /** From the ProjectionListener interface. */
    public void projectionChanged(com.bbn.openmap.event.ProjectionEvent pe) {    
	Projection newProjection = pe.getProjection();
	
	if(!newProjection.equals(oldProjection)){
	    oldProjection = newProjection.makeClone();
	    omList.generate(newProjection);	
	    repaint();
	}    
	
	fireStatusUpdate(LayerStatusEvent.FINISH_WORKING);
    }

    public java.awt.Component getGUI() {
	Box box;
	box = Box.createVerticalBox();
	return box;
    }

    /**
     * Note: A layer interested in receiving amouse events should
     * implement this function .  Otherwise, return the default, which
     * is null.
     */
    public synchronized MapMouseListener getMapMouseListener(){
	return this;
    }

    /**
     * Return a list of the modes that are interesting to the
     * MapMouseListener.  You MUST override this with the modes you're
     * interested in.
     */
    public String[] getMouseModeServiceList(){
	String[] services = {"Gestures"};// what are other possibilities in OpenMap
	return services;
    }
    
    ////////////////////////
    // Mouse Listener events
    ////////////////////////
    
    /**
     * Invoked when a mouse button has been pressed on a component.
     * @param e MouseEvent
     * @return false
     */
    public boolean mousePressed(MouseEvent e){ 
	return false;
    }
    
    /**
     * Invoked when a mouse button has been released on a component.
     * @param e MouseEvent
     * @return false
     */
    public boolean mouseReleased(MouseEvent e){      
	return false;
    }
    
    /**
     * Invoked when the mouse has been clicked on a component.
     * @param e MouseEvent
     * @return false
     */
    public boolean mouseClicked(MouseEvent e){ 
	OMGraphic omgr = omList.findClosest(e.getX(),e.getY(),4);
	if(omgr != null){
	    if(e.getClickCount() >= 2){	         	
		fireRequestURL("http://openmap.bbn.com");
	    } else {
		fireRequestMessage("Clicking more than once would bring up this URL http://openmap.bbn.com");
	    }
	} else {
	    return false;
	}
	
	return true; 	
    }
    
    /**
     * Invoked when the mouse enters a component.
     * @param e MouseEvent
     */
    public void mouseEntered(MouseEvent e){
	return;
    }
    
    /**
     * Invoked when the mouse exits a component.
     * @param e MouseEvent
     */
    public void mouseExited(MouseEvent e){
	return;
    }
    
    ///////////////////////////////
    // Mouse Motion Listener events
    ///////////////////////////////
    
    /**
     * Invoked when a mouse button is pressed on a component and then 
     * dragged.  The listener will receive these events if it
     * @param e MouseEvent
     * @return false
     */
    public boolean mouseDragged(MouseEvent e){      
	return false;
    }

    OMGraphic lastSelected = null;

    /**
     * Invoked when the mouse button has been moved on a component
     * (with no buttons down).
     * @param e MouseEvent
     * @return false
     */
    public boolean mouseMoved(MouseEvent e){  
	
	OMGraphic omgr = omList.findClosest(e.getX(),e.getY(),4.0d);
	
	if(omgr != null) {
	    fireRequestInfoLine("Clicking on icon brings up a message box");	  
	} else {
	    fireRequestInfoLine("");
	    if(lastSelected != null){
		lastSelected.deselect();
		lastSelected.generate(oldProjection);
		lastSelected = null;
		repaint();
		//System.out.println("MouseMove Kicking repaint");
	    }
	}

	if(omgr instanceof OMBitmap){ 
	    omgr.select();	  
	    omgr.generate(oldProjection);
	    lastSelected = omgr;
	    //System.out.println("MouseMove Kicking repaint");
	    repaint();
	}
	
	return true;
    }
    
    /**
     * Handle a mouse cursor moving without the button being pressed.
     * Another layer has consumed the event.
     */
    public void mouseMoved(){
	System.out.println("mouseMoved2 event consumed by other layer  Called");
    }
}










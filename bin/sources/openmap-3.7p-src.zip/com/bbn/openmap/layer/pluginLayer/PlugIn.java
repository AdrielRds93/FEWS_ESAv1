/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/pluginLayer/PlugIn.java,v $
 * $Revision: 1.7 $
 * $Date: 2000/05/08 14:22:45 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.pluginLayer;

import com.bbn.openmap.omGraphics.OMGraphicList;
import com.bbn.openmap.event.MapMouseListener;

    /**  This interface describes the PlugIn module, that is used with
     *  the PlugInLayer. The PlugIn module is the customizable part of
     *  the Layer.  By implementing this interface, you can create a
     *  local layer that will run within OpenMap.
     *  
     * */
public interface PlugIn {

    /** The setLayer command is provided so that the plugin can be
     *  told its parent Layer.  Don't call this.  Hook the PlugIn into
     *  the PlugInLayer by calling setPlugIn on the PlugInLayer.  That
     *  method calls this one.
     * */
    public void setLayer(PlugInLayer layer);

    /** Returns the MapMouseListener that the plugin thinks should be used.
     */
    public MapMouseListener getMapMouseListener();

    /**  The getRectangle call is the main call into the PlugIn
     *  module.  The module is expected to fill the graphics list with
     *  objects that are within the screen parameters passed.  The
     *  Graphics List is NOT automatically cleared with every call to
     *  getRectangle.  YOU have to do that, if you want it to work
     *  that way.
     *  
     *  @param p projection of the screen, holding scale, center coords, height, width.
     *  @param staticArgs string controlled by the PlugIn writer, set usually from the OverlayTable
     *  @param dynamicArgs string controlled by the Layer writer, set at runtime
     * */
  public OMGraphicList getRectangle(com.bbn.openmap.proj.Projection p,
				    java.lang.String staticArgs,
				    java.lang.String dynamicArgs);

    /** 
     *  
     *  
     * */
  public void getGUI();

}

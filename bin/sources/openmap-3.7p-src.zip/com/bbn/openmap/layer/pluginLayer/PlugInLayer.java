/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/pluginLayer/PlugInLayer.java,v $
 * $Revision: 1.38 $
 * $Date: 2000/05/25 22:29:49 $
 * $Author: dietrick $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.pluginLayer;


/*  Java Core  */
import java.awt.Point;
import java.awt.Component;
import java.awt.event.*;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;
import java.util.StringTokenizer;
import java.util.Vector;

/*  OpenMap  */
import com.bbn.openmap.util.Debug;
import com.bbn.openmap.util.SwingWorker;
import com.bbn.openmap.*;
import com.bbn.openmap.event.*;
import com.bbn.openmap.proj.*;
import com.bbn.openmap.omGraphics.OMGraphicList;
import com.bbn.openmap.omGraphics.OMGraphic;

/**
 * The PlugInLayer is a kind of layer that has a direct interface
 * with the MapBean.  The Layer contains a handle to a PlugIn object,
 * which is, in effect, a module that knows how to respond to
 * geographical requests for information, and can create graphics to
 * be drawn.
 * <p>
 * The PlugInLayer has a standard interface to the PlugIn module
 * object, and knows to call certain PlugIn methods to respond to
 * Layer methods.  It also knows about the OMGraphicsList that is
 * part of the PlugIn, and when graphical objects are to be rendered,
 * it tells the plugin's OMGraphicsList to render the object using a
 * Graphics that the Layer provides.  OMGraphics that are created by
 * a plugin are rendered (projected) when they are created.
 */
public class PlugInLayer extends Layer implements ProjectionListener {

    /** Arguments passed in from the OverlayTable. */
    protected String staticArgs = null;
 
    /** Tokens for the debugging. */
    private final static String[] debugTokens = {
	"debug.plugin"
    };

    /** The handle to the PlugIn object. */
    protected transient PlugIn plugin = null;

    /** The MapMouseListener */
    protected MapMouseListener mml;

    /**
     * The OMGraphicList is a common feature of PlugIns.  The layer
     * expects that the graphic list will be filed with relevant
     * graphics on each call to getPlugInGraphics.  The list is
     * basically a Java vector, with some helper functions that take
     * care of rendering and updating, and other functions that
     * require that you iterate through the collection of graphics.
     */
    protected OMGraphicList omGraphics;
    
    /** Selection distance of the objects for gestures. */
    protected short selectDist = 0;

    /** Whether events are wanted by the plugin. */
    protected boolean wantAreaEvents = false;

    /** Projection that gets set on a projection event. */
    Projection projection;

    /** Set when the projection has changed while a swing worker is
     * gathering graphics, and we want him to stop early. */
    protected boolean cancelled = false;

    /** The Projection ID of the last projection passed to the plugin
     * in a prepare call, which is used to determine if the prepare
     * call was the result of a new projection being set in the map
     * panel. 
     * */
    private String oldProjID = null;

    PlugInWorker currentWorker;

    class PlugInWorker extends SwingWorker {
	/** Constructor used to create a worker thread. */
	public PlugInWorker () {
	    super();
	}

	/** 
	 * Compute the value to be returned by the <code>get</code> method. 
	 */
	public Object construct() {
	    Debug.message("plugin", getName()+"|PlugInWorker.construct()");
	    return prepare();
	}

	/**
	 * Called on the event dispatching thread (not on the worker thread)
	 * after the <code>construct</code> method has returned.
	 */
	public void finished() {
	    workerComplete(this);
	}
    }

    /**
     * The default constructor for the Layer.  All of the attributes
     * are set to their default values.
     */
    public PlugInLayer () {
    }

    /**
     * Sets the current graphics list to the given list.
     *
     * @param aList a list of OMGraphics
     */
    public synchronized void setGraphicList (OMGraphicList aList) {
	omGraphics = aList;
    }

    /**
     * Retrieves the current graphics list.
     */
    public synchronized OMGraphicList getGraphicList () {
	return omGraphics;
    }

    /** 
     *  Returns the plugin module of the layer.
     */
    public PlugIn getPlugIn () {
        return plugin;
    }

    /**  Sets the plugin module of the layer.  This method also calls
     *  setLayer on the plugin, and gets the MapMouseListener from the
     *  plugin, too.
     */
    public void setPlugIn (PlugIn aPlugIn) {
	plugin = aPlugIn;
	plugin.setLayer(this);
	mml = plugin.getMapMouseListener();
    }

    /**
     * Returns the MapMouseListener object that handles the mouse
     * events.
     * @return the MapMouseListener for the layer, or null if none
     */
    public synchronized MapMouseListener getMapMouseListener() {
	return mml;
    }
 
    /**
     * Set the MapMouseListener for the layer.
     * @param mml the object that will handle the mouse events for the
     * layer.
    public synchronized void setMapMouseListener(MapMouseListener mml) {
	this.mml = mml;
    }
     */ 

    /**
     * Interface Layer method to get the static args, which are
     * usually set via the OverlayTable. 
     */
    public String getStaticArgs () {
	return staticArgs;
    }

    /**
     * Interface Layer method to set the static args, which are
     * usually set via the OverlayTable. 
     */
    public void setStaticArgs (String args) {
	staticArgs = args;
    }

    
    /** Used to set the cancelled flag in the layer.  The swing worker
     * checks this once in a while to see if the projection has
     * changed since it started working.  If this is set to true, the
     * swing worker quits when it is safe. 
     * */
    public synchronized void setCancelled(boolean set){
	cancelled = set;
    }

    /** Check to see if the cancelled flag has been set. */
    public synchronized boolean isCancelled(){
	return cancelled;
    }

    /** 
     * Implementing the ProjectionPainter interface.
     */
    public synchronized void renderDataForProjection(Projection proj, java.awt.Graphics g){
	if (proj == null){
	    Debug.error("PlugInLayer.renderDataForProjection: null projection!");
	    return;
	} else if (!proj.equals(projection)){
	    projection = proj.makeClone();
	    setGraphicList(prepare());
	}
	paint(g);
    }

    public void projectionChanged (ProjectionEvent e) {
	Debug.message("basic", getName()+"|PlugInLayer.projectionChanged()");

	if (projection != null){
	    if (projection.equals(e.getProjection()))
		// Nothing to do, already have it and have acted on it...
	      {
		repaint();
		return;
	      }
	}
 	setGraphicList(null);
	synchronized (this) {
	    projection = e.getProjection().makeClone();

	    // If there isn't a worker thread working on this already,
	    // create a thread that will do the real work. If there is
	    // a thread working on this, then set the cancelled flag
	    // in the layer.
	    if (currentWorker == null) {
		currentWorker = new PlugInWorker();
		currentWorker.execute();
	    }
	    else setCancelled(true);
	}
    }

    /**  The PlugInWorker calls this method on the layer when it is
     * done working.  If the calling worker is not the same as the
     * "current" worker, then a new worker is created.
     *
     * @param worker the worker that has the graphics.
     * */
    protected synchronized void workerComplete (PlugInWorker worker) {
	if (!isCancelled()) {
	    currentWorker = null;
	    setGraphicList((OMGraphicList)worker.get());
	    repaint();
	}
	else{
	    setCancelled(false);
	    currentWorker = new PlugInWorker();
	    currentWorker.execute();
	}
    }

    /** Prepares the graphics for the layer.  This is where the
     * getRectangle() method call is made on the plugin.  <p>
     * Occasionally it is necessary to abort a prepare call.  When
     * this happens, the map will set the cancel bit in the
     * LayerThread, (the thread that is running the prepare).  If this
     * Layer needs to do any cleanups during the abort, it should do
     * so, but return out of the prepare asap.
     *
     * */
    public OMGraphicList prepare () {
	Debug.message("plugin",getName()+"|PlugInLayer.prepare()");

	if (isCancelled()){
	    Debug.message("plugin", getName()+"|PlugInLayer.prepare(): aborted.");
	    return null;
	}

	if (plugin == null) {
	    System.out.println(getName()+"|PlugInLayer.prepare(): No plugin in layer.");
	    return null;
	}

	Debug.message("basic", getName()+"|PlugInLayer.prepare(): doing it");

	// Setting the OMGraphicsList for this layer.  Remember, the
	// OMGraphicList is made up of OMGraphics, which are generated
	// (projected) when the graphics are added to the list.  So,
	// after this call, the list is ready for painting.

	// call getRectangle();
	if (Debug.debugging("plugin")) {
	    System.out.println(
		      getName()+"|PlugInLayer.prepare(): " +
		      "calling getRectangle " +
		      " with projection: " + projection +
		      " ul = " + projection.getUpperLeft() + " lr = " + 
		      projection.getLowerRight()); 
	}

	OMGraphicList omGraphicList = plugin.getRectangle(projection, 
							  staticArgs, 
							  dynamicArgs);

	/////////////////////
	// safe quit
	int size = 0;
	if (omGraphicList != null){
	    size = omGraphicList.size();	
	    Debug.message("basic", getName()+
			  "|PlugInLayer.prepare(): finished with "+
			  size+" graphics");
	}
	else 
	    Debug.message("basic", getName()+
	      "|PlugInLayer.prepare(): finished with null graphics list");

	// Don't forget to project them....
	omGraphicList.project(projection);
	return omGraphicList;
    }


    /**
     * Paints the layer.
     *
     * @param g the Graphics context for painting
     *
     */
    public void paint (java.awt.Graphics g) {
	Debug.message("plugin", getName()+"|PlugInLayer.paint()");

	OMGraphicList tmpGraphics = getGraphicList();

	if (tmpGraphics != null) {
	    tmpGraphics.render(g);
	}
    }
}

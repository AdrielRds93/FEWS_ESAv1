/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/rpf/corba/CorbaRpfLayer.java,v $
 * $Revision: 1.7 $
 * $Date: 2000/07/27 14:46:55 $
 * $Author: dietrick $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.rpf.corba;

/*  Java Core  */
import java.awt.Point;
import java.awt.Component;
import java.awt.event.*;
import java.util.StringTokenizer;
import java.util.Properties;
import java.io.*;
import java.net.URL;
import javax.swing.*;
import javax.swing.event.*;

/*  OpenMap  */
import com.bbn.openmap.*;
import com.bbn.openmap.event.*;
import com.bbn.openmap.util.Debug;
import com.bbn.openmap.util.SwingWorker;
import com.bbn.openmap.util.PaletteHelper;
import com.bbn.openmap.layer.util.LayerUtils;
import com.bbn.openmap.layer.rpf.*;
import com.bbn.openmap.omGraphics.OMGraphicList;

/**
 * An RpfLayer that uses a CORBA-based RpfFrameProvider.  JDK 1.2 and the <BR>
 * com.sun.image.codec.jpeg package is required, as well as some <BR>
 * CORBA implementation.  Tested with Visibroker 3.3.
 * 
 *<BR>
 *#-----------------------------<BR>
 *# Additional Properties for RpfLayer<BR>
 *#-----------------------------<BR>
 *layer.ior=<URL for ior file>
 *layer.jpegQuality=<quality between 0.4 and 1.0>
 *<BR>
 */
public class CorbaRpfLayer extends RpfLayer {

    /** Property to change the quickRedraw setting.  T/F */
    public static final String QuickRedrawProperty = ".quickRedraw";

    /** Flag to attempt to redraw the images already in the cache
     *  while waiting for new frames.  Works better for slower
     *  servers. Default value is false. */
    protected boolean quickRedraw = false;

    /** The default constructor for the Layer.  All of the attributes
     * are set to their default values. Use this construct if you are
     * going to use a standard properties file, which will set the
     * paths. */
    public CorbaRpfLayer () {
	super();
    }

    /**
     * Set all the RPF properties from a properties object.
     */
    public void setProperties(String prefix, java.util.Properties properties) {
	super.setProperties(prefix, properties);
	setFrameProvider((RpfFrameProvider) new CRFPClient());
	((CRFPClient)frameProvider).setProperties(prefix, properties);

	quickRedraw = LayerUtils.booleanFromProperties(properties, prefix + QuickRedrawProperty, false);
    }

    /**
     * When the layer is deleted, it should sign off from the
     * server, so that it can free up it's cache for it.
     */
    protected void finalize() {
	((CRFPClient)frameProvider).finalize();
    }
    
    /**
     * The projectionListener interface method that lets the Layer
     * know when the projection has changes, and therefore new graphics
     * have to created /supplied for the screen.
     *
     * @param e The projection event, most likely fired from a map
     * bean. 
     */
    public void projectionChanged (ProjectionEvent e) {
	projectionChanged (e, false);
    }

    /**
     * Prepares the graphics for the layer. The only thing this
     * method does that is different than the RpfLayer is that if the
     * current OMGraphicList is not null, then it is reprojected and
     * redrawn.
     *
     * @return OMGraphicList of images and text.
     */
    public OMGraphicList prepare () {
	OMGraphicList oldList = getGraphicList();
	if (oldList != null){
	    oldList.generate(getProjection());
	    if (getCoverage() != null){
		getCoverage().generate(getProjection());
	    }
	    repaint();
	}
	return super.prepare();
    }

    /** Provides the palette widgets to control the options of showing
     * maps, or attribute text.
     * @return Component object representing the palette widgets.
     * */
    public java.awt.Component getGUI() {
	JCheckBox showMapsCheck, showInfoCheck, lockSeriesCheck;

	Box box = Box.createVerticalBox();

	Box box1 = Box.createVerticalBox();
	Box box2 = Box.createVerticalBox();
	JPanel topbox = new JPanel();

	showMapsCheck = new JCheckBox("Show Images", viewAttributes.showMaps);
	showMapsCheck.setActionCommand(showMapsCommand);
	showMapsCheck.addActionListener(this);

	showInfoCheck = new JCheckBox("Show Attributes", viewAttributes.showInfo);
	showInfoCheck.setActionCommand(showInfoCommand);
	showInfoCheck.addActionListener(this);

	boolean locked = viewAttributes.chartSeries.equalsIgnoreCase(RpfViewAttributes.ANY)?false:true;
	String lockedTitle = locked?
	    (lockedButtonTitle + " - " + viewAttributes.chartSeries):
	    unlockedButtonTitle;

	lockSeriesCheck = new JCheckBox(lockedTitle, locked);
	lockSeriesCheck.setActionCommand(lockSeriesCommand);
	lockSeriesCheck.addActionListener(this);

	box1.add(showMapsCheck);
	box1.add(showInfoCheck);
	box1.add(lockSeriesCheck);

	if (coverage != null){
	    JCheckBox showCoverageCheck = new JCheckBox("Show Coverage Tool", 
							false);
	    showCoverageCheck.setActionCommand(showCoverageCommand);
	    showCoverageCheck.addActionListener(this);
	    box1.add(showCoverageCheck);
	}

	topbox.add(box1);
	topbox.add(box2);
	box.add(topbox);

	JPanel opaquePanel = PaletteHelper.createPaletteJPanel("Map Opaqueness");
	JSlider opaqueSlide = new JSlider(JSlider.HORIZONTAL, 0/*min*/, 255/*max*/,
					  viewAttributes.opaqueness/*inital*/);
	java.util.Hashtable dict = new java.util.Hashtable();
	dict.put(new Integer(0), new JLabel("clear"));
	dict.put(new Integer(255), new JLabel("opaque"));
	opaqueSlide.setLabelTable(dict);
	opaqueSlide.setPaintLabels(true);
	opaqueSlide.setMajorTickSpacing(50);
	opaqueSlide.setPaintTicks(true);
	opaqueSlide.addChangeListener(new ChangeListener(){
	    public void stateChanged(ChangeEvent ce){
		JSlider slider = (JSlider) ce.getSource();
		if (!slider.getValueIsAdjusting()){
		    getViewAttributes().opaqueness = slider.getValue();
		    // Notify the server...
		    getFrameProvider().setViewAttributes(getViewAttributes());
		    fireRequestInfoLine("RPF Opaqueness set to " + 
					getViewAttributes().opaqueness + 
					" for future requests.");
		}
	    }
	});
	opaquePanel.add(opaqueSlide);
	box.add(opaquePanel);

	if (getViewAttributes().colorModel == 
	    com.bbn.openmap.omGraphics.OMRasterObject.COLORMODEL_DIRECT){
	    
	    JPanel qualityPanel = PaletteHelper.createPaletteJPanel("Image JPEG Quality/Time");
	    JSlider qualitySlide = new JSlider(
		JSlider.HORIZONTAL, 0/*min*/, 100/*max*/, 
		(int)(((CRFPClient)frameProvider).jpegQuality * 100)/*inital*/);
	    java.util.Hashtable dict2 = new java.util.Hashtable();
	    dict2.put(new Integer(0), new JLabel("Less"));
	    dict2.put(new Integer(100), new JLabel("More"));
	    qualitySlide.setLabelTable(dict2);
	    qualitySlide.setPaintLabels(true);
	    qualitySlide.setMajorTickSpacing(20);
	    qualitySlide.setPaintTicks(true);
	    qualitySlide.addChangeListener(new ChangeListener(){
		public void stateChanged(ChangeEvent ce){
		    JSlider slider = (JSlider) ce.getSource();
		    if (!slider.getValueIsAdjusting()){
			((CRFPClient)getFrameProvider()).jpegQuality = (float)(slider.getValue())/100f;
			fireRequestInfoLine("RPF Image JPEG Quality set to " + ((CRFPClient)getFrameProvider()).jpegQuality + " for future requests.");
		    }
		}
	    });
	    qualityPanel.add(qualitySlide);
	    
	    box.add(qualityPanel);
	}

	JPanel subbox2 = new JPanel();
	JButton redraw = new JButton("Redraw RPF Layer");
	redraw.addActionListener(this);
	subbox2.add(redraw);
	box.add(subbox2);

	return box;
    }
}

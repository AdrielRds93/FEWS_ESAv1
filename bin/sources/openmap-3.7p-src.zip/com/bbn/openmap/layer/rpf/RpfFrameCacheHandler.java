// **********************************************************************
// 
//  BBNT Solutions LLC, A part of GTE
//  10 Moulton St.
//  Cambridge, MA 02138
//  (617) 873-2000
// 
//  Copyright (C) 1997, 2000
//  This software is subject to copyright protection under the laws of 
//  the United States and other countries.
// 
// **********************************************************************
// 
// $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/rpf/RpfFrameCacheHandler.java,v $
// $RCSfile: RpfFrameCacheHandler.java,v $
// $Revision: 1.21 $
// $Date: 2000/08/23 21:23:57 $
// $Author: dietrick $
// 
// **********************************************************************


package com.bbn.openmap.layer.rpf;

import com.bbn.openmap.layer.util.cacheHandler.CacheHandler;
import com.bbn.openmap.layer.util.cacheHandler.CacheObject;
import com.bbn.openmap.omGraphics.OMRaster;
import com.bbn.openmap.omGraphics.OMRasterObject;
import com.bbn.openmap.proj.CADRG;
import com.bbn.openmap.util.Debug;

import java.util.Vector;

/**
 * The RpfFrameCacheHandler does everything involved with handling
 * RAW RPF frames.  If used locally, it can also deal with filling the
 * role of RpfFrameProvider.  You create one of these with the paths
 * to the RPF directories, and then hand it to something that needs a
 * RpfFrameProvider, or that acts like one.
 */
public class RpfFrameCacheHandler extends CacheHandler 
    implements RpfFrameProvider {

    /* Default frame cache size. */
    public final static int FRAME_CACHE_SIZE = 5;
    /** Colortable used on the frames. */
    protected RpfColortable colortable;

    /** For future use... */
    protected boolean Dchum = true;
    /** Special outlining for chummed subframes*/
    protected boolean outlineChum = false; 
    /** The Table of Contents files, parsed and ready to use. */
    protected RpfTocHandler[] tocs;
    /** View and display attributes for the data. */
    protected RpfViewAttributes viewAttributes = new RpfViewAttributes();
    
    /**
     * The default constructor.
     *
     * @param RpfPaths the directory paths to the RPF directories.
     */
    public RpfFrameCacheHandler(String[] RpfPaths){
	this(RpfPaths, FRAME_CACHE_SIZE);
    }
    
    /**
     *  The constructor to use if you want to modify the number of
     * frames held in the cache..
     *
     * @param RpfPaths the directory paths to the RPF directories.
     */
    public RpfFrameCacheHandler(String[] RpfPaths,
				int max_size){
	super(max_size);
	tocs = createTocHandlers(RpfPaths);
	colortable = new RpfColortable();
    }

    /**
     * When you pre-initialize the RpfTocHandlers before giving them
     * to the RpfFrameCacheHandler.
     */
    public RpfFrameCacheHandler(RpfTocHandler[] tocHandlers){
	tocs = tocHandlers;
	colortable = new RpfColortable();
    }
 
    public void finalize(){
	Debug.message("gc", "RpfFrameCacheHandler: getting GC'd");
    }

    /**
     * RpfFrameProvider interface method.  If this is being used as a
     * frame provider, it's local, right? 
     */
    public boolean needViewAttributeUpdates(){
	return false;
    }

    /**
     *  Should only be set via the object it is sending frame data
     *  to. Don't send in a null value, since this is assumed to be
     *  valid in other parts of the code. 
     */
    public void setViewAttributes(RpfViewAttributes va){
	viewAttributes = va;

	if (va != null && colortable != null){
	    colortable.setOpaqueness(va.opaqueness);
	    colortable.setNumColors(va.numberOfColors);
	}
    }

    /** 
     * RpfFrameProvider interface method.  Return all the
     * RpfCoverageBoxes that fall in the area of interest.
     *
     * @param double ullat NW latitude.
     * @param double ullon NW longitude.
     * @param double ullat SE latitude.
     * @param double ullat SE longitude
     * @param float CADRG projection to use for zone decisions.
     * @param RpfProductInfo.seriesCode entry.
     * @return Vector of RpfCoverageBoxes.  
     */
    public Vector getCatalogCoverage(double ullat, double ullon,
				     double lrlat, double lrlon,
				     CADRG proj, String chartSeries){
	int i;
	
	Vector coverages = new Vector();
	for (i = 0; i < tocs.length; i++){
	    
	    // Check the tochandlers for differences, and reload them
	    // if necessary.
	    if (tocs[i].hasChanged()) tocs[i].reload();
	    if (!tocs[i].isValid()) continue;

	    tocs[i].getCatalogCoverage(ullat, ullon, lrlat, lrlon, proj,
				       chartSeries, coverages);
	}

	return coverages;
    }

    /**
     * Given an area and a two-letter chart series code, find the
     * percentage of coverage on the map that that chart series can
     * offer.  If you want specific coverage information, use the
     * getCatalogCoverage call.  Don't send a chart series code of
     * ANY, since that doesn't make sense.
     *
     * @param double ullat NW latitude.
     * @param double ullon NW longitude.
     * @param double ullat SE latitude.
     * @param double ullat SE longitude
     * @param double CADRG projection to use for zone decisions.
     * @param RpfProductInfo.seriesCode entry.
     * @return percentage of map covered by specific chart type.
     * @see #getCatalogCoverage 
     */
    public double getCalculatedCoverage(double ullat, double ullon,
				       double lrlat, double lrlon,
				       CADRG p, String chartSeries){

	if (chartSeries.equalsIgnoreCase(RpfViewAttributes.ANY)){
	    return 0d;
	}

	Vector results = getCatalogCoverage(ullat, ullon, lrlat, lrlon,
					    p, chartSeries);

	int size = results.size();

	if (size == 0){
	    return 0d;
	}

	// Now interpret the results and figure out the real total
	// percentage coverage for the chartSeries.  First need to
	// figure out the current size of the subframes.  Then create
	// a boolean matrix of those subframes that let you figure out
	// how many of them are available.  Calculate the percentage
	// off that.
	int pZone = p.getZone();
	int i, x, y;
	
	double frameLatInterval = Double.MAX_VALUE;
	double frameLonInterval = Double.MAX_VALUE;
	RpfCoverageBox rcb;
	for (i = 0; i < size; i++){
	    rcb = (RpfCoverageBox)results.elementAt(i);
	    if (rcb.subframeLatInterval < frameLatInterval){
		frameLatInterval = rcb.subframeLatInterval;
	    }
	    if (rcb.subframeLonInterval < frameLonInterval){
		frameLonInterval = rcb.subframeLonInterval;
	    }
	}

	if (frameLatInterval == Double.MAX_VALUE || 
	    frameLonInterval == Double.MAX_VALUE){
	    return 0.0d;
	}

	int numHFrames = (int) Math.ceil((lrlon - ullon)/frameLonInterval);
	int numVFrames = (int) Math.ceil((ullat- lrlat)/frameLatInterval);

	boolean[][] coverage = new boolean[numHFrames][numVFrames];
	for (i = 0; i < size; i++){

	    rcb = (RpfCoverageBox)results.elementAt(i);
	    if (rcb.percentCoverage == 100){
		return 1.0d;
	    }

	    for (y = 0; y < numVFrames; y++){
		for (x = 0; x < numHFrames; x++){
		    // degree location of indexs
		    float yFrameLoc = (float)(lrlat + (y*frameLatInterval));
		    float xFrameLoc = (float)(ullon + (x*frameLonInterval));
		    if (coverage[x][y] == false){
			if (rcb.within(yFrameLoc, xFrameLoc)){
			    coverage[x][y] = true;
			}
		    }
		}
	    }
	}
	
	float count = 0;

	for (y = 0; y < numVFrames; y++){
	    for (x = 0; x < numHFrames; x++){
		if (coverage[x][y] == true){
// 		    System.out.print("X");
		    count++;
		} else {
// 		    System.out.print(".");
		}
	    }
// 	    System.out.println("");
	}	
	
	return count/(float)(numHFrames*numVFrames);
    }

    /** 
     * Given a projection which describes the map (or area of
     * interest), return the best RpfTocEntry, from all the A.TOC,
     * that covers the area.  RpfFrameProvider method.
     *
     * @param double ullat NW latitude.
     * @param double ullon NW longitude.
     * @param double ullat SE latitude.
     * @param double ullat SE longitude
     * @param double CADRG projection to use for zone decisions.
     * @return Vector of RpfCoverageBoxes.
     */
    public Vector getCoverage(double ullat, double ullon,
			      double lrlat, double lrlon,
			      CADRG proj){
	int i;
	RpfTocEntry currentEntry;
	RpfCoverageBox rcb;
	Debug.message("rpf", "RpfFrameCacheHandler: getCoverage()");

	Vector coverageBoxes = new Vector();

	for (i = 0; i < tocs.length; i++){
	    
	    // Check the tochandlers for differences, and reload them
	    // if necessary.
	    if (tocs[i].hasChanged()) tocs[i].reload();

	    if (!tocs[i].isValid()) continue;

	    currentEntry = tocs[i].getBestCoverageEntry(ullat, ullon,
							lrlat, lrlon, proj,
							viewAttributes);
	    // This is a test for total coverage.  If we get total
	    // coverage of an exact scale match, just return this
	    // coverage box right away.  If the scale is not a perfect
	    // match, then we will return the box that has complete
	    // coverage with the best scale.  A boundaryHit of 8 means
	    // total coverage.  Trust me.
	    if (currentEntry != null){

		if (Debug.debugging("rpftoc")){
		    System.out.println("RFCH: Toc " + i + " returned an entry");
		}

		RpfCoverageBox currentCoverage = currentEntry.coverage;
		
		if (currentCoverage.percentCoverage >= 100d &&
		    scaleDifference(proj, currentCoverage) == 0){
		    coverageBoxes.removeAllElements();
		    coverageBoxes.addElement(currentCoverage);
		    return coverageBoxes;
		} else {

		    // You know ought to at least make sure that the
		    // scales are the same for all A.TOCs.  That way,
		    // the subframe spacing will be the same.  Put the
		    // best coverage (smallest scale difference) at
		    // the front of the list, and whittle it down from
		    // there.

		    Object[] coverageArray = new Object[coverageBoxes.size()];
		    coverageBoxes.copyInto(coverageArray);
		    coverageBoxes.removeAllElements();
		    int size = coverageArray.length;

		    // Set this here in case the vector is empty...
// 		    float currentScale = currentEntry.info.scale;

		    if (size == 0) coverageBoxes.addElement(currentCoverage);
		    else{

			for (int j = 0; j < size; j++){
			    rcb = (RpfCoverageBox) coverageArray[j];
			    
			    if (j == 0) {
				
				// So first, check to see if the current
				// coverage is a better match than the
				// current best, first considering
				// scale, and then considering coverage.
				if (scaleDifference(proj, currentCoverage) < scaleDifference(proj, rcb) && currentCoverage.percentCoverage > rcb.percentCoverage){
				    
				    coverageBoxes.addElement(currentCoverage);
				}
			    }
			    
			    // Only add the current entry if it matches the scale...
			    if (currentCoverage.scale == rcb.scale){
				// Add it to the vector if the scale is the same.
				coverageBoxes.addElement(rcb);
			    }
			}
		    }
		}
	    } else {
		if (Debug.debugging("rpftoc")){
		    System.out.println("RFCH: Toc " + i + " did NOT return an entry");
		}
	    }
	}

	return coverageBoxes;
    }

    /**
     * Given the indexes to a certain RpfTocEntry within a certain
     * A.TOC, find the frame and return the attribute information.
     * The tocNumber and entryNumber are given within the
     * RpfCoverageBox received from a getCoverage call.
     *
     * @param tocNumber the toc id for a RpfTocHandler for a
     * particular frame provider.
     * @param entryNumber the RpfTocEntry id for a RpfTocHandler for a
     * particular frame provider.
     * @param x the horizontal subframe index, from the left side of a
     * boundary rectangle of the entry.
     * @param y the vertical subframe index, from the top side of a
     * boundary rectangle of the entry.
     * @see #getCoverage
     * @return string.  
     */
    public String getSubframeAttributes(int tocNumber, int entryNumber, int x, int y){

	if (!tocs[tocNumber].isValid()) return null;

	RpfTocEntry entry = tocs[tocNumber].entries[entryNumber];
	
	/* If beyond the image boundary, forget it */
	if (y < 0 || x < 0 || entry == null ||
	    y >= entry.vertFrames * 6 ||
	    x >= entry.horizFrames * 6){

	    return null;
	}
	
	RpfFrameEntry frameEntry = entry.frames[y/6][x/6];
	
	/* Get the right frame from the frame cache */
	RpfFrame frame = (RpfFrame) get(frameEntry);
	
	if(frame == null) return null;
	
	/* This should never fail, since all subframes should be present */
	return frame.getReport(x, y, frameEntry, entry.Cib);
    }

    /**
     * Given the indexes to a certain RpfTocEntry within a certain
     * A.TOC, find the frame/subframe data, decompress it, and return
     * image pixels.  The tocNumber and entryNumber are given within
     * the RpfCoverageBox received from a getCoverage call.
     *
     * @param tocNumber the toc id for a RpfTocHandler for a
     * particular frame provider.
     * @param entryNumber the RpfTocEntry id for a RpfTocHandler for a
     * particular frame provider.
     * @param x the horizontal subframe index, from the left side of a
     * boundary rectangle of the entry.
     * @param y the vertical subframe index, from the top side of a
     * boundary rectangle of the entry.
     * @see #getCoverage
     * @return integer pixel data.  
     */
    public int[] getSubframeData(int tocNumber, int entryNumber, int x, int y){

	if (!tocs[tocNumber].isValid()) return null;

	RpfTocEntry entry = tocs[tocNumber].entries[entryNumber];
	
	/* If beyond the image boundary, forget it */
	if (y < 0 || x < 0 || entry == null ||
	    y >= entry.vertFrames * 6 ||
	    x >= entry.horizFrames * 6){

	    return null;
	}
	
	RpfFrameEntry frameEntry = entry.frames[y/6][x/6];
	
	/* Get the right frame from the frame cache */
	RpfFrame frame = (RpfFrame) get(frameEntry);

	if(frame == null) return null;
	
	checkColortable(frame, frameEntry, entry, tocNumber, entryNumber);

	/* This should never fail, since all subframes should be present */
	return decompressSubframe(frame, x, y, colortable);
    }


    public RpfIndexedImageData getRawSubframeData(int tocNumber, int entryNumber,
						  int x, int y) {
	if (!tocs[tocNumber].isValid()) return null;
	
	RpfTocEntry entry = tocs[tocNumber].entries[entryNumber];
	
	/* If beyond the image boundary, forget it */
	if (y < 0 || x < 0 || entry == null ||
	    y >= entry.vertFrames * 6 ||
	    x >= entry.horizFrames * 6){

	    return null;
	}
	
	RpfFrameEntry frameEntry = entry.frames[y/6][x/6];
	
	/* Get the right frame from the frame cache */
	RpfFrame frame = (RpfFrame) get(frameEntry);

	if(frame == null) return null;
	
	checkColortable(frame, frameEntry, entry, tocNumber, entryNumber);

	RpfIndexedImageData riid = new RpfIndexedImageData();
	riid.imageData =  decompressSubframe(frame, x, y);
	riid.colortable = colortable.colors;
	return riid;
    }

    /** 
     * Take a bunch of stuff that has already been calculated, and
     * then figure out if a new colortable is needed.  If it is, load
     * it up with info. Called from two different places, which is why
     * it exists.
     *
     * It's been determined that, for each subframe, the colortable
     * from it's parent frame should be used.  Although RPF was
     * designed and specified that the colortable should be constant
     * across zones, that's not always the case.
     */
    protected void checkColortable(RpfFrame frame, RpfFrameEntry frameEntry,
				   RpfTocEntry entry, int tocNumber, int entryNumber){
	// Colortables are constant across chart types and zones.  If
	// the current chart type and zone don't match the colortable,
	// read the proper one from the frame.  All the frames inside
	// an entry, which is a boundary box, will certainly share a
	// colortable.
//  	if (colortable.colors == null || 
//  	    !colortable.isSameATOCIndexes(tocNumber, entryNumber)){

	// You know, we don't need to make the check - we should just
	// do this every time - the colortable is already created for
	// the frame, so we might as well use what we know to be good
	// for each subframe.

	if (true){

	    if (Debug.debugging("rpf")){
		System.out.println("RpfFrameCacheHandler: getting new colors");
	    }
	    colortable.setCib(entry.Cib);
	    colortable.setATOCIndexes(tocNumber, entryNumber);

	    colortable = frame.getColortable();
	    colortable.zone = entry.zone;
	    colortable.seriesCode = entry.info.seriesCode;
	}

	if (viewAttributes != null){
	    colortable.setNumColors(viewAttributes.numberOfColors);
	    colortable.setOpaqueness(viewAttributes.opaqueness);
	}
    }

    /**
     * Decompress a subframe into a cache entry OMRaster.
     *
     * @param frame the frame to get the subframe from
     * @param x the x coord for the subframe
     * @param y the y coord for the subframe
     * @param subframe the subframe to create the image for
     * @param colortable the colortable to use with this image
     * @param viewAttributes our image generation parameters
     */
    protected boolean decompressSubframe(RpfFrame frame, int x, int y,
					 RpfSubframe subframe,
					 RpfColortable colortable,
					 RpfViewAttributes viewAttributes){
	boolean isDirectColorModel = 
	    (viewAttributes.colorModel == OMRasterObject.COLORMODEL_DIRECT);

	if (!isDirectColorModel) {
	    System.out.println("decompress to byte[]");
	    byte[] pixels = decompressSubframe(frame, x, y);
	    OMRaster image = subframe.image;
	    image.setBits(pixels);
	    image.setColors(colortable.colors);
	    return true;
	} else {
	    int[] pixels = decompressSubframe(frame, x, y, colortable);
	    OMRaster image = subframe.image;
	    image.setPixels(pixels);
	    return true;
	}
    }

    /**
     * Decompress a subframe into an array of bytes suitable for in
     * indexed color model image.
     *
     * @param frame the frame to get the subframe from
     * @param x the x coord for the subframe
     * @param y the y coord for the subframe
     */
    public byte[] decompressSubframe(RpfFrame frame, int x, int y) {
	// Convert x,y to the subframe index in the frame - they come in as
	// cache subframe indexes
	x = x % 6;
	y = y % 6;

	// used to keep track of location into compressedSubframe array.
	int readptr = 0;

	// and the compressedSubframe array
	byte[] compressedSubframe = frame.compressedSubframe[y][x];
	
	/* This should never occur since all subframes should be present */
	/* But if it does occur, just put up black pixels on the screen  */
	if ((compressedSubframe == null) || frame.masked[y][x]) {
	    return null;
	} else { // Normal pixel */
	    byte [] pixels = new byte[256*256];
	    for (int i = 0; i < 256; i += 4) {
		for (int j = 0; j < 256; j += 8)
		{
		    int firstByte = compressedSubframe[readptr++] & 0xff;
		    int secondByte = compressedSubframe[readptr++] & 0xff;
		    int thirdByte = compressedSubframe[readptr++] & 0xff;

		    //because dealing with half-bytes is hard, we
		    //uncompress two 4x4 tiles at the same time. (a
		    //4x4 tile compressed is 12 bits )

		    /* Get first 12-bit value as index into VQ table */
		    int val1 = (firstByte << 4) | (secondByte >> 4);
		    /* Get second 12-bit value as index into VQ table*/
		    int val2 = ((secondByte & 0x000F) << 8) | thirdByte;
		    for (int t = 0; t < 4; t++) {
			for (int e = 0; e < 4; e++){
			    int tableVal1 = frame.table[t][val1][e] & 0xff;
			    int tableVal2 = frame.table[t][val2][e] & 0xff;
			    if (tableVal1 >= RpfColortable.CADRG_COLORS) {
				tableVal1 = RpfColortable.CADRG_COLORS-1;
			    }
			    if (tableVal2 >= RpfColortable.CADRG_COLORS) {
				tableVal2 = RpfColortable.CADRG_COLORS-1;
			    }
			    int pixindex = (i+t)*256 + j + e;
			    pixels[pixindex] = (byte)tableVal1;
			    pixels[pixindex+4] = (byte)tableVal2;
			} //for e
		    } //for t
		}  /* for j */
	    } //for i
	    return pixels;
	}   /* else */
    }

    /**
     * Decompress a subframe into an array of ints suitable for a
     * direct color model image. (argb format)
     *
     * @param frame the frame to get the subframe from
     * @param x the x coord for the subframe
     * @param y the y coord for the subframe
     * @param colortable the colortable to use with this image
     */
    public int[] decompressSubframe(RpfFrame frame, int x, int y,
				    RpfColortable colortable) {
	// Convert x,y to the subframe index in the frame - they come in as
	// cache subframe indexes
	x = x % 6;
	y = y % 6;

	// used to keep track of location into compressedSubframe array.
	int readptr = 0;

	// and the compressedSubframe array
	byte[] compressedSubframe = frame.compressedSubframe[y][x];
	
	/* This should never occur since all subframes should be present */
	/* But if it does occur, just put up black pixels on the screen  */
	if ((compressedSubframe == null) || frame.masked[y][x]) {
	    return null;
	} else { // Normal pixel */
	    int [] pixels = new int[256*256];
	    for (int i = 0; i < 256; i += 4) {
		for (int j = 0; j < 256; j += 8)
		{
		    int firstByte = compressedSubframe[readptr++] & 0xff;
		    int secondByte = compressedSubframe[readptr++] & 0xff;
		    int thirdByte = compressedSubframe[readptr++] & 0xff;

		    //because dealing with half-bytes is hard, we
		    //uncompress two 4x4 tiles at the same time. (a
		    //4x4 tile compressed is 12 bits )

		    /* Get first 12-bit value as index into VQ table */
		    int val1 = (firstByte << 4) | (secondByte >> 4);
		    /* Get second 12-bit value as index into VQ table*/
		    int val2 = ((secondByte & 0x000F) << 8) | thirdByte;
		    for (int t = 0; t < 4; t++) {
			for (int e = 0; e < 4; e++){
			    int tableVal1 = frame.table[t][val1][e] & 0xff;
			    int tableVal2 = frame.table[t][val2][e] & 0xff;
			    if (tableVal1 >= RpfColortable.CADRG_COLORS) {
				tableVal1 = RpfColortable.CADRG_COLORS-1;
			    }
			    if (tableVal2 >= RpfColortable.CADRG_COLORS) {
				tableVal2 = RpfColortable.CADRG_COLORS-1;
			    }
			    int pixindex = (i+t)*256 + j + e;
			    pixels[pixindex] = colortable.colors[tableVal1].getRGB();
			    pixels[pixindex+4] = colortable.colors[tableVal2].getRGB();
			} //for e
		    } //for t
		}  /* for j */
	    } //for i
	    return pixels;
	}   /* else */
    }

    /**
     * Set up the A.TOC files, to find out what coverage there is. 
     * @param RpfPaths the paths to the RPF directories.
     * @return the RpfTocHandlers for the A.TOCs.
     */
    public static RpfTocHandler[] createTocHandlers(String[] RpfPaths){
	
	RpfTocHandler[] tocs = new RpfTocHandler[(RpfPaths != null?RpfPaths.length:0)];
	for (int i = 0; i < tocs.length; i++){
	    tocs[i] = new RpfTocHandler(RpfPaths[i], i);
	}
	return tocs;
    }
    
    /** Cachehandler method. */
    public CacheObject load(String RpfFramePath){

	RpfFrame frame = new RpfFrame(RpfFramePath);
	if (frame.isValid()){
	    CacheObject obj = new CacheObject(RpfFramePath, frame);
	    return obj;
	}
	return null;
    }

    /**
     * A customized way to retrieve a frame from the cache, using a
     * RpfFrameEntry.  A RpfFrameEntry is the way to get the Dchum
     * capability kicked off in the frame.  If you don't care about
     * Dchum, use the other get method.  CacheHandler method.
     */
    public Object get(RpfFrameEntry rfe){

	CacheObject ret = searchCache(rfe.framePath);
	if(ret != null) return ret.obj;
	
	ret = load(rfe);
	if (ret == null) return null;

	if (Debug.debugging("rpfdetail")){
	    System.out.println(rfe);
	}

	replaceLeastUsed(ret);
	return ret.obj;
    }

    /** Cachehandler method. */
    public CacheObject load(RpfFrameEntry rfe){

	if (!rfe.exists) return null;

	if (Debug.debugging("rpf")){
	    System.out.println("RpfFrameCacheHandler: Loading Frame " + 
			       rfe.framePath);
	}

	RpfFrame frame = new RpfFrame(rfe);
	if (frame.isValid()){
	    CacheObject obj = new CacheObject(rfe.framePath, frame);
	    return obj;
	} else {
	    Debug.error("RpfFrameCacheHandler:  Couldn't find frame /" +
			rfe.framePath + "/ (" + rfe.framePath.length() + " chars)");
	}
	return null;
    }

    /** 
     * Cachehandler method. 
     */
    public void resizeCache(int max_size){
	resetCache(max_size);
    }
  
    /**
     * CacheHandler method.  Need to clear memory, get gc moving, and
     * ready for new objects 
     */
    public void resetCache(){
	super.resetCache();
	Debug.message("rpf", "RpfFrameCacheHandler: reset frame cache.");
    }

    public static float scaleDifference(CADRG proj, RpfCoverageBox box){
	return (float)(Math.abs(proj.getScale() - box.scale));
    }

    public RpfColortable getColortable(){
	return colortable;
    }
}


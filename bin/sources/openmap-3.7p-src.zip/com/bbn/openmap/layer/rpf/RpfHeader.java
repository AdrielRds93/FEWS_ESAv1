/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 *
 * The meat of this code is based on source code provided by
 * The MITRE Corporation, through the browse application source
 * code.  Many thanks to Nancy Markuson who provided BBN with the
 * software, and to Theron Tock, who wrote the software, and
 * Daniel Scholten, who revised it - (c) 1994 The MITRE
 * Corporation for those parts, and used with permission.
 *
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/rpf/RpfHeader.java,v $
 * $Revision: 1.10 $
 * $Date: 2000/08/21 22:40:57 $
 * $Author: dietrick $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.rpf;

import java.io.File;
import java.io.IOException;
import java.io.FileNotFoundException;

import com.bbn.openmap.util.Debug;
import com.bbn.openmap.util.BinaryBufferedFile;
import com.bbn.openmap.util.FormatException;

/** Reads the part of the RpfFrame that gives a basic location map to
 * the locations of the file.
 * */
public class RpfHeader {
    
    public static final int RPF_DATE_LOCATION = 31;
    public static final int HEADER_SECTION_LENGTH = 48;
    public static final int TOC_NITF_HEADER_LENGTH = 410;
    public static final int FRAME_SHORT_NITF_HEADER_LENGTH = 413;
    public static final int FRAME_LONG_NITF_HEADER_LENGTH = 426;
    

    public boolean endian = false;
    public short headerSectionLength;
    public String filename; // 12 chars
    public byte neww; // new/replacement/update indicator
    public String standardNumber; // 15 chars
    public String standardDate; // 8 chars
    public char classification; // 1 char
    public String country; // 2 chars
    public String release; // 2 chars
    public int locationSectionLocation;
    

    public RpfHeader(){}

    /** Starts at the beginning of the file and handles the NITF
     * header if it is there.  
     * */
    public boolean read(BinaryBufferedFile binFile){

	try{
	    int headerOffset = handleNITFHeader(binFile);

	    if (headerOffset < 0) return false;
	    else binFile.seek(headerOffset);

	    return readHeader(binFile);
	} catch (IOException e){
	    Debug.error("RpfHeader: File IO Error while reading header information:\n" + e);
	    return false;
	}
    }

    /** Assumes that the binFile is set to the header location. */
    public boolean readHeader(BinaryBufferedFile binFile){

	try{ 
	    //  Read header 
	    byte[] endianByte = binFile.readBytes(1, false);
	    if (endianByte[0] > 0) endian = true;
	    
	    binFile.byteOrder(!endian); // opposite meanings

	    headerSectionLength = binFile.readShort();
	    
	    byte[] filenameArray = binFile.readBytes(12, false);
	    filename = new String(filenameArray);
	    
	    // Read rest of header so we can write it later 
	    byte[] newwByte = binFile.readBytes(1, false);
	    neww = newwByte[0];

	    byte[] standardNumberArray = binFile.readBytes(15, false);
	    standardNumber = new String(standardNumberArray);
	    
	    byte[] standardDateArray = binFile.readBytes(8, false);
	    standardDate = new String(standardDateArray);
	    
	    classification = binFile.readChar();

	    byte[] countryArray = binFile.readBytes(2, false);
	    country = new String(countryArray);
	    
	    byte[] releaseArray = binFile.readBytes(2, false);
	    release = new String(releaseArray);
	    
	    locationSectionLocation = binFile.readInteger();

	    if (Debug.debugging("rpfheader")){
		Debug.output(this.toString());
	    }
	    
	} catch (IOException e){
	    Debug.error("RpfHeader: File IO Error while reading header information:\n" + e);
	    return false;
	} catch (FormatException f){
	    Debug.error("RpfHeader: File IO Format error while reading header information:\n" + f);
	    return false;
	}

	return true;	
    }

    public String toString(){
	StringBuffer s = new StringBuffer();
	s.append("RpfHeader: endian is " + endian + "\n");
	s.append("RpfHeader: header section length = " + headerSectionLength + "\n");
	s.append("RpfHeader: filename = " + filename + "\n");
	s.append("RpfHeader: neww = " + neww + "\n");
	s.append("RpfHeader: standard number = " + standardNumber + "\n");
	s.append("RpfHeader: standard date = " + standardDate + "\n");
	s.append("RpfHeader: classification = " + classification + "\n");
	s.append("RpfHeader: country = " + country + "\n");
	s.append("RpfHeader: release = " + release + "\n");
	s.append("RpfHeader: location section location = " + locationSectionLocation + "\n");
	return s.toString();
    }


    /** Checks to see if the file is in NITF or not, and then puts the
     * file pointer in the right place to start reading the header for
     * the file.  If the file is in NITF format, it skips the NITF
     * header, and if it isn't, it resets the pointer to the
     * beginning. 
     * */
    public int handleNITFHeader(BinaryBufferedFile binFile){
	try{

	    byte[] nitfArray = binFile.readBytes(4, false);
	    String nitf = new String(nitfArray);

	    binFile.seek(RPF_DATE_LOCATION);
	    nitfArray = binFile.readBytes(2, false);
	    nitf = new String(nitfArray);
	    
	    if (nitf.equalsIgnoreCase("19") || nitf.equalsIgnoreCase("20"))
		return 0;
	    
	    binFile.seek(RPF_DATE_LOCATION+TOC_NITF_HEADER_LENGTH);
	    nitfArray = binFile.readBytes(2, false);
	    nitf = new String(nitfArray);
	    
	    if (nitf.equalsIgnoreCase("19") || nitf.equalsIgnoreCase("20"))
		return TOC_NITF_HEADER_LENGTH;
	    
	    binFile.seek(RPF_DATE_LOCATION+FRAME_SHORT_NITF_HEADER_LENGTH);
	    nitfArray = binFile.readBytes(2, false);
	    nitf = new String(nitfArray);
	    
	    if (nitf.equalsIgnoreCase("19") || nitf.equalsIgnoreCase("20"))
		return FRAME_SHORT_NITF_HEADER_LENGTH;
	    
	    binFile.seek(RPF_DATE_LOCATION+FRAME_LONG_NITF_HEADER_LENGTH);
	    nitfArray = binFile.readBytes(2, false);
	    nitf = new String(nitfArray);
	    
	    if (nitf.equalsIgnoreCase("19") || nitf.equalsIgnoreCase("20"))
		return FRAME_LONG_NITF_HEADER_LENGTH;

	} catch (IOException e){
	    Debug.error("RpfHeader: File IO Error while handling NITF header:\n" + e);
	    return -1;
	} catch (FormatException f){
	    Debug.error("RpfHeader: File IO Format error while reading header information:\n" + f);
	    return -1;
	}
	
	return -1;
    }

    public static void main(String[] args){
	if (args.length != 1){
	    System.out.println("Usage: java RpfHeader <path to A.TOC or RPF frame file>");
	    return;
	}

	File file = new File(args[0]);
	BinaryBufferedFile binFile = null;
	try {
	    binFile = new BinaryBufferedFile(file);
	} catch (FileNotFoundException e) {
	    System.err.println("RpfHeader: file "+args[0]+" not found");
	    System.exit(1);
	} catch (IOException ioe){
	    System.err.println("RpfHeader: File IO Error while handling NITF header:");
	    System.err.println(ioe);
	} 

	RpfHeader header = new RpfHeader();
	if (header.read(binFile)) 
	    System.out.println(header);
	else System.out.println("RpfHeader: NOT read sucessfully!");
    
    }
}

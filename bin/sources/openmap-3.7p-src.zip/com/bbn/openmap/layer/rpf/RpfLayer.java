/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/rpf/RpfLayer.java,v $
 * $Revision: 1.45 $
 * $Date: 2000/08/23 21:23:57 $
 * $Author: dietrick $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.rpf;


/*  Java Core  */
import java.awt.Component;
import java.awt.Point;
import java.awt.event.*;
import java.io.*;
import java.net.URL;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.Vector;
import javax.swing.*;
import javax.swing.event.*;

/*  OpenMap  */
import com.bbn.openmap.*;
import com.bbn.openmap.event.*;
import com.bbn.openmap.layer.util.LayerUtils;
import com.bbn.openmap.layer.util.cacheHandler.CacheHandler;
import com.bbn.openmap.omGraphics.OMGraphicList;
import com.bbn.openmap.omGraphics.OMRasterObject;
import com.bbn.openmap.proj.*;
import com.bbn.openmap.util.Debug;
import com.bbn.openmap.util.PaletteHelper;
import com.bbn.openmap.util.SwingWorker;

/**
 * The RpfLayer fills the screen with RPF data.  There is also a tool
 * available that allows you to see the coverage of the available
 * data.  To view theimages, the projection of the map has to be set
 * in the ARC projection, which OpenMap calls the CADRG projection.
 * The RpfLayer can use several RPF directories at the same time, and
 * doesn't require that the data actually be there at runtime.  That
 * way, you can give a location where the data may be mouted during
 * runtime(i.e. CDROM) and the layer will still use the data. The
 * scale of the projection does not necessarily have to match the
 * scale of a map series for that series to be displayed.  There are
 * options, set in the RpfViewAttributes, that allow scaling of the
 * RPF images to match the map scale.<P>
 * 
 * The RpfLayer uses the RpfCacheManager to get the images it needs to
 * display.  Whenever the projection changes, the cache manager takes
 * the new projection and creates a OMGraphicList with the new image
 * frames and attribute text. <P>
 *
 * The RpfLayer gets its intial settings from properties. This should be
 * done right after the RpfLayer is created. The properties list contains
 * the location of the RPF directories, the opaqueness of the images,
 * the number of colors to use, and whether to show the images and/or
 * attributes by default.  An example of the RpfLayer properties: <P>
 * 
 *<BR>
 *#-----------------------------<BR>
 *# Properties for RpfLayer<BR>
 *#-----------------------------<BR>
 *# Mandatory properties<BR>
 *# This property should reflect the paths to the RPF directories<BR>
 *rpf.paths=/usr/local/matt/data/RPF /usr/local/matt/data/CIB/RPF<BR>
 *<BR>
 *# Optional Properties - the default will be set if these are not
 *# included in the properties file:
 *# Number between 0-255: 0 is transparent, 255 is opaque.  255 is default.<BR>
 *rpf.opaque=128<BR>
 *<BR>
 *# Number of colors to use on the maps - 16, 32, 216.  216 is default.<BR>
 *rpf.numberColors=216<BR>
 *<BR>
 *# Display maps on startup.  Default is true.<BR>
 *rpf.showMaps=true<BR>
 *<BR>
 *# Display attribute information on startup.  Default is false.<BR>
 *rpf.showInfo=false<BR>
 *<BR>
 *# Scale charts to match display scale.  Default is true.<BR>
 *rpf.scaleImages=true<BR>
 *<BR>
 *# The scale factor to allow when scaling images (2x, 4x, also mean 1/2, 1/4).  Default is 4.<BR>
 *rpf.imageScaleFactor=4<BR>
 *<BR>
 *# Delete the cache if the layer is removed from the map.  Default is false.<BR>
 *rpf.killCache=true<BR>
 *# Limit the display to the chart code specified. (GN, JN, ON, TP, etc.).<BR>
 *# Default is ANY<BR>
 *rpf.chartSeries=ANY<BR>
 *# Get the subframe attribute data from the Frame provider.<BR>
 *rpf.autofetchAttributes=false<BR>
 *# Set to true if you want the coverage tool available.<BR>
 *rpf.coverage=true<BR>
 *# Set the subframe cache size. (Number of subframes to hold on to, 256x256 pixels)<BR>
 *rpf.subframeCacheSize=128<BR>
 *# Then also include coverage properties, which are available in the RpfConstants.<BR>
 *#------------------------------------<BR>
 *# End of properties for RpfLayer<BR>
 *#------------------------------------<BR>
 *<BR>
 *
 */
public class RpfLayer extends Layer 
    implements ProjectionListener, ActionListener, RpfConstants, Serializable {
    
    /** The main source for the images and attribute information.  All
     * requests for graphic objects should go through this cache, and it
     * will automatically handle getting the frame files, decoding them,
     * and returning an object list.
     * */
    protected transient RpfCacheManager cache = null;
    /** The graphic list of objects to draw. */
    protected OMGraphicList omGraphics;
    /** Projection that gets set on a projection event. */
    protected Projection projection;
    /** Set when the projection has changed while a swing worker is
     * gathering graphics, and we want him to stop early. */
    protected boolean cancelled = false;
    /** The paths to the RPF directories, telling where the data is. * */
    protected String[] paths;
    /** The display attributes for the maps.  This object should not
     * be replaced, because the caches all look at it, too.  Just
     * adjust the parameters within it. 
     * @see RpfViewAttributes */
    protected RpfViewAttributes viewAttributes;
    /** Flag to delete the cache if the layer is removed from the map. */
    protected boolean killCache = true;
    /** The supplier of frame data. */
    protected RpfFrameProvider frameProvider;
    /** The coverage tool for the layer. */
    protected RpfCoverage coverage;
    /** Subframe cache size. Default is 40.*/
    protected int subframeCacheSize;
    /** Auxillary subframe cache size. Default is 10.*/
    protected int auxSubframeCacheSize;

    /**
     * The swing worker that goes off in it's own thread to get
     * graphics.
     */
    RpfWorker currentWorker;

    /**
     * Since we can't have the main thread taking up the time to
     * create images, we use this worker thread to do it.
     */
    class RpfWorker extends SwingWorker {
	/** Constructor used to create a worker thread. */
	public RpfWorker () {
	    super();
	}

	/**
	 * Compute the value to be returned by the <code>get</code>
	 * method. 
	 */
	public Object construct() {
	    Debug.message("rpf", getName()+"|RpfWorker.construct()");
	    fireStatusUpdate(LayerStatusEvent.START_WORKING);
	    try {
		return prepare();
	    } catch (OutOfMemoryError e) {
		String msg = getName() + 
		    "|RpfLayer.RpfWorker.construct(): " + e;
		System.err.println(msg);
		e.printStackTrace();
		fireRequestMessage(new InfoDisplayEvent(this, msg));
		fireStatusUpdate(LayerStatusEvent.FINISH_WORKING);
		return null;
	    }
	}

	/**
	 * Called on the event dispatching thread (not on the worker
	 * thread) after the <code>construct</code> method has
	 * returned. 
	 */
	public void finished() {
	    workerComplete(this);
	    fireStatusUpdate(LayerStatusEvent.FINISH_WORKING);
	}
    }

    /**
     * The default constructor for the Layer.  All of the attributes
     * are set to their default values. Use this construct if you are
     * going to use a standard properties file, which will set the
     * paths. 
     */
    public RpfLayer () {
	viewAttributes = new RpfViewAttributes();
    }

    /** 
     * The default constructor for the Layer.  All of the attributes
     * are set to their default values.
     *
     * @param pathsToRPFDirs paths to the RPF directories that hold
     * A.TOC files.  
     */
    public RpfLayer (String[] pathsToRPFDirs) {
	setPaths(pathsToRPFDirs);
	viewAttributes = new RpfViewAttributes();
    }

    /**
     * Set the paths to the RPF directories, which are by default the
     * parents of the A.TOC table of contents files.
     *
     * @param pathsToRPFDirs Array of strings that list the paths to
     * RPF directories.  
     */
    public void setPaths(String[] pathsToRPFDirs){
	if (pathsToRPFDirs != null){
	    frameProvider = new RpfFrameCacheHandler(pathsToRPFDirs);
	} else {
	    Debug.output("RpfLayer: Need RPF directory paths.");
	    frameProvider = null;
	}
	paths = pathsToRPFDirs;
	this.cache = null;
    }

   /** 
     *  Called when the layer is no longer part of the map.  In this
     *  case, we should disconnect from the server if we have a
     *  link. 
     */
    public void removed(java.awt.Container cont){
	if (killCache){
	    Debug.message("rpf", "RpfLayer: emptying cache!");
	    clearCache();
	}
    }

    protected void setDefaultValues(){
	// defaults
	paths = null;
    }

    /**
     * Set all the RPF properties from a properties object.
     */
    public void setProperties(String prefix, java.util.Properties properties) {

	super.setProperties(prefix, properties);

	paths = LayerUtils.initPathsFromProperties(properties, 
						   prefix + RpfPathsProperty);

	String numColorsString = properties.getProperty(prefix + 
							NumColorsProperty);

	viewAttributes.opaqueness = LayerUtils.intFromProperties(properties, prefix + OpaquenessProperty, viewAttributes.opaqueness);
	
	viewAttributes.numberOfColors = LayerUtils.intFromProperties(properties, prefix + NumColorsProperty, viewAttributes.numberOfColors);

	viewAttributes.showMaps = LayerUtils.booleanFromProperties(properties, prefix + ShowMapsProperty, viewAttributes.showMaps);

	viewAttributes.showInfo = LayerUtils.booleanFromProperties(properties, prefix + ShowInfoProperty, viewAttributes.showInfo);

	viewAttributes.scaleImages = LayerUtils.booleanFromProperties(properties, prefix + ScaleImagesProperty, viewAttributes.scaleImages);

	viewAttributes.chartSeries = properties.getProperty(prefix + ChartSeriesProperty);

	viewAttributes.autofetchAttributes = LayerUtils.booleanFromProperties(properties, prefix + AutoFetchAttributeProperty, viewAttributes.autofetchAttributes);

	viewAttributes.imageScaleFactor =  LayerUtils.floatFromProperties(properties, prefix + ImageScaleFactorProperty, viewAttributes.imageScaleFactor);

	subframeCacheSize = LayerUtils.intFromProperties(properties, prefix + CacheSizeProperty, RpfCacheHandler.SUBFRAME_CACHE_SIZE);

	auxSubframeCacheSize = LayerUtils.intFromProperties(properties, prefix + CacheSizeProperty, RpfCacheManager.SMALL_CACHE_SIZE);

	if (viewAttributes.chartSeries == null) 
	    viewAttributes.chartSeries = RpfViewAttributes.ANY;

	killCache = LayerUtils.booleanFromProperties(properties, prefix + KillCacheProperty, true);

	if(LayerUtils.booleanFromProperties(properties, 
					    prefix + CoverageProperty, false)){
	    setCoverage(new RpfCoverage(this));
	    coverage.setProperties(prefix, properties);
	}
	
	String colormodel = properties.getProperty(prefix + ColormodelProperty);
	if (colormodel != null && colormodel.equalsIgnoreCase("indexed")){
	    viewAttributes.colorModel = OMRasterObject.COLORMODEL_INDEXED;
	} else {
	    viewAttributes.colorModel = OMRasterObject.COLORMODEL_DIRECT;
	}
    }

    /**
     * Sets the current graphics list to the given list.
     *
     * @param aList a list of OMGraphics.
     */
    public synchronized void setGraphicList (OMGraphicList aList) {
	omGraphics = aList;
    }

    /** Retrieves the current graphics list.  */
    public synchronized OMGraphicList getGraphicList () {
	return omGraphics;
    }

    /**  
     * Retrives the current projection.  Do not use this to modify
     * the projection - results will be unpredicable with relation to
     * the MapBean.
     */
    public Projection getProjection(){
	return projection;
    }

    /**
     * Used to set the cancelled flag in the layer.  The swing worker
     * checks this once in a while to see if the projection has
     * changed since it started working.  If this is set to true, the
     * swing worker quits when it is safe. 
     */
    public synchronized void setCancelled(boolean set){
	cancelled = set;
    }

    /** Check to see if the cancelled flag has been set. */
    public synchronized boolean isCancelled(){
	return cancelled;
    }

    /**
     * Clear the frame cache.
     */
    public void clearCache(){

	if (frameProvider instanceof CacheHandler){
	    ((CacheHandler)frameProvider).resetCache();
	}

	this.cache.setViewAttributes(null);
	this.cache.setFrameProvider(null);
	frameProvider = null;

	if (this.cache != null){
	    this.cache.clearCaches();
	}
	setGraphicList(null);
	this.cache = null;
    }

    /**
     * Set the view attributes for the layer.  The frame provider view
     * attributes are updated, and the cache is cleared.
     * @param rva the RpfViewAttributes used for the layer.  
     */
    public void setViewAttributes(RpfViewAttributes rva){
	viewAttributes = rva;
	if (this.cache != null){
	    this.cache.setViewAttributes(rva);
	}
    }

    /** 
     * Get the view attributes or the layer.
     * @return RpfViewAttributes.
     */
    public RpfViewAttributes getViewAttributes(){
	return viewAttributes;
    }

    /**
     * Set the RpfCoverage tool used by the layer.  If the view
     * attributes chart series setting is not equal to
     * RpfViewAttributes.ANY, then the palette of the tool is not
     * shown.
     * @param cov the RpfCoverage tool.  
     */
    public void setCoverage(RpfCoverage cov){
	coverage = cov;
	if (viewAttributes != null && coverage != null &&
	    !viewAttributes.chartSeries.equalsIgnoreCase(RpfViewAttributes.ANY)){
	    coverage.setShowPalette(false);
	}
    }

    /**
     * Return the coverage tool used by the layer.
     * @return RpfCoverage tool.
     */
    public RpfCoverage getCoverage(){
	return coverage;
    }

    /**
     * Set the RpfFrameProvider for the layer.  Clears out the cache,
     * and the frame provider gets the RpfViewAttributes held by the
     * layer.
     * @param fp the frame provider.  
     */
    public void setFrameProvider(RpfFrameProvider fp){
	frameProvider = fp;
	if (this.cache != null){
	    this.cache.setFrameProvider(frameProvider);
	}
    }

    /**
     * Return RpfFrameProvider used by the layer.
     */
    public RpfFrameProvider getFrameProvider(){
	return frameProvider;
    }

    /**
     *  Returns the Vector containing RpfCoverageBoxes that was
     *  returned from the RpfFrameProvider as a result of the last
     *  setCache call.  These provide rudimentary knowledge about what
     *  is being displayed.  This vector is from the primary cache
     *  handler.
     * @return Vector of RpfCoverageBoxes.  
     */
    public Vector getCoverageBoxes(){
	return this.cache.getCoverageBoxes();
    }

    /** 
     * Implementing the ProjectionPainter interface.
     */
    public synchronized void renderDataForProjection(Projection proj, 
						     java.awt.Graphics g){
	if (proj == null){
	    Debug.error("RpfLayer.renderDataForProjection: null projection!");
	    return;
	} else if (!proj.equals(projection)){
	    projection = proj.makeClone();
	    setGraphicList(prepare());
	}
	paint(g);
    }

    /**
     * The projectionListener interface method that lets the Layer
     * know when the projection has changes, and therefore new graphics
     * have to created /supplied for the screen.
     *
     * @param e The projection event, most likely fired from a map
     * bean. 
     */
    public void projectionChanged (ProjectionEvent e) {
	projectionChanged (e, false);
    }

    /** 
     * Called from projectionListener interface method that lets the
     * Layer know when the projection has changes, and therefore new
     * graphics have to created /supplied for the screen.
     *
     * @param e The projection event, most likely fired from a map
     * bean. 
     * @param saveGraphicsForRedraw flag to test for whether the scale
     * and zone has changed for the projection.  If true, and the
     * scale and zone is the same, we'll just reproject and redraw the
     * current frames before getting new ones, to fake something
     * happening quickly.
     */
    public void projectionChanged (ProjectionEvent e, 
				   boolean saveGraphicsForRedraw) {
	Debug.message("basic", getName()+"|RpfLayer.projectionChanged()");

	if (projection != null){
	    Projection tmpProj = e.getProjection();
	    if (projection.equals(tmpProj)){
		// Nothing to do, already have it and have acted on it...
		
		repaint();
		return;
	    } else if (saveGraphicsForRedraw && 
		       tmpProj instanceof CADRG &&
		       projection instanceof CADRG){
		CADRG cadrg1 = (CADRG) tmpProj;
		CADRG cadrg2 = (CADRG) projection;
		if (cadrg1.getScale() != cadrg2.getScale() ||
		    cadrg1.getZone() != cadrg2.getZone()){
		    setGraphicList(null);
		}
		// else set graphic list escapes deletion....
	    } else {
		setGraphicList(null);
	    }
	} else {
	    setGraphicList(null);
	}

	// Not so fast, we may want to reproject
	// and redisplay first....
	// setGraphicList(null); 

	projection = e.getProjection().makeClone();
	doPrepare();
    }

    /** 
     * The RpfWorker calls this method on the layer when it is
     * done working.  If the calling worker is not the same as the
     * "current" worker, then a new worker is created.
     *
     * @param worker the worker that has the graphics.
     */
    protected synchronized void workerComplete (RpfWorker worker) {
	if (!isCancelled()) {
	    currentWorker = null;
	    setGraphicList((OMGraphicList)worker.get());
	    repaint();
	}
	else{
	    setCancelled(false);
	    currentWorker = new RpfWorker();
	    currentWorker.execute();
	}
    }

    /**
     * A method that will launch a RpfWorker to fetch the images
     * that best suit the settings in the current RpfViewAttributes.
     * Should not be called externally, unless you change settings in
     * the RpfViewAttributes, and do not change the projection.  If
     * you call this AND change the projection of the MapBean, you
     * double the work for the layer.
     */
    public void doPrepare(){
	// If there isn't a worker thread working on a projection
	// changed or other doPrepare call, then create a thread that
	// will do the real work. If there is a thread working on
	// this, then set the cancelled flag in the layer.
	if (currentWorker == null) {
	    currentWorker = new RpfWorker();
	    currentWorker.execute();
	}
	else setCancelled(true);
    }

    /**
     * Prepares the graphics for the layer.  This is where the
     * getRectangle() method call is made on the rpf.  <p>
     * Occasionally it is necessary to abort a prepare call.  When
     * this happens, the map will set the cancel bit in the
     * LayerThread, (the thread that is running the prepare).  If this
     * Layer needs to do any cleanups during the abort, it should do
     * so, but return out of the prepare asap.
     *
     * @return graphics list of images and attributes.
     */
    public OMGraphicList prepare () {

	if (isCancelled()){
	    Debug.message("rpf", getName()+"|RpfLayer.prepare(): aborted.");
	    return null;
	}

	if (this.cache == null){
	    Debug.message("rpf", "RpfLayer: Creating cache!");
	    if (frameProvider == null) {
		// Assuming running locally - otherwise the
		// frameProvider should be set before we get here,
		// like in setProperties or in the constructor.
		setPaths(paths);
		if (frameProvider == null){
		    // Doh! no paths were set!
		    return new OMGraphicList();
		}
	    }
	    this.cache = new RpfCacheManager(frameProvider, viewAttributes,
					     subframeCacheSize, auxSubframeCacheSize);
	}

	if (coverage != null && coverage.isInUse()){
	    coverage.prepare(frameProvider, projection, 
			     viewAttributes.chartSeries);
	}

	// Check to make sure the projection is CADRG
	if (!(projection instanceof CADRG) && 
	    (viewAttributes.showMaps || viewAttributes.showInfo)){
	    fireRequestMessage("RpfLayer requires the CADRG projection\nfor images or attributes!");
	    return null;
	}

	Debug.message("basic", getName()+"|RpfLayer.prepare(): doing it");

	// Setting the OMGraphicsList for this layer.  Remember, the
	// OMGraphicList is made up of OMGraphics, which are generated
	// (projected) when the graphics are added to the list.  So,
	// after this call, the list is ready for painting.

	// call getRectangle();
	if (Debug.debugging("rpf")) {
	    Debug.output(getName()+"|RpfLayer.prepare(): " +
			 "calling getRectangle " +
			 " with projection: " + projection +
			 " ul = " + projection.getUpperLeft() + " lr = " + 
			 projection.getLowerRight()); 
	}

	if (frameProvider.needViewAttributeUpdates()){
	    frameProvider.setViewAttributes(viewAttributes);
	}

	OMGraphicList omGraphicList;
	try{
	    omGraphicList = this.cache.getRectangle(projection);
	} catch (java.lang.NullPointerException npe){
	    Debug.error(getName() + 
			"|RpfLayer.prepare(): Something really bad happened - \n " +
			npe);
	    npe.printStackTrace();
	    omGraphicList = new OMGraphicList();
	    this.cache = null;
	}

	/////////////////////
	// safe quit
	int size = 0;
	if (omGraphicList != null){
	    size = omGraphicList.size();	
	    if (Debug.debugging("basic")){
		Debug.output("RpfLayer.prepare(): finished with "+
			     size + " graphics");
	    }
	}
	else 
	    Debug.message("basic", 
			  "RpfLayer.prepare(): finished with null graphics list");

	// Don't forget to project them.  Since they are only being
	// recalled if the projection hase changed, then we need to
	// force a reprojection of all of them because the screen
	// position has changed.
	omGraphicList.project(projection, true);
	return omGraphicList;
    }


    /**
     * Paints the layer.
     *
     * @param g the Graphics context for painting
     *
     */
    public void paint (java.awt.Graphics g) {
	Debug.message("rpf", "RpfLayer.paint()");

	OMGraphicList tmpGraphics = getGraphicList();

	if (tmpGraphics != null) {
	    tmpGraphics.render(g);
	}

	if (coverage != null && coverage.isInUse()){
	    coverage.paint(g);
	}
    }

    
    //----------------------------------------------------------------------
    // GUI
    //----------------------------------------------------------------------
    private transient Box box = null;

    /**
     * Provides the palette widgets to control the options of showing
     * maps, or attribute text.
     * @return Component object representing the palette widgets.
     */
    public java.awt.Component getGUI() {
	if (box == null){
	    JCheckBox showMapsCheck, showInfoCheck, lockSeriesCheck;

	    box = Box.createVerticalBox();
	    Box box1 = Box.createVerticalBox();
	    Box box2 = Box.createVerticalBox();
	    JPanel topbox = new JPanel();
	    JPanel subbox2 = new JPanel();

	    showMapsCheck = new JCheckBox("Show Images", viewAttributes.showMaps);
	    showMapsCheck.setActionCommand(showMapsCommand);
	    showMapsCheck.addActionListener(this);

	    showInfoCheck = new JCheckBox("Show Attributes", viewAttributes.showInfo);
	    showInfoCheck.setActionCommand(showInfoCommand);
	    showInfoCheck.addActionListener(this);

	    boolean locked = viewAttributes.chartSeries.equalsIgnoreCase(RpfViewAttributes.ANY)?false:true;
	    String lockedTitle = locked?
		(lockedButtonTitle + " - " + viewAttributes.chartSeries):
		unlockedButtonTitle;

	    lockSeriesCheck = new JCheckBox(lockedTitle, locked);
	    lockSeriesCheck.setActionCommand(lockSeriesCommand);
	    lockSeriesCheck.addActionListener(this);

	    box1.add(showMapsCheck);
	    box1.add(showInfoCheck);
	    box1.add(lockSeriesCheck);

	    if (coverage != null){
		JCheckBox showCoverageCheck;
		if (coverage.isShowPalette()){
		    showCoverageCheck = new JCheckBox("Show Coverage Tool", false);
		} else {
		    showCoverageCheck = new JCheckBox("Show Coverage", false);
		}
		showCoverageCheck.setActionCommand(showCoverageCommand);
		showCoverageCheck.addActionListener(this);
		box1.add(showCoverageCheck);
	    }

	    topbox.add(box1);
	    topbox.add(box2);
	    box.add(topbox);

	    JPanel opaquePanel = PaletteHelper.createPaletteJPanel("Map Opaqueness");
	    JSlider opaqueSlide = new JSlider(
		JSlider.HORIZONTAL, 0/*min*/, 255/*max*/, 
		viewAttributes.opaqueness/*inital*/);
	    java.util.Hashtable dict = new java.util.Hashtable();
	    dict.put(new Integer(0), new JLabel("clear"));
	    dict.put(new Integer(255), new JLabel("opaque"));
	    opaqueSlide.setLabelTable(dict);
	    opaqueSlide.setPaintLabels(true);
	    opaqueSlide.setMajorTickSpacing(50);
	    opaqueSlide.setPaintTicks(true);
	    opaqueSlide.addChangeListener(new ChangeListener(){
		    public void stateChanged(ChangeEvent ce){
			JSlider slider = (JSlider) ce.getSource();
			if (slider.getValueIsAdjusting()){
			    viewAttributes.opaqueness = slider.getValue();
			    fireRequestInfoLine("RPF Opaqueness set to " + 
						viewAttributes.opaqueness + 
						" for future requests.");
			}
		    }
		});
	    opaquePanel.add(opaqueSlide);
	    box.add(opaquePanel);

	    JButton redraw = new JButton("Redraw RPF Layer");
	    redraw.addActionListener(this);
	    subbox2.add(redraw);
	    box.add(subbox2);
	}
	return box;
    }


    //----------------------------------------------------------------------
    // ActionListener interface implementation
    //----------------------------------------------------------------------

    /**
     * The Action Listener method, that reacts to the palette widgets
     * actions.
     */
    public void actionPerformed (ActionEvent e) {
	String cmd = e.getActionCommand();
	if (cmd == showMapsCommand) {
	    JCheckBox mapCheck = (JCheckBox)e.getSource();
	    viewAttributes.showMaps = mapCheck.isSelected();
	    repaint();
	} else if (cmd == showInfoCommand) {
	    JCheckBox infoCheck = (JCheckBox)e.getSource();
	    viewAttributes.showInfo = infoCheck.isSelected();
	    repaint();
	} else if (cmd == lockSeriesCommand) {
	    JCheckBox lockCheck = (JCheckBox)e.getSource();
	    boolean locked = lockCheck.isSelected();
	    if (locked){
		Vector vector = getCoverageBoxes();
		String seriesName;

		if (vector == null || vector.size() == 0){
		    seriesName = RpfViewAttributes.ANY;
		} else {
		    seriesName = ((RpfCoverageBox)vector.elementAt(0)).chartCode;
		}
		lockCheck.setText(lockedButtonTitle + " - " + 
				  seriesName);
		viewAttributes.chartSeries = seriesName;

	    } else {
		lockCheck.setText(unlockedButtonTitle);
		viewAttributes.chartSeries = RpfViewAttributes.ANY;
	    }

	} else if (cmd == showCoverageCommand){
	    if (coverage != null){
		JCheckBox coverageCheck = (JCheckBox)e.getSource();
		coverage.setInUse(coverageCheck.isSelected());
		if (coverage.isInUse()){
		    coverage.prepare(frameProvider, projection, 
				     viewAttributes.chartSeries);
		}
		repaint();
	    }
	} else {
//  	    Debug.error("RpfLayer: Unknown action command \"" + cmd +
//  			"\" in RpfLayer.actionPerformed().");

	    // OK, not really sure what happened, just act like a
	    // reset.
	    doPrepare();
	}
    }

    /** Print out the contents of a properties file. */
    public static void main (String[] argv){
	System.out.println("#########################################");
	System.out.println("# Properties for the JAVA RpfLayer");
	System.out.println("# Mandatory properties:");
	System.out.println("layer.class=com.bbn.openmap.layer.rpf.RpfLayer");
	System.out.println("layer.prettyName=CADRG");
	System.out.println("# This property should reflect the paths to the RPF directories");
	System.out.println("layer.paths=<Path to RPF dir>;/cdrom/cdrom0/RPF");
	System.out.println("# Optional properties - Defaults will be set for properties not included (defaults are listed):");
	System.out.println("# Number between 0-255: 0 is transparent, 255 is opaque");
	System.out.println("layer.opaque=255");
	System.out.println("# Number of colors to use on the maps - 16, 32, 216");
	System.out.println("layer.numberColors=216");
	System.out.println("# Display maps on startup");
	System.out.println("layer.showMaps=true");
	System.out.println("# Display attribute information on startup");
	System.out.println("layer.showInfo=false");
	System.out.println("# Scale images to match map scale");
	System.out.println("layer.scaleImages=true");
	System.out.println("# The scale factor to allow when scaling images (2x, 4x, also mean 1/2, 1/4).  Default is 4.");
	System.out.println("rpf.imageScaleFactor=4");
	System.out.println("# Reset the cache if layer is removed from map");
	System.out.println("layer.killCache=false");
	System.out.println("# Limit the display to the chart code specified. (GN, JN, ON, TP, etc.)");
	System.out.println("layer.chartSeries=ANY");
	System.out.println("# Set the subframe cache size. (Number of subframes to hold on to, 256x256 pixels");
	System.out.println("layer.subframeCacheSize=128");
	System.out.println("# Get the subframe attribute data from the frame provider.");
	System.out.println("rpf.autofetchAttributes=false");
	System.out.println("#If you want the coverage tool to be available");
	System.out.println("layer.coverage=true");
	System.out.println("#Then add coverage constants as needed.");
    }
}

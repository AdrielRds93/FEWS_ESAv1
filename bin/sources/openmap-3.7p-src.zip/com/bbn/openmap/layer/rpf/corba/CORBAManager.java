/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/rpf/corba/CORBAManager.java,v $
 * $Revision: 1.3 $
 * $Date: 2000/05/08 14:22:51 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.rpf.corba;

import java.applet.Applet;

import org.omg.CORBA.*;
import com.bbn.openmap.util.Debug;
import com.bbn.openmap.Environment;

/**
 * @HACK CORBAManager class is a hack workaround broken Visiborker
 * implementation of ORB.init(applet, props) where it spawns two new threads
 * each time it's called.  If it didn't do this stupid thing, then we wouldn't
 * need this class.
 *
 */
public class CORBAManager {
    
    private static ORB CORBAMANAGER_orb;
    
    private CORBAManager(){}
    
    /**
     * Return a static reference to the ORB.
     *
     * @HACK see above.
     *
     */
    public static ORB getORB() {
	if (CORBAMANAGER_orb == null) {
	    Debug.message("basic", "CORBAManager.getORB(): initializing ORB");
	    Applet applet = Environment.getApplet();
	    if (applet == null) {
		if (Debug.debugging("basic")) {
		    System.out.println("CORBAManager: initializing application");
		}
		CORBAMANAGER_orb = ORB.init();
	    } else {
		// initialize the Environment with the properties passed in.
		if (Debug.debugging("basic")) {
		    System.out.println("CORBAManager: initializing applet");
		}
		CORBAMANAGER_orb = ORB.init(applet, Environment.getProperties());
	    }
	}
	return CORBAMANAGER_orb;
    }
}

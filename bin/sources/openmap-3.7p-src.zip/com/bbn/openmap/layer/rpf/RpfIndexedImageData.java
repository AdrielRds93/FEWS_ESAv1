// **********************************************************************
// 
//  BBNT Solutions LLC, A part of GTE
//  10 Moulton St.
//  Cambridge, MA 02138
//  (617) 873-2000
// 
//  Copyright (C) 1997, 2000
//  This software is subject to copyright protection under the laws of 
//  the United States and other countries.
// 
// **********************************************************************
// 
// $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/rpf/RpfIndexedImageData.java,v $
// $RCSfile: RpfIndexedImageData.java,v $
// $Revision: 1.2 $
// $Date: 2000/05/08 14:22:49 $
// $Author: wjeuerle $
// 
// **********************************************************************


package com.bbn.openmap.layer.rpf;

import com.bbn.openmap.omGraphics.OMColor;

public class RpfIndexedImageData {
    public byte[] imageData;
    public OMColor[] colortable;
}

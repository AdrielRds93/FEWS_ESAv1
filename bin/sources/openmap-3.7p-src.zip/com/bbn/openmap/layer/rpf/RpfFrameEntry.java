/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 *
 * The meat of this code is based on source code provided by
 * The MITRE Corporation, through the browse application source
 * code.  Many thanks to Nancy Markuson who provided BBN with the
 * software, and to Theron Tock, who wrote the software, and
 * Daniel Scholten, who revised it - (c) 1994 The MITRE
 * Corporation for those parts, and used with permission.
 *
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/rpf/RpfFrameEntry.java,v $
 * $Revision: 1.10 $
 * $Date: 2000/05/08 14:22:48 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.rpf;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

import com.bbn.openmap.util.*;

/**
 * The RpfFrameEntry is a description of a RPF frame file that can be
 * used to quickly gain status about the frame.  It is mainly created
 * by the table of contents handler (RpfTocHandler), and passed, in an
 * array of brothers in a RpfTocEntry, to the cache handler.  The cache
 * handler will use the RpfTocEntry to figure out which frames are
 * needed to get the subframes it wants, and the RpfFrameEntry supplies
 * information to assist in loading that frame file.
 */
public class RpfFrameEntry {
    
    /** Whether the file exists or not.*/
    public boolean exists;
    /** Absolute path to Rpf dir. */
    public String rpfdir; 
    /** Rpf to frame dir path. */
    public String directory;
    /** Frame file name. */
    public String filename; // [16]
    /** Real path to the frame file. */
    public String framePath;
    /**Used by the RpfTocHandler to create disk usage estimates. */
    public long diskspace;

    public RpfFrameEntry(){
	exists = false;
	directory = null;
    }
    
    public String toString(){
	StringBuffer s = new StringBuffer();
	s.append("File Name: " + filename + "\n");
	s.append("In Directory: " + directory + "\n");
	s.append("Is Located At: " + framePath + "\n");
	s.append("Exists: " + exists + "\n");
	s.append("Size: " + diskspace);
	return s.toString();
    }
}



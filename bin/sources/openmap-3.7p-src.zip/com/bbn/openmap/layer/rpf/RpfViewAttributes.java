/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 *
 *
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/rpf/RpfViewAttributes.java,v $
 * $Revision: 1.5 $
 * $Date: 2000/05/08 14:22:49 $
 * $Author: wjeuerle $
 * 
 * ********************************************************************** */

package com.bbn.openmap.layer.rpf;

import com.bbn.openmap.omGraphics.OMRasterObject;
import com.bbn.openmap.proj.CADRG;

/** 
 * This class contains information to pass through the
 * RpfCacheManager and RpfCacheHandlers to describe limitations and
 * parameters desired for data view.  It contains information about
 * the numbers of colors to use, how opaque to make the images, the
 * chart series to retrieve, etc.
 */
public class RpfViewAttributes {

    public final static String ANY = "ANY";
    public final static String ALL = "ALL";

    /** Number of colors to use - 16, 32, 216 */
    public int numberOfColors;
    /** The opaqueness of the image (transparency) 0-255. 0 is clear,
     *  255 is opaque. */
    public int opaqueness;
    /** The image colormodel to use, indexed or colortable, for the
     *  OMRasters. */
    public int colorModel;
    /** Flag to use to scale images or not.  This will cause the
     *  caches to scale the images to match the map scale, instead of
     *  requiring the map to be at the same scale as the desired
     *  image. */
    public boolean scaleImages;
    /** The limiting factor for image scaling.  Make this too big, and
     *  you will run out of memory. */
    public float imageScaleFactor;
    /** The data series two-letter code to limit responses to.  If you
     *  want any data that is the closest match for the current map,
     *  use ANY (default).  If you want all of the RpfCoverageBoxes
     *  that have some coverage, use ALL. */
    public String chartSeries;
    /** Flag to set if the CADRG projection is required. Might not be,
     *  if we start warping images.*/
    public boolean requireProjection;
    /** Flag to display images. */
    public boolean showMaps;
    /** Flag to display attribute information about the subframes. */
    public boolean showInfo;
    /** CADRG Projection of the map. */
    public CADRG proj;
    /** Autofetch the subframe attributes from the FrameProvider. Use
     *  only if you are interested in background information about
     *  the images. */
    public boolean autofetchAttributes;

    public RpfViewAttributes(){
	setDefaults();
    }

    public void setDefaults(){
	numberOfColors = RpfColortable.CADRG_COLORS;
	opaqueness = RpfColortable.DEFAULT_OPAQUENESS;
	scaleImages = true;
	imageScaleFactor = 4.0f;
	colorModel = OMRasterObject.COLORMODEL_DIRECT;
	chartSeries = ANY;
	requireProjection = true;
	showMaps = true;
	showInfo = false;
	autofetchAttributes = false;
    }
}

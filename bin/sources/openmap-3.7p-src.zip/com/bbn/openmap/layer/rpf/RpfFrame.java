/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 *
 * Some of the ideas for this code is based on source code provided by
 * The MITRE Corporation, through the browse application source code.
 * Many thanks to Nancy Markuson who provided BBN with the software,
 * to Theron Tock, who wrote the software, and Daniel Scholten, who
 * revised it - (c) 1994 The MITRE Corporation for those parts, and
 * used/distributed with permission.  Namely, the frame file reading
 * mechanism is the part that has been modified.
 *
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/rpf/RpfFrame.java,v $
 * $Revision: 1.20 $
 * $Date: 2000/08/03 14:50:37 $
 * $Author: dietrick $
 * 
 * ********************************************************************** */

package com.bbn.openmap.layer.rpf;

import java.io.File;
import java.io.IOException;
import java.io.FileNotFoundException;

import com.bbn.openmap.omGraphics.OMColor;
import com.bbn.openmap.layer.nitf.NitfHeader;
import com.bbn.openmap.util.Debug;
import com.bbn.openmap.util.BinaryBufferedFile;
import com.bbn.openmap.util.FormatException;

/** The object that organizes the information found within the RPF
* frame file.  The RpfFrame handles reading through the different
* sections, and holds on to the compressed subframe data.  The cache
* handler gets the compressed subframe data and decompresses it before
* storing the uncompressed subframe in the cache.
* */
public class RpfFrame {
    
    boolean valid = false;
    
    NitfHeader nitfHeader;
    RpfHeader header;
    RpfFileSections fileSections;
    RpfAttributes attributes;
    RpfFileSections.RpfCoverageSection coverage;
    RpfColortable colortable;
    String report;

    byte[][][] compressedSubframe = new byte[6][6][];
    byte[][][] table = new byte[4][4096][4];
    /* DKS NEW for CHUMMED subfr info.  [y][x] */
    boolean[][] chummed = new boolean[6][6];
    /* DKS NEW for masked subfr info: WAS EXTERNAL. */
    boolean[][] masked = new boolean[6][6];

    /** Want to bother with Dchum? */
    boolean Dchum = false;
    int chumVersion; /* Chum version: 2,3,etc. */

    int numCharsInDesc; // ushort, # chars in DCHUM descriptor string */
    int  descCount; /* # descriptors */
    /** Array of descriptor strings */
    String[] descriptors; // char desc_str[MAX_NUM_DESC][MAX_DESC_LEN];   
    /** Array of descriptor dates */
    String[] descriptorDates; // char desc_date[MAX_NUM_DESC][9];

    /** Loads the RpfFrame, given a complete path to the file. */
    public RpfFrame(String framePath){
	File file = new File(framePath);
	BinaryBufferedFile binFile = null;
	try {
	    binFile = new BinaryBufferedFile(file);
	    read(binFile);
	} catch (FileNotFoundException e) {
	    Debug.error("RpfFrame: file "+framePath+" not found");
	    valid = false;
	} catch (IOException ioe){
	    Debug.error("RpfFrame: File IO Error while handling NITF header:\n" +
			ioe);
	    valid = false;
	} catch (NullPointerException npe){
	    Debug.error("RpfFrame: File IO Error NPE:\n" + npe);
	    valid = false;
	}
    }

    /**
     *  Loads the RpfFrame, given the RpfFrameEntry that the
     * RpfCacheHandler got from the RpfTocHandler.
     */
    public RpfFrame(RpfFrameEntry rfe){
	this(rfe.framePath);
	Dchum = true;
	chumVersion = Character.digit(rfe.filename.charAt(6), 10);
    }

    public void finalize(){
	Debug.message("gc", "RpfFrame: getting GC'd");
    }

    public boolean isValid(){
	return valid;
    }

    /** Create the screen text used on a subframe.  The internal
     * string is set. 
     * @param Cib whether the frame is a Cib frame.  The report is
     * different if it is. 
     **/
    protected void setReport(boolean Cib){
	if (attributes != null){
	    StringBuffer s = new StringBuffer();
	    s.append("\nRPF Currency Date: " + attributes.currencyDate);
	    s.append("\nRPF Production Date: " + attributes.productionDate);
	    s.append("\nSource Significant Date: " + attributes.significantDate);
	    if (Cib){
		s.append("\nMap Source: " + attributes.dataSource);
	    }
	    else{
		s.append("\nMap Designation: " + attributes.mapDesignationCode);
		s.append("\nMap Series: " + attributes.chartSeriesCode);
		s.append("\nMap Edition: " + attributes.edition);
	    }
	    report = s.toString();
	}
    }	    

    /** Get the attribute text to display on the screen.  This goes to
     * the RpfSubframe object.  The RpfCacheHandler knows about the
     * four variables.
     * @param x subframe index within the array from the TocEntry.
     * @param y subframe index within the array from the TocEntry
     * @param entry the RpfFrameEntry describing the frame.
     * @param Cib whether the frame is an imagery frame.
     * */
    public String getReport(int x, int y, RpfFrameEntry entry, boolean Cib){
	StringBuffer s = new StringBuffer();

	x = x % 6;
	y = y % 6;
	s.append("Subframe " + x + ", " + y + "\n");
	if (entry != null){
	    s.append("\nFrame Name: ");
	    s.append(entry.filename);
	}
	else{
	    s.append("\nThere are no attributes in frame: ");
	    s.append(entry.filename);
	}

	if (report == null) setReport(Cib);  // preset the attribute part of the info.
	if (report != null) s.append(report);

	s.append("\nFrom Frame Dir: ");

	String actualFilePath = entry.rpfdir + entry.directory;

	if (actualFilePath.length()>20){
	    int start = 0;
	    int index = actualFilePath.indexOf("/", 15);
	    while (index != -1){
		s.append(actualFilePath.substring(start, index));
		s.append("/\n    ");
		start = index+1;
		index = actualFilePath.indexOf("/", start + 15);
	    }
	    s.append(actualFilePath.substring(start));
	}

	else s.append(actualFilePath);
	return s.toString();
    }
	

    /** The only reason to call this is to read the colortable that is
     * within the frame file, and set the colors that you will be
     * using for all the frames accordingly.  The RpfColortable is
     * passed in so you can set the opaqueness, number of colors, and
     * other colortable variables inside your own colortable object,
     * and then read the color conversion tables as they apply (inside
     * the frame file).  Since the frame file is read when the
     * RpfFrame is created, the fileSections object will (should) be
     * valid.
     * */
    public OMColor[] getColors(BinaryBufferedFile binFile, 
			       RpfColortable ct){

	fileSections.parseColorSection(binFile, ct);
	return ct.colors;
    }

    /**
     * Load the colortable with the colors from a particular frame
     * file.  Not needed, really, since the frame file is not loading
     * it's own colortable at loadtime.
     */
    public static OMColor[] getColors(String framePath, RpfColortable ct){
	File file = new File(framePath);
	BinaryBufferedFile binFile = null;
	try {
	    binFile = new BinaryBufferedFile(file);
	    RpfFileSections rfs = new RpfFileSections();
	    RpfHeader head = new RpfHeader();

	    head.read(binFile);
	    binFile.seek(head.locationSectionLocation);
	    rfs.parse(binFile);

	    OMColor[] ret = 
		rfs.parseColorSection(binFile, ct);

	    binFile.close();
	    return ret;
	} catch (FileNotFoundException e) {
	    Debug.error("RpfFrame: getColortable(): file "+
			framePath+" not found");
	} catch (IOException ioe){
	    Debug.error("RpfFrame: getColortable(); File IO Error!\n" +	ioe);
	} 
	return null;
    }

    /**
     * Get the colortable stored inside this RpfFrame.
     * @return RpfColortable
     */
    public RpfColortable getColortable(){
	return colortable;
    }

    /** Read the RPF frame. */
    public boolean read(BinaryBufferedFile binFile){

	Compression compression;
	LookupTable[] lookupTable = new LookupTable[4];
	Image image;

	int[][] indices = new int[6][6]; //ushort
	int rowBytes;
	int i, j, rc;
	
	/*  bool (uchar) */
	/* all subframes present indicator */
	boolean  allSubframes;
	long currentPos; // uint
	long lookupOffsetTableOffset; // uint
	int lookupTableOffsetRecLen; //ushort

	long subframeMaskTableOffset; //uint
	/* subframe offset (mask section) */
	long[][] subframeOffset = new long[6][6];//uint[][]

	/* for DCHUM */
	long fsave; /* saved file loc */
	int chummedSubframe; //uint
	int attributeId; // ushort
	int attributeParamId; //uchar
	int tempc; //uchar
	long attributeRecOffset; //uint
	int numAttributeOffsetRecs; //ushort
	int numSubframesChummed; //ushort

	if(Debug.debugging("rpfdetail")){
	    Debug.output("ENTER RPFFRAME.READ") ;
	}

	try {
	    // Let's start at the beginning, shall we?
	    binFile.seek(0);

	    // Read the NITF part of the file...
	    nitfHeader = new NitfHeader();
	    // If false, it might not be a NITF file, start over...
	    if (!nitfHeader.read(binFile)) binFile.seek(0);

	    long rpfOffset = binFile.getFilePointer();

	    header = new RpfHeader();
	    // Now, read the RPF header...
	    if (!header.readHeader(binFile)) return false;

	    /* Check date for validity: date should be "1993xxxx" */
	    if (!header.standardDate.startsWith("199") &&
		!header.standardDate.startsWith("20")) {
		Debug.output("RpfFrame.read: Invalid date in header: " +
			     header.standardDate);
		return false;
	    }

	    // Need to do this right after the header...
	    binFile.seek(header.locationSectionLocation);
	    fileSections = new RpfFileSections(binFile);
	    	    
	    RpfFileSections.RpfLocationRecord[] loc = 
		fileSections.getLocations(RpfFileSections.FRAME_LOCATION_KEY);

 	    attributes = fileSections.parseAttributes(binFile);
 	    coverage = fileSections.parseCoverageSection(binFile);

	    colortable = new RpfColortable();
	    getColors(binFile, colortable);

	    /* DKS: from index to componentLocation */
	    if (loc[0] == null){
		Debug.output("RpfFrame: No compression section!");
		return false;
	    }
	
	    /* Read the compression tables */
	    binFile.seek(loc[0].componentLocation);
	    compression = new Compression(binFile);
	    if(Debug.debugging("rpfdetail")) 
		Debug.output(compression.toString());
	
	    if (loc[2] == null){
		Debug.output("Warning: Can't find compr. lookup subsection in FrameFile:");
		Debug.output("   Using alternate computation") ;
		/* length of compr. sect. subhdr = 10 */
		binFile.seek(loc[0].componentLocation + 10);
	    }
	    else {
		/* DKS: Position at start of compression lookup table
                   offset record */
		if(Debug.debugging("rpfdetail")){
		    Debug.output("Comp lkup subsect: loc[2].componentLocation(264?): " + loc[2].componentLocation);
		}
		binFile.seek(loc[2].componentLocation);
	    }
	
	    /* 2 new hdr fields */
	    
	    lookupOffsetTableOffset = (long)binFile.readInteger();
	    lookupTableOffsetRecLen = (int)binFile.readShort();

	    if(Debug.debugging("rpfdetail")){
		Debug.output("lookupOffsetTableOffset(6): " + 
			     lookupOffsetTableOffset);
		Debug.output("lookupTableOffsetRecLen(14): " + 
			     lookupTableOffsetRecLen);
	    }
	
	    /* For each compression table */
	    for (i = 0; i < 4; i++){
		lookupTable[i] = new LookupTable(binFile);
		if(Debug.debugging("rpfdetail")){
		    Debug.output("Compression lookup table offset record " + i);
		    Debug.output(lookupTable[i].toString());
		}
	    
		if (lookupTable[i].records != 4096 ||
		    lookupTable[i].values != 4 ||
		    lookupTable[i].bitLength != 8){
		    Debug.output("RpfFrame: Bad VQ info in compression record");
		    return false;
		}
	    } /* for i */
	
	    for (i = 0; i < 4; i++) {      /* Read compression lookup table */
		/* new position from compression lookup subsection: loc[2] */
		binFile.seek(loc[2].componentLocation + lookupTable[i].offset);
		if(Debug.debugging("rpfdetail")){
		    currentPos = binFile.getFilePointer();
		    Debug.output("Read compr. lookup table (4x4096) at position: " + 
				 currentPos);
		}
		for (j = 0; j < 4096; j++)
		    table[i][j] = binFile.readBytes(4, false);
		
		
	    }  /* for i=1 to 4 (# compression tables, 1 for each pixel row)  */

	    /* seek to LOC_ATTRIB_SUBHEADER, ID=141 */
	    if ((Dchum) && (chumVersion > 1 )) {  /* Chum selected and file version > 1 */
		if (loc[6] == null){
		    Debug.output("RpfFrame: Can't find ATTRIBUTE_SUBHEADER section!");
		    return false;
		}
		if(Debug.debugging("rpfdetail"))
		    Debug.output("ATTRIBUTE SUBHEADER location: " + 
				 loc[6].componentLocation);

		binFile.seek(loc[6].componentLocation);

		numAttributeOffsetRecs = (int) binFile.readShort();
		if(Debug.debugging("rpfdetail"))
		    Debug.output("numAttributeOffsetRecs: " + numAttributeOffsetRecs);
	    
		/* Go to Attrib subsection */
		if (loc[7] == null){
		    Debug.output("RpfFrame: Can't find ATTRIBUTE_SECTION in Frame file");
		    return false;
		} 

		if(Debug.debugging("rpfdetail"))
		    Debug.output("ATTRIBUTE SECTION location: " + 
				 loc[7].componentLocation);
		
		binFile.seek(loc[7].componentLocation);    
	    
		descCount = 0;   /* # descriptor strings so far */
		
		for (i=0; i<numAttributeOffsetRecs; i++) {
		    attributeId = (int) binFile.readShort();
		    attributeParamId = binFile.read();
		    tempc = binFile.read();
		    attributeRecOffset = (long) binFile.readInteger();
		    
		    /* # subframes impacted */
		    if ((attributeId==24) && (attributeParamId==4)) {  
			/* save file loc */
			fsave = binFile.getFilePointer();
			/* Go to proper spot in attrib section */
			binFile.seek(loc[7].componentLocation+attributeRecOffset);
			/* read # subframes impacted */
			numSubframesChummed = (int) binFile.readShort();

			if(Debug.debugging("rpfdetail")){
			    Debug.output("n_attrib_chummedSubframe: " + 
					 numSubframesChummed);
			}
			/* Read list of subframes chummed */
			/* Assume these are next in file */
			for (j=0; j<numSubframesChummed; j++) {
			    chummedSubframe = (int)binFile.readShort();
			    
			    if(Debug.debugging("rpfdetail")){
				Debug.output("chummedSubframe: " +  chummedSubframe);
			    }

			    /* y,x */
			    chummed[chummedSubframe/6][chummedSubframe%6] = true;  
			} /* for j */
			binFile.seek(fsave);   /* restore file pos */
		    } /* if 24,4 */
		
		    /* Update date */
		    if ((attributeId==24) && (attributeParamId==3)) {  
			/* save file loc */
			fsave = binFile.getFilePointer();
			/* Go to proper spot in attrib section */
			binFile.seek(loc[7].componentLocation+
				     attributeRecOffset);
			/* read date */
			descriptorDates[descCount] = binFile.readFixedLengthString(8);

			if(Debug.debugging("rpfdetail"))
			    Debug.output("descriptorDate: " + 
					 descriptorDates[descCount]);
			
			binFile.seek(fsave);   /* restore file pos */
		    } /* if 24,3 */
		
		    /* # chars in descriptor */
		    if ((attributeId==24) && (attributeParamId==6)) {
			/* save file loc */
			fsave = binFile.getFilePointer();
			/* Go to proper spot in attrib section */
			binFile.seek(loc[7].componentLocation+
				     attributeRecOffset);
			/* read # chars in descriptor */
			
			numCharsInDesc = (int) binFile.readShort();
		    
			if(Debug.debugging("rpfdetail")){
			    Debug.output("Prepare to fread descriptors[descCount]");
			    Debug.output("RpfFrame.read: descCount: " + 
					 descCount);
			}
		    
			descriptors[descCount] = 
			    binFile.readFixedLengthString(numCharsInDesc);

			/* Array of strings, not 2-d array !!!!???? */
			if(Debug.debugging("rpfdetail")){
			    Debug.output("descriptors[descCount]: " + 
					 descriptors[descCount]);
			}
			descCount++;    /* string number */
		    
			binFile.seek(fsave);   /* restore file pos */
		    } /* if 24,6 */
		} /* for i */
	    } /* if Dchum */
	
	    
	    /* READ THE IMAGE DATA */
	    if(Debug.debugging("rpfdetail")){
		Debug.output("Image descr. subheader location: loc[1].componentLocation(68576?): " + loc[1].componentLocation);
	    }
	    binFile.seek(loc[1].componentLocation);
	    image = new Image(binFile);
	
	    /* New, DKS.  NULL (FF) if no subfr mask table */
	    subframeMaskTableOffset = binFile.readInteger();
	
	    if(Debug.debugging("rpfdetail")){
		Debug.output(image.toString());
		Debug.output("subframeMaskTableOffset: " + 
			     subframeMaskTableOffset);
	    }
	
	    if (subframeMaskTableOffset == 0) {  /* ERROR Check */
		Debug.error("RpfFrame.read(): subframeMaskTableOffset==0.");
		return false;
	    }
	
	    if (subframeMaskTableOffset == 0xFFFFFFFF) allSubframes = true;
	    else allSubframes = false;

	    if(Debug.debugging("rpfframe")){
		Debug.output("allSubframes: " + allSubframes);
	    }
	
	    if (!allSubframes) {     /* Read mask data */
		/* fseek to LOC_MASK_SUBSECTION, ID=138 */
		if (loc[5] == null){
		    Debug.error("RpfFrame.read(): Can't find MASK_SUBSECTION section in Frame file");
		    return false;
		}
		if(Debug.debugging("rpfdetail")){
		    Debug.output("MASK SUBSECTION location: " + 
				 loc[5].componentLocation);
		}

		binFile.seek(loc[5].componentLocation+subframeMaskTableOffset);    

		for (i=0; i<6; i++) {   /* y */
		    for (j=0; j<6; j++) {
			subframeOffset[i][j] = (long) binFile.readInteger();
			if (subframeOffset[i][j] == 0xFFFFFFFF)
			    masked[i][j] = true; /* subfr masked*/

			if(Debug.debugging("rpfdetail")){
			    Debug.output("i:" + i + ", j:" + j + 
					 ", masked[i][j]: " + 
					 masked[i][j]);
			}

		    } /* for j */
		} /* for i */
	    } /* if !allSubframes */
	
	    if (image.vertSubframes != 6 ||
		image.horizSubframes != 6){
		Debug.output( "Not 6x6 subframes per frame: must be masked.");
	    }
	    
	    rowBytes = 256 / 4 * 3 / 2;
	    // Is this section needed??
	    /* fseek to LOC_IMAGE_DISPLAY_PARAM_SUBHEADER, ID=137 */
	    if (loc[4] == null)	{
		Debug.error("RpfFrame.read(): Can't find IMAGE_DISPLAY_PARAM_SUBHEADER section!");
		return false;
	    }
	    
	    /* Image Display Parameters Subheader */
	    if(Debug.debugging("rpfdetail")){
		Debug.output("IMAGE Display params subheader location: " + 
			     loc[4].componentLocation);
	    }
	    binFile.seek(loc[4].componentLocation);
	
	
	    /* Go to start of image spatial data subsection */
	    if (loc[3] == null) {
		Debug.output( "WARNING: Can't find Image spatial data subsection in FrameFile:");
		Debug.output("   Using alternate computation");
		/* DKS.  skip 14 bytes of image display parameters subheader instead  */
		binFile.seek(loc[4].componentLocation + 14);
	    } else {
		/* DKS: Position at start of image spatial data subsection */
		currentPos = binFile.getFilePointer();
		if(Debug.debugging("rpfdetail")){
		    Debug.output("Current frame file position(68595?): " + currentPos);
		    Debug.output("Image spatial data subsect: loc[3](68609?): " + 
				 loc[3].componentLocation);
		}
		
		binFile.seek(loc[3].componentLocation);  
	    } /* else */ 
	
	    /* Read subframes from top left, row-wise */
	    for (i = 0; i < 6; i++) {  /* row */
		for (j = 0; j < 6; j++) {   /* col */
		    /* DKS.  New: init indices to valid subframes */
		    indices[i][j] = i*6 + j ;
		    /* (256/4)=64.  64*64 * 12bits / 8bits = 6144 bytes */
		    if (!masked[i][j]) {
			compressedSubframe[i][j] = binFile.readBytes(6144, false);
			if(Debug.debugging("rpfdetail"))
			    Debug.output(" i:" + i + ", j:" + j + 
					 ", read image data. rc(6144):" + 
					 compressedSubframe[i][j].length);
		    }
		    else compressedSubframe[i][j] = new byte[6144];
		}
	    }

	} catch (IOException e){
	    Debug.error("RpfFrame: read(): File IO Error!\n" + e);
	    return false;
	} catch (FormatException f){
	    Debug.error("RpfFrame: read(): File IO Format error!" + f);
	    return false;
	}
	
	if(Debug.debugging("rpfdetail")){
	    Debug.output("LEAVE RPFFRAME.READ");
	}

	valid = true;
	return valid;
    }  /* read */

    static public class Compression{
	public int algorithm;//ushort
	/* New, dks */
	public int numOffsetRecs;//ushort
	public int numParmOffRecs;//ushort

	public Compression(BinaryBufferedFile binFile){
	    try{
		algorithm = (int) binFile.readShort();
		numOffsetRecs = (int) binFile.readShort();
		numParmOffRecs = (int) binFile.readShort();
	    } catch (IOException e){
		Debug.error("Compression: File IO Error!\n" + e);
	    } catch (FormatException f){
		Debug.error("Compression: File IO Format error!\n" + f);
	    }
	}

	public String toString(){
	    StringBuffer s = new StringBuffer();
	    s.append("Compression.algorithm: " + algorithm + "\n");
	    s.append("Compression.numOffsetRecs: " + numOffsetRecs + "\n");
	    s.append("Compression.numParmOffRecs: " + numParmOffRecs + "\n");
	    return s.toString();
	}
    }

    static public class LookupTable{
	int id; //ushort
	long records; //uint
	int values; //ushort
	int bitLength; //ushort
	long offset; // uint

	public LookupTable(BinaryBufferedFile binFile){
	    try{
		id = (int) binFile.readShort();
		records = (long) binFile.readInteger();
		values = (int) binFile.readShort();
		bitLength = (int) binFile.readShort();
		offset = (long) binFile.readInteger();
	    } catch (IOException e){
		Debug.error("Compression: File IO Error!\n" + e);
	    } catch (FormatException f){
		Debug.error("Compression: File IO Format error!\n" + f);
	    }
	}

	public String toString(){
	    StringBuffer s = new StringBuffer();
	    s.append("LookupTable.id: " + id + "\n");
	    s.append("LookupTable.records: " + records + "\n");
	    s.append("LookupTable.values: " + values + "\n");
	    s.append("LookupTable.bitLength: " + bitLength + "\n");
	    s.append("LookupTable.offset: " + offset + "\n");
	    return s.toString();
	}
    }

    static public class Image{
	int spectralGroups; //ushort
	int subframeTables;//ushort
	int spectralTables;//ushort
	int spectralLines;//ushort
	int horizSubframes, vertSubframes;//ushort
	long outputColumns, outputRows;//uint

	public Image(BinaryBufferedFile binFile){
	    try{
		spectralGroups = (int) binFile.readShort();
		subframeTables = (int) binFile.readShort();
		spectralTables = (int) binFile.readShort();
		spectralLines = (int) binFile.readShort();
		horizSubframes = (int) binFile.readShort();
		vertSubframes = (int) binFile.readShort();
		outputColumns = (long) binFile.readInteger();
		outputRows = (long) binFile.readInteger();
	    } catch (IOException e){
		Debug.error("Compression: File IO Error!\n" + e);
	    } catch (FormatException f){
		Debug.error("Compression: File IO Format error!\n" + f);
	    }
	}

	public String toString(){
	    StringBuffer s = new StringBuffer();
	    s.append("Image.spectralGroups: " + spectralGroups + "\n");
	    s.append("Image.subframeTables: " + subframeTables + "\n");
	    s.append("Image.spectralTables: " + spectralTables + "\n");
	    s.append("Image.spectralLines: " + spectralLines + "\n");
	    s.append("Image.horizSubframes: " + horizSubframes + "\n");
	    s.append("Image.vertSubframes: " + vertSubframes + "\n");
	    s.append("Image.outputColumns: " + outputColumns + "\n");
	    s.append("Image.outputRows: " + outputRows + "\n");
	    return s.toString();
	}
    } 

    public static void main(String[] argv){
	if (argv.length < 1 ){
	    System.out.println("usage: java com.bbn.openmap.layer.rpf.RpfFrame <path to frame file>");
	    return;
	}

	Debug.init();
	Debug.put("rpfframe");
	Debug.put("rpfdetail");

	RpfFrame rpfFrame = new RpfFrame(argv[0]);
    }
    
}

/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/rpf/corba/CRFPServer.java,v $
 * $Revision: 1.13 $
 * $Date: 2000/05/08 14:22:51 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.rpf.corba;

import java.io.*;
import java.util.*;

import com.bbn.openmap.util.Debug;
import com.bbn.openmap.Environment;
import com.bbn.openmap.LatLonPoint;
import com.bbn.openmap.proj.CADRG;
import com.bbn.openmap.layer.rpf.*;
import com.bbn.openmap.layer.rpf.corba.CRpfFrameProvider.*;
import com.bbn.openmap.image.JPEGHelper;

import org.omg.CosNaming.*;

/** 
 * The CRFPServer is a server implementation of the
 * CorbaRpfFrameProvider.idl.  It realy implements most of the
 * fuctions of the RpfFrameProvider, but is not one.  The CRFPClient
 * is the RpfFrameProvider.  
 * 
 * <P>This server requires the com.sun.image.codec.jpeg package.
 */

public  class CRFPServer extends _ServerImplBase {

    protected org.omg.CORBA.BOA boa = null;
    protected static String iorfile = null;
    protected static String naming = null;
    /** A cache for every client. */
    Dictionary caches;
    /** View Attributes for every client. */
    Dictionary viewAttributeLists;
    /** The cache for the current client. */
    protected RpfFrameCacheHandler currentCache;
    /** The view attrbutes for the current client. */
    protected RpfViewAttributes currentViewAttributes;
    /** The paths to the RPF directories. */
    protected String[] rpfpaths;
    /** The Rpf Table of Contents handlers for the data. */
    protected RpfTocHandler[] tocs;

    /**
     * Default Constructor.
     */
    public CRFPServer(){
	this("Default");
    }

    /**
     * The constructor that you should use.
     * @param name the identifying name for persistance.
     */
    public CRFPServer(String name) {
	super(name);
	caches = new Hashtable();
	viewAttributeLists = new Hashtable();
    }

    /**
     * Get the current cache given a unique ID.  If a cache is not
     * here, create it.
     *
     * @param uniqueID a unique identifier. 
     */
    protected RpfFrameCacheHandler getCurrentCache(String uniqueID){
	RpfFrameCacheHandler cache = (RpfFrameCacheHandler) caches.get(uniqueID);
	if (cache == null && tocs != null){
	    Debug.message("crfp", "CRFPServer: Creating cache for new client");
	    cache = new RpfFrameCacheHandler(tocs);
	    caches.put(uniqueID, cache);
	}
	return cache;
    }

    /**
     * Get the current view attributes given a unique ID.  If view
     * attributes are not here, create them.
     *
     * @param uniqueID a client-unique identifier.
     */
    protected RpfViewAttributes getCurrentViewAttributes(String uniqueID){
	RpfViewAttributes va = (RpfViewAttributes) viewAttributeLists.get(uniqueID);
	if (va == null){
	    Debug.message("crfp", "CRFPServer: Creating attributes for new client");
	    va = new RpfViewAttributes();
	    viewAttributeLists.put(uniqueID, va);
	}
	return va;
    }

    /**
     * Set the view attributtes for the current client.
     *
     * @param va the view attribute settings.
     * @param uniqueID a client-unique identifier.
     */
    public void setViewAttributes(CRFPViewAttributes va, String uniqueID){

	currentViewAttributes = getCurrentViewAttributes(uniqueID);
	currentViewAttributes.numberOfColors = (int) va.numberOfColors;
	currentViewAttributes.opaqueness = (int) va.opaqueness;
	currentViewAttributes.scaleImages = va.scaleImages;
	currentViewAttributes.imageScaleFactor = va.imageScaleFactor;
	currentViewAttributes.chartSeries = va.chartSeries;

	if (Debug.debugging("crfp")){
	    Debug.output("CRFPServer: Setting attributes for client:\n    " + 
			 currentViewAttributes);
	}
   }

    /**
     * Get the Coverage Boxes that fit the geographical area given.
     *
     * @param ullat NW latitude.
     * @param ullon NW longitude
     * @param lrlat SE latitude
     * @param lrlon SE longitude
     * @param p a CADRG projection
     * @param uniqueID a client-unique identifier.
     */
    public CRFPCoverageBox[] getCoverage(float ullat, float ullon,
					 float lrlat, float lrlon,
					 CRFPCADRGProjection p,
					 String uniqueID){

	Debug.message("crfp", "CRFPServer: Handling coverage request for client");

	currentCache = getCurrentCache(uniqueID);
	currentViewAttributes = getCurrentViewAttributes(uniqueID);
	currentCache.setViewAttributes(currentViewAttributes);

	LatLonPoint llpoint = new LatLonPoint(p.center.lat, p.center.lon);
	CADRG proj = new CADRG(llpoint, p.scale, p.width, p.height);

	Vector vector = currentCache.getCoverage(ullat, ullon, 
						 lrlat, lrlon, proj);

	return vectorToCRFPCoverageBoxes(vector);
    }

    /**
     * Method that provides all the coverage boxes that could provide
     * coverage over the given area.
     *
     * @param ullat NW latitude.
     * @param ullon NW longitude
     * @param lrlat SE latitude
     * @param lrlon SE longitude
     * @param p a CADRG projection
     * @param uniqueID a client-unique identifier.  
     */
    public CRFPCoverageBox[] getCatalogCoverage(float ullat, float ullon,
						float lrlat, float lrlon,
						CRFPCADRGProjection p,
						String chartSeriesCode,
						String uniqueID){

	Debug.message("crfp", "CRFPServer: handling catalog request for client");
	currentCache = getCurrentCache(uniqueID);
	currentViewAttributes = getCurrentViewAttributes(uniqueID);
	currentCache.setViewAttributes(currentViewAttributes);

	LatLonPoint llpoint = new LatLonPoint(p.center.lat, p.center.lon);
	CADRG proj = new CADRG(llpoint, p.scale, p.width, p.height);
	Vector vector = currentCache.getCatalogCoverage(ullat, ullon, 
							lrlat, lrlon,
							proj, chartSeriesCode);
	return vectorToCRFPCoverageBoxes(vector);
    }

    /**
     * Convert a Vector of RpfCoverageBox to a CRFPCoverageBox array.
     *
     * @param vector vector of RpfCoverageBox.
     * @return array of CRFPCoverageBox.
     */
    protected CRFPCoverageBox[] vectorToCRFPCoverageBoxes(Vector vector){
	int size = vector.size();
	CRFPCoverageBox[] rets = new CRFPCoverageBox[size];
	
	for (int i = 0; i < size; i++){
	    RpfCoverageBox box = (RpfCoverageBox) vector.elementAt(i);
	    if (box != null){
		rets[i] = new CRFPCoverageBox((float) box.nw_lat,
					      (float) box.nw_lon,
					      (float) box.se_lat,
					      (float) box.se_lon,
					      box.subframeLatInterval,
					      box.subframeLonInterval,
					      box.chartCode,
					      (short)box.zone,
					      new XYPoint((short)box.startIndexes.x,
							  (short)box.startIndexes.y),
					      new XYPoint((short)box.endIndexes.x,
							  (short)box.endIndexes.y),
					      (short) box.tocNumber,
					      (short)box.entryNumber,
					      box.scale,
					      box.percentCoverage);
	    }
	}
	return rets;
    }

    /**
     * Retrieve the subframe data from the frame cache, decompress it,
     * and convert it to a JPEG image.
     * 
     * @param tocNumber the number of the RpfTocHandler for the currentCache to use.
     * @param entryNumber the coverage box index that contains the subframe.
     * @param x the horizontal location of the subframe.  The
     * RpfCacheHandler figures this out.
     * @param y the vertical location of the subframe.  The
     * RpfCacheHandler figures this out.
     * @param jpegQuality the compression parameter for the image.
     * @param uniqueID a client-unique identifier.
     * @return byte[] of jpeg image
     */
    public byte[] getSubframeData(short tocNumber, short entryNumber,
				  short x, short y, float jpegQuality, 
				  String uniqueID)
    {

	Debug.message("crfpdetail", "CRFPServer: handling subframe request for client");
	currentCache = getCurrentCache(uniqueID);
	int[] pixels =  currentCache.getSubframeData((int) tocNumber, 
						     (int) entryNumber,
						     (int) x, (int) y);
	if (pixels != null){
	    byte[] compressed = null;
	    try {
		compressed = JPEGHelper.encodeJPEG(RpfSubframe.PIXEL_EDGE_SIZE, 
						   RpfSubframe.PIXEL_EDGE_SIZE,
						   pixels, jpegQuality);
	    } catch (Exception e) {
		Debug.error("CRFPServer: JPEG Compression error: " + e);
		compressed = new byte[0];
	    } 
	    if (Debug.debugging("crfpdetail")) {
		Debug.output("CRFPServer: subframe is " + compressed.length + " bytes");
	    }
	    return compressed;
	}

	return new byte[0];
    }

    public RawImage getRawSubframeData(short tocNumber, short entryNumber,
				       short x, short y,
				       String uniqueID){
	
	Debug.message("crfpdetail", "CRFPServer: handling raw subframe request for client");
	
	currentCache = getCurrentCache(uniqueID);
	
	RawImage ri = new RawImage();
	RpfIndexedImageData riid = currentCache.getRawSubframeData((int) tocNumber, 
								   (int) entryNumber,
								   (int) x, (int) y);
	if (riid == null || riid.imageData == null){
	    Debug.message("crfpdetail", "CRFPServer: null image data");
	    ri.imagedata =  new byte[0];
	    ri.colortable = new int[0];
	} else {
	    ri.imagedata = riid.imageData;

	    RpfColortable colortable = currentCache.getColortable();
	    
	    ri.colortable = new int[colortable.colors.length];
	    for (int i = 0; i < colortable.colors.length; i++){
		ri.colortable[i] = colortable.colors[i].getRGB();
	    }
	    Debug.message("crfpdetail", "CRFPServer: GOOD image data");
	}
	return ri;
    }

    /**
     * Get the subframe attributes for the identified subframe.
     * Provided as a single string, with newline characters separating
     * features.
     *
     * @param tocNumber the number of the RpfTocHandler for the currentCache to use.
     * @param entryNumber the coverage box index that contains the subframe.
     * @param x the horizontal location of the subframe.  The
     * RpfCacheHandler figures this out.
     * @param y the vertical location of the subframe.  The
     * RpfCacheHandler figures this out.
     * @param uniqueID a client-unique identifier.
     * @return String with the subframe attributes.
     */
    public String getSubframeAttributes(short tocNumber, short entryNumber,
					short x, short y, String uniqueID){
	Debug.message("crfpdetail", "CRFPServer: handling subframe attribute request for client");

	currentCache = getCurrentCache(uniqueID);
	return currentCache.getSubframeAttributes((int) tocNumber, 
						  (int) entryNumber,
						  (int) x, (int) y);
    }

    /**
     * The signoff function lets the server know that a client is
     * checking out. 
     * @param uniqueID a client-unique identifier.
     */
    public void signoff(String uniqueID){
	Debug.message("crfp", "CRFPServer: Client" + uniqueID + " signing off!");
	caches.remove(uniqueID);
	viewAttributeLists.remove(uniqueID);
    }

    /**
     * Start the server.
     * @args command line arguments.
     */
    public void start(String[] args){

	// Initialize the ORB
	org.omg.CORBA.ORB orb = org.omg.CORBA.ORB.init();

	if (args != null){
	    parseArgs(args);
	}

	// Initialize the BOA
	boa = orb.BOA_init();

	// Export the newly created object
	boa.obj_is_ready(this);

	// write the IOR out
	if (iorfile != null) {
	    PrintWriter fs = null;
	    try {
		fs = new PrintWriter((OutputStream)new FileOutputStream(iorfile));
	    } catch (IOException e) {
		Debug.error("CRFPServer.start(): can't write ior to file " + iorfile);
		System.exit(1);
	    }
	    fs.print(orb.object_to_string(this));
	    fs.flush();
	    fs.close();
	    // // 	  Debug.output(orb.object_to_string(this));
	}

	if (naming != null) {
	    //*** Naming server stuff
	    org.omg.CORBA.Object obj = null;
	    try {
		obj = orb.resolve_initial_references("NameService");
	    } catch (org.omg.CORBA.ORBPackage.InvalidName e) {
		Debug.error("CRFPServer.start(): Invalid Name exception");
	    }
    
	    NamingContext rootContext = NamingContextHelper.narrow(obj);
	    if (rootContext== null){
// 		Debug.output("CRFPServer.start(): Root context is null!");
	    }
       
	    String temp = naming;
	    Vector components = new Vector();
	    int numcomponents = 0;
	    String temporaryTemp = null;
       
	    int tindex = temp.indexOf("/");
	    while (tindex != -1) {
		numcomponents++;
		temporaryTemp=temp.substring(0,tindex);
		components.addElement(temporaryTemp);
		temp=temp.substring(tindex+1);
		tindex = temp.indexOf("/");
	    }
	    components.addElement(temp);
       
	    //        NameComponent[] specialistName = new NameComponent[components.size()];
	    //        for (int i=0; i<components.size(); i++)
	    // 	   specialistName[i] = new NameComponent((String)(components.elementAt(i)), "");
       
       
	    NamingContext newContext = null;
	    NamingContext oldContext = rootContext;
	    for (int i = 0 ; i<components.size()-1; i++)
		{
		    NameComponent[] newName = new NameComponent[1];
		    newName[0] = new NameComponent((String)(components.elementAt(i)), "");
		    String debugName = (String)(components.elementAt(i));
		    try {
			newContext = 
			    NamingContextHelper.narrow( oldContext.resolve(newName) );
		    }
		    catch( org.omg.CosNaming.NamingContextPackage.NotFound nfe ) {
			try {
			    newContext = oldContext.bind_new_context(newName);
			} catch (org.omg.CosNaming.NamingContextPackage.AlreadyBound abe ) {
			    Debug.error("CRFPServer.start(): Already bound");
			} catch (org.omg.CosNaming.NamingContextPackage.CannotProceed cpe0 ) {
			    Debug.error("CRFPServer.start(): Cannot proceed 0");
			} catch (org.omg.CosNaming.NamingContextPackage.InvalidName ine0 ) {
			    Debug.error("CRFPServer.start(): Invalid Name 0");
			} catch (org.omg.CosNaming.NamingContextPackage.NotFound nfe0 ) {
			    Debug.error("CRFPServer.start(): Not found 0");
			}
		    }
		    catch (  org.omg.CosNaming.NamingContextPackage.InvalidName ine ) {
			Debug.error("CRFPServer.start(): Invalid name");
		    }
		    catch (  org.omg.CosNaming.NamingContextPackage.CannotProceed cpe ) {
			Debug.error("CRFPServer.start(): Cannot proceed");
		    }
		    oldContext=newContext;
		}
       
	    NameComponent[] finalName = new NameComponent[1];
	    finalName[0] = new NameComponent((String)(components.elementAt(components.size()-1)), "");
	    String debugName = (String)(components.elementAt(components.size()-1));

	    try {
		oldContext.rebind( finalName, this );
	    } catch (org.omg.CosNaming.NamingContextPackage.CannotProceed cpe1 ) {
		Debug.error("CRFPServer: Cannot proceed 1");
	    } catch (org.omg.CosNaming.NamingContextPackage.InvalidName ine1 ) {
		Debug.error("CRFPServer: Invalid Name 1");
	    } catch (org.omg.CosNaming.NamingContextPackage.NotFound nfe1 ) {
		Debug.error("CRFPServer: Not found 1");
	    }
	}
       
	// Announce ourselves to the world
	Debug.output(this + " is ready.");
	
	// Wait for incoming requests
	boa.impl_is_ready();
    }
    
    /**
     */
    public void parseArgs(String[] args) {
	rpfpaths = null;
	for (int i = 0; i < args.length; i++) {
	    if (args[i].equalsIgnoreCase("-ior")) {
		iorfile = args[++i];
	    } else if (args[i].equalsIgnoreCase("-name")) {
		naming = args[++i];
	    } else if (args[i].equalsIgnoreCase("-help")) {
		printHelp();
	    } else  if (args[i].equalsIgnoreCase("-rpfpaths")) {
		rpfpaths = getPaths(args[++i]);
	    } else if (args[i].equalsIgnoreCase("-h")) {
		printHelp();
	    }
	}
	
	// if you didn't specify an iorfile
	if (iorfile == null && naming == null) {
	    Debug.error("CRFPServer: IOR file and name service name are null!  Use `-ior' or '-name' flag!");
	    System.exit(-1);
	}

	if (rpfpaths == null){
	    Debug.error("CRFPServer: No RPF directory paths specified!  Use `-rpfpaths' flag!");
	    System.exit(-1);
	} else {
	    tocs = RpfFrameCacheHandler.createTocHandlers(rpfpaths);
	    Debug.output("CRFPServer: CRFPServer!  Running with paths => ");
	    for (int j = 0; j < rpfpaths.length; j++){
		Debug.output("     " + rpfpaths[j]);
	    }
	}
    }
    
    private String[] getPaths (String str) {
	StringTokenizer tok = new StringTokenizer(str, ";");
	int len = tok.countTokens();
	String[] paths = new String[len];
	for (int j=0; j<len; j++) {
	    paths[j] = tok.nextToken();
	}
	return paths;
    }

    /** 
     * <b>printHelp</b> should print a usage statement which reflects the
     * command line needs of your specialist. 
     */
    public void printHelp() {
	Debug.output("usage: java CRFPServer [-ior <file> || -name <NAME>] -rpfpaths \"<path to rpf dir>;<path to rpf dir>;<...>\"");
	System.exit(1);
    }

    public static void main (String[] args) {
	Debug.init(System.getProperties());

	// Create the specialist server
	CRFPServer srv = new CRFPServer("CRFPServer");
	srv.start(args);
    }

}

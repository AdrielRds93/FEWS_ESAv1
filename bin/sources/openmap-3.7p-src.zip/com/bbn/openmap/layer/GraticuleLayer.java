/* **********************************************************************
 * 
 *  BBNT Solutions LLC, A part of GTE
 *  10 Moulton St.
 *  Cambridge, MA 02138
 *  (617) 873-2000
 * 
 *  Copyright (C) 1998-2000
 *  This software is subject to copyright protection under the laws of 
 *  the United States and other countries.
 * 
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/GraticuleLayer.java,v $
 * $Revision: 1.19 $
 * $Date: 2000/05/25 22:15:10 $
 * $Author: dietrick $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer;

import com.bbn.openmap.LatLonPoint;
import com.bbn.openmap.Layer;
import com.bbn.openmap.MoreMath;
import com.bbn.openmap.event.InfoDisplayEvent;
import com.bbn.openmap.event.LayerStatusEvent;
import com.bbn.openmap.event.ProjectionEvent;
import com.bbn.openmap.layer.util.LayerUtils;
import com.bbn.openmap.omGraphics.OMGraphic;
import com.bbn.openmap.omGraphics.OMGraphicList;
import com.bbn.openmap.omGraphics.OMPoly;
import com.bbn.openmap.omGraphics.OMText;
import com.bbn.openmap.proj.Cylindrical;
import com.bbn.openmap.proj.Projection;
import com.bbn.openmap.util.Debug;
import com.bbn.openmap.util.PaletteHelper;
import com.bbn.openmap.util.SwingWorker;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JPanel;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


/**
 * Layer that draws graticule lines.  If the showRuler property is
 * set to true, then longitude values are displayed on the bottom of
 * the map, and latitude values are displayed on the left side.  If
 * the show1And5Lines property is true, then 5 degree lines are drawn
 * when there are &lt;= threshold ten degree latitude or longitude lines,
 * and 1 degree lines are drawn when there are &lt;= threshold five
 * degree latitude or longitude degree lines.
 *
 * <P> The openmap.properties file can control the layer with the
 * following settings:
 * <code><pre>
 * # Show lat / lon spacing labels
 * graticule.showRuler=true
 * graticule.show1And5Lines=true
 * # Controls when the five degree lines and one degree lines kick in
 * #- when there is less than the threshold of ten degree lat or lon
 * #lines, five degree lines are drawn.  The same relationship is there
 * #for one to five degree lines.
 * graticule.threshold=2
 * # the color of 10 degree spacing lines (Hex ARGB)
 * graticule.10DegreeColor=FF000000
 * # the color of 5 degree spacing lines (Hex ARGB)
 * graticule.5DegreeColor=C7009900
 * # the color of 1 degree spacing lines (Hex ARGB)
 * graticule.1DegreeColor=C7003300
 * # the color of the equator (Hex ARGB)
 * graticule.equatorColor=FFFF0000
 * # the color of the international dateline (Hex ARGB)
 * graticule.dateLineColor=7F000099
 * # the color of the special lines (Hex ARGB)
 * graticule.specialLineColor=FF000000
 * # the color of the labels (Hex ARGB)
 * graticule.textColor=FF000000
 * </pre></code>
 * In addition, you can get this layer to work with the OpenMap viewer
 * by editing your openmap.properties file:
 * <code><pre>
 * # layers
 * openmap.layers=graticule ...
 * # class
 * graticule.class=com.bbn.openmap.layer.GraticuleLayer
 * # name
 * graticule.prettyName=Graticule
 * </pre></code>
 *
 */
public class GraticuleLayer extends Layer implements ActionListener{

    // default to not showing the ruler (mimicing older GraticuleLayer)
    protected boolean defaultShowRuler = false;
    protected boolean defaultShowOneAndFiveLines = false;
    protected int defaultThreshold = 2;

    /** Flag for lineType - true is LINETYPE_STRAIGHT, false is
     * LINETYPE_GREATCIRCLE. */
    private boolean boxy = true;
    /** Threshold is the total number of ten lines on the screen before the
     * five lines appear, and the total number of five lines on the screen
     * before the one lines appear.
     * */
    protected int threshold = defaultThreshold;
    /** Swing worker containing the separate thread to do the work. */
    protected GraticuleWorker currentWorker = null;
    /** Projection that gets set on a projection event. */
    protected Projection projection;
    /** Set when the projection has changed while a swing worker is
     * gathering graphics, and we want him to stop early. */
    protected boolean cancelled = false;
    /** The complete list of lines and markers, which will include the
     *  other two lists. */
    protected OMGraphicList omgraphics = new OMGraphicList(0);
    /** The ten degree latitude and longitude lines, premade. */
    protected OMGraphicList tenDegreeLines = null;
    /** The equator, dateline and meridian lines, premade. */
    protected OMGraphicList markerLines = null;

    private final static int SHOW_TENS = 0;
    private final static int SHOW_FIVES = 1;
    private final static int SHOW_ONES = 2;

    protected boolean showOneAndFiveLines = defaultShowOneAndFiveLines;
    protected boolean showRuler = defaultShowRuler;

    protected Font font = new Font("Helvetica", java.awt.Font.PLAIN, 10);

    // Color variables for different line types
    protected Color tenDegreeColor = null;
    protected Color fiveDegreeColor = null;
    protected Color oneDegreeColor = null;
    protected Color equatorColor = null;
    protected Color dateLineColor = null;
    protected Color specialLineColor = null; // Tropic of Cancer, Capricorn
    protected Color textColor = null;

    // Default colors to use, if not specified in the properties.
    protected String defaultTenDegreeColorString = "000000";
    protected String defaultFiveDegreeColorString = "33009900";
    protected String defaultOneDegreeColorString = "33003300";
    protected String defaultEquatorColorString = "990000";
    protected String defaultDateLineColorString = "000099";
    protected String defaultSpecialLineColorString = "000000"; 
    protected String defaultTextColorString = "000000";

    // property text values
    public static final String TenDegreeColorProperty = ".10DegreeColor";
    public static final String FiveDegreeColorProperty = ".5DegreeColor";
    public static final String OneDegreeColorProperty = ".1DegreeColor";
    public static final String EquatorColorProperty = ".equatorColor";
    public static final String DateLineColorProperty = ".datelineColor";
    public static final String SpecialLineColorProperty = ".specialLineColor";
    public static final String TextColorProperty = ".textColor";
    public static final String ThresholdProperty = ".threshold";
    public static final String ShowRulerProperty = ".showRuler";
    public static final String ShowOneAndFiveProperty = ".show1And5Lines";

    /** Since we can't have the main thread taking up the time to
     * create images, we use this worker thread to do it.
     * */
    class GraticuleWorker extends SwingWorker {

	/** Constructor used to create a worker thread. */
	public GraticuleWorker () {
	    super();
	}

	/**  Compute the value to be returned by the <code>get</code>
	 * method.  */
	public Object construct() {
	    Debug.message("graticule", getName()+
			  "|GraticuleWorker.construct()");
	    fireStatusUpdate(LayerStatusEvent.START_WORKING);
	    try {
		return constructGraticuleLines();
	    } catch (OutOfMemoryError e) {
		String msg = getName() + 
		    "|GraticuleLayer.GraticuleWorker.construct(): " + e;
		Debug.error(msg);
		e.printStackTrace();
		fireRequestMessage(new InfoDisplayEvent(this, msg));
		fireStatusUpdate(LayerStatusEvent.FINISH_WORKING);
		return null;
	    }
	}

	/** Called on the event dispatching thread (not on the worker
	 * thread) after the <code>construct</code> method has
	 * returned.  */
	public void finished() {
	    workerComplete(this);
	    fireStatusUpdate(LayerStatusEvent.FINISH_WORKING);
	}
    }

    /**
     * Construct the GraticuleLayer.
     */
    public GraticuleLayer() {
	// precalculate for boxy
	boxy = true;
    }

    /** 
     * The properties and prefix are managed and decoded here, for
     * the standard uses of the GraticuleLayer.
     *
     * @param prefix string prefix used in the properties file for this layer.
     * @param properties the properties set in the properties file.  
     */
    public void setProperties(String prefix, java.util.Properties properties) {
	super.setProperties(prefix, properties);

	tenDegreeColor = LayerUtils.parseColorFromProperties(
	    properties,
	    prefix + TenDegreeColorProperty,
	    defaultTenDegreeColorString);	
	
	fiveDegreeColor = LayerUtils.parseColorFromProperties(
	    properties,
	    prefix + FiveDegreeColorProperty,
	    defaultFiveDegreeColorString);
	
	oneDegreeColor = LayerUtils.parseColorFromProperties(
	    properties,
	    prefix + OneDegreeColorProperty,
	    defaultOneDegreeColorString);	
	
	equatorColor = LayerUtils.parseColorFromProperties(
	    properties,
	    prefix + EquatorColorProperty,
	    defaultEquatorColorString);	
	
	dateLineColor = LayerUtils.parseColorFromProperties(
	    properties,
	    prefix + DateLineColorProperty,
	    defaultDateLineColorString);	
	
	specialLineColor = LayerUtils.parseColorFromProperties(
	    properties,
	    prefix + SpecialLineColorProperty,
	    defaultSpecialLineColorString);	
	
	textColor = LayerUtils.parseColorFromProperties(
	    properties,
	    prefix + TextColorProperty,
	    defaultTextColorString);	

	String ThresholdString = properties.getProperty(prefix + ThresholdProperty);
	try {
	    threshold = Integer.valueOf(ThresholdString).intValue();
	} catch (NumberFormatException e) {
	    if (Debug.debugging("graticule")){
		Debug.output("GraticuleLayer: Unable to parse " + 
			     ThresholdProperty +
			       " = " + ThresholdString + 
			     ", using default value.");
	    }
	    threshold = defaultThreshold;
	}

	showOneAndFiveLines = Boolean.valueOf(properties.getProperty(
	    prefix + ShowOneAndFiveProperty, 
	    ""+defaultShowOneAndFiveLines)).booleanValue();

	showRuler = Boolean.valueOf(properties.getProperty(
	    prefix + ShowRulerProperty, 
	    ""+defaultShowRuler)).booleanValue();
    }

    /** 
     * Implementing the ProjectionPainter interface.
     */
    public synchronized void renderDataForProjection(Projection proj, java.awt.Graphics g){
	if (proj == null){
	    Debug.error("GraticuleLayer.renderDataForProjection: null projection!");
	    return;
	} else if (!proj.equals(projection)){
	    projection = proj.makeClone();
	    // Figure out which line type to use
	    if (projection instanceof Cylindrical) boxy = true;
	    else boxy = false;

	    setOMGraphics(constructGraticuleLines());
	}
	paint(g);
    }

    /**
     * Invoked when the projection has changed or this Layer has been added to
     * the MapBean.
     * <p>
     * Perform some extra checks to see if reprojection of the graphics is
     * really necessary.
     * @param e ProjectionEvent
     *
     */    
    public void projectionChanged (ProjectionEvent e) {

	// extract the projection and check to see if it's really different.
	// if it isn't then we don't need to do all the work again, just
	// repaint.
	if (projection != null){
	    if (projection.equals(e.getProjection()))
		// Nothing to do, already have it and have acted on it...
	    {
		repaint();
		return;
	    }
	}
	
	projection = e.getProjection().makeClone();

	// Figure out which line type to use
	if (projection instanceof Cylindrical) boxy = true;
	else boxy = false;

	setOMGraphics(new OMGraphicList(0));

	// If there isn't a worker thread working on this already,
	// create a thread that will do the real work. If there is
	// a thread working on this, then set the cancelled flag
	// in the layer.
	if (currentWorker == null) {
	    if (Debug.debugging("graticule")){
		Debug.output(getName() + " | updating image via projection changed...");
	    }
	    currentWorker = new GraticuleWorker();
	    currentWorker.execute();
	}
	else setCancelled(true);
    }
    
    /**  
     * The GraticuleWorker calls this method on the layer when it is
     * done working.  If the calling worker is not the same as the
     * "current" worker, then a new worker is created.
     *
     * @param worker the worker that has the graphics.
     */
    protected synchronized void workerComplete (GraticuleWorker worker) {
	if (!isCancelled()) {
	    currentWorker = null;
	    setOMGraphics((OMGraphicList)worker.get());
	    repaint();
	}
	else{
	    setCancelled(false);
	    currentWorker = new GraticuleWorker();
	    currentWorker.execute();
	}
    }

    /** 
     * Sets the list to the applicable lines and markers.
     *
     * @param graphics list of lines and markers 
     */
    public synchronized void setOMGraphics (OMGraphicList graphics) {
	omgraphics = graphics;
    }

    /** 
     * Get the current list of the applicable lines and markers.
     *
     * @return list of lines 
     */
    public synchronized OMGraphicList getOMGraphics () {
	return omgraphics;
    }

    /** 
     * Used to set the cancelled flag in the layer.  The swing worker
     * checks this once in a while to see if the projection has
     * changed since it started working.  If this is set to true, the
     * swing worker quits when it is safe. 
     */
    public synchronized void setCancelled(boolean set){
	cancelled = set;
    }

    /** Check to see if the cancelled flag has been set. */
    public synchronized boolean isCancelled(){
	return cancelled;
    }

    /**
     * Paints the layer.
     *
     * @param g the Graphics context for painting
     *
     */
    public void paint (java.awt.Graphics g) {
	Debug.message("basic", "GraticuleLayer.paint()");

	// invariant: omgraphics != null
	getOMGraphics().render(g);
    }

    /**
     * Create the graticule lines.
     * <p>
     * NOTES:
     * <ul>
     * <li>Currently graticule lines are hardcoded to 10 degree intervals.
     * <li>No thought has been given to clipping based on the view rectangle.
     * For non-boxy projections performance may be degraded at very large
     * scales.  (But we make up for this by running the task in its own
     * thread to support liveness).
     * </ul>
     * @return OMGraphicList new graphic list
     */
    private OMGraphicList constructGraticuleLines() {
	double[] llp;
	OMGraphicList newgraphics = new OMGraphicList(20);
	OMPoly currentLine; //polyline

	// Lets figure out which lines should be painted...

	if (showOneAndFiveLines || showRuler){
	    double left = projection.getUpperLeft().getLongitude();
	    double right = projection.getLowerRight().getLongitude();
	    double up = projection.getUpperLeft().getLatitude();
	    double down = projection.getLowerRight().getLatitude();

	    if (up > 80.0d) up = 80.0d;
	    if (down > 80.0d) down = 80d; // unlikely
	    if (up < -80.0d) up = -80.0d; // unlikely
	    if (down < -80) down = -80.0d;

	    int showWhichLines = evaluateSpacing(up, down, left, right);
	    
	    // Find out whether we need to do one or two queries,
	    // depending on if we're straddling the dateline.
	    if ((left > 0 && right < 0) || 
		(left > right) || 
		(Math.abs(left - right) < 1)){
		// Test to draw the ones and fives, which will also do the labels.
		if (showWhichLines != SHOW_TENS){
		    newgraphics.add(constructGraticuleLines(up, down, 
							    left, 180.0d,
							    showWhichLines));
		    newgraphics.add(constructGraticuleLines(up, down, 
							    -180.0d, right,
							    showWhichLines));
		} else if (showRuler){  // Just do the labels for the tens lines
		    newgraphics.add(constructTensLabels(up, down, 
							left, 180.0d, true));
		    newgraphics.add(constructTensLabels(up, down, 
							-180.0d, right, false));
		}
	    } else {
		// Test to draw the ones and fives, which will also do the labels.
		if (showWhichLines != SHOW_TENS){
		    newgraphics = constructGraticuleLines(up, down, left, right, 
							  showWhichLines);
		} else if (showRuler){  // Just do the labels for the tens lines
		    newgraphics.add(constructTensLabels(up, down, left, right, true));
		}
	    }
	}

	OMGraphicList list;
	if (tenDegreeLines == null) {
	    list = constructTenDegreeLines();
	    tenDegreeLines = list;
	} else {
	    synchronized(tenDegreeLines){
		setLineTypeAndProject(tenDegreeLines, boxy ? OMGraphic.LINETYPE_STRAIGHT
				      : OMGraphic.LINETYPE_RHUMB);
	    }
	}
	if (markerLines == null){
	    list = constructMarkerLines();
	    markerLines = list;
	} else {
	    synchronized(markerLines){
		setLineTypeAndProject(markerLines, boxy ? OMGraphic.LINETYPE_STRAIGHT
				      : OMGraphic.LINETYPE_RHUMB);
	    }
	}

	newgraphics.add(markerLines);
	newgraphics.add(tenDegreeLines);

	if (Debug.debugging("graticule")) {
	    Debug.output("GraticuleLayer.constructGraticuleLines(): " +
		    "constructed " + newgraphics.size() + " graticule lines");
	}

	return newgraphics;
    }

    /** 
     * Figure out which graticule lines should be drawn based on the
     * treshold set in the layer, and the coordinates of the screen.
     * Method checks for crossing of the dateline, but still assumes
     * that the up and down latitude coordinates are less than
     * abs(+/-80).  This is because the projection shouldn't give
     * anything above 90 degrees, and we limit the lines to less than
     * 80..
     *
     * @param up northern latitude corrdinate, in decimal degrees,
     * @param down southern latitude coordinate, in decimal degrees.
     * @param left western longitude coordinate, in decimal degrees,
     * @param right eastern longitude coordinate, in decimal degrees.
     * @return which lines should be shown, either SHOW_TENS,
     * SHOW_FIVES and SHOW_ONES.  
     */
    protected int evaluateSpacing(double up, double down,
				  double left, double right){
	int ret = SHOW_TENS;

	// Set the flag for when labels are wanted, but not the 1 and
	// 5 lines;
	if (!showOneAndFiveLines){
	    return ret;
	}

	// Find the north - south difference
	double nsdiff = up - down;
	// And the east - west difference
	double ewdiff;
	// Check for straddling the dateline -west is positive while
	// right is negative, or, in a big picture view, the west is
	// positive, east is positive, and western hemisphere is
	// between them.
	if ((left > 0 && right < 0) || 
	    (left > right) || 
	    (Math.abs(left - right) < 1)){
	    ewdiff = (180.0d - left) + (right + 180.0d);
	} else {
	    ewdiff = right - left;
	}

	// And use the lesser of the two.
	double diff = (nsdiff < ewdiff)?nsdiff:ewdiff;
	// number of 10 degree lines
	if ((diff/10) <= (double)threshold) ret = SHOW_FIVES;
	// number of five degree lines
	if ((diff/5) <= (double)threshold) ret = SHOW_ONES;

	return ret;
    }

    /** 
     * Construct the five degree and one degree graticule lines,
     * depending on the showWhichLines setting. Assumes that the
     * coordinates passed in do not cross the dateline, and that the
     * up is not greater than 80 and that the south is not less than
     * -80.
     *
     * @param up northern latitude corrdinate, in decimal degrees,
     * @param down southern latitude coordinate, in decimal degrees.
     * @param left western longitude coordinate, in decimal degrees,
     * @param right eastern longitude coordinate, in decimal degrees.
     * @param showWhichLines indicator for which level of lines should
     * be included, either SHOW_FIVES or SHOW_ONES.  SHOW_TENS could
     * be there, too, but then we wouldn't do anything.  
     */
    private OMGraphicList constructGraticuleLines(double up, double down,
						  double left, double right,
						  int showWhichLines){
	OMGraphicList lines = new OMGraphicList();

	// Set the line limits for the lat/lon lines...
	int north = (int)Math.ceil(up);
	if (north > 80) north = 80;

	int south = (int)Math.floor(down);
	south -= (south%10); // Push down to the lowest 10 degree line.
	// for neg numbers, Mod raised it, lower it again.  Also
	// handle straddling the equator.
	if ((south < 0 && south > -80) || south == 0) south -= 10; 

	int west = (int)Math.floor(left);
	west -= (west%10);
	// for neg numbers, Mod raised it, lower it again.  Also
	// handle straddling the prime meridian.
	if ((west < 0 && west > -180) || west == 0) west -= 10;

	int east = (int)Math.ceil(right);
	if (east > 180) east = 180;

	int stepSize;
	// Choose how far apart the lines will be.
	stepSize = ((showWhichLines == SHOW_ONES)? 1:5);
	double[] llp;
	OMPoly currentLine;
	OMText currentText;

	// For calculating text locations
	java.awt.Point point;
	LatLonPoint llpoint;

	// generate other parallels of latitude be creating series
	// of polylines
	for (int i = south; i < north; i += stepSize) {
	    double lat = (double)i;
	    // generate parallel of latitude North/South of the equator
	    if (west < 0 && east > 0){
		llp = new double[6];
		llp[2] = lat; llp[3] = 0d;
		llp[4] = lat; llp[5] = east;
	    } else {
		llp = new double[4];
		llp[2] = lat; llp[3] = east;
	    }
	    llp[0] = lat; llp[1] = west;

	    // Do not duplicate the 10 degree line.
	    if ((lat%10) != 0){
		currentLine = new OMPoly(llp, OMGraphic.DECIMAL_DEGREES,
					 boxy ? OMGraphic.LINETYPE_STRAIGHT
					 : OMGraphic.LINETYPE_RHUMB);
		if ((lat%5) == 0){
		    currentLine.setLineColor(fiveDegreeColor);
		} else {
		    currentLine.setLineColor(oneDegreeColor);
		}
		lines.addOMGraphic(currentLine);
	    }

	    if (showRuler && (lat%2) == 0){
		if (boxy){
		    point = projection.forward(lat, west);
		    point.x = 0;
		    llpoint = projection.inverse(point);
		} else {
		    llpoint = new LatLonPoint(lat, west);
		    while (projection.forward(llpoint).x < 0){
			llpoint.setLongitude(llpoint.getLongitude() + stepSize);
		    }
		}
		
		currentText = new OMText(llpoint.getLatitude(), llpoint.getLongitude(),
                2, -2, // Move them up a little
					 Integer.toString((int)lat),
					 font, OMText.JUSTIFY_LEFT);
		currentText.setLineColor(textColor);
		lines.addOMGraphic(currentText);
	    }
	}
	
	// generate lines of longitude
	for (int i = west; i < east; i += stepSize) {
	    double lon = (double)i;
	    
	    if (north < 0 && south > 0){
		llp = new double[6];
		llp[2] = 0d; llp[3] = lon;
		llp[4] = south; llp[5] = lon;
	    } else {
		llp = new double[4];
		llp[2] = south; llp[3] = lon;
	    }
	    llp[0] = north; llp[1] = lon;
	    
	    if ((lon%10) != 0){
		currentLine = new OMPoly(llp, OMGraphic.DECIMAL_DEGREES,
					 boxy ? OMGraphic.LINETYPE_STRAIGHT
					 : OMGraphic.LINETYPE_GREATCIRCLE);
		if ((lon%5) == 0){
		    currentLine.setLineColor(fiveDegreeColor);
		} else {
		    currentLine.setLineColor(oneDegreeColor);
		}
		lines.addOMGraphic(currentLine);
	    }

	    if (showRuler && (lon%2) == 0){
		if (boxy){
		    point = projection.forward(south, lon);
		    point.y = projection.getHeight();
		    llpoint = projection.inverse(point);
		} else {
		    llpoint = new LatLonPoint(south, lon);
		    while (projection.forward(llpoint).y > projection.getHeight()){
			llpoint.setLatitude(llpoint.getLatitude() + stepSize);
		    }
		}
		
		currentText = new OMText(llpoint.getLatitude(), llpoint.getLongitude(),
                2, -5, // Move them up a little
					 Integer.toString((int)lon),
					 font, OMText.JUSTIFY_CENTER);
		currentText.setLineColor(textColor);
		lines.addOMGraphic(currentText);

	    }
	}

	if (Debug.debugging("graticule")) {
	    Debug.output("GraticuleLayer.constructTenDegreeLines(): " +
		    "constructed " + lines.size() + " graticule lines");
	}
	lines.generate(projection);
	return lines;
    }

    /** Create the ten degree lines. */
    protected OMGraphicList constructTenDegreeLines(){

	OMGraphicList lines = new OMGraphicList(3);
	OMPoly currentLine;

	// generate other parallels of latitude by creating series
	// of polylines
	for (int i = 1; i <= 8; i++) {
	    for (int j = -1; j < 2; j += 2) {
		double lat = (double)(10*i*j);
		// generate parallel of latitude North/South of the equator
		double[] llp = {lat, -180d,
			       lat, -90d,
			       lat, 0d,
			       lat, 90d,
			       lat, 180d};
		currentLine = 	new OMPoly(llp, OMGraphic.DECIMAL_DEGREES,
					   boxy ? OMGraphic.LINETYPE_STRAIGHT
					   : OMGraphic.LINETYPE_RHUMB);
		currentLine.setLineColor(tenDegreeColor);
		lines.addOMGraphic(currentLine);
	    }
	}

	// generate lines of longitude
	for (int i = 1; i < 18; i++) {
	    for (int j = -1; j < 2; j += 2) {
		double lon = (double)(10*i*j);
		//not quite 90.0 for beautification reasons.
		double[] llp = {80d, lon,
			       0d,  lon,
			       -80d, lon};
		if (MoreMath.approximately_equal(Math.abs(lon), 90d, 0.001d)) {
		    llp[0] = 90d;
		    llp[4] = -90d;
		}
		currentLine = new OMPoly(llp, OMGraphic.DECIMAL_DEGREES,
					 boxy ? OMGraphic.LINETYPE_STRAIGHT
					 : OMGraphic.LINETYPE_GREATCIRCLE);
		currentLine.setLineColor(tenDegreeColor);
		lines.addOMGraphic(currentLine);
	    }
	}

	if (Debug.debugging("graticule")) {
	    Debug.output("GraticuleLayer.constructTenDegreeLines(): " +
		    "constructed " + lines.size() + " graticule lines");
	}
	lines.generate(projection);
	return lines;
    }

    /** 
     * Constructs the labels for the tens lines.  Called from within
     * the constructGraticuleLines if the showRuler variable is true.
     * Usually called only if the ones and fives lines are not being
     * drawn.
     *
     * @param up northern latitude corrdinate, in decimal degrees,
     * @param down southern latitude coordinate, in decimal degrees.
     * @param left western longitude coordinate, in decimal degrees,
     * @param right eastern longitude coordinate, in decimal degrees.  
     * @param doLats do the latitude labels if true.
     * @return OMGraphicList of labels.
     */
    protected OMGraphicList constructTensLabels(double up, double down,
						double left, double right,
						boolean doLats){

	OMGraphicList labels = new OMGraphicList();

	// Set the line limits for the lat/lon lines...
	int north = (int)Math.ceil(up);
	if (north > 80) north = 80;

	int south = (int)Math.floor(down);
	south -= (south%10); // Push down to the lowest 10 degree line.
	// for neg numbers, Mod raised it, lower it again
	if ((south < 0 && south > -70) || south == 0){
	    south -= 10; 
	}

	int west = (int)Math.floor(left);
	west -= (west%10);
	// for neg numbers, Mod raised it, lower it again
	if ((west < 0 && west > -170) || west == 0){
	    west -= 10;
	}

	int east = (int)Math.ceil(right);
	if (east > 180) east = 180;

	int stepSize = 10;
	OMText currentText;

	// For calculating text locations
	java.awt.Point point;
	LatLonPoint llpoint;

	if (doLats){

	    // generate other parallels of latitude be creating series
	    // of labels
	    for (int i = south; i < north; i += stepSize) {
		double lat = (double)i;
		
		if ((lat%2) == 0){
		    if (boxy){
			point = projection.forward(lat, west);
			point.x = 0;
			llpoint = projection.inverse(point);
		    } else {
			llpoint = new LatLonPoint(lat, west);
			while (projection.forward(llpoint).x < 0){
			    llpoint.setLongitude(llpoint.getLongitude() + stepSize);
			}
		    }
		    
		    currentText = new OMText(llpoint.getLatitude(), llpoint.getLongitude(),
                    2, -2, // Move them up a little
					     Integer.toString((int)lat),
					     font, OMText.JUSTIFY_LEFT);
		    currentText.setLineColor(textColor);
		    labels.addOMGraphic(currentText);
		}
	    }
	}
	
	// generate labels of longitude
	for (int i = west; i < east; i += stepSize) {
	    double lon = (double)i;
	    
	    if ((lon%2) == 0){
		if (boxy){
		    point = projection.forward(south, lon);
		    point.y = projection.getHeight();
		    llpoint = projection.inverse(point);
		} else {
		    llpoint = new LatLonPoint(south, lon);
		    while (projection.forward(llpoint).y > projection.getHeight()){
			llpoint.setLatitude(llpoint.getLatitude() + stepSize);
		    }
		}
		
		currentText = new OMText(llpoint.getLatitude(), llpoint.getLongitude(),
                2, -5, // Move them up a little
					 Integer.toString((int)lon),
					 font, OMText.JUSTIFY_CENTER);
		currentText.setLineColor(textColor);
		labels.addOMGraphic(currentText);

	    }
	}

	if (Debug.debugging("graticule")) {
	    Debug.output("GraticuleLayer.constructTensLabels(): " +
		    "constructed " + labels.size() + " graticule labels");
	}
	labels.generate(projection);
	return labels;
    }

    /** Constructs the Dateline and Prime Meridian lines. */
    protected OMGraphicList constructMarkerLines(){

	OMGraphicList lines = new OMGraphicList(3);
	OMPoly currentLine;

	// generate Prime Meridian and Dateline
	for (int j = 0; j < 360; j += 180) {
	    double lon = (double)j;
	    double[] llp = {90d, lon,
			   0d,  lon,
			   -90d, lon};
	    currentLine = new OMPoly(llp, OMGraphic.DECIMAL_DEGREES,
				     boxy ? OMGraphic.LINETYPE_STRAIGHT
				     : OMGraphic.LINETYPE_GREATCIRCLE);
	    currentLine.setLineColor(dateLineColor);
	    lines.addOMGraphic(currentLine);
	}

	// equator
	double[] llp = {0d, -180d,
		       0d, -90d,
		       0d, 0d,
		       0d, 90d,
		       0d, 180d};
	// polyline
	currentLine = new OMPoly(llp, OMGraphic.DECIMAL_DEGREES,
				 boxy ? OMGraphic.LINETYPE_STRAIGHT
				 : OMGraphic.LINETYPE_GREATCIRCLE);
	currentLine.setLineColor(equatorColor);
	lines.addOMGraphic(currentLine);

	if (Debug.debugging("graticule")) {
	    Debug.output("GraticuleLayer.constructMarkerLines(): " +
		    "constructed " + lines.size() + " graticule lines");
	}
	lines.generate(projection);
	return lines;
    }

    /** 
     * Take a graphic list, and set all the items on the list to the
     * line type specified, and project them into the current
     * projection.
     * 
     * @param list the list containing the lines to change.
     * @param lineType the line type to cahnge the lines to.  */
    protected void setLineTypeAndProject(OMGraphicList list, int lineType){
	int size = list.size();
	OMGraphic graphic;
	for (int i = 0; i < size; i++){
	    graphic = list.getOMGraphicAt(i);
	    graphic.setLineType(lineType);
	    graphic.generate(projection);
	}
    }


    //----------------------------------------------------------------------
    // GUI
    //----------------------------------------------------------------------

    /** The user interface palette for the DTED layer. */
    protected Box palette = null;

    /** Creates the interface palette. */
    public java.awt.Component getGUI() {

	if (palette == null){
	    if (Debug.debugging("graticule"))
		Debug.output("GraticuleLayer: creating Graticule Palette.");

 	    palette = Box.createVerticalBox();

	    JPanel layerPanel = PaletteHelper.createPaletteJPanel("Graticule Layer Options");
	    
	    ActionListener al = new ActionListener(){
		public void actionPerformed(ActionEvent e){
		    String ac = e.getActionCommand();
		    
		    if (ac.equalsIgnoreCase(ShowRulerProperty)){
			JCheckBox jcb = (JCheckBox)e.getSource();
			showRuler = jcb.isSelected();
		    } else if (ac.equalsIgnoreCase(ShowOneAndFiveProperty)){
			JCheckBox jcb = (JCheckBox)e.getSource();
			showOneAndFiveLines = jcb.isSelected();
		    } else {
			Debug.error("Unknown action command \"" + ac +
					   "\" in GraticuleLayer.actionPerformed().");
		    }
		}
	    };

	    JCheckBox showRulerButton = new JCheckBox("Show Lat/Lon Labels", 
						      showRuler);
	    showRulerButton.addActionListener(al);
	    showRulerButton.setActionCommand(ShowRulerProperty);

	    JCheckBox show15Button = new JCheckBox("Show 1, 5 Degree Lines", 
						   showOneAndFiveLines);
	    show15Button.addActionListener(al);
	    show15Button.setActionCommand(ShowOneAndFiveProperty);


	    layerPanel.add(showRulerButton);
	    layerPanel.add(show15Button);
	    palette.add(layerPanel);

	    Box subbox3 = Box.createHorizontalBox();
	    JButton redraw = new JButton("Redraw Graticule Layer");
	    redraw.addActionListener(this);
	    subbox3.add(redraw);
	    palette.add(subbox3);
	}
	return palette;
    }

    //----------------------------------------------------------------------
    // ActionListener interface implementation
    //----------------------------------------------------------------------
    
    /**
     * Used just for the redraw button.
     */
    public void actionPerformed (ActionEvent e) {
	if (currentWorker == null) {
	    fireStatusUpdate(LayerStatusEvent.START_WORKING);
	    currentWorker = new GraticuleWorker();
	    currentWorker.execute();
	}
	else setCancelled(true);
    }

}

/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBN Technologies
 * 			    A Division of
 * 			   BBN Corporation
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998 by BBN Technologies, A Division of
 * 		BBN Corporation, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/location/db/LocationData.java,v $
 * $RCSfile: LocationData.java,v $
 * $Revision: 1.2 $
 * $Date: 2000/07/13 21:11:38 $
 * $Author: dietrick $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.location.db;

import java.sql.*;
import java.util.Properties;

/** 
 * This class is responsible for retrieving Latitude and Longitude
 * Data from a table in a Database given a City/Town name, State.
 * Also it retrieves identifier of the object that would be used to
 * represent this City/Town on Map.  For instance, identifier can be
 * either a url or a name that can be looked up somewhere else.  
 * <P>
 * This class needs the RecordSet to be called with the following query:<BR>
 * select CITY (string), STATE (string), GRAPHIC (string, url or graphic name), LATITUDE (double), LONGITUDE (double) from LOCATION_TABLE (tablename where data is stored)<BR>
 * The class is expecting the results in this order.
 */
public class LocationData {

    /** Connection object that will be used to retrieve data. */
    protected Connection connection;

    /* variables that would hold current values of record set*/	
    protected String cityName, stateName, graphicName;
    protected double latitude, longitude;
    protected String queryString = null;
    
    private Statement stmt;
    private ResultSet rset;

    public LocationData() {}
    
    public LocationData(Connection inConnection){
	connection = inConnection;
    }
    
    public LocationData (RecordSet drs) throws SQLException {

	ResultSet rset = drs.getResultSet();

	cityName = rset.getString(1);
	stateName = rset.getString(2);
	graphicName = rset.getString(3);
	latitude = rset.getFloat(4);
	longitude = rset.getFloat(5);
    }
    
    public void close() throws SQLException {	
	rset.close();
	stmt.close();
    }
    
    public Connection getConnection(){
	return connection;
    }
    
    public void setConnection(Connection inConnection){
	connection = inConnection;
    }
    
    /** 
     * @return city name of current record 
     */
    public String getCityName(){
	return cityName;
    }	

    public String getStateName(){	
	return stateName;
    }
    
    public String getGraphicName(){
	return graphicName;
    }

    public double getLatitude(){
	return latitude;
    }
    
    public double getLongitude(){
	return longitude;
    }
    
    public String getQueryString(){
	return queryString;
    }
    
    public void setQueryString(String inQueryString){
	queryString = inQueryString;
    }

    public String toString(){
	StringBuffer s = new StringBuffer();
	s.append("Location Data values:\n");    
	s.append(" City Name = " + cityName + "\n"); 
	s.append(" State Name = " + stateName + "\n");
	s.append(" Graphic = " + graphicName + "\n");
	s.append(" Latitude = " + latitude + "\n");
	s.append(" Longitude = " + longitude + "\n");
	return s.toString();
    }

    public static void main(String[] args){
	System.out.println("\n*** LocationData looks for the following query: ***\n");
	System.out.println(" select CITY (string), STATE (string), GRAPHIC (string, url or graphic name), LATITUDE (double), LONGITUDE (double) from LOCATION_TABLE (tablename where data is stored)\n");
	System.out.println("Note: Column names and tablename should reflect whatever is stored in the database.  Data types should match what this class is expecting, in the order listed here.\n");
    }

}

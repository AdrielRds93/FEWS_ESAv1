/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/location/ByteRasterLocation.java,v $
 * $Revision: 1.6 $
 * $Date: 2000/08/02 15:49:51 $
 * $Author: dietrick $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.location;

/*  Java Core  */
import java.io.*;
import java.net.URL;
import javax.swing.ImageIcon;
import java.awt.Point;

/*  OpenMap  */
import com.bbn.openmap.omGraphics.OMRaster;
import com.bbn.openmap.omGraphics.OMRasterObject;
import com.bbn.openmap.omGraphics.OMGraphic;
import com.bbn.openmap.layer.DeclutterMatrix;
import com.bbn.openmap.proj.Projection;

/**
 * A Location that takes a byte array and creates a Raster for a
 * Location marker.  
 */
public class ByteRasterLocation extends Location {

    public ByteRasterLocation(double latitude, double longitude,
			     String name, byte bytearr[]){
	super(latitude, longitude, name, getIconRaster(latitude, longitude, bytearr));

	if (location instanceof OMRaster){
	    label.setX(label.getX() + 
		       (((OMRaster)location).getWidth()/2) + DEFAULT_SPACING);
	}

    }
    
    public ByteRasterLocation(int x, int y, String name, 
			     byte bytearr[]){
	super(x, y, name, getIconRaster(x, y, bytearr));

	if (location instanceof OMRaster){
	    label.setX(label.getX() + 
		       (((OMRaster)location).getWidth()/2) + DEFAULT_SPACING);
	}
    }

    public ByteRasterLocation(double latitude, double longitude,
			     int xOffset, int yOffset, String name, 
			     byte bytearr[]){
	super(latitude, longitude, xOffset, yOffset, name, 
	      getIconRaster(latitude, longitude, xOffset, yOffset, bytearr));

	if (location instanceof OMRaster){
	    label.setX(label.getX() + 
		       (((OMRaster)location).getWidth()/2) + DEFAULT_SPACING);
	}
    }

    public static OMRaster getIconRaster(double lat, double lon, byte bytearr[]){

	ImageIcon icon = getIconRaster(bytearr);
	if (icon == null) return null;

	int offX = icon.getIconWidth() / 2;
	int offY = icon.getIconHeight() / 2;
	return new OMRaster(lat, lon, -offX, -offY, icon);
    }

    public static OMRaster getIconRaster(int x, int y, byte bytearr[]){
	ImageIcon icon = getIconRaster(bytearr);
	if (icon == null) return null;

	int offX = icon.getIconWidth() / 2;
	int offY = icon.getIconHeight() / 2;
	return new OMRaster(x-offX, y-offY, icon);
    }

    public static OMRaster getIconRaster(double lat, double lon,
					 int x, int y, byte bytearr[]){
	ImageIcon icon = getIconRaster(bytearr);
	if (icon == null) return null;

	int offX = icon.getIconWidth() / 2;
	int offY = icon.getIconHeight() / 2;
	return new OMRaster(lat, lon, x-offX, y-offY, icon);
    }

    public static ImageIcon getIconRaster(byte bytearr[]){	
	if (bytearr == null) return null;
	ImageIcon icon = new ImageIcon(bytearr);
	return icon;
    }

    /**
     * Given the label is this location has a height and width, find
     * a clean place on the map for it.  Assumes label is not null.
     *
     * @param declutter the DeclutterMatrix for the map.
     */
    protected void declutterLabel(DeclutterMatrix declutter, Projection proj){

	super.declutterLabel(declutter, proj);
	
	if (isShowLocation()){
	    // Take up space with the label
	    if (location instanceof OMRasterObject){
		Point lp = ((OMRasterObject)location).getMapLocation();
		// This location is the upper left location of the
		// declutter matrix.  The decutter matrix works from
		// lower left to upper right.
		if (lp != null){
		    int locHeight = ((OMRasterObject)location).getHeight();
		    int locWidth = ((OMRasterObject)location).getWidth();
		    // Need to get this right for the DeclutterMatrix
		    // space, but changing lp changes where the
		    // location will appear - fix this later.
		    lp.y += locHeight;
		    declutter.setTaken(lp, locWidth, locHeight);
		    // Reset it to the original projected location.
		    lp.y -= locHeight;
		}
	    }
	}
    }

    public void setGraphicLocations(double latitude, double longitude){
	if (location instanceof OMRaster){
	    OMRaster ras = (OMRaster) location;
	    ras.setLat(latitude);
	    ras.setLon(longitude);

	    label.setLat(latitude);
	    label.setLon(longitude);
	    label.setX(label.getX() + 
		       (ras.getWidth()/2) + DEFAULT_SPACING);

	}
    }

    public void setGraphicLocations(int x, int y){
	if (location instanceof OMRaster){
	    OMRaster ras = (OMRaster) location;
	    ras.setX(x);
	    ras.setY(y);

	    label.setX(x);
	    label.setY(y);
	    label.setX(label.getX() + 
		       (ras.getWidth()/2) + DEFAULT_SPACING);

	}
    }

    public void setGraphicLocations(double latitude, double longitude,
				    int offsetX, int offsetY){
	if (location instanceof OMRaster){
	    OMRaster ras = (OMRaster) location;
	    ras.setLat(latitude);
	    ras.setLon(longitude);
	    ras.setX(offsetX);
	    ras.setY(offsetY);

	    label.setLat(latitude);
	    label.setLon(longitude);
	    label.setX(offsetX);
	    label.setY(offsetY);
	    label.setX(label.getX() + 
		       (ras.getWidth()/2) + DEFAULT_SPACING);

	}
    }
}

/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/location/csv/CSVLinkHandler.java,v $
 * $Revision: 1.6 $
 * $Date: 2000/05/08 14:22:37 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.location.csv;


/*  Java Core  */
import com.bbn.openmap.layer.location.Link;
import com.bbn.openmap.omGraphics.OMGraphic;
import com.bbn.openmap.util.CSVTokenizer;
import com.bbn.openmap.util.Debug;
import com.bbn.openmap.util.quadtree.QuadTree;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;

/*  OpenMap  */

/**  
 * The CSVLinkHandler is designed to let you put data on the map based
 * on information from a Comma Separated Value(CSV) file.  It's
 * assumed that the each row in the file refers to two locations, and
 * that a link is to be shown between the two locations.
 *
 * <P>The individual fields must not have leading whitespace.
 *
 * <P>The locationFile property should contain a URL referring to the file.
 * This can take the form of file:/myfile.csv for a local file or
 * http://somehost.org/myfile.csv for a remote file.
 *
 * <P>In the openmap.properties file (for instance):<BR>
 * csvlocationlayer.class=com.bbn.openmap.layer.csvLocation.CSVLocationLayer<BR>
 * 
 * If there is a lat1/lon1 index, and a lat2/lon2 index, then the links'
 * endpoints are in the link file.  
 */

public class CSVLinkHandler extends CSVLocationHandler {

    ////////////////////////
    // Link Variables

    /** Property to use to designate the column of the link file to use
     * as the latitude of end "1". */
    public static final String Lat1IndexProperty = ".lat1Index";
    /** Property to use to designate the column of the link file to use
     * as the longitude of end "1". */
    public static final String Lon1IndexProperty = ".lon1Index";
    /** Property to use to designate the column of the link file to use
     * as the latitude of end "2". */
    public static final String Lat2IndexProperty = ".lat2Index";
    /** Property to use to designate the column of the link file to use
     * as the longitude of end "2". */
    public static final String Lon2IndexProperty = ".lon2Index";
    public static final String linkTypeIndexProperty = ".linkTypeIndex";
    public static final String DashIndexProperty = ".dashIndex";
    public static final String ColorIndexProperty = ".colorIndex";
    public static final String ThicknessIndexProperty = ".thicknessIndex";
    public static final String GeoStyleIndexProperty = ".geoStyleIndex";

    /** The names of the various link types on the map */
    public static final String LinkTypesProperty = ".linkTypes";
    
    /** Index of column in CSV to use as latitude1 of link. */
    protected int lat1Index = -1;
    /** Index of column in CSV to use as longitude1 of link. */
    protected int lon1Index = -1;
    /** Index of column in CSV to use as latitude2 of link. */
    protected int lat2Index = -1;
    /** Index of column in CSV to use as longitude2 of link. */
    protected int lon2Index = -1;
    /** Index of column in CSV to use as the type of link. */
    protected int linkTypeIndex = -1;
    /** Index of column in CSV to use as the line-type to draw a link in. */
    protected int geoStyleIndex = -1;
    
    protected int dashIndex = -1;
    protected int colorIndex = -1;
    protected int thicknessIndex = -1;

    /** 
     * The default constructor for the Layer.  All of the attributes
     * are set to their default values.
     */
    public CSVLinkHandler () {}

    /** 
     * The properties and prefix are managed and decoded here, for
     * the standard uses of the CSVLinkHandler.
     *
     * @param prefix string prefix used in the properties file for this layer.
     * @param properties the properties set in the properties file.  
     */
    public void setProperties(String prefix,
			      java.util.Properties properties) {
	super.setProperties(prefix, properties);


	String lat1IndexString =
	    properties.getProperty(prefix + Lat1IndexProperty);
	String lon1IndexString =
	    properties.getProperty(prefix + Lon1IndexProperty);
	String lat2IndexString =
	    properties.getProperty(prefix + Lat2IndexProperty);
	String lon2IndexString =
	    properties.getProperty(prefix + Lon2IndexProperty);
	
	// This will replace the three properties below it. 
	String linkTypeIndexString =
	    properties.getProperty(prefix + linkTypeIndexProperty);

	// These will be removed.
	String dashIndexString =
	    properties.getProperty(prefix + DashIndexProperty);
	String colorIndexString =
	    properties.getProperty(prefix + ColorIndexProperty);
	String thicknessIndexString =
	    properties.getProperty(prefix + ThicknessIndexProperty);
	String geoStyleIndexString = 
	    properties.getProperty(prefix + GeoStyleIndexProperty);
	
	lat1Index     = -1;
	lon1Index     = -1;
	lat2Index     = -1;
	lon2Index     = -1;
	colorIndex    = -1;
	dashIndex	= -1;
	thicknessIndex	= -1;
	geoStyleIndex	= -1;

	// Check to make sure we have enough indexes specified.
	if (lat1IndexString != null && lon1IndexString != null) {
	    try {
		lat1Index = Integer.valueOf(lat1IndexString).intValue();
		lon1Index = Integer.valueOf(lon1IndexString).intValue();
	    }
	    catch (NumberFormatException e) {
		Debug.error
		    ("CSVLinkHandler: Unable to parse node1Index string.");
	    }
	} else {
	    Debug.error
		("CSVNodeLayer: no Index-1 specified as lat/lon or node");
	}
	
	if (lat2IndexString != null && lon2IndexString != null) {
	    try {
		lat2Index = Integer.valueOf(lat2IndexString).intValue();
		lon2Index = Integer.valueOf(lon2IndexString).intValue();
	    }
	    catch (NumberFormatException e) {
		Debug.error
		    ("CSVLinkHandler: Unable to parse node2Index string.");
	    }
	} else {
	    Debug.error
		("CSVNodeLayer: no Index-2 specified as lat/lon or node");
	}
	
	if ( linkTypeIndexString != null ){
	    try {
		linkTypeIndex = Integer.valueOf(linkTypeIndexString).intValue();
	    }
	    catch (NumberFormatException e) {
		Debug.error
		    ("CSVLinkHandler: Unable to parse linkTypeIndex string.");
	    }
	} else {
	    Debug.error ("CSVNodeLayer: no linkTypeIndex specified");
	}   

	if ( geoStyleIndexString != null ){
	    try {
		geoStyleIndex = Integer.valueOf(geoStyleIndexString).intValue();
	    }
	    catch (NumberFormatException e) {
		Debug.error
		    ("CSVLinkHandler: Unable to parse geoStyleIndex string.");
	    }
	} else {
	    Debug.error ("CSVNodeLayer: no geoStyleIndex specified");
	}   

	// These will be removed too... 
	if ( dashIndexString != null ){
	    try {
		dashIndex = Integer.valueOf(dashIndexString).intValue();
	    }
	    catch (NumberFormatException e) {
		Debug.error
		    ("CSVLinkHandler: Unable to parse dashIndex string.");
	    }
	} else {
	    Debug.error ("CSVNodeLayer: no dashIndex specified");
	}   

	if ( colorIndexString != null ){
	    try {
		colorIndex = Integer.valueOf(colorIndexString).intValue();
	    }
	    catch (NumberFormatException e) {
		Debug.error
		    ("CSVLinkHandler: Unable to parse colorIndex string.");
	    }
	} else {
	    Debug.error ("CSVNodeLayer: no colorIndex specified");
	}  
	
	if ( thicknessIndexString != null ){
	    try {
		thicknessIndex = Integer.valueOf(thicknessIndexString).intValue();
	    }
	    catch (NumberFormatException e) {
		Debug.error
		    ("CSVLinkHandler: Unable to parse thicknessIndex string.");
	    }
	} else {
	    Debug.error ("CSVNodeLayer: no thicknessIndex specified");
	}   
    }

    /**
     * This is called by the CSVLinkWorker to load the CSV file
     */
    protected QuadTree createData(){
	
	QuadTree qt = new QuadTree(90.0d, -180.0d, -90.0d, 180.0d, 100, 50d);

	try {
	    Object token = null;

	    // This lets the property be specified as a file name
	    // even if it's not specified as file:/<name> in
	    // the properties file.
	    URL csvURL = new URL(new URL("file:"), locationFile); 
	    CSVTokenizer csvt =
	      new CSVTokenizer(new BufferedReader
			       (new InputStreamReader
				(csvURL.openStream())));

	    double lat1 = 0;
	    double lon1 = 0;
	    double lat2 = 0;
	    double lon2 = 0;
	    String linkType = "";
	    int linetype = OMGraphic.LINETYPE_STRAIGHT;
	    Color color = Color.black;
	    boolean dashed = false;
	    float thickness = 0;

	    Link link = null;
	    
	    token = csvt.token();

	if (Debug.debugging("link")){
	    Debug.output("CSVLinkHandler: Reading File:" + locationFile
			       + " lat1Index: " + lat1Index
			       + " lon1Index: " + lon1Index
			       + " lat2Index: " + lat2Index
			       + " lon2Index: " + lon2Index
			       + " geoStyleIndex: " + geoStyleIndex
			       // + " linkTypeIndex: " + linkTypeIndex
			       + " dashIndex: " + dashIndex
			       + " colorIndex: " + colorIndex
			       + " thicknessIndex: " + thicknessIndex);
	}
	    
	    
	    while (!csvt.isEOF(token)){
		int i = 0;

		Debug.message("link", "CSVLinkHandler: Starting a line");
		
		while (!csvt.isNewline(token)){
		    
		    try {
			if (i == lat1Index)
			    lat1 = ((Double)token).floatValue();
			else if (i == lon1Index)
			    lon1 = ((Double)token).floatValue();
			else if (i == lat2Index)
			    lat2 = ((Double)token).floatValue();
			else if (i == lon2Index)
			    lon2 = ((Double)token).floatValue();
			else if (i == geoStyleIndex) 
			    linetype = GetLineTypeFromToken(token);
			
			// These are going to go away... 
			else if (i == colorIndex) 
			    color  = GetColorFromToken(token);
			else if (i == thicknessIndex)
			    thickness = ((Double)token).floatValue();
			else if (i == dashIndex)
			    dashed = Boolean.valueOf((String)token).booleanValue();
			
		    } catch (Exception e) {
			e.printStackTrace(); 
		    }

		    token = csvt.token();
		    i++;
		}


		link = new Link(lat1, lon1, lat2, lon2, "no details",
				color, dashed, thickness, linetype);
		link.setLocationHandler(this);
 		Debug.message("link", "CSVLinkHandler: " + link.getDetails());

 		qt.put(lat1, lon1, link);
 		qt.put(lat2, lon2, link);
		token = csvt.token();
	    }
	} catch (java.io.IOException ioe){
	    new com.bbn.openmap.util.HandleError(ioe);
	} catch (ArrayIndexOutOfBoundsException aioobe){
	    new com.bbn.openmap.util.HandleError(aioobe);
	} catch (NumberFormatException nfe){
	    new com.bbn.openmap.util.HandleError(nfe);
	} catch (ClassCastException cce){
	    new com.bbn.openmap.util.HandleError(cce);
	}
	Debug.message("link", "CSVLinkHandler: Finished File:" + locationFile);
	return qt;
    }

    /** 
     * Provides the palette widgets to control the options of showing
     * maps, or attribute text.
     * <P>
     * In this case, the palette widget only contains one button, 
     * which reloads the data files for the layer. 
     * <p>
     * @return Component object representing the palette widgets.
     */
    public java.awt.Component getGUI() {
	JButton rereadFilesButton;
	JCheckBox showCSVLinkCheck;
	
	showCSVLinkCheck = new JCheckBox("Show Links", isShowLocations());
	showCSVLinkCheck.setActionCommand(showLocationsCommand);
	showCSVLinkCheck.addActionListener(this);
	
	rereadFilesButton = new JButton("Re-Read Data File");
	rereadFilesButton.setActionCommand(readDataCommand);
	rereadFilesButton.addActionListener(this);
	Box box = Box.createVerticalBox();
	box.add(showCSVLinkCheck);
	box.add(rereadFilesButton);
	return box;
    }

    //----------------------------------------------------------------------
    // ActionListener interface implementation
    //----------------------------------------------------------------------

    /** 
     * The Action Listener method, that reacts to the palette widgets
     * actions.
     */
    public void actionPerformed (ActionEvent e) {
	String cmd = e.getActionCommand();
	if (cmd == showLocationsCommand) {		
	    JCheckBox linkCheck = (JCheckBox)e.getSource();
	    setShowLocations(linkCheck.isSelected());
	    if(Debug.debugging("location")){
	    	Debug.output("CSVLinkHandler::actionPerformed showLocations is "
				   + isShowLocations());
	    }
	    getLayer().repaint();
	}else if (cmd == readDataCommand) {
	    Debug.output("Re-reading links file");
	    quadtree = null;
	    getLayer().doPrepare();
	} else {
	    Debug.error("Unknown action command \"" + cmd +
			       "\" in CSVLinkLayer.actionPerformed().");
	}
    }

    /* Utility functions */

    /** 
     * This gets a line-type from a token, and translates it into one of 
     * LINETYPE_STRAIGHT, LINETYPE_GREATCIRCLE, or LINETYPE_RHUMB
     * <p>
     * @param token the token read from teh CSV file. 
     * <p>
     * @return one of LINETYPE_STRAIGHT, LINETYPE_GREATCIRCLE, or LINETYPE_RHUMB
     */

    protected int GetLineTypeFromToken (Object token){
	int default_lintetype = OMGraphic.LINETYPE_STRAIGHT;
	String tokstring = (String)token;

	if (Debug.debugging("link")){
	    Debug.output("CSVLinkHandler:GetLineTypeFromToken(" + 
			       tokstring + ")");
	}
	
	if (tokstring.equals("STRAIGHT"))
	    return OMGraphic.LINETYPE_STRAIGHT;
	else if (tokstring.equals("GC"))
	    return OMGraphic.LINETYPE_GREATCIRCLE;
	else if (tokstring.equals("RHUMB"))
	    return OMGraphic.LINETYPE_RHUMB;
	else {
	    Debug.error("Don't understand Linetype " 
			       + tokstring + ", using default (STRAIGHT)");
	    return default_lintetype;
	}
    }
    


    /**  
     * This interprets a color value from a token. The color can be
     * one of the standard colors in the java.awt.Color class, or it
     * can be a hexadecimal representation of any other displayable
     * color.
     * <p>
     * @param token the token read from the CSV file. 
     * <p>
     * @return the java.awt.Color described by that token, or Color.black 
     * (if the token cannot be translated into a proper color).
     */

    protected Color GetColorFromToken(Object token){
	String tokstring = (String)token;
	
	Color result = Color.black;
	
	if (Debug.debugging("link")){
	    Debug.output("CSVLinkHandler: GetColorFromToken(" + 
			       tokstring + ")");
	}

	// Thank the heavens for Emacs macros!
	if (tokstring.equals("black"))
	    result =  Color.black;
	else if (tokstring.equals("blue"))
	    result =  Color.blue;
	else if (tokstring.equals("cyan"))
	    result =  Color.cyan;
	else if (tokstring.equals("darkGray"))
	    result =  Color.darkGray;
	else if (tokstring.equals("gray"))
	    result =  Color.gray;
	else if (tokstring.equals("green"))
	    result =  Color.green;
	else if (tokstring.equals("lightGray"))
	    result =  Color.lightGray;
	else if (tokstring.equals("magenta"))
	    result =  Color.magenta;
	else if (tokstring.equals("orange"))
	    result =  Color.orange;
	else if (tokstring.equals("pink"))
	    result =  Color.pink;
	else if (tokstring.equals("red"))
	    result =  Color.red;
	else if (tokstring.equals("white"))
	    result =  Color.white;
	else if (tokstring.equals("yellow"))
	    result =  Color.yellow;
	else
	    // decode a hex color string.
	    result = Color.decode(tokstring);
	
	if (Debug.debugging("link")){
	    Debug.output("CSVLinkHandler: GetColorFromToken returns (" + 
			       result + ")");
	}

	return result;
    }
  
}

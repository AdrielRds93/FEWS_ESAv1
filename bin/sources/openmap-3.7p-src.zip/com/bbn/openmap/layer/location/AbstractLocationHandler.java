/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/location/AbstractLocationHandler.java,v $
 * $Revision: 1.2 $
 * $Date: 2000/07/13 21:27:28 $
 * $Author: dietrick $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.location;

/*  Java Core  */
import java.awt.Color;
import java.awt.Component;
import java.util.Properties;
import java.util.Vector;
import java.util.Enumeration;

import javax.swing.JPanel;
import javax.swing.JLabel;

import com.bbn.openmap.layer.location.LocationHandler;
import com.bbn.openmap.layer.location.LocationLayer;
import com.bbn.openmap.layer.location.LocationPopupMenu;
import com.bbn.openmap.layer.util.LayerUtils;

/**
 * The <tt>AbstractLocationHandler</tt> class facilitates the
 * implementation of a <code>LocationHandler</code> by implementing a
 * number of methods.  By extending this class, a developer need only
 * implement get(), setProperties(), and reloadData().
 * <P>
 *
 * @see         com.bbn.openmap.layer.location.LocationHandler
 * @version    $Revision: 1.2 $ $Date: 2000/07/13 21:27:28 $
 * @author     Michael E. Los D530/23448
 *
 * locationhandler.locationColor=FF0000<BR>
 * locationhandler.nameColor=008C54<BR>
 * locationhandler.showNames=false<BR>
 * locationhandler.showLocations=true<BR>
 */
public abstract class AbstractLocationHandler implements LocationHandler{
    
    /** The parent layer. */
    protected LocationLayer zLayer;
    
    // - - - - - - - - - - - - - -
    // Name-related Variables
    // - - - - - - - - - - - - - -
    /** The default setting for the labels at startup. */
    private boolean showNames = false;
    /** The color for the names. */
    protected Color nameColor;
    
    // - - - - - - - - - - - - - -
    // Location-related Variables
    // - - - - - - - - - - - - - -
    /** The default setting for the locations at startup. */
    private boolean showLocations = true;
    /** The color for the locations. */
    protected Color locationColor;
    
    /**
     * The location layer passes a LocationPopupMenu to the handler
     * when on of its locations has been clicked on.  This is an
     * opportunity for the handler to add options to the menu that can
     * bring up further information about the location, or to change
     * the appearance of the location.  This implementation makes no
     * changes to the popup menu.
     *
     * @param lpm LocationPopupMenu to add buttons to.
     */
    public void fillLocationPopUpMenu(LocationPopupMenu lpm) {}
    
    /**
     * Set the layer the handler is responding to.  This is needed in
     * case the handler has updates that it wants to show, and needs
     * to trigger a repaint.  It can also be used to communicate with
     * the information delegator.
     *
     * @param layer a LocationLayer
     */
    public void setLayer(LocationLayer l){
	zLayer = l;
    }
    
    /** Get the layer the handler is serving. */
    public LocationLayer getLayer(){
	return zLayer;
    }
    
    /**
     * See if the handler is displaying labels at a global level.
     */
    public boolean isShowNames(){
	return showNames;
    }
    
    /**
     * Set the handler to show/hide labels at a global level.
     */
    public void setShowNames(boolean set){
	showNames = set;
    }
    
    /**
     * See if the handler is displaying location graphics at a global
     * level.
     */
    public boolean isShowLocations(){
	return showLocations;
    }
    
    /**
     * Set the handler to show/hide location graphics at a global
     * level.
     */
    public void setShowLocations(boolean set){
	showLocations = set;
    }

    /**
     * Set the color used for the name label.
     */
    public void setNameColor(Color nColor){
	nameColor = nColor;
    }

    /**
     * Get the color used for the name label.
     */
    public Color getNameColor(){
	return nameColor;
    }

    /**
     * Set the color used for the location graphic.
     */
    public void setLocationColor(Color lColor){
	locationColor = lColor;
    }

    /**
     * Get teh color used for the location graphic.
     */
    public Color getLocationColor(){
	return locationColor;
    }
    
    /** 
     * Set up the properties of the handler.
     * Supported properties include:
     * <UL>
     * <LI>locationColor - number of seconds between attempts to retrieve
     Features data
     * <LI>featuresSvcURL - URL to invoke to retrieve the XML Features
     document
     * </UL>
     */
    public void setProperties(String prefix, Properties properties){
	showLocations = 
	    LayerUtils.booleanFromProperties(properties,
					     prefix + ShowLocationsProperty,
					     showLocations);
	
	locationColor = 
	    LayerUtils.parseColorFromProperties(properties,
						prefix + LocationColorProperty,
						defaultLocationColorString);
	
	showNames = LayerUtils.booleanFromProperties(properties,
						     prefix + ShowNamesProperty,
						     showNames);
	
	nameColor = LayerUtils.parseColorFromProperties(properties,
							prefix + NameColorProperty,
							defaultNameColorString);
    }
    
    /**
     * A set of controls to manipulate and control the display of data
     * from the handler. This implementation returns a JPanel with a
     * "No Palette" message.
     *
     * @return a JPanel with text, No Pallette
     */
    public java.awt.Component getGUI(){
	// LocationLayer.java chokes if we return null
	JPanel jp = new JPanel();
	jp.add(new JLabel("No Palette"));
	return jp;
    }
}




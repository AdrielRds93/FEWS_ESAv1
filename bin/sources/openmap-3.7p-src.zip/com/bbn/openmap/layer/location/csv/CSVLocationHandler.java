/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/location/csv/CSVLocationHandler.java,v $
 * $Revision: 1.9 $
 * $Date: 2000/08/16 21:25:26 $
 * $Author: pmanghwa $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.location.csv;


/*  Java Core  */
import java.awt.Point;
import java.awt.Component;
import java.awt.Color;
import java.awt.event.*;
import java.util.StringTokenizer;
import java.util.Properties;
import java.util.Vector;
import java.util.Enumeration;
import java.io.*;
import java.net.URL;

/*  OpenMap  */
import com.bbn.openmap.util.Debug;
import com.bbn.openmap.util.SwingWorker;
import com.bbn.openmap.util.CSVTokenizer;
import com.bbn.openmap.util.quadtree.QuadTree;
import com.bbn.openmap.layer.util.LayerUtils;
import com.bbn.openmap.*;
import com.bbn.openmap.event.*;
import com.bbn.openmap.proj.*;
import com.bbn.openmap.omGraphics.OMRect;
import com.bbn.openmap.omGraphics.OMText;
import com.bbn.openmap.omGraphics.OMGraphic;
import com.bbn.openmap.omGraphics.OMGraphicList;
import com.bbn.openmap.layer.DeclutterMatrix;
import com.bbn.openmap.layer.location.*;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JPopupMenu;
import javax.swing.JMenuItem;
import javax.swing.Box;
import javax.swing.SwingUtilities;

/**  
 * The CSVLocationLayer is a LocationHandler designed to let you put
 * data on the map based on information from a Comma Separated
 * Value(CSV) file.  It's assumed that the each row in the file refers
 * to a certain location, and that location contains a name label, a
 * latitude and a longitude (both in decimal degrees).
 *
 * <P>The individual fields must not have leading whitespace.
 *
 * <P>The CSVLocationLayer gives you some basic functionality.  The
 * properties file lets you set defaults on whether to draw the
 * locations and the names by default.  For crowded layers, having all
 * the names displayed might cause a cluttering problem.  In gesture
 * mode, OpenMap will display the name of each location as the mouse
 * is passed over it.  Pressing the left mouse button over a location
 * brings up a popup menu that lets you show/hide the name label, and
 * also to display the entire row contents of the location CSV file in
 * a Browser window that OpenMap launches.
 *
 * <P>If you want to extend the functionality of this LocationHandler,
 * there are a couple of methods to focus your changes: The
 * setProperties() method lets you add properties to set from the
 * properties file.  The createData() method, by default, is a
 * one-time method that creates the graphic objects based on the CSV
 * data.  By modifying these methods, and creating a different
 * combination graphic other than the CSVLocation, you can create
 * different layer effects pretty easily.
 *
 * <P>The locationFile property should contain a URL referring to the file.
 * This can take the form of file:/myfile.csv for a local file or
 * http://somehost.org/myfile.csv for a remote file.
 *
 * <P>In the openmap.properties file (for instance):<BR>
 * <BR>
 * # In the section for the LocationLayer:<BR>
 * locationLayer.locationHandlers=csvlocationhandler<BR>
 * <BR>
 * csvlocationhandler.class=com.bbn.openmap.layer.location.csv.CSVLocationHandler<BR>
 * csvlocationhandler.locationFile=/data/worldpts/WorldLocs_point.csv<BR>
 * csvlocationhandler.locationColor=FF0000<BR>
 * csvlocationhandler.nameColor=008C54<BR>
 * csvlocationhandler.showNames=false<BR>
 * csvlocationhandler.showLocations=true<BR>
 * csvlocationhandler.nameIndex=0<BR>
 * csvlocationhandler.latIndex=8<BR>
 * csvlocationhandler.lonIndex=10<BR>
 */
public class CSVLocationHandler extends AbstractLocationHandler
    implements LocationHandler, ActionListener {
        	
    /** The path to the primary CSV file holding the locations. */
    protected String locationFile;
    /** The property describing the locations of location data. */
    public static final String LocationFileProperty = ".locationFile";
    /** The storage mechanism for the locations. */
    protected QuadTree quadtree = null;
    
    ///////////////////////
    // Name label variables

    /** Index of column in CSV to use as name of location. */
    protected int nameIndex = -1;
    /** Property to use to designate the column of the CSV file to use
     * as a name. */
    public static final String NameIndexProperty = ".nameIndex";


    ////////////////////////
    // Location Variables
		
    /** Property to use to designate the column of the CSV file to use
     * as the latitude. */
    public static final String LatIndexProperty = ".latIndex";
    /** Property to use to designate the column of the CSV file to use
     * as the longitude. */
    public static final String LonIndexProperty = ".lonIndex";
    /** Property to use to designate the column of the CSV file to use
     * as an icon URL */
    public static final String IconIndexProperty = ".iconIndex";
    /** Index of column in CSV to use as latitude of location. */
    protected int latIndex = -1;
    /** Index of column in CSV to use as logitude of location. */
    protected int lonIndex = -1;
    /** Index of column in CSV to use as URL of the icon. */
    protected int iconIndex = -1;

    /** 
     * The default constructor for the Layer.  All of the attributes
     * are set to their default values.
     */
    public CSVLocationHandler () {}

    /** 
     * The properties and prefix are managed and decoded here, for
     * the standard uses of the CSVLocationHandler.
     *
     * @param prefix string prefix used in the properties file for this layer.
     * @param properties the properties set in the properties file.  
     */
    public void setProperties(String prefix,
			      java.util.Properties properties) {
	super.setProperties(prefix, properties);
	locationFile = properties.getProperty(prefix + LocationFileProperty);
	
	latIndex = LayerUtils.intFromProperties(properties, 
						prefix + LatIndexProperty, -1);
	lonIndex = LayerUtils.intFromProperties(properties, 
						prefix + LonIndexProperty, -1);
	
	iconIndex = LayerUtils.intFromProperties(properties, 
						prefix + IconIndexProperty, -1);

	nameIndex = LayerUtils.intFromProperties(properties, 
						prefix + NameIndexProperty, -1);
    }
    
    public void reloadData(){
	quadtree = createData();
    }
    
    /**
     * Look at the CSV file and create the QuadTree holding all the
     * Locations.
     */
    protected QuadTree createData(){
	
	QuadTree qt = new QuadTree(90.0d, -180.0d, -90.0d, 180.0d, 100, 50d);

	if (latIndex == -1 || lonIndex == -1){
	    Debug.error
		("CSVLocationHandler: createData():  "
		 + "Index properties for Lat/Lon/Name are not set properly!");
	    return null;
	}
	BufferedReader streamReader = null;
	try {
	    Object token = null;

	    // This lets the property be specified as a file name
	    // even if it's not specified as file:/<name> in
	    // the properties file.
	    URL csvURL = new URL(new URL("file:"), locationFile); 
	    streamReader = new BufferedReader(new InputStreamReader(csvURL.openStream()));
	    CSVTokenizer csvt = new CSVTokenizer(streamReader);

	    String name = null;
	    double lat = 0;
	    double lon = 0;
	    URLRasterLocation loc = null;
	    String iconURL = null;
	    
	    token = csvt.token();

	    Debug.message("csvlocation", "CSVLocationHandler: Reading File:" 
			  + locationFile
			  + " NameIndex: " + nameIndex
			  + " latIndex: " + latIndex
			  + " lonIndex: " + lonIndex
			  + " iconIndex: " + iconIndex);
	    
	    while (!csvt.isEOF(token)){
		int i = 0;

		Debug.message("csvlocation", "CSVLocationHandler| Starting a line");
		
		while (!csvt.isNewline(token) && !csvt.isEOF(token)){
	    
		    if (i == nameIndex)
			name = (String)token;
		    else if (i == latIndex)
			lat = ((Double)token).floatValue();
		    else if (i == lonIndex)
			lon = ((Double)token).floatValue();
		    else if (i == iconIndex)
			iconURL = (String)token;
		    
		    token = csvt.token();
		    // For some reason, the check above doesn't always
		    // work
		    if (csvt.isEOF(token)) break;
		    i++;
		}

// 		Debug.output(iconURL);
		loc = new URLRasterLocation(lat, lon, name, iconURL);
		loc.setLocationHandler(this);
		loc.setLocationColor(getLocationColor());
		loc.getLabel().setLineColor(getNameColor());
		loc.setDetails(name + " is at lat: " + lat
			       + ", lon: " + lon);

		if(iconURL != null) {
		    loc.setDetails(loc.getDetails()
				   + " icon: "
				   + iconURL);
		}

 		Debug.message("csvlocation", "CSVLocationHandler loc.getDetails()");

 		qt.put(lat, lon, loc);
		token = csvt.token();
	    }
	} catch (java.io.IOException ioe){
	    new com.bbn.openmap.util.HandleError(ioe);
	} catch (ArrayIndexOutOfBoundsException aioobe){
	    new com.bbn.openmap.util.HandleError(aioobe);
	} catch (NumberFormatException nfe){
	    new com.bbn.openmap.util.HandleError(nfe);
	} catch (ClassCastException cce){
	    new com.bbn.openmap.util.HandleError(cce);
	}

	Debug.message("csvlocation",
		      "CSVLocationHandler | Finished File:" + locationFile);
	try {	      
	    if(streamReader != null){
		streamReader.close();
	    }
	} catch(java.io.IOException ioe) {
	    new com.bbn.openmap.util.HandleError(ioe);
	}
		
	return qt;
    }

    /**  
     * @param ranFile the file to be read.  The file pointer shoutd be
     * set to the line you want read.
     * @return Array of strings representing the values between the
     * commas.
     * */
    protected String[] readCSVLineFromFile(BufferedReader ranFile, 
					   String[] retPaths) {
	if (ranFile != null) {

	    try {
		String newLine = ranFile.readLine();
		if (newLine == null) return null;
		StringTokenizer token = new StringTokenizer(newLine, ",");
		int numPaths = token.countTokens();

		if (retPaths == null) {
		    retPaths = new String[numPaths];
		} else numPaths = retPaths.length;
		for (int i = 0; i < numPaths; i++){
		    retPaths[i] = token.nextToken();
		}		    
	    } catch (java.io.IOException ioe) {
		return null;
	    } catch (java.util.NoSuchElementException nsee){
		Debug.output("CSVLocationHandler: readCSVLineFromFile: oops");
	    }
	}
	return retPaths;
    }

    /**
     * Prepares the graphics for the layer.  This is where the
     * getRectangle() method call is made on the location.  <p>
     * Occasionally it is necessary to abort a prepare call.  When
     * this happens, the map will set the cancel bit in the
     * LayerThread, (the thread that is running the prepare).  If this
     * Layer needs to do any cleanups during the abort, it should do
     * so, but return out of the prepare asap.
     *
     */
    public Vector get(double nwLat, double nwLon, double seLat, double seLon,
		      Vector graphicList){
	
	// IF the quadtree has not been set up yet, do it!
	if (quadtree == null){
	    Debug.output("CSVLocationHandler: Figuring out the locations and names! (This is a one-time operation!)");
	    quadtree = createData();
	}

	if (quadtree != null){
	    if (Debug.debugging("csvlocation")) {
		Debug.output("CSVLocationHandler|CSVLocationHandler.get() ul.lon = "
				   + nwLon + " lr.lon = " + seLon +
				   " delta = " + (seLon - nwLon)); 
	    }

	    quadtree.get(nwLat, nwLon, seLat, seLon, graphicList);
	}
	return graphicList;
    }

    public void fillLocationPopUpMenu (LocationPopupMenu locMenu) {

	LocationCBMenuItem lcbi = new LocationCBMenuItem(LocationHandler.showname, 
							 locMenu, 
							 getLayer());
	lcbi.setState(locMenu.getLoc().isShowName());
	locMenu.add(lcbi);
	locMenu.add(new LocationMenuItem(showdetails, locMenu, getLayer()));
    }

    protected Box box = null;

   /** 
     * Provides the palette widgets to control the options of showing
     * maps, or attribute text.
     * 
     * @return Component object representing the palette widgets.
     */
    public java.awt.Component getGUI() {
	if (box == null){
	    JCheckBox showCSVLocationCheck, showNameCheck;
	    JButton rereadFilesButton;
	    
	    showCSVLocationCheck = new JCheckBox("Show Locations", isShowLocations());
	    showCSVLocationCheck.setActionCommand(showLocationsCommand);
	    showCSVLocationCheck.addActionListener(this);
	    
	    showNameCheck = new JCheckBox("Show Location Names", isShowNames());
	    showNameCheck.setActionCommand(showNamesCommand);
	    showNameCheck.addActionListener(this);
	    
	    rereadFilesButton = new JButton("Reload Data From Source");
	    rereadFilesButton.setActionCommand(readDataCommand);
	    rereadFilesButton.addActionListener(this);
	    
	    box = Box.createVerticalBox();
	    box.add(showCSVLocationCheck);
	    box.add(showNameCheck);
	    box.add(rereadFilesButton);
	}
	return box;
    }

    //----------------------------------------------------------------------
    // ActionListener interface implementation
    //----------------------------------------------------------------------

    /** 
     * The Action Listener method, that reacts to the palette widgets
     * actions.
     */
    public void actionPerformed (ActionEvent e) {
	String cmd = e.getActionCommand();
	if (cmd == showLocationsCommand) {		
	    JCheckBox locationCheck = (JCheckBox)e.getSource();
	    setShowLocations(locationCheck.isSelected());	        
	    if(Debug.debugging("location")){
	    	Debug.output("CSVLocationHandler::actionPerformed showLocations is "
				   + isShowLocations());
	    }
	    getLayer().repaint();
	} else if (cmd == showNamesCommand) {
	    JCheckBox namesCheck = (JCheckBox)e.getSource();
	    setShowNames(namesCheck.isSelected());
	    if(Debug.debugging("location")){
	    	Debug.output("CSVLocationHandler::actionPerformed showNames is "
			     + isShowNames());
	    }
	    getLayer().repaint();
	} else if (cmd == readDataCommand) {
	    Debug.output("Re-reading Locations file");
	    quadtree = null;
	    getLayer().doPrepare();
	} else 	{
	    Debug.error("Unknown action command \"" + cmd +
			       "\" in LocationLayer.actionPerformed().");
	}
    }

}

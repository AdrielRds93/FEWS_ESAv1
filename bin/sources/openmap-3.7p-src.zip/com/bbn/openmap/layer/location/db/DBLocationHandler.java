/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/location/db/DBLocationHandler.java,v $
 * $Revision: 1.7 $
 * $Date: 2000/05/25 22:26:31 $
 * $Author: dietrick $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.location.db;


/*  Java Core  */
import java.awt.Color;
import java.awt.Component;
import java.awt.Point;
import java.awt.event.*;
import java.io.*;
import java.net.URL;
import java.sql.*;
import java.util.Enumeration;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.Vector;

/*  OpenMap  */
import com.bbn.openmap.*;
import com.bbn.openmap.event.*;
import com.bbn.openmap.layer.DeclutterMatrix;
import com.bbn.openmap.layer.location.*;
import com.bbn.openmap.layer.util.LayerUtils;
import com.bbn.openmap.omGraphics.OMGraphic;
import com.bbn.openmap.omGraphics.OMGraphicList;
import com.bbn.openmap.omGraphics.OMRect;
import com.bbn.openmap.omGraphics.OMText;
import com.bbn.openmap.proj.*;
import com.bbn.openmap.util.Debug;
import com.bbn.openmap.util.SwingWorker;
import com.bbn.openmap.util.quadtree.QuadTree;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import javax.swing.SwingUtilities;

/** 
 * The DBLocationLayer is a LocationHandler designed to let you put
 * data on the map based on information from a Database.  The
 * properties file lets you set defaults on whether to draw the
 * locations and the names by default.  For crowded layers, having all
 * the names displayed might cause a cluttering problem.  In gesture
 * mode, OpenMap will display the name of each location as the mouse
 * is passed over it.  Pressing the left mouse button over a location
 * brings up a popup menu that lets you show/hide the name label, and
 * also to display attributes of the location in a Browser window that
 * OpenMap launches.
 *
 * <P>If you want to extend the functionality of this LocationHandler,
 * there are a couple of methods to focus your changes: The
 * setProperties() method lets you add properties to set from the
 * properties file.  The createData() method, by default, is a
 * one-time method that creates the graphic objects based on the data.
 * By modifying these methods, and creating a different combination
 * graphic other than the default LocationDataRecordSet, you can
 * create different layer effects pretty easily.
 *
 * <P>In the openmap.properties file (for instance):<BR>
 * <BR>
 * # In the section for the LocationLayer:<BR>
 * locationLayer.locationHandlers=dblocationhandler<BR>
 * <BR>
 * dblocationhandler.class=com.bbn.openmap.layer.location.db.DBLocationHandler<BR>
 * dblocationhandler.locationColor=FF0000<BR>
 * dblocationhandler.nameColor=008C54<BR>
 * dblocationhandler.showNames=false<BR>
 * dblocationhandler.showLocations=true<BR>
 * dblocationhandler.jdbcDriver=oracle.jdbc.driver.OracleDriver<BR>
 * dblocationhandler.jdbcString=jdbc login string<BR>
 * dblocationhandler.userName=username<BR>
 * dblocationhandler.userPassword=password<BR>
 * <P>
 * # In addition, this DBLocationHandler also uses the LocationDataRecordSet properties:<BR>
 * dblocationhandler.locationDataTableName=table name <BR>
 * dblocationhandler.locationDataStateColumnName=state column name <BR>
 * dblocationhandler.locationDataCityColumnName=city column name <BR>
 * dblocationhandler.locationDataGraphicColumnName=poptype column name <BR>
 * dblocationhandler.locationDataLatitudeColumnName=latitude column name <BR>
 * dblocationhandler.locationDataLongitudeColumnName=longitude column name <BR>
 * <P>
 * # And the RawDataRecordSet for GIF images - their properties look like: <BR>
 * dblocationhandler.rawDataTableName=table name<BR>
 * dblocationhandler.rawDataColumnName=data column name<BR>
 * dblocationhandler.rawDataKeyColumnName=data key name<BR>
 */
public class DBLocationHandler extends AbstractLocationHandler
    implements LocationHandler, ActionListener {
        	        
    /** The storage mechanism for the locations. */
    protected QuadTree quadtree = null;
    
    //Database variables.
    /*
       This String should be completely specified based on which Database
       is being used including username and password.
       Alternately, username and password can be specified by in properties file as
       jdbc.user=USERNAME
       jdbc.password=PASSWORD    	    	    	
    */
    /** String that would be used for making a connection to Database */
    protected String jdbcString = null;
    /** Property that should be specified for setting jdbc String*/
    public static final String jdbcStringProperty = ".jdbcString";
    /** 
     * This String would be used to load the driver.  If this string
     * is null, jdbc Connection Manager would try to load the
     * approriate driver.  
     */
    protected String jdbcDriver = null;
    /** Property to specify jdbc driver to loaded. */
    public static final String jdbcDriverProperty = ".jdbcDriver";
    /** User name to be used for connecing to DB. */
    protected String userName = null;
    /** Password to be used with for connecting to DB. */
    protected String userPassword = null;
    /** Property to specify userName for connecting to Database */
    public static final String userNameProperty = ".userName";
    /** Property to specify password for connecting to Database */
    public static final String userPasswordProperty = ".userPassword";
    /** Property to specify the query string passed to the database. */
    public static final String locationQueryStringProperty = ".locationQueryString";

    /** The string used to query the database for the location information. */
    protected String locationQueryString = null;

    /** A copy of properties used to construct this Layer */
    protected Properties props;
    protected String propertyPrefix;

    /** 
    *  The default constructor for the Layer.  All of the attributes
    *  are set to their default values.
    */
    public DBLocationHandler () {}

    /** 
     * The properties and prefix are managed and decoded here, for
     * the standard uses of the DBLocationHandler.
     *
     * @param prefix string prefix used in the properties file for this layer.
     * @param properties the properties set in the properties file.  
     */
    public void setProperties(String prefix,
			      java.util.Properties properties) {
	super.setProperties(prefix, properties);
	props = properties; // Save it now. We would need it in future
	propertyPrefix = prefix; // Save it now. We would need it in future
	
	jdbcString = properties.getProperty(prefix+jdbcStringProperty);
	jdbcDriver = properties.getProperty(prefix+jdbcDriverProperty);
	userName = properties.getProperty(prefix+userNameProperty);
	userPassword = properties.getProperty(prefix+userPasswordProperty);

	locationQueryString = 
	    properties.getProperty(prefix+locationQueryStringProperty);
    }
    
    public void reloadData(){
	quadtree = createData();
    }
    
    /**
     * Look in the database and create the QuadTree holding all the
     * Locations.
     */
    protected QuadTree createData(){
	
	QuadTree qt = new QuadTree(90.0d, -180.0d, -90.0d, 180.0d, 100, 50d);
	ByteRasterLocation loc;
	byte bytearr[];

	if (locationQueryString == null){
	    return qt;
	}

	// Code for reading from DB and pushing it into QuadTree.	
	try {	    
	    if(jdbcDriver != null){
		Class.forName(getJdbcDriver());
	    }

	    Connection connection =		
		DriverManager.getConnection (getJdbcString(),
					     getUserName(),
					     getUserPassword());

	    RawDataRecordSet gifdataRS = 
		new RawDataRecordSet(connection, propertyPrefix, props);

	    RecordSet locationdataRS = 
		new RecordSet(connection, locationQueryString);

	    while(locationdataRS.next()){	

		LocationData ld = new LocationData(locationdataRS);

		if (Debug.debugging("location")){
		    Debug.output("DBLocationHandler:  location information:\n" + ld);
		}

		bytearr = gifdataRS.getRawData(ld.getGraphicName());
		
		double lat = ld.getLatitude();
		double lon = ld.getLongitude();

		loc = new ByteRasterLocation(lat, lon,
					     ld.getCityName(), bytearr);

		loc.setLocationHandler(this);
		loc.setLocationColor(getLocationColor());
		loc.getLabel().setLineColor(getNameColor());
		loc.setDetails(ld.getCityName() + " is at lat: " + lat
			       + ", lon: " + lon);
		
 		qt.put(lat, lon, loc);
					
	    }
			
	    locationdataRS.close();	
	    connection.close();

	} catch(SQLException sqlE){
	    Debug.error("DBLocationHandler:SQL Exception: " + sqlE.getMessage());
	    sqlE.printStackTrace();
	} catch(ClassNotFoundException cnfE){
	    Debug.error("DBLocationHandler: Class not found Exception: " + cnfE);
	}

	return qt;
    }
    
    public String getJdbcString(){	
	return jdbcString;
    }
    
    
    public String getJdbcDriver(){	
	return jdbcDriver;
    }
    
    public String getUserName(){	
	return userName;
    }
    
    public String getUserPassword(){	
	return userPassword;
    }
    
    public String getPropertyPrefix(){
	return propertyPrefix;
    }    

    public Properties getLocationProperties(){
	return props;
    }    

    /**
     * Prepares the graphics for the layer.  This is where the
     * getRectangle() method call is made on the location.  <p>
     * Occasionally it is necessary to abort a prepare call.  When
     * this happens, the map will set the cancel bit in the
     * LayerThread, (the thread that is running the prepare).  If this
     * Layer needs to do any cleanups during the abort, it should do
     * so, but return out of the prepare asap.
     *
     */
    public Vector get(double nwLat, double nwLon, double seLat, double seLon,
		      Vector graphicList){
	
	// IF the quadtree has not been set up yet, do it!
	if (quadtree == null){
	    Debug.output("DBLocationHandler: Figuring out the locations and names! (This is a one-time operation!)");
	    quadtree = createData();
	}

	if (quadtree != null){
	    if (Debug.debugging("location")) {
		Debug.output("DBLocationHandler|DBLocationHandler.get() ul.lon = "
			     + nwLon + " lr.lon = " + seLon +
			     " delta = " + (seLon - nwLon)); 
	    }

	    quadtree.get(nwLat, nwLon, seLat, seLon, graphicList);
	}
	return graphicList;
    }

    public void fillLocationPopUpMenu (LocationPopupMenu locMenu) {

	LocationCBMenuItem lcbi = new LocationCBMenuItem(LocationHandler.showname, 
							 locMenu, 
							 getLayer());
	lcbi.setState(locMenu.getLoc().isShowName());
	locMenu.add(lcbi);
	locMenu.add(new LocationMenuItem(showdetails, locMenu, getLayer()));
    }

    protected Box box = null;

   /** 
     * Provides the palette widgets to control the options of showing
     * maps, or attribute text.
     * 
     * @return Component object representing the palette widgets.
     */
    public java.awt.Component getGUI() {
	if (box == null){
	    JCheckBox showDBLocationCheck, showNameCheck;
	    JButton rereadFilesButton;
	    
	    showDBLocationCheck = new JCheckBox("Show Locations", isShowLocations());
	    showDBLocationCheck.setActionCommand(showLocationsCommand);
	    showDBLocationCheck.addActionListener(this);
	    
	    showNameCheck = new JCheckBox("Show Location Names", isShowNames());
	    showNameCheck.setActionCommand(showNamesCommand);
	    showNameCheck.addActionListener(this);
	    
	    rereadFilesButton = new JButton("Reload Data From Source");
	    rereadFilesButton.setActionCommand(readDataCommand);
	    rereadFilesButton.addActionListener(this);
	    
	    box = Box.createVerticalBox();
	    box.add(showDBLocationCheck);
	    box.add(showNameCheck);
	    box.add(rereadFilesButton);
	}
	return box;
    }

    //----------------------------------------------------------------------
    // ActionListener interface implementation
    //----------------------------------------------------------------------

    /** 
     * The Action Listener method, that reacts to the palette widgets
     * actions.
     */
    public void actionPerformed (ActionEvent e) {
	String cmd = e.getActionCommand();
	if (cmd == showLocationsCommand) {		
	    JCheckBox locationCheck = (JCheckBox)e.getSource();
	    setShowLocations(locationCheck.isSelected());
	    if(Debug.debugging("location")){
	    	Debug.output("DBLocationHandler::actionPerformed showLocations is "
			     + isShowLocations());
	    }
	    getLayer().repaint();
	} else if (cmd == showNamesCommand) {
	    JCheckBox namesCheck = (JCheckBox)e.getSource();
	    setShowNames(namesCheck.isSelected());
	    if(Debug.debugging("location")){
	    	Debug.output("DBLocationHandler::actionPerformed showNames is "
			     + isShowNames());
	    }
	    getLayer().repaint();
	} else if (cmd == readDataCommand) {
	    Debug.output("DBLocationHandler: Re-reading Locations file");
	    quadtree = null;
	    getLayer().doPrepare();
	} else 	{
	    Debug.error("DBLocationHandler: Unknown action command \"" + cmd +
			"\" in actionPerformed().");
	}
    }

}

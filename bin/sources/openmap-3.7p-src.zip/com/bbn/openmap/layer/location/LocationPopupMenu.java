/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/location/LocationPopupMenu.java,v $
 * $Revision: 1.2 $
 * $Date: 2000/05/08 14:22:36 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.location;


/*  Java Core  */
import java.awt.event.*;

/*  OpenMap  */
import com.bbn.openmap.*;
import com.bbn.openmap.event.*;

import javax.swing.JPopupMenu;


/** 
 * This is the menu that pops up when the mouse button is pressed,
 * giving a set of options to the user.  The LocationMenu keeps
 * track of the location of the last mouse event, the last
 * Location (if there was one), and the MapBean. 
 */
public class LocationPopupMenu extends JPopupMenu { 
    /** The location of the event. */
    protected MouseEvent event;
    /** Used to recenter the map. */
    protected MapBean map;
    /** Used as a reference for the details gathering. */
    protected Location loc;
    
    public LocationPopupMenu(){
    }
    
    public void setLoc(Location location){
	loc = location;
    }
    
    public void setMap(MapBean aMap){
	map = aMap;
    }
    
    public void setEvent(MouseEvent anEvt){
	event = anEvt;
    }

    public Location getLoc(){
	return loc;
    }

    public MouseEvent getEvent(){
	return event;
    }
    
    public MapBean getMap(){
	return map;
    }
}


/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/location/LocationLayer.java,v $
 * $Revision: 1.16 $
 * $Date: 2000/08/16 21:18:48 $
 * $Author: pmanghwa $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.location;


/*  Java Core  */

import com.bbn.openmap.LatLonPoint;
import com.bbn.openmap.Layer;
import com.bbn.openmap.MapBean;
import com.bbn.openmap.event.InfoDisplayEvent;
import com.bbn.openmap.event.LayerStatusEvent;
import com.bbn.openmap.event.MapMouseListener;
import com.bbn.openmap.event.ProjectionEvent;
import com.bbn.openmap.event.ProjectionListener;
import com.bbn.openmap.layer.DeclutterMatrix;
import com.bbn.openmap.layer.util.LayerUtils;
import com.bbn.openmap.omGraphics.OMGraphic;
import com.bbn.openmap.proj.Projection;
import com.bbn.openmap.util.Debug;
import com.bbn.openmap.util.PaletteHelper;
import com.bbn.openmap.util.SwingWorker;

import javax.swing.Box;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import java.awt.event.MouseEvent;
import java.util.Enumeration;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.Vector;

// To get jdk 1.1 compatability, delete these
/* Openmap */

/**
 * The LocationLayer is a layer that displays graphics supplied by
 * LocationHandlers.  The whole idea behind locations is that there
 * are geographic places that are to be marked with a graphic, and/or
 * a text label.  The location handler handles the interface with the
 * source and type of location to be displayed, and the LocationLayer
 * deals with all the locations in a generic way.  The LocationLayer
 * is capable of using more than one LocationHandler.
 * <P>
 * As a side note, a Link is nothing more than a connection between
 * Locations, and is an extension of the Location Class.  They have a
 * graphic representing the link, an optional label, and an extra set
 * of location coordinates.
 * <P>
 * The layer responds to gestures, pop-up menus.  Which menu appears
 * depends if the gesture affects a graphic.
 * <P>
 * The properties for this layer are:<BR>
 * ####################################<BR>
 * # Properties for LocationLayer<BR>
 * # Use the DeclutterMatrix to declutter the labels.r<BR>
 * locationlayer.useDeclutter=false<BR>
 * # Which declutter matrix class to use.r<BR>
 * locationlayer.declutterMatrix=com.bbn.openmap.layer.DeclutterMatrixr<BR>
 * # Let the DeclutterMatrix have labels that run off the edge of the map.r<BR>
 * locationlayer.allowPartials=truer<BR>
 * # The list of location handler prefixes - each prefix should thenr<BR>
 * # be used to further define the location handler properties.r<BR>
 * locationlayer.locationHandlers=handler1 handler2r<BR>
 * # Then come the handler properties...r<BR>
 * ####################################<BR> 
 */
public class LocationLayer extends Layer
    implements ProjectionListener, MapMouseListener {

    /** The declutter matrix to use, if desired. */
    protected DeclutterMatrix declutterMatrix = null;
    /** Flag to use declutter matrix or not. */
    protected boolean useDeclutterMatrix = false;
    /** Flag to let objects appear partially off the edges of the map,
     *  when decluttering through the decluterr matrix. */
    protected boolean allowPartials = true;
    /** The graphic list of objects to draw. */
    protected Vector omGraphics;
    /** Projection that gets set on a projection event. */
    protected Projection projection;
    /** Handlers load the data, and manage it for the layer. */
    protected LocationHandler[] dataHandlers;
    /** Pretty names for the handlers, for GUIs and such. */
    protected String[] dataHandlerNames;

    /////////////////////
    // Variables to manage the gesturing mechanisms

    /** Used for recentering commands off the pop-up menu. */
    protected MapBean map;
    /** What pops up if someone clicks on the background. The handler
     *  is responsible for suppling the pop-up menu when one of its
     *  objects is selected.*/
    protected LocationPopupMenu backgroundMenu;
    /** What pops up if someone clicks on a location. */
    protected LocationPopupMenu locMenu;
    
    static final public String recenter = "Re-center map";
    static final public String cancel = "Cancel";

    public static final String UseDeclutterMatrixProperty = ".useDeclutter";
    public static final String DeclutterMatrixClassProperty = ".declutterMatrix";
    public static final String AllowPartialsProperty = ".allowPartials";
    public static final String LocationHandlerListProperty = ".locationHandlers";

    /** The swing worker that goes off in it's own thread to get
     * graphics.
     * */
    protected LocationWorker currentWorker;
    /** Set when the projection has changed while a swing worker is
     * gathering graphics, and we want him to stop early. */
    protected boolean cancelled = false;

    /** Since we can't have the main thread taking up the time to
     * create images, we use this worker thread to do it.
     */
    class LocationWorker extends SwingWorker {
	/** Constructor used to create a worker thread. */
	public LocationWorker () {
	    super();
	}

	/**  Compute the value to be returned by the <code>get</code>
	 * method.  */
	public Object construct() {
	    Debug.message("location", getName()+
			  "|LocationWorker.construct()");
	    fireStatusUpdate(LayerStatusEvent.START_WORKING);
	    try {
		return prepare();
	    } catch (OutOfMemoryError e) {
		String msg = getName() + 
		    "|LocationLayer.LocationWorker.construct(): " + e;
		Debug.error(msg);
		e.printStackTrace();
		fireRequestMessage(new InfoDisplayEvent(this, msg));
		fireStatusUpdate(LayerStatusEvent.FINISH_WORKING);
		return null;
	    }
	}

	/** Called on the event dispatching thread (not on the worker
	 * thread) after the <code>construct</code> method has
	 * returned.  */
	public void finished() {
	    workerComplete(this);
	    fireStatusUpdate(LayerStatusEvent.FINISH_WORKING);
	}
    }

    /** 
     * The default constructor for the Layer.  All of the attributes
     * are set to their default values.
     */
    public LocationLayer () {}

    /** 
     * The properties and prefix are managed and decoded here, for
     * the standard uses of the LocationLayer.
     *
     * @param prefix string prefix used in the properties file for this layer.
     * @param properties the properties set in the properties file.  
     */
    public void setProperties(String prefix,
			      java.util.Properties properties) {
	super.setProperties(prefix, properties);
	
	setLocationHandlers(prefix, properties);
	declutterMatrix = (DeclutterMatrix) LayerUtils.objectFromProperties(properties, prefix + DeclutterMatrixClassProperty);
	allowPartials = LayerUtils.booleanFromProperties(properties, prefix + AllowPartialsProperty, true);

	if (declutterMatrix != null){
	    useDeclutterMatrix = LayerUtils.booleanFromProperties(properties, prefix + UseDeclutterMatrixProperty, useDeclutterMatrix);
	    declutterMatrix.setAllowPartials(allowPartials);
	    Debug.message("location", "LocationLayer: Found DeclutterMatrix to use");
// 	    declutterMatrix.setXInterval(3);
// 	    declutterMatrix.setYInterval(3);
	} else {
	    useDeclutterMatrix = false;
	}
    }

    /** 
     * Sets the current graphics list to the given list.
     *
     * @param aList a vector of OMGraphics 
     */
    public synchronized void setGraphicList (Vector aList) {
	omGraphics = aList;
    }

    /** 
     * Retrieves a vector of the current graphics list.  
     *
     * @return vector of OMGraphics.
     */
    public synchronized Vector getGraphicList () {
	return omGraphics;
    }

    /** Used to get the projection to determine where a mouse click occured. */
    public Projection getProjection(){
	return projection;
    }

    /** 
     * Used to set the cancelled flag in the layer.  The swing worker
     * checks this once in a while to see if the projection has
     * changed since it started working.  If this is set to true, the
     * swing worker quits when it is safe. 
     */
    public synchronized void setCancelled(boolean set){
	cancelled = set;
    }

    /** Check to see if the cancelled flag has been set. */
    public synchronized boolean isCancelled(){
	return cancelled;
    }

    public synchronized MapMouseListener getMapMouseListener(){
	return this;
    }

    public void reloadData(){
	if (dataHandlers != null){
	    for (int i = 0; i < dataHandlers.length; i++){
		dataHandlers[i].reloadData();
	    }
	}
    }

    /** 
     * Implementing the ProjectionPainter interface.
     */
    public synchronized void renderDataForProjection(Projection proj, java.awt.Graphics g){
	if (proj == null){
	    Debug.error("LocationLayer.renderDataForProjection: null projection!");
	    return;
	} else if (!proj.equals(projection)){
	    projection = proj.makeClone();
	    setGraphicList(prepare());
	}
	paint(g);
    }

    /** 
     * The projectionListener interface method that lets the Layer
     * know when the projection has changes, and therefore new graphics
     * have to created /supplied for the screen.
     *
     * @param e The projection event, most likely fired from a map bean.
     */
    public void projectionChanged (ProjectionEvent e) {
	Debug.message("basic", getName()+"|LocationLayer.projectionChanged()");
	
	if (projection != null){
	    if (projection.equals(e.getProjection()))
		// Nothing to do, already have it and have acted on it...
	    {
		//Location.CreateDeclutterMatrix(projection);	
		repaint();
		return;
	    }
	}
 	setGraphicList(null);
	
	projection = e.getProjection().makeClone();
	// If there isn't a worker thread working on this already,
	// create a thread that will do the real work. If there is
	// a thread working on this, then set the cancelled flag
	// in the layer.		
	
	if (currentWorker == null) {
	    currentWorker = new LocationWorker();
	    currentWorker.execute();
	}
	else setCancelled(true);
    }

    /**  
     * The LocationWorker calls this method on the layer when it is
     * done working.  If the calling worker is not the same as the
     * "current" worker, then a new worker is created.
     *
     * @param worker the worker that has the graphics.
     */
    protected synchronized void workerComplete (LocationWorker worker) {
	if (!isCancelled()) {
	    currentWorker = null;
	    setGraphicList((Vector)worker.get());
	    repaint();
	}
	else{
	    setCancelled(false);
	    currentWorker = new LocationWorker();
	    currentWorker.execute();
	}
    }

    /**
     * A method that will launch a Worker to fetch the data.
     */
    public void doPrepare(){
	// If there isn't a worker thread working on a projection
	// changed or other doPrepare call, then create a thread that
	// will do the real work. If there is a thread working on
	// this, then set the cancelled flag in the layer.
	if (currentWorker == null) {
	    currentWorker = new LocationWorker();
	    currentWorker.execute();
	}
	else setCancelled(true);
    }

    /**
     * Prepares the graphics for the layer.  This is where the
     * getRectangle() method call is made on the location.  <p>
     * Occasionally it is necessary to abort a prepare call.  When
     * this happens, the map will set the cancel bit in the
     * LayerThread, (the thread that is running the prepare).  If this
     * Layer needs to do any cleanups during the abort, it should do
     * so, but return out of the prepare asap.
     */
    public Vector prepare () {

	if (isCancelled()){
	    Debug.message("location", getName()+
			  "|LocationLayer.prepare(): aborted.");
	    return null;
	}
	
	Debug.message("basic", getName()+"|LocationLayer.prepare(): doing it");

	if (useDeclutterMatrix && declutterMatrix != null){
	    declutterMatrix.setWidth(projection.getWidth());
	    declutterMatrix.setHeight(projection.getHeight());
	    declutterMatrix.create();
	}
	
	// Setting the OMGraphicsList for this layer.  Remember, the
	// Vector is made up of OMGraphics, which are generated
	// (projected) when the graphics are added to the list.  So,
	// after this call, the list is ready for painting.

	// call getRectangle();
	if (Debug.debugging("location")) {
	    Debug.output(
		getName()+"|LocationLayer.prepare(): " +
		"calling prepare with projection: " + projection +
		" ul = " + projection.getUpperLeft() + " lr = " + 
		projection.getLowerRight()); 
	}

	LatLonPoint ul = projection.getUpperLeft();
	LatLonPoint lr = projection.getLowerRight();

	Vector omGraphicList = new Vector();

	if (Debug.debugging("location")) {
	    double delta = lr.getLongitude() - ul.getLongitude();
	    Debug.output(getName()+ "|LocationLayer.prepare(): " +
			       " ul.lon =" + ul.getLongitude() +
			       " lr.lon = " + lr.getLongitude() +
			       " delta = " + delta); 
	}
	if (dataHandlers != null){
	    for (int i = 0; i < dataHandlers.length; i++){
		dataHandlers[i].get(ul.getLatitude(),
                ul.getLongitude(),
                lr.getLatitude(),
                lr.getLongitude(),
                omGraphicList);
	    }
	}

	/////////////////////
	// safe quit
	int size = 0;
	if (omGraphicList != null){
	    size = omGraphicList.size();	
	    Debug.message("basic", getName()+
			  "|LocationLayer.prepare(): finished with " + 
			  size + " graphics");

	    // Don't forget to project them.  Since they are only
	    // being recalled if the projection hase changed, then
	    // we need to force a reprojection of all of them
	    // because the screen position has changed.
	    Enumeration things = omGraphicList.elements();
	    while (things.hasMoreElements()){
		OMGraphic thingy = (OMGraphic)things.nextElement();

		if (useDeclutterMatrix && thingy instanceof Location){
		    Location loc = (Location) thingy;
		    loc.generate(projection, declutterMatrix);
		} else {
		    thingy.generate(projection);
		}
	    }
	}
	else 
	    Debug.message("basic", getName()+
		   "|LocationLayer.prepare(): finished with null graphics list");
	
	return omGraphicList;
    }

    /**
     * Paints the layer.
     *
     * @param g the Graphics context for painting
     */
    public void paint (java.awt.Graphics g) {	
	    Debug.message("location",getName()+"|LocationLayer.paint()");
	
	Vector vlist = getGraphicList();
	Object[] list = null;

	if (vlist != null)
	    list = vlist.toArray();
	
	if (list != null){
	    int i;
	    OMGraphic loc;
	    // Draw from the bottom up, so it matches the palette, and
	    // the order in which the handlers were loaded - the first
	    // in the list is on top.

	    // We need to go through list twice.  The first time, draw
	    // all the regular OMGraphics, and also draw all of the
	    // graphics for the locations.  The second time through,
	    // draw the labels.  This way, the labels won't be covered
	    // up by graphics.
	    for (int j = 0; j < 2; j++){
		for (i = list.length - 1; i >= 0; i--){
		    loc = (OMGraphic) list[i];
		    if (j == 0){
			if (loc instanceof Location){
			    ((Location)loc).renderLocation(g);
			} else {
			    loc.render(g);
			}
		    } else if (loc instanceof Location){
			((Location)loc).renderName(g);
		    }
		}
	    }
	} else {
	    if (Debug.debugging("location")){
		Debug.error(getName()+"|LocationLayer: paint(): Null list...");
	    }
	}
    }

    /**
     * Parse the properties and set up the location handlers.
     */
    protected void setLocationHandlers(String prefix, Properties p) {

	String handlersValue = p.getProperty(prefix + LocationHandlerListProperty);

	if (Debug.debugging("location")){
	    Debug.output(getName() + "| handlers = \"" + handlersValue + "\"");
	}

	if (handlersValue == null) {
	    Debug.error("No property \"" + prefix + LocationHandlerListProperty
			       + "\" found in application properties.");
	    return;
	}

	// Divide up the names ...
	StringTokenizer tokens = new StringTokenizer(handlersValue, " ");
	Vector handlerNames = new Vector();
	while(tokens.hasMoreTokens()) {
	    handlerNames.addElement(tokens.nextToken());
	}

	if (Debug.debugging("location")) {
	    Debug.output("OpenMap.getLocationHandlers(): "+ handlerNames);
	}

	int nHandlerNames = handlerNames.size();
	Vector handlers = new Vector(nHandlerNames);
	Vector goodNames = new Vector(nHandlerNames);
	for (int i = 0; i < nHandlerNames; i++) {
	    String handlerName = (String)handlerNames.elementAt(i);
	    String classProperty = handlerName + ".class";
	    String className = p.getProperty(classProperty);

	    String nameProperty = handlerName + ".prettyName";
	    String prettyName = p.getProperty(nameProperty);

	    if (className == null) {
		Debug.error("Failed to locate property \""
				   + classProperty + "\"");
		Debug.error("Skipping handler \"" + handlerName + "\"");
		continue;
	    }
	    try {
		if (Debug.debugging("location")) {
		    Debug.output(
			"OpenMap.getHandlers():instantiating handler \""+
			className+"\"");
		}

		Object obj = Class.forName(className).newInstance();// Works for applet!
		if (obj instanceof LocationHandler) {
		    LocationHandler lh = (LocationHandler) obj;
		    lh.setProperties(handlerName, p);
		    lh.setLayer(this);
		    handlers.addElement(lh);
		    goodNames.addElement(prettyName!=null?prettyName:"");
		}
		if (false) throw new java.io.IOException();//fool javac compiler
	    } catch (java.lang.ClassNotFoundException e) {
		Debug.error("Handler class not found: \""
				   + className + "\"");
		Debug.error("Skipping handler \"" + handlerName + "\"");
	    } catch (java.io.IOException e) {
		Debug.error("IO Exception instantiating class \""
				   + className + "\"");
		Debug.error("Skipping handler \"" + handlerName + "\"");
	    } catch (Exception e) {
		Debug.error("Exception instantiating class \""
				   + className + "\": " + e);
	    }
	}

	int nHandlers = handlers.size();

	dataHandlers = new LocationHandler[nHandlers];
	dataHandlerNames = new String[nHandlers];

	if (nHandlers != 0){
	    handlers.copyInto(dataHandlers);
	    goodNames.copyInto(dataHandlerNames);
	}

    }

    //----------------------------------------------------------------------
    // GUI
    //----------------------------------------------------------------------

    protected Box box = null;

    /** 
     * Provides the palette widgets to control the options of showing
     * maps, or attribute text.
     * 
     * @return Component object representing the palette widgets.
     */
    public java.awt.Component getGUI() {
	if (box == null){
	    box = Box.createVerticalBox();
	    JPanel[] panels = new JPanel[dataHandlers.length];
	    for (int i = 0; i < dataHandlers.length; i++){
		panels[i] = PaletteHelper.createPaletteJPanel(dataHandlerNames[i]);
		panels[i].add(dataHandlers[i].getGUI());
		box.add(panels[i]);
	    }
	}	
	return box;
    }

    //------------------------------------------------------------
    // MapMouseListener implementation
    //------------------------------------------------------------

    /** Given a mouse event, find the closest location on the screen. */
    public Location findClosestLocation(MouseEvent evt) {
	Vector graphics = getGraphicList();
        if (graphics != null){
	    int x = evt.getX();
	    int y = evt.getY();
	    double limit = 4.0d;
	    Location ret = null;
	    Location loc;

	    double closestDistance = Double.MAX_VALUE;
	    double currentDistance;
	    int i;
	    int size = graphics.size();

	    for (i = size -1; i >= 0; i--) {
		loc = (Location)graphics.elementAt(i);
		currentDistance = loc.distance(x, y);
		if (currentDistance < closestDistance){
		    ret = loc;
		    closestDistance = currentDistance;
		}
	    }
	    if (closestDistance <= limit) return ret;
	} 
	return null;
    }

    public String[] getMouseModeServiceList() {
	String[] services = {"Gestures"};
	return services;
    }

    protected void showMapPopup (MouseEvent evt, MapBean map) {
        if (backgroundMenu == null){
	    backgroundMenu = new LocationPopupMenu();
	    backgroundMenu.add(new LocationMenuItem(recenter, backgroundMenu, this));
	    backgroundMenu.add(new LocationMenuItem(cancel, backgroundMenu, this));
	    backgroundMenu.setMap(map);
	}
	backgroundMenu.setEvent(evt);
	backgroundMenu.show(this, evt.getX(), evt.getY());
    }

    protected void showLocationPopup (MouseEvent evt, Location loc, MapBean map) {
        if (locMenu == null){
	    locMenu = new LocationPopupMenu();
	    locMenu.setMap(map);
	}
	locMenu.removeAll();

	locMenu.setEvent(evt);
	locMenu.setLoc(loc);

	locMenu.add(new LocationMenuItem(LocationLayer.recenter, locMenu, this));
	locMenu.add(new LocationMenuItem(LocationLayer.cancel, locMenu, this));
	locMenu.addSeparator();

	LocationHandler lh = loc.getLocationHandler();
	if (lh != null) {
	    lh.fillLocationPopUpMenu(locMenu);
	}

	locMenu.show(this, evt.getX(), evt.getY());
    }

    public boolean mousePressed(MouseEvent evt) {
        if (!isVisible()) return false;

	Location loc = findClosestLocation(evt);
	if (map == null) {
	    try{
	        map = (MapBean) SwingUtilities.getAncestorOfClass(Class.forName("com.bbn.openmap.MapBean"), this);
	    }
	    catch (java.lang.ClassNotFoundException e){
	        Debug.error("LocationLayer: Whatza MapBean??");
	    }
	}
	if (loc == null) {
	    // user clicked on map
	    Debug.message("location", "Clicked on background");
	    showMapPopup(evt, map);
	} else {
	    // user clicked on rate center
	    Debug.message("location", "Clicked on location");
	    showLocationPopup(evt, loc, map);
	}
	return true;
    }
  
    public boolean mouseReleased(MouseEvent e) { return false;}
    public boolean mouseClicked(MouseEvent evt) { return false;}
    public void mouseEntered(MouseEvent e) {}
    public void mouseExited(MouseEvent e) {}
    public boolean mouseDragged(MouseEvent e) {	return false;}

    public boolean mouseMoved(MouseEvent evt) {
        if (!isVisible()) return false;

	Location loc = findClosestLocation(evt);
	if (loc == null) {
	    fireRequestInfoLine("");
	} else {
	    fireRequestInfoLine(loc.getName());
	}
	return true;
    }

    public void mouseMoved() {
// 	fireRequestInfoLine("");
    }
}

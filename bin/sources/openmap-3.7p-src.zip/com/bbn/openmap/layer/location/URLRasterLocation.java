/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/location/URLRasterLocation.java,v $
 * $Revision: 1.4 $
 * $Date: 2000/08/02 15:49:51 $
 * $Author: dietrick $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.location;

/*  Java Core  */
import java.io.*;
import java.net.URL;
import javax.swing.ImageIcon;

/*  OpenMap  */
import com.bbn.openmap.omGraphics.OMRaster;
import com.bbn.openmap.omGraphics.OMGraphic;

public class URLRasterLocation extends Location {

    public URLRasterLocation(double latitude, double longitude,
			     String name, String iconURL){
	super(latitude, longitude, name, getIconRaster(latitude, longitude, iconURL));

	if (location instanceof OMRaster){
	    label.setX(label.getX() + 
		       (((OMRaster)location).getWidth()/2) + DEFAULT_SPACING);
	}

    }
    
    public URLRasterLocation(int x, int y, String name, 
			     String iconURL){
	super(x, y, name, getIconRaster(x, y, iconURL));

	if (location instanceof OMRaster){
	    label.setX(label.getX() + 
		       (((OMRaster)location).getWidth()/2) + DEFAULT_SPACING);
	}
    }

    public URLRasterLocation(double latitude, double longitude,
			     int xOffset, int yOffset, String name, 
			     String iconURL){
	super(latitude, longitude, xOffset, yOffset, name, 
	      getIconRaster(latitude, longitude, xOffset, yOffset, iconURL));

	if (location instanceof OMRaster){
	    label.setX(label.getX() + 
		       (((OMRaster)location).getWidth()/2) + DEFAULT_SPACING);
	}
    }

    public static OMRaster getIconRaster(double lat, double lon, String iconURL){

	ImageIcon icon = getIconRaster(iconURL);
	if (icon == null) return null;

	int offX = icon.getIconWidth() / 2;
	int offY = icon.getIconHeight() / 2;
	return new OMRaster(lat, lon, -offX, -offY, icon);
    }

    public static OMRaster getIconRaster(int x, int y, String iconURL){
	ImageIcon icon = getIconRaster(iconURL);
	if (icon == null) return null;

	int offX = icon.getIconWidth() / 2;
	int offY = icon.getIconHeight() / 2;
	return new OMRaster(x-offX, y-offY, icon);
    }

    public static OMRaster getIconRaster(double lat, double lon,
					 int x, int y, String iconURL){
	ImageIcon icon = getIconRaster(iconURL);
	if (icon == null) return null;

	int offX = icon.getIconWidth() / 2;
	int offY = icon.getIconHeight() / 2;
	return new OMRaster(lat, lon, x-offX, y-offY, icon);
    }

    public static ImageIcon getIconRaster(String iconURL){
	try {
	    return new ImageIcon(new URL(iconURL));
	} catch (java.net.MalformedURLException mue) {
	    new com.bbn.openmap.util.HandleError(mue);
	} catch (java.io.IOException ioe){
	    new com.bbn.openmap.util.HandleError(ioe);
	}
	return null;
    }

    public void setGraphicLocations(double latitude, double longitude){
	if (location instanceof OMRaster){
	    OMRaster ras = (OMRaster) location;
	    ras.setLat(latitude);
	    ras.setLon(longitude);

	    label.setLat(latitude);
	    label.setLon(longitude);
	    label.setX(label.getX() + 
		       (ras.getWidth()/2) + DEFAULT_SPACING);

	}
    }

    public void setGraphicLocations(int x, int y){
	if (location instanceof OMRaster){
	    OMRaster ras = (OMRaster) location;
	    ras.setX(x);
	    ras.setY(y);

	    label.setX(x);
	    label.setY(y);
	    label.setX(label.getX() + 
		       (ras.getWidth()/2) + DEFAULT_SPACING);

	}
    }

    public void setGraphicLocations(double latitude, double longitude,
				    int offsetX, int offsetY){
	if (location instanceof OMRaster){
	    OMRaster ras = (OMRaster) location;
	    ras.setLat(latitude);
	    ras.setLon(longitude);
	    ras.setX(offsetX);
	    ras.setY(offsetY);

	    label.setLat(latitude);
	    label.setLon(longitude);
	    label.setX(offsetX);
	    label.setY(offsetY);
	    label.setX(label.getX() + 
		       (ras.getWidth()/2) + DEFAULT_SPACING);

	}
    }
}

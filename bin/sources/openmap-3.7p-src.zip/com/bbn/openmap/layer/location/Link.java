/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/location/Link.java,v $
 * $Revision: 1.5 $
 * $Date: 2000/08/02 15:49:51 $
 * $Author: dietrick $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.location;


/*  Java Core  */
import com.bbn.openmap.omGraphics.OMGraphic;
import com.bbn.openmap.omGraphics.OMLine2D;
import com.bbn.openmap.util.Debug;

import java.awt.Color;

/*  OpenMap  */

/**
 * A Link is a relationship between Locations, represented as a line
 * between them. 
 */
public class Link extends Location {

    /* The other endpoints of the link, in decimal degrees.  The
     * first endpoints are contained in the Location superclass. */
    /** The lat of point 2. */
    public double lat2 = 0.0d;
    /** The lon of point 2. */
    public double lon2 = 0.0d;
    /** The x of point 2. */
    public int x2 = 0;
    /** The y of point 2. */
    public int y2 = 0;

    /** The x offset of point 2. */
    public int xOffset2 = 0;
    /** The y offset of point 2. */
    public int yOffset2 = 0;

    public static Color DEFAULT_COLOR = Color.black;
    public static boolean DEFAULT_DASHED = false;
    public static int DEFAULT_LINETYPE = OMGraphic.LINETYPE_STRAIGHT;
    public static float DEFAULT_THICKNESS = 1.0f;

    /** 
     * A plain contructor if you are planning on setting everything
     * yourself.  
     */
    public Link(){}

    /** 
     * Construct a Link with the given attributes
     *
     * @param lat1  latitude of start-point
     * @param lon1  longitude of start-point
     * @param lat2  latitude of end-point
     * @param lon2  longitude of endpoint
     * @param details A string that gives information about this link
     * @param color the links displayed color. 
     * @param dashed Is it a dashed line?
     * @param thickness The line thickness. 
     * @param linetype LINETYPE_STRAIGHT, LINETYPE_GREATCIRCLE, LINETYPE_RHUMB
     */
    public Link(double lat1, double lon1, double lat2, double lon2,
		String details, Color color, boolean dashed, 
		float thickness, int linetype ){

	if (Debug.debugging("location")){
	    Debug.output("Link("
			 + lat1 + ", " + lon1 + ", "
			 + lat2 + ", " + lon2 + ", "
			 + details + ", "
			 + color + ", "
			 + dashed + ", "
			 + thickness + ", "
			 + linetype + ")");
	}

	this.lat = lat1;
	this.lon = lon2;
	this.lat2 = lat2;
	this.lon2 = lon2;

	if (details != null)
	    this.details = details;
	else
	    this.details = "";

	OMLine2D link =  new OMLine2D(lat1, lon1, lat2, lon2, linetype);

	link.setLineWidth(thickness);
	if (dashed){
	    // create a basic default dash
	    float [] dash = new float[2];
	    dash[0] = 8.0f;
	    dash[1] = 8.0f;
	    link.setLineDash(dash, 0.0f);
	}
	link.setLineColor(color);
	setLocationMarker(link);
    }
    
    /**
     * @param x1 Starting x point of Link
     * @param y1 Starting y point of Link
     * @param x2 End x point of Link
     * @param y2 End y point of Link
     */
    public Link(int x1, int y1, int x2, int y2,
		String details, Color color, 
		boolean dashed, float thickness){

	if (Debug.debugging("location")){
	    Debug.output("Link("
			 + x1 + ", " + y1 + ", "
			 + x2 + ", " + y2 + 
			 ")");
	}

	this.x = x1;
	this.y = y1;
	this.x2 = x2;
	this.y2 = y2;
	
	if (details != null)
	    this.details = details;
	else
	    this.details = "";

	OMLine2D link = new OMLine2D(x1,y1,x2,y2);
	link.setLineWidth(thickness);
	if (dashed){
	    // create a basic default dash
	    float [] dash = new float[2];
	    dash[0] = 8.0f;
	    dash[1] = 8.0f;
	    link.setLineDash(dash,0.0f);
	}
	link.setLineColor(color);
	setLocationMarker(link);
    }

    public void setLocation(double lat1, double lon1, double lat2, double lon2){

	this.lat = lat1;
	this.lon = lon2;
	this.lat2 = lat2;
	this.lon2 = lon2;

	OMLine2D line = (OMLine2D) getLocationMarker();
	double[] locs = new double[4];
	locs[0] = lat1;
	locs[1] = lon1;
	locs[2] = lat2;
	locs[3] = lon2;
	line.setLL(locs);
    }

    /**
     * Set new coordinates for this link.
     */
    public void setLocation(int x1,int y1,int x2, int y2){

	this.x = x1;
	this.y = y1;
	this.x2 = x2;
	this.y2 = y2;

	int xy[] = new int[4];
	xy[0] = this.x = x1;
	xy[1] = this.y = y1;
	xy[2] = this.x2 = x2;
	xy[3] = this.y2 = y2;
	OMLine2D link = getLink();
	link.setPts(xy);
	link.setRenderType(RENDERTYPE_XY);
    }

    /** Does nothing - marker handled in setLocation methods. */
    public void setGraphicLocations(double latitude, double longitude){}
    /** Does nothing - marker handled in setLocation methods. */
    public void setGraphicLocations(int x, int y){}
    /** Does nothing - marker handled in setLocation methods. */
    public void setGraphicLocations(double latitude, double longitude,
				    int offsetX, int offsetY){}

    public void setLinkColor(Color linkColor){
	// location is actually the link graphic.  getLink() does the
	// proper casting.
	if(location != null) {
	    getLink().setLineColor(linkColor);
	}
    }

    public void setShowLink(boolean showLinks){
	showLocation = showLinks;
    }

    public boolean isShowLink(){
	return showLocation;
    }

    public OMLine2D getLink(){
	return (OMLine2D) getLocationMarker();
    }
}

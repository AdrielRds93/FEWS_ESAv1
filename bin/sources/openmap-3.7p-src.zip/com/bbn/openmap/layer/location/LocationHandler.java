/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/location/LocationHandler.java,v $
 * $Revision: 1.5 $
 * $Date: 2000/05/08 14:22:36 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.location;


/*  Java Core  */
import java.awt.Component;
import java.util.Properties;
import java.util.Vector;
import java.util.Enumeration;

/**
 * The LocationHandler is the LocationLayer interface to the data.
 * It is the bearer of knowledge about how the location data is
 * stored, and has the smarts on creating the locations and links to
 * represent the data on the map. It also provides controls for
 * changing the display of the data, provided through the getGUI()
 * method, and therefore controls how the data is displayed at a
 * supervisory level.  Each location handler should have its own set of properties:
 * <P>
 * # Properties for LocationHandler
 * # Show the graphics for all the locations.
 * handler.showLocations=true
 * # Show the labels for all the locations.
 * handler.showNames=true
 */
public interface LocationHandler {

    /** A default button name used to trigger more information about a
     *  location to come up in a web browser. */
    public final static String showdetails = "Show Details";
    /** A button name used to turn a location label on/off. */
    public final static String showname = "Show Name";

    /** Property setting to show name data on startup. */
    public static final String ShowNamesProperty = ".showNames";
    /** Property to use to change the color for name data. */
    public static final String NameColorProperty = ".nameColor";
    /** The default line color for names.  */
    public final static String defaultNameColorString = "FF339159"; // greenish

    /** Property setting to show location splots on startup */
    public static final String ShowLocationsProperty = ".showLocations";
    /** Property to use to set the color of the location splot */
    public static final String LocationColorProperty = ".locationColor";
    /** The default line color for locations.  */
    public final static String defaultLocationColorString = "FFCE4F3F"; // reddish

    public final static String showLocationsCommand = "showLocations";
    public final static String showNamesCommand = "showNames";
    public final static String readDataCommand = "readData";

    /** Set up the properties of the handler. */
    public void setProperties(String prefix, Properties props);

    /**
     * Fill a vector of OMGraphics to represent the data from this
     * handler. 
     *
     * @param nwLat NorthWest latitude of area of interest.
     * @param nwLon NorthWest longitude of area of interest.
     * @param seLat SouthEast latitude of area of interest.
     * @param seLon SouthEast longitude of area of interest.
     * @param graphicList Vector to add Locations to.
     */
    public Vector get(double nwLat, double nwLon, double seLat, double seLon,
		      Vector graphicList);
    /**
     * A trigger function to tell the handler that new data is
     * available. 
     */
    public void reloadData();

    /**
     * The location layer passes a LocationPopupMenu to the handler
     * when on of its locations has been clicked on.  This is an
     * opportunity for the handler to add options to the menu that can
     * bring up further information about the location, or to change
     * the appearance of the location.
     * 
     * @param lpm LocationPopupMenu to add buttons to.
     */
    public void fillLocationPopUpMenu(LocationPopupMenu lpm);

    /**
     * Return the layer that the handler is responding to.
     */
    public LocationLayer getLayer();

    /**
     * Set the layer the handler is responding to.  This is needed in
     * case the handler has updates that it wants to show, and needs
     * to trigger a repaint.  It can also be used to communicate with
     * the information delegator.
     *
     * @param layer a LocationLayer
     */
    public void setLayer(LocationLayer layer);

    /**
     * See if the handler is displaying labels at a global level.
     */
    public boolean isShowNames();

    /**
     * Set the handler to show/hide labels at a global level.
     */
    public void setShowNames(boolean set);

    /** 
     * See if the handler is displaying location graphics at a global
     * level.  
     */
    public boolean isShowLocations();

    /**
     * Set the handler to show/hide location graphics at a global
     * level.
     */
    public void setShowLocations(boolean set);

    /**
     * A set of controls to manipulate and control the display of data
     * from the handler.
     *
     * @return Components used for control.
     */
    public java.awt.Component getGUI();
}


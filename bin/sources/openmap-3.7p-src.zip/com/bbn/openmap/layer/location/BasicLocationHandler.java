/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/location/BasicLocationHandler.java,v $
 * $Revision: 1.4 $
 * $Date: 2000/08/02 15:49:51 $
 * $Author: dietrick $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.location;

/*  Java Core  */
import javax.swing.Box;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

/**
 * A basic location handler, that just returns simple testing locaitions.
 */
public class BasicLocationHandler 
    implements LocationHandler, ActionListener {
    /** The parent layer. */
    protected LocationLayer layer;
    
    /** 
     * The default constructor for the Layer.  All of the attributes
     * are set to their default values.
     */
    public BasicLocationHandler () {}

    /** Set the layer this handler is serving. */
    public void setLayer(LocationLayer l){
	layer = l;
    }
    
    /** Get the layer the handler is serving. */
    public LocationLayer getLayer(){
	return layer;
    }

    /** 
     * The properties and prefix are managed and decoded here, for
     * the standard uses of the TestHandler.
     *
     * @param prefix string prefix used in the properties file for this layer.
     * @param properties the properties set in the properties file.  
     */
    public void setProperties(String prefix,
			      java.util.Properties properties) {
    }
    
    public void reloadData(){
    }
    
    public boolean isShowNames(){
	return true;
    }

    public void setShowNames(boolean set){
    }

    public boolean isShowLocations(){
	return true;
    }

    public void setShowLocations(boolean set){
    }

    protected Color[] colors = null;

    public Vector get(double nwLat, double nwLon, double seLat, double seLon,
		      Vector graphicList){
	if (colors == null){
	    colors = new Color[8];
	    colors[0] = Color.red;
	    colors[1] = Color.green;
	    colors[2] = Color.yellow;
	    colors[3] = Color.blue;
	    colors[4] = Color.black;
	    colors[5] = Color.white;
	    colors[6] = Color.orange;
	    colors[7] = Color.pink;
	}


	for (int i = 0; i < 10; i++){
	    Location location = new BasicLocation(42d, -72d, new String("testing"+i), null);
	    location.setLocationHandler(this);
	    location.getLabel().setLineColor(colors[i%8]);
// 	    location.getLabel().setShowBounds(true);
	    location.setShowName(true);
	    location.setShowLocation(true);
	    graphicList.addElement(location);
	}


	return graphicList;
    }

    public void fillLocationPopUpMenu (LocationPopupMenu locMenu) {
    }

    protected Box box = null;

   /** 
     * Provides the palette widgets to control the options of showing
     * maps, or attribute text.
     * 
     * @return Component object representing the palette widgets.
     */
    public java.awt.Component getGUI() {
	return box;
    }

    //----------------------------------------------------------------------
    // ActionListener interface implementation
    //----------------------------------------------------------------------

    /** 
     * The Action Listener method, that reacts to the palette widgets
     * actions.
     */
    public void actionPerformed (ActionEvent e) {
    }

}

/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/daynight/DayNightLayer.java,v $
 * $Revision: 1.11 $
 * $Date: 2000/05/25 22:17:47 $
 * $Author: dietrick $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.daynight;


/*  Java Core  */
import com.bbn.openmap.LatLonPoint;
import com.bbn.openmap.Layer;
import com.bbn.openmap.MoreMath;
import com.bbn.openmap.event.InfoDisplayEvent;
import com.bbn.openmap.event.LayerStatusEvent;
import com.bbn.openmap.event.ProjectionEvent;
import com.bbn.openmap.event.ProjectionListener;
import com.bbn.openmap.omGraphics.OMCircle;
import com.bbn.openmap.omGraphics.OMGraphic;
import com.bbn.openmap.omGraphics.OMRaster;
import com.bbn.openmap.proj.Cylindrical;
import com.bbn.openmap.proj.GreatCircle;
import com.bbn.openmap.proj.Projection;
import com.bbn.openmap.util.ColorFactory;
import com.bbn.openmap.util.Debug;
import com.bbn.openmap.util.SwingWorker;

import javax.swing.Timer;
import java.awt.Color;
import java.awt.event.ActionListener;

/*  OpenMap  */

/** 
 * The DayNightLayer is a layer that draws the day/Night terminator
 * on the map.  When the layer is re-projected, it figures out the
 * brightest point on the earth (closest to the sun), and creates an
 * image that has daytime pixels clear and the nighttime pixels
 * shaded.  There are a couple of options available for the layer.
 * The terminator can be faded from light to dark, and the width of
 * the fading can be adjusted.  The color of the shading can be
 * changed.  The shading can reflect the current time, or be set to
 * display the shading of a specified time.  A time interval can be
 * set to have the layer automatically update at regular intervals.
 *
 * <P>The openmap.properties file can control the layer with the
 * following settings:
 * <code><pre>
 * # These are all optional, and can be omitted if you want to use the defaults.
 * # draw terminator as poly (faster calculation than image,
 * # defaults to true).
 * daynight.doPolyTerminator=true
 * # number of vertices for polygon terminator line.  this is only valid
 * # if doPolyTerminator is true...
 * daynight.terminatorVerts=360
 * # termFade - the distance of the transition of fade, as a percentage of PI.
 * daynight.termFade=.1
 * # currentTime - true to display the shading at the computer's current time.
 * daynight.currentTime=true
 * # overlayTime - time, in milliseconds from java/unix epoch, to set the layer
 * # time being displayed.  currentTime has to be false for this to be used.
 * daynight.overlayTime=919453689000
 * # updateInterval - time in milliseconds between updates.  currentTime has to be
 * # true for this to be used.
 * daynight.updateInterval=300000
 * # Color of the shading (32bit Hex ARGB)
 * daynight.nighttimeColor=64000000
 * </pre></code>
 * In addition, you can get this layer to work with the OpenMap viewer
 * by editing your openmap.properties file:
 * <code><pre>
 * # layers
 * openmap.layers=daynight ...
 * # class
 * daynight.class=com.bbn.openmap.layer.daynight.DayNightLayer
 * # name
 * daynight.prettyName=Day/Night Shading
 * </pre></code>
 *
 */
public class DayNightLayer extends Layer 
    implements ProjectionListener, ActionListener {
    /** Default value of fade to the terminator line, set to .10d.
     * This means that the last 10% of the horizon will be faded
     * out. */
    public static final transient double DEFAULT_TERM_FADE = .10d;
    /** Default update interval, which is never - updates occur on re-projections. */
    public static final transient int DO_NOT_UPDATE = -1;
    /** Projection that gets set on a projection event. */
    protected Projection projection;
    /** The image used to show lightness/darkness. */
    protected OMGraphic overlay;
    /** The color of daytime - default is white and clear. */
    protected Color daytimeColor;
    /** Default color string for daytime */
    protected String defaultDaytimeColorString = "00FFFFFF";
    /** the color of darkness - default is black. */
    protected Color nighttimeColor;
    /** Default color string for nighttime */
    protected String defaultNighttimeColorString = "7F000000";
    /** Percentange of the distance from the horizon to the brightest
     * point to start fading to darkness. (0 - .5) */
    protected double termFade = DEFAULT_TERM_FADE;
    /** If true, the layer will set the darkness according to the
     * current time. */
    protected boolean currentTime = true;
    /** The time used to create the layer, in milliseconds from java/unix epoch. */
    protected long overlayTime;
    /** Update interval to automatically update the layer, in milli-seconds */
    protected int updateInterval = 300000;
    /** Update timer. */
    protected Timer timer;

    /**
     * Create the terminator line as a polygon.
     */
    protected boolean doPolyTerminator = true;

    /**
     * The number of vertices of the polygon terminator line.
     */
    protected int terminatorVerts = 360;

    /////// Properties
    public static final transient String DaytimeColorProperty = ".daytimeColor";
    public static final transient String NighttimeColorProperty = ".nighttimeColor";
    public static final transient String TermFadeProperty = ".termFade";
    public static final transient String CurrentTimeProperty = ".useCurrentTime";
    public static final transient String OverlayTimeProperty = ".overlayTime";
    public static final transient String UpdateIntervalProperty = ".updateInterval";
    public static final transient String DoPolyTerminatorProperty = ".doPolyTerminator";
    public static final transient String TerminatorVertsProperty = ".terminatorVerts";

    /** The swing worker that goes off in it's own thread to get
     * graphics.
     * */
    DayNightWorker currentWorker;
    /** Set when the projection has changed while a swing worker is
     * gathering graphics, and we want him to stop early. */
    protected boolean cancelled = false;

    /** Since we can't have the main thread taking up the time to
     * create images, we use this worker thread to do it.
     * */
    class DayNightWorker extends SwingWorker {
	/** Constructor used to create a worker thread. */
	public DayNightWorker () {
	    super();
	}

	/**  Compute the value to be returned by the <code>get</code>
	 * method.  */
	public Object construct() {
	    Debug.message("daynight", getName()+
			  "|DayNightWorker.construct()");
	    fireStatusUpdate(LayerStatusEvent.START_WORKING);
	    try {
		return prepare();
	    } catch (OutOfMemoryError e) {
		String msg = getName() + 
		    "|DayNightLayer.DayNightWorker.construct(): " + e;
		System.err.println(msg);
		e.printStackTrace();
		fireRequestMessage(new InfoDisplayEvent(this, msg));
		fireStatusUpdate(LayerStatusEvent.FINISH_WORKING);
		return null;
	    }
	}

	/** Called on the event dispatching thread (not on the worker
	 * thread) after the <code>construct</code> method has
	 * returned.  */
	public void finished() {
	    workerComplete(this);
	    fireStatusUpdate(LayerStatusEvent.FINISH_WORKING);
	}
    }

    /** 
     * The default constructor for the Layer.  All of the attributes
     * are set to their default values.
     */
    public DayNightLayer () {}

    /** 
     * The properties and prefix are managed and decoded here, for
     * the standard uses of the DayNightLayer.
     *
     * @param prefix string prefix used in the properties file for this layer.
     * @param properties the properties set in the properties file.  
     */
    public void setProperties(String prefix, java.util.Properties properties) {
	super.setProperties(prefix, properties);

	String termFadeString = properties.getProperty(prefix + TermFadeProperty);
	String currentTimeString = properties.getProperty(prefix + CurrentTimeProperty);
	String overlayTimeString = properties.getProperty(prefix + OverlayTimeProperty);
	String updateIntervalString = properties.getProperty(prefix + 
							     UpdateIntervalProperty);
	
	if (currentTimeString != null)
	    currentTime = Boolean.valueOf(currentTimeString).booleanValue();
	

	// If something stupid gets passed in here, just us the current time...
	try {
	    if (overlayTimeString != null)
		overlayTime = Long.valueOf(overlayTimeString).longValue();
	    if (overlayTime <= 0){
		currentTime = true;
	    }
	} catch (NumberFormatException e) {
	    System.err.println("DayNightLayer: Unable to parse " + 
			       OverlayTimeProperty +
			       " = " + overlayTimeString);
	    currentTime = true;
	}

	try {
	    if (updateIntervalString != null)
		updateInterval = Integer.valueOf(updateIntervalString).intValue();
	    if (updateInterval <= 0){
		updateInterval = DO_NOT_UPDATE;
		System.err.println("DayNightLayer: Not updating display.");
	    } else {
		timer = new Timer(updateInterval, this);
	    }
	} catch (NumberFormatException e) {
	    System.err.println("DayNightLayer: Unable to parse " + 
			       UpdateIntervalProperty +
			       " = " + updateIntervalString);
	    updateInterval = DO_NOT_UPDATE;
	}

	try {
	    if (termFadeString != null)
		termFade = Double.valueOf(termFadeString).floatValue();
	    else termFade = DEFAULT_TERM_FADE;

	    if (termFade < 0 || termFade >= .5){
		System.err.println("DayNightLayer: termFade funky value ignored.");
		termFade = DEFAULT_TERM_FADE;
	    }
	} catch (NumberFormatException e) {
	    System.err.println("DayNightLayer: Unable to parse " + 
			       TermFadeProperty +
			       " = " + termFadeString);
	    termFade = DEFAULT_TERM_FADE;
	}

	daytimeColor = ColorFactory.parseColorFromProperties(
	    properties,
	    prefix + DaytimeColorProperty,
	    defaultDaytimeColorString, true);

	nighttimeColor = ColorFactory.parseColorFromProperties(
	    properties,
	    prefix + NighttimeColorProperty,
	    defaultNighttimeColorString, true);

	doPolyTerminator = Boolean.valueOf(properties.getProperty(
		    prefix + DoPolyTerminatorProperty, ""+doPolyTerminator)).booleanValue();

	try {
	    terminatorVerts = Integer.parseInt(
		    properties.getProperty(
			prefix+TerminatorVertsProperty, ""+terminatorVerts));
	} catch (NumberFormatException e) {
	    System.err.println("DayNightLayer: Unable to parse " + 
			       TerminatorVertsProperty);
	}
    }

    /**
     * Handle an ActionEvent from the Timer.
     * @param ae action event from the timer.
     */
    public void actionPerformed(java.awt.event.ActionEvent ae){
	if (currentWorker == null) {
	    Debug.message("daynight", getName()+"| updating image via timer...");
	    currentWorker = new DayNightWorker();
	    currentWorker.execute();
	}
    }

    /**
     * Create the OMGraphic that acts as an overlay showing the
     * day/night terminator.  The brightest spot on the earth is
     * calculated, and then each pixel is inverse projected to find
     * out its coordinates.  Then the great circle distance is
     * calculated.  The terminator is assumed to be the great circle
     * where all the points are PI/2 away from the bright point. If
     * the termFade variable is set, then the difference in color over
     * the terminator is feathered, on equal amount of the terminator.
     *
     * @param projection the projection of the screen,
     * @return OMGraphic containing image to use for the layer.  The
     * image has been projected.
     */
    protected OMGraphic createImage(Projection projection){

	if (currentTime) overlayTime = System.currentTimeMillis();
	LatLonPoint brightPoint = SunPosition.sunPosition(overlayTime);

	// Do a fast and relatively inexpensive calculation of the
	// terminator.  NOTE: for non-cylindrical projections we don't
	// create a full-hemisphere circle so that we don't get
	// flip-rendering problem...
	if (doPolyTerminator) {
	    LatLonPoint darkPoint = GreatCircle.spherical_between(
		    brightPoint.radlat_,
		    brightPoint.radlon_,
		    Math.PI,
		    Math.PI/4d);
	    OMCircle circle = new OMCircle(
		    darkPoint,
		    (projection instanceof Cylindrical) ? 90d : 89.0d,//HACK
		    -1, terminatorVerts);
	    circle.setPolarCorrection(true);
	    circle.setFillColor(nighttimeColor);
	    circle.setLineColor(nighttimeColor);
	    circle.generate(projection);
	    return circle;
	}

	int width = projection.getWidth();
	int height = projection.getHeight();
	int[] pixels = new int[width*height];

	OMRaster ret = new OMRaster(0, 0, width, height, pixels);



	double lat, lon;

	Debug.message("daynight", getName()+
		      "|createImage: Center of bright spot lat= " + 
		      brightPoint.getLatitude() + 
		      ", lon= " + brightPoint.getLongitude());

	// Light is clear and/or white	
	int light = daytimeColor.getRGB();

	// Allocate the memory here for the testPoint
	LatLonPoint testPoint = new LatLonPoint(0d, 0d);
	// great circle distance between the bright point and each pixel.
	double distance;

	//  Set the darkeness value
	int dark = nighttimeColor.getRGB();// ARGB
	int darkness = dark >>> 24;// darkness alpha
	int value;

	// Calculate the fae limits around the terminator
	double upperFadeLimit =  (MoreMath.HALF_PI*(1.0+termFade));
	double lowerFadeLimit =  (MoreMath.HALF_PI*(1.0-termFade));
	int fadeColorValue = 0x00FFFFFF & (dark); // RGB

	for (int i = 0; i < width; i++){
	    for (int j = 0; j < height; j++){

		testPoint = projection.inverse(i, j, testPoint);
		distance = GreatCircle.spherical_distance(brightPoint.radlat_, 
							  brightPoint.radlon_,
							  testPoint.radlat_, 
							  testPoint.radlon_);

		if (distance > upperFadeLimit) {
		    pixels[j*width+i] = dark;
		} else if (distance > lowerFadeLimit){
		    value = (int)(darkness * (1 - ((upperFadeLimit - distance)/
						   (upperFadeLimit - lowerFadeLimit))));
		    value <<= 24;
		    pixels[j*width+i] = fadeColorValue | value;
		} else {
		    pixels[j*width+i] = light;
		}
	    }
	}

	ret.generate(projection);
 	return ret;
    }

    /** 
     * Sets the current raster terminator overlay.
     *
     * @param raster image of overlay 
     */
    public synchronized void setOverlay (OMGraphic raster) {
	overlay = raster;
    }

    /** 
     * Get the current raster terminator overlay.
     *
     * @return raster image of overlay 
     */
    public synchronized OMGraphic getOverlay () {
	return overlay;
    }

    /** 
     * Used to set the cancelled flag in the layer.  The swing worker
     * checks this once in a while to see if the projection has
     * changed since it started working.  If this is set to true, the
     * swing worker quits when it is safe. 
     */
    public synchronized void setCancelled(boolean set){
	cancelled = set;
    }

    /** Check to see if the cancelled flag has been set. */
    public synchronized boolean isCancelled(){
	return cancelled;
    }

    /** 
     * Implementing the ProjectionPainter interface.
     */
    public synchronized void renderDataForProjection(Projection proj, java.awt.Graphics g){
	if (proj == null){
	    Debug.error("DayNightLayer.renderDataForProjection: null projection!");
	    return;
	} else if (!proj.equals(projection)){
	    projection = proj.makeClone();
	    setOverlay(createImage(proj));
	}
	paint(g);
    }

    /** 
     * The projectionListener interface method that lets the Layer
     * know when the projection has changes, and therefore new graphics
     * have to created /supplied for the screen.
     *
     * @param e The projection event, most likely fired from a map bean.
     */
    public void projectionChanged (ProjectionEvent e) {
	Debug.message("basic", getName()+"|DayNightLayer.projectionChanged()");

	if (projection != null){
	    if (projection.equals(e.getProjection()))
		// Nothing to do, already have it and have acted on it...
	      {
		repaint();
		return;
	      }
	}
 	setOverlay(null);

	projection = e.getProjection().makeClone();
	// If there isn't a worker thread working on this already,
	// create a thread that will do the real work. If there is
	// a thread working on this, then set the cancelled flag
	// in the layer.
	if (currentWorker == null) {
	    Debug.message("daynight", getName()+"| updating image via projection changed...");
	    currentWorker = new DayNightWorker();
	    currentWorker.execute();
	}
	else setCancelled(true);
    }

    /**  
     * The DayNightWorker calls this method on the layer when it is
     * done working.  If the calling worker is not the same as the
     * "current" worker, then a new worker is created.
     *
     * @param worker the worker that has the graphics.
     */
    protected synchronized void workerComplete (DayNightWorker worker) {
	if (!isCancelled()) {
	    currentWorker = null;
	    setOverlay((OMGraphic)worker.get());
	    repaint();
	}
	else{
	    setCancelled(false);
	    currentWorker = new DayNightWorker();
	    currentWorker.execute();
	}
    }

    /**
     * Prepares the graphics for the layer.  This is where the
     * getRectangle() method call is made on the location.  <p>
     * Occasionally it is necessary to abort a prepare call.  When
     * this happens, the map will set the cancel bit in the
     * LayerThread, (the thread that is running the prepare).  If this
     * Layer needs to do any cleanups during the abort, it should do
     * so, but return out of the prepare asap.
     *
     */
    public OMGraphic prepare () {

	if (isCancelled()){
	    Debug.message("daynight", getName()+
			  "|DayNightLayer.prepare(): aborted.");
	    return null;
	}

	Debug.message("basic", getName()+"|DayNightLayer.prepare(): doing it");

	OMGraphic ret = createImage(projection);
	if (timer != null) timer.restart();
	return ret;
    }

    /**
     * Paints the layer.
     *
     * @param g the Graphics context for painting
     *
     */
    public void paint (java.awt.Graphics g) {
	Debug.message("daynight", getName()+"|DayNightLayer.paint()");
	OMGraphic image = getOverlay();

	if (image != null){
	    image.render(g);
	}
    }
}

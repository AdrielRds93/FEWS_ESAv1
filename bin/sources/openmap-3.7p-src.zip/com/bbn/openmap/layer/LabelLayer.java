/* **********************************************************************
 * 
 *  BBNT Solutions LLC, A part of GTE
 *  10 Moulton St.
 *  Cambridge, MA 02138
 *  (617) 873-2000
 * 
 *  Copyright (C) 1998, 2000
 *  This software is subject to copyright protection under the laws of 
 *  the United States and other countries.
 * 
 * **********************************************************************
 * 
 */

package com.bbn.openmap.layer;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.text.*;

import javax.swing.*;

import com.bbn.openmap.*;
import com.bbn.openmap.event.*;
import com.bbn.openmap.omGraphics.*;
import com.bbn.openmap.proj.*;
import com.bbn.openmap.util.ColorFactory;
import com.bbn.openmap.util.Debug;
import com.bbn.openmap.util.Taskable;


/**
 * Layer that displays a label.
 * This Layer is a Taskable (ActionListener) object so that it can be
 * prompted by a javax.swing.Timer object. This layer understands the
 * following properties:
 * <code><pre>
 * # display font as a Java font string
 * label.font=SansSerif-Bold
 * # like XWindows geometry: [+-]X[+-]Y, `+' indicates relative to
 * # left edge or top edges, `-' indicates relative to right or bottom
 * # edges, XX is x coordinate, YY is y coordinate
 * label.geometry=+20-30
 * # background rectangle color (ARGB)
 * label.color.bg=ffb3b3b3
 * # foreground text color (ARGB)
 * label.color.fg=ff000000
 * # date format (using java.text.SimpleDateFormat patterns)
 * label.text=The Graph
 * </pre></code>
 * <p>
 * In addition to the previous properties, you can get this layer to
 * work with the OpenMap viewer by adding/editing the additional
 * properties in your <code>openmap.properties</code> file:
 * <code><pre>
 * # layers
 * openmap.layers=label ...
 * # class
 * label.class=com.bbn.openmap.layer.LabelLayer
 * # name
 * label.prettyName=Label Layer
 * </pre></code>
 * NOTE: the color properties do not support alpha value if running on
 * JDK 1.1...
 */
public class LabelLayer extends Layer
    implements Taskable, MapMouseListener, ComponentListener
{

    // property keys
    public final static transient String fontProperty = ".font";
    public final static transient String fgColorProperty = ".color.fg";
    public final static transient String bgColorProperty = ".color.bg";
    public final static transient String geometryProperty = ".geometry";
    public final static transient String labelProperty = ".text";

    // properties
    private String fontString = "SansSerif";
    protected Font font = Font.decode(fontString);
    private int fgColorValue = 0x000000;//black
    protected Color fgColor = new Color(fgColorValue);
    private int bgColorValue = 0xffffff;//white
    protected Color bgColor = new Color(bgColorValue);
    protected String geometryString = "+20+20";
    protected String labelText = "";

    protected OMText text;
    protected Projection proj;

    protected int xpos=10;
    protected int ypos=10;
    protected String xgrav=geometryString.substring(0,1);
    protected String ygrav=geometryString.substring(3,4);

    private int dragX;
    private int dragY;
    private boolean dragging = false;


    /**
     * Construct the LabelLayer.
     */
    public LabelLayer() {
	text = new OMText(
		0, 0, "uninitialized", font,
		OMText.JUSTIFY_RIGHT);
	text.setLineColor(fgColor);
	text.setShowBounds(true);
	text.setBoundsLineColor(bgColor);
	text.setBoundsFillColor(bgColor);

	addComponentListener(this);
    }


    /**
     * Sets the properties for the <code>Layer</code>.
     * @param prefix the token to prefix the property names
     * @param props the <code>Properties</code> object
     */
    public void setProperties(String prefix, Properties props) {
	super.setProperties(prefix, props);

	fontString = props.getProperty(prefix+fontProperty, fontString);

	fgColor = ColorFactory.parseColorFromProperties(
		props, prefix+fgColorProperty, ""+fgColorValue);

	bgColor = ColorFactory.parseColorFromProperties(
		props, prefix+bgColorProperty, ""+bgColorValue);

	geometryString = props.getProperty(prefix+geometryProperty,
		geometryString);
	parseGeometryString();

	labelText = props.getProperty(
		prefix+labelProperty, labelText);

	// reset the property values
	font = Font.decode(fontString);
	text.setFont(font);
	text.setLineColor(fgColor);
	text.setBoundsLineColor(bgColor);
	text.setBoundsFillColor(bgColor);

    }

    // parse X-like geometry string
    protected void parseGeometryString () {
	int i=0;
	byte[] bytes = geometryString.getBytes();
	xgrav = new String(bytes, 0, 1);
	for (i=2; i<bytes.length; i++) {
	    if ((bytes[i] == '-') || (bytes[i] == '+'))
		break;
	}
	if (i == bytes.length)
	    return;
	ygrav = (bytes[i] == '-') ? "-" : "+";
	xpos = Integer.parseInt(new String(bytes, 1, i-1));
	++i;
	ypos = Integer.parseInt(new String(bytes, i, bytes.length-i));
    }
    
    
    // position the text graphic
    protected void positionText (int w, int h) {
	int xoff, yoff, justify;
	if (xgrav.equals("+")) {
	    xoff = xpos;
	    justify = OMText.JUSTIFY_LEFT;
	} else {
	    xoff = w - xpos;
	    justify = OMText.JUSTIFY_RIGHT;
	}
	if (ygrav.equals("+")) {
	    yoff = ypos;
	} else {
	    yoff = h - ypos;
	}
	text.setX(xoff);
	text.setY(yoff);
	text.setJustify(justify);
    }
    
    
    /**
     * Set the text to display 
     * @param s String
     */
    protected void setLabelText (String s) {
	labelText = s;
    }


    /**
     * Get the String to display
     * @return String
     */
    protected String getLabelText () {
	return labelText;
    }
    
    
    /**
     * Invoked when the projection has changed or this Layer has been
     * added to the MapBean.
     * @param e ProjectionEvent
     */    
    public void projectionChanged (ProjectionEvent e) {
	proj = e.getProjection();
	repaint();
    }
    
    /** 
     * Implementing the ProjectionPainter interface.
     */
    public synchronized void renderDataForProjection(Projection proj, Graphics g){
	if (proj != null){
	    this.proj = proj.makeClone();
	    paint(g);
	}
    }
    
    /**
     * Paints the layer.
     * @param g the Graphics context for painting
     */
    public void paint (Graphics g) {
	Projection p = proj;

	if (p == null) return;

	if (Debug.debugging("labellayer")) {
	    System.out.println("labelLayer.paint(): "+labelText);
	}
        int w = Environment.getInteger(Environment.Width, 480);
	int h = Environment.getInteger(Environment.Height, 480);
	positionText(w, h);
	text.setData(labelText);
	text.generate(p);//to get bounds
	
	// render graphics
	text.render(g);
    }
    
    //----------------------------------------------------------------------
    // Taskable Interface
    //----------------------------------------------------------------------

    /**
     * Invoked by a javax.swing.Timer.
     * @param e ActionEvent
     */
    public void actionPerformed (ActionEvent e) {
	if (Debug.debugging("datelayer")) {
	    System.out.println("DateLayer.actionPerformed()");
	}
	Object obj = e.getSource();
	// generate and repaint the graphics
	repaint();
    }
    
    //----------------------------------------------------------------------
    // MapMouseListener Interface
    //----------------------------------------------------------------------

    /**
     * Returns the MapMouseListener object that handles the mouse
     * events.
     * @return MapMouseListener this
     */
    public MapMouseListener getMapMouseListener() {
	return this;
    }

    /**
     * Return a list of the modes that are interesting to the
     * MapMouseListener.
     * @return String[] { SelectMouseMode.modeID }
     */
    public String[] getMouseModeServiceList() {
	return new String[] {
	    SelectMouseMode.modeID
	};
    }

    // Mouse Listener events
    ////////////////////////

    /**
     * Invoked when a mouse button has been pressed on a component.
     * @param e MouseEvent
     * @return false
     */
    public boolean mousePressed(MouseEvent e){ 
	int x = e.getX();
	int y = e.getY();
	if (text.distance(x, y) <= 0d) {
	    dragging = true;
	    dragX = x;
	    dragY = y;
	    return true;
	}
	return false; // did not handle the event
    }

    /**
     * Invoked when a mouse button has been released on a component.
     * @param e MouseEvent
     * @return false
     */
    public boolean mouseReleased(MouseEvent e){
	dragging = false;
	return false;
    }

    /**
     * Invoked when the mouse has been clicked on a component.
     * @param e MouseEvent
     * @return false
     */
    public boolean mouseClicked(MouseEvent e){
	return false;
    }

    /**
     * Invoked when the mouse enters a component.
     * @param e MouseEvent
     */
    public void mouseEntered(MouseEvent e){
    }

    /**
     * Invoked when the mouse exits a component.
     * @param e MouseEvent
     */
    public void mouseExited(MouseEvent e){
    }

    // Mouse Motion Listener events
    ///////////////////////////////

    /**
     * Invoked when a mouse button is pressed on a component and then 
     * dragged.  The listener will receive these events if it
     * @param e MouseEvent
     * @return false
     */
    public boolean mouseDragged(MouseEvent e){
	int w = proj.getWidth();
	int h = proj.getHeight();
	int x = e.getX();
	int y = e.getY();

	// limit coordinates
	if (x < 0) x = 0;
	if (y < 0) y = 0;
	if (x > w) x = w;
	if (y > h) y = h;

	// calculate deltas
	int dx = x-dragX;
	int dy = y-dragY;

	if (dragging) {
	    // reset dragging parms
	    dragX = x;
	    dragY = y;
	    // reset graphics positions
	    text.setX(text.getX()+dx);
	    text.setY(text.getY()+dy);
	    repaint();
	    return true;
	}
	return false;
    }

    /**
     * Invoked when the mouse button has been moved on a component
     * (with no buttons down).
     * @param e MouseEvent
     * @return false
     */
    public boolean mouseMoved(MouseEvent e){
	return false;
    }

    /**
     * Handle a mouse cursor moving without the button being pressed.
     * Another layer has consumed the event.
     */
    public void mouseMoved(){
    }

    //----------------------------------------------------------------------
    // ComponentListener implementation
    //----------------------------------------------------------------------

    /**
     * Invoked when component has been resized.
     */
    public void componentResized (ComponentEvent e) {
	Rectangle bounds = e.getComponent().getBounds();

	// move to home coordinates if out-of-bounds
	Polygon poly = text.getPolyBounds();
	if (poly != null) {
	    if (!bounds.intersects(poly.getBounds())) {
		positionText(bounds.width, bounds.height);
	    }
	}
    }

    /**
     * Invoked when component has been moved.
     */    
    public void componentMoved (ComponentEvent e) {
    }

    /**
     * Invoked when component has been shown.
     */
    public void componentShown (ComponentEvent e) {
    }

    /**
     * Invoked when component has been hidden.
     */
    public void componentHidden (ComponentEvent e) {
    }

    public int getSleepHint () {
        return 1000000;//update every 1000 seconds
    }

}

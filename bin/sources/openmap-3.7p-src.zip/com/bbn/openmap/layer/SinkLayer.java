/* **********************************************************************
 * 
 *  BBNT Solutions LLC, A part of GTE
 *  10 Moulton St.
 *  Cambridge, MA 02138
 *  (617) 873-2000
 * 
 *  Copyright (C) 1998, 2000
 *  This software is subject to copyright protection under the laws of 
 *  the United States and other countries.
 * 
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/SinkLayer.java,v $
 * $Revision: 1.4 $
 * $Date: 2000/05/08 14:22:19 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer;

import com.bbn.openmap.Layer;
import com.bbn.openmap.event.*;


/**
 * SinkLayer is a Layer which does nothing.
 * This can be used primarily as a placeholder.
 */
public class SinkLayer extends Layer {

    // the shared instance
    private static SinkLayer sharedInstance;


    /**
     * Get a shared instance of the SinkLayer.
     * @return SinkLayer shared instance
     */
    public final static SinkLayer getSharedInstance () {
	if (sharedInstance == null)
	    sharedInstance = new SinkLayer();
	return sharedInstance;
    }


    // cannot construct
    private SinkLayer () {}


    /**
     * ProjectionListener interface method.
     * @param e ProjectionEvent
     */
    public void projectionChanged (ProjectionEvent e) {
    }
}

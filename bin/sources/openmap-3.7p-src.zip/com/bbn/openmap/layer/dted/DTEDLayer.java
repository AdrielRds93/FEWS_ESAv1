/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/dted/DTEDLayer.java,v $
 * $Revision: 1.35 $
 * $Date: 2000/08/17 21:38:28 $
 * $Author: dietrick $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.dted;


/*  Java Core  */
import com.bbn.openmap.LatLonPoint;
import com.bbn.openmap.Layer;
import com.bbn.openmap.event.InfoDisplayEvent;
import com.bbn.openmap.event.LayerStatusEvent;
import com.bbn.openmap.event.MapMouseListener;
import com.bbn.openmap.event.ProjectionEvent;
import com.bbn.openmap.event.ProjectionListener;
import com.bbn.openmap.layer.util.LayerUtils;
import com.bbn.openmap.omGraphics.OMGraphicList;
import com.bbn.openmap.omGraphics.OMRect;
import com.bbn.openmap.omGraphics.OMText;
import com.bbn.openmap.proj.CADRG;
import com.bbn.openmap.proj.Projection;
import com.bbn.openmap.util.Debug;
import com.bbn.openmap.util.PaletteHelper;
import com.bbn.openmap.util.SwingWorker;

import javax.swing.Box;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.io.Serializable;

/*  OpenMap  */

/**  The DTEDLayer fills the screen with DTED data.  To view the DTED
 * iamges, the projection has to be set in the ARC projection, which
 * OpenMap calls the CADRG projection. In Gesture mode, clicking on
 * the map will cause the DTEDLayer to place a point on the window and
 * show the elevation of that point.  The Gesture response is not
 * dependent on the scale or projection of the screen.<P>
 *
 * The DTEDLayer uses the DTEDCacheManager to get the images it needs.
 * The DTEDLayer receives projection change events, and then asks the
 * cache manager for the images it needs based on the new projection.
 *
 * The DTEDLayer also relies on properties to set its
 * variables, such as the dted frame paths (there can be several at a
 * time), the opaqueness of the frame images, number of colors to use,
 * and some other display variables.  The DTEDLayer properties
 * look something like this:<P>
 * <pre>
 * #------------------------------
 * # Properties for DTEDLayer
 * #------------------------------
 * # This property should reflect the paths to the dted level 0 and 1 directories
 * dted.paths=/usr/local/matt/data/dted /cdrom/cdrom0/dted
 * 
 * # This property should reflect the paths to the dted level 2 directories
 * dted.level2.paths=/usr/local/matt/data/dted_level2
 * 
 * # Number between 0-255: 0 is transparent, 255 is opaque
 * dted.opaque=255
 * 
 * # Number of colors to use on the maps - 16, 32, 216
 * dted.number.colors=216
 * 
 * # Level of DTED data to use 0, 1, 2
 * dted.level=0
 * 
 * # Type of display for the data
 * # 0 = no shading at all
 * # 1 = greyscale slope shading
 * # 2 = band shading, in meters
 * # 3 = band shading, in feet
 * # 4 = subframe testing
 * # 5 = elevation, colored
 * dted.view.type=5
 * 
 * # Contrast setting, 1-5
 * dted.contrast=3
 * 
 * # height (meters or feet) between color changes in band shading
 * dted.band.height=25
 * 
 * # Minumum scale to display images. Larger numbers mean smaller scale, 
 * # and are more zoomed out.
 * dted.min.scale=20000000
 * 
 * # Delete the cache if the layer is removed from the map.
 * dted.kill.cache=true
 * # Number of frames to hold in the cache. The default is 
 * # DTEDFrameCache.FRAME_CACHE_SIZE, which is 15 to help smaller systems.  Better
 * # caching happens, the larger the number.
 * dted.cacheSize=40
 * #-------------------------------------
 * # End of properties for DTEDLayer
 * #-------------------------------------
 * </pre>
 * */
public class DTEDLayer extends Layer 
    implements ProjectionListener, ActionListener, MapMouseListener, Serializable {
    
    /** The cache manager. */
    protected transient DTEDCacheManager cache = null;
    /** The graphics list used for display. */
    protected OMGraphicList omGraphics;
    /** Projection that gets set on a projection event. */
    Projection projection;
    /** Set when the projection has changed while a swing worker is
     * gathering graphics, and we want him to stop early. */
    protected boolean cancelled = false;
    /** The paths to the DTED Level 0, 1 directories, telling where
     * the data is. */
    protected String[] paths;
    /** The paths to the DTED Level 2 directories, telling where the
     * data is. */
    protected String[] paths2;
    /** The level of DTED to use.  Level 0 is 1km post spacing, Level
     * 1 is 100m post spacing. Level 2 is 30m post spacing */
    protected int dtedLevel;
    /** The display type for the dted images.  Slope shading is
     * greyscale terrain modeling with highlights and shading, with
     * the 'sun' being in the NorthWest.  Colored Elevation shading is
     * the same thing, except colors are added to indicate the
     * elevation.  Band shading colors the pixels according to a range
     * of elevations.
     * */
    protected int viewType;
    /** The elevation range to use for each color in band shading. */
    protected int bandHeight;
    /** A contrast adjustment, for slope shading (1-5). */
    protected int slopeAdjust;
    protected int numColors = 216;
    protected int opaqueness;
    protected long minScale = 20000000;
    /** Flag to delete the cache if the layer is removed from the map. */
    protected boolean killCache = true;
    /** The number of frames held by the cache objects. */
    protected int cacheSize = DTEDCacheHandler.FRAME_CACHE_SIZE;
    /** The Projection ID of the last projection passed to the DTEDCacheManager
     * in a prepare call, which is used to determine if the prepare
     * call was the result of a new projection being set in the map
     * panel. 
     * */
    private String oldProjID = null;

    public static final String DTEDPathsProperty = "paths";
    public static final String DTED2PathsProperty = "level2.paths";
    public static final String OpaquenessProperty = "opaque";
    public static final String NumColorsProperty = "number.colors";
    public static final String DTEDLevelProperty = "level";
    public static final String DTEDViewTypeProperty = "view.type";
    public static final String DTEDSlopeAdjustProperty = "contrast";
    public static final String DTEDBandHeightProperty = "band.height";
    public static final String DTEDMinScaleProperty = "min.scale";
    public static final String DTEDKillCacheProperty = "kill.cache";
    public static final String DTEDFrameCacheSizeProperty = "cacheSize";

    private String level0Command = "setLevelTo0";
    private String level1Command = "setLevelTo1";
    private String level2Command = "setLevelTo2";

    /** The thread worker used to create the DTED images. */    
    DTEDWorker currentWorker;
    /** The elevation spot used in the gesture mode. */
    DTEDLocation location = null;

    static class DTEDLocation {
	OMText text;
	OMRect dot;

	public DTEDLocation(int x, int y){
	    text = new OMText(x+10, y,
                null,
                null,
			      OMText.JUSTIFY_LEFT);

	    dot = new OMRect(x-1, y-1, x+1, y+1);
	    text.setLineColor(java.awt.Color.red);
	    dot.setLineColor(java.awt.Color.red);
	}

	/** Set the text to the elevation text.
	 *
	 * @param elevation elevation of the point in meters.
	 * */
	public void setElevation(int elevation){
	    // m - ft conversion
	    if (elevation < -100)
		text.setData ("No Data Here");
	    else {
		int elevation_ft = (int)((double)elevation * 3.280840d);
		text.setData(elevation + " m / " + elevation_ft + " ft");
	    }
	}

	/** Set the x-y location of the combo in the screen */
	public void setLocation(int x, int y){
	    text.setX(x+10);
	    text.setY(y);
	    dot.setLocation(x-1, y-1, x+1, y+1);
	}

	public void render(java.awt.Graphics g){
	    text.render(g);
	    dot.render(g);
	}

	public void generate(Projection proj){
	    text.generate(proj);
	    dot.generate(proj);
	}
    }

    class DTEDWorker extends SwingWorker {
	/** Constructor used to create a worker thread. */
	public DTEDWorker () {
	    super();
	}

	/** 
	 * Compute the value to be returned by the <code>get</code> method. 
	 */
	public Object construct() {
	    Debug.message("dted", getName()+"|DTEDWorker.construct()");
	    fireStatusUpdate(LayerStatusEvent.START_WORKING);
	    try {
		return prepare();
	    } catch (OutOfMemoryError e) {
		String msg = getName()+"|DTEDLayer.DTEDWorker.construct(): "+e;
		Debug.error(msg);
		fireRequestMessage(new InfoDisplayEvent(this, msg));
		fireStatusUpdate(LayerStatusEvent.FINISH_WORKING);
		cache = null;
		return null;
	    }
	}

	/**
	 * Called on the event dispatching thread (not on the worker thread)
	 * after the <code>construct</code> method has returned.
	 */
	public void finished() {
	    workerComplete(this);
	    fireStatusUpdate(LayerStatusEvent.FINISH_WORKING);
	}
    }

    /**
     * The default constructor for the Layer.  All of the attributes
     * are set to their default values.
     */
    public DTEDLayer () {
	this(null, null);
    }

    /**
     * The default constructor for the Layer.  All of the attributes
     * are set to their default values.
     *
     * @param pathsToDTEDDirs paths to the DTED directories that hold
     * level 0 and 1 data.  
     * */
    public DTEDLayer (String[] pathsToDTEDDirs) {
	this(pathsToDTEDDirs, null);
    }

   /**
     * The default constructor for the Layer.  All of the attributes
     * are set to their default values.
     *
     * @param pathsToDTEDDirs paths to the DTED directories that hold
     * level 0 and 1 data.  
     * @param pathsToDTED2Dirs paths to the DTED directories that hold
     * level 2 data.  
     * */
    public DTEDLayer (String[] pathsToDTEDDirs, String[] pathsToDTED2Dirs) {
	setDefaultValues();
	paths = pathsToDTEDDirs;
	paths2 = pathsToDTED2Dirs;
    }

    public void setPaths(String[] pathsToDTEDDirs, String[] pathsToDTED2Dirs){
	paths = pathsToDTEDDirs;
	paths2 = pathsToDTED2Dirs;
	if (cache != null)
	    cache.setDtedDirPaths(pathsToDTEDDirs, pathsToDTED2Dirs);
    }

    protected void setDefaultValues(){
	// defaults
	paths = null;
	paths2 = null;
	opaqueness = DTEDFrameColorTable.DEFAULT_OPAQUENESS;
	dtedLevel = DTEDFrameSubframe.LEVEL_0;
	bandHeight = DTEDFrameSubframe.DEFAULT_BANDHEIGHT;
	slopeAdjust = DTEDFrameSubframe.DEFAULT_SLOPE_ADJUST;
	viewType = DTEDFrameSubframe.COLOREDSHADING;
	minScale = 20000000;
    }

    /**
     * Sets the current graphics list to the given list.
     *
     * @param aList a list of OMGraphics
     */
    public synchronized void setGraphicList (OMGraphicList aList) {
	omGraphics = aList;
    }

    /**
     * Retrieves the current graphics list.
     */
    public synchronized OMGraphicList getGraphicList () {
	return omGraphics;
    }

    /**
     * Set all the DTED properties from a properties object.
     */
    public void setProperties(java.util.Properties properties) {
	setProperties(null, properties);
    }

    /**
     * Set all the DTED properties from a properties object.
     */
    public void setProperties(String prefix, java.util.Properties properties) {

	super.setProperties(prefix, properties);

	String realPrefix;
	if (prefix != null){
	    realPrefix = prefix + ".";
	} else {
	    realPrefix = "";
	}

	paths = LayerUtils.initPathsFromProperties(properties,
						   realPrefix + DTEDPathsProperty);
	paths2 = LayerUtils.initPathsFromProperties(properties,
						    realPrefix + DTED2PathsProperty);

	String bandHeightString = properties.getProperty(realPrefix + DTEDBandHeightProperty);
	String minScaleString = properties.getProperty(realPrefix + DTEDMinScaleProperty);

	opaqueness = LayerUtils.intFromProperties(properties, 
						  realPrefix + OpaquenessProperty, 
						  DTEDFrameColorTable.DEFAULT_OPAQUENESS);
	
	numColors = LayerUtils.intFromProperties(properties, 
						 realPrefix + NumColorsProperty,
						 DTEDFrameColorTable.DTED_COLORS);

	dtedLevel = LayerUtils.intFromProperties(properties, 
						 realPrefix + DTEDLevelProperty,
						 DTEDFrameSubframe.LEVEL_0);

	viewType = LayerUtils.intFromProperties(properties, 
						realPrefix + DTEDViewTypeProperty,
						DTEDFrameSubframe.NOSHADING);

	slopeAdjust = LayerUtils.intFromProperties(properties, 
						   realPrefix + DTEDSlopeAdjustProperty,
						   DTEDFrameSubframe.DEFAULT_SLOPE_ADJUST);

	bandHeight = LayerUtils.intFromProperties(properties, 
						  realPrefix + DTEDBandHeightProperty, 25);
	
	minScale =  (long) LayerUtils.intFromProperties(properties, 
							realPrefix + DTEDMinScaleProperty,
							20000000);
	
	cacheSize = LayerUtils.intFromProperties(properties,
							realPrefix + DTEDFrameCacheSizeProperty,
							DTEDCacheHandler.FRAME_CACHE_SIZE);
	if (minScale < 100){
	    minScale = 20000000;
	    Debug.error("DTEDLayer: min.scale unreasonable, setting to 20M");
	}

	killCache = LayerUtils.booleanFromProperties(properties, 
						     realPrefix + DTEDKillCacheProperty,
						     true);
    }

   /** 
     *  Called when the layer is no longer part of the map.  In this
     *  case, we should disconnect from the server if we have a
     *  link. 
     */
    public void removed(java.awt.Container cont){
	if (killCache){
	    Debug.output("DTEDLayer: emptying cache!");
	    cache = null;
	}
    }

    /** Used to set the cancelled flag in the layer.  The swing worker
     * checks this once in a while to see if the projection has
     * changed since it started working.  If this is set to true, the
     * swing worker quits when it is safe. 
     * */
    public synchronized void setCancelled(boolean set){
	cancelled = set;
    }

    /** Check to see if the cancelled flag has been set. */
    public synchronized boolean isCancelled(){
	return cancelled;
    }

    /** 
     * Implementing the ProjectionPainter interface.
     */
    public synchronized void renderDataForProjection(Projection proj, java.awt.Graphics g){
	if (proj == null){
	    Debug.error("DTEDLayer.renderDataForProjection: null projection!");
	    return;
	} else if (!proj.equals(projection)){
	    projection = proj.makeClone();
	    setGraphicList(prepare());
	}
	paint(g);
    }

    /**
     * From the ProjectionListener interface.
     */
    public void projectionChanged (ProjectionEvent e) {
	Debug.message("basic", getName()+"|DTEDLayer.projectionChanged()");

	if (projection != null){
	    if (projection.equals(e.getProjection()))
		// Nothing to do, already have it and have acted on it...
	      {
		repaint();
		return;
	      }
	}
 	setGraphicList(null);

	projection = e.getProjection().makeClone();
	// If there isn't a worker thread working on this already,
	// create a thread that will do the real work. If there is
	// a thread working on this, then set the cancelled flag
	// in the layer.
	if (currentWorker == null) {
	    currentWorker = new DTEDWorker();
	    currentWorker.execute();
	}
	else setCancelled(true);
    }

    /**  The DTEDWorker calls this method on the layer when it is
     * done working.  If the calling worker is not the same as the
     * "current" worker, then a new worker is created.
     *
     * @param worker the worker that has the graphics.
     * */
    protected synchronized void workerComplete (DTEDWorker worker) {
	if (!isCancelled()) {
	    currentWorker = null;
	    setGraphicList((OMGraphicList)worker.get());
	    repaint();
	}
	else{
	    setCancelled(false);
	    currentWorker = new DTEDWorker();
	    currentWorker.execute();
	}
    }

    /** Prepares the graphics for the layer.  This is where the
     * getRectangle() method call is made on the dted.  <p>
     * Occasionally it is necessary to abort a prepare call.  When
     * this happens, the map will set the cancel bit in the
     * LayerThread, (the thread that is running the prepare).  If this
     * Layer needs to do any cleanups during the abort, it should do
     * so, but return out of the prepare asap.
     *
     * */
    public OMGraphicList prepare () {

	if (isCancelled()){
	    Debug.message("dted", getName()+"|DTEDLayer.prepare(): aborted.");
	    return null;
	}

	if (projection == null){
	    Debug.error("DTED Layer needs to be added to the MapBean before it can draw images!");
	    return new OMGraphicList();
	}

	if (cache == null){
	    Debug.output("DTEDLayer: Creating cache! (This is a one-time operation!)");
	    cache = new DTEDCacheManager(paths, paths2, numColors, opaqueness);
	    cache.setCacheSize(cacheSize);
	    DTEDFrameSubframeInfo dfsi = new DTEDFrameSubframeInfo(viewType, bandHeight, 
								   dtedLevel, slopeAdjust);
	    cache.setSubframeInfo(dfsi);
	}

	// Check to make sure the projection is CADRG
	if (!(projection instanceof CADRG)) {
	    if (viewType != DTEDFrameSubframe.NOSHADING){
		fireRequestInfoLine("  DTED requires the CADRG projection to view images.");
		Debug.error("DTEDLayer: DTED requires the CADRG projection to view images.");
	    }
	    return new OMGraphicList();
	}

	Debug.message("basic", getName()+"|DTEDLayer.prepare(): doing it");

	// Setting the OMGraphicsList for this layer.  Remember, the
	// OMGraphicList is made up of OMGraphics, which are generated
	// (projected) when the graphics are added to the list.  So,
	// after this call, the list is ready for painting.

	// call getRectangle();
	if (Debug.debugging("dted")) {
	    Debug.output(
		getName()+"|DTEDLayer.prepare(): " +
		"calling getRectangle " +
		" with projection: " + projection +
		" ul = " + projection.getUpperLeft() + " lr = " + 
		projection.getLowerRight()); 
	}

	OMGraphicList omGraphicList;

	if (projection.getScale() < minScale)
	    omGraphicList = cache.getRectangle((CADRG)projection);
	else {
	    fireRequestInfoLine("  The scale is too small for DTED viewing.");
	    Debug.error("DTEDLayer: scale (" + projection.getScale() + 
			") is smaller than minimum (" + minScale + ") allowed.");
	    omGraphicList = new OMGraphicList();
	}
	/////////////////////
	// safe quit
	int size = 0;
	if (omGraphicList != null){
	    size = omGraphicList.size();	
	    Debug.message("basic", getName()+
			  "|DTEDLayer.prepare(): finished with "+
			  size+" graphics");
	}
	else 
	    Debug.message("basic", getName()+
	      "|DTEDLayer.prepare(): finished with null graphics list");

	// Don't forget to project them.  Since they are only being
	// recalled if the projection hase changed, then we need to
	// force a reprojection of all of them because the screen
	// position has changed.
	omGraphicList.project(projection, true);
	return omGraphicList;
    }


    /**
     * Paints the layer.
     *
     * @param g the Graphics context for painting
     *
     */
    public void paint (java.awt.Graphics g) {
	Debug.message("dted", getName()+"|DTEDLayer.paint()");

	OMGraphicList tmpGraphics = getGraphicList();

	if (tmpGraphics != null) {
	    tmpGraphics.render(g);
	}

	if (location != null) location.render(g);
	location = null;
    }


    //----------------------------------------------------------------------
    // GUI
    //----------------------------------------------------------------------

    /** The user interface palette for the DTED layer. */
    protected Box palette = null;

    /** Creates the interface palette. */
    public java.awt.Component getGUI() {

	if (palette == null){
	    if (Debug.debugging("dted"))
		Debug.output("DTEDLayer: creating DTED Palette.");

 	    palette = Box.createVerticalBox();
 	    Box subbox1 = Box.createHorizontalBox();
 	    Box subbox2 = Box.createVerticalBox();
 	    Box subbox3 = Box.createHorizontalBox();

// 	    palette = new JPanel();
//  	    palette.setLayout(new GridLayout(0, 1));

	    // The DTED Level selector
	    JPanel levelPanel = PaletteHelper.createPaletteJPanel("DTED Level");
	    ButtonGroup levels = new ButtonGroup();
	    
	    ActionListener al = new ActionListener(){
		public void actionPerformed(ActionEvent e){
		    if (cache != null){
			String ac = e.getActionCommand();
			int newLevel;
			if (ac.equalsIgnoreCase(level2Command))
			    newLevel = DTEDFrameSubframe.LEVEL_2;
			else if (ac.equalsIgnoreCase(level1Command))
			    newLevel = DTEDFrameSubframe.LEVEL_1;
			else newLevel = DTEDFrameSubframe.LEVEL_0;
			DTEDFrameSubframeInfo dfsi = cache.getSubframeInfo();
			dfsi.dtedLevel = newLevel;
// 			cache.setSubframeInfo(dfsi);
		    }
		}
	    };

	    JRadioButton level0 = new JRadioButton("Level 0");
	    level0.addActionListener(al);
	    level0.setActionCommand(level0Command);
	    JRadioButton level1 = new JRadioButton("Level 1");
	    level1.addActionListener(al);
	    level1.setActionCommand(level1Command);
	    JRadioButton level2 = new JRadioButton("Level 2");
	    level2.addActionListener(al);
	    level2.setActionCommand(level2Command);

	    levels.add(level0);
	    levels.add(level1);
	    levels.add(level2);

	    switch(dtedLevel){
	    case 2: level2.setSelected(true); break;
	    case 1: level1.setSelected(true); break;
	    case 0:
	    default:
		level0.setSelected(true);
	    }

	    levelPanel.add(level0);
	    levelPanel.add(level1);
	    levelPanel.add(level2);

	    // The DTED view selector
	    JPanel viewPanel = PaletteHelper.createPaletteJPanel("View Type");
	    String[] viewStrings = { "None", "Shading", "Elevation Shading", 
				     "Elevation Bands (Meters)", "Elevation Bands (Feet)"};

	    JComboBox viewList = new JComboBox(viewStrings);
	    viewList.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent e){
		    JComboBox jcb = (JComboBox) e.getSource();
		    int newView = jcb.getSelectedIndex();
		    switch(newView){
		    case 0: viewType = DTEDFrameSubframe.NOSHADING; break;
		    case 1: viewType = DTEDFrameSubframe.SLOPESHADING; break;
		    case 2: viewType = DTEDFrameSubframe.COLOREDSHADING; break;
		    case 3: viewType = DTEDFrameSubframe.METERSHADING; break;
		    case 4: viewType = DTEDFrameSubframe.FEETSHADING; break;
		    default: viewType = DTEDFrameSubframe.NOSHADING;
		    }
		    if (cache != null){
			DTEDFrameSubframeInfo dfsi = cache.getSubframeInfo();
			dfsi.viewType = viewType;
// 			cache.setSubframeInfo(dfsi);
		    }	

		}
	    });
	    int selectedView;
	    switch (viewType) {
	    case 0:
	    case 1:
		selectedView = viewType; break;
	    case 2:
	    case 3:
		selectedView = viewType + 1; break;
	    case 4:
		// This puts the layer in testing mode, and the menu
		// changes.
		String[] viewStrings2 = {"None", "Shading", 
					 "Elevation Bands (Meters)", 
					 "Elevation Bands (Feet)", 
					 "Subframe Testing", 
					 "Elevation Shading"};
		viewList = new JComboBox(viewStrings2);
		viewList.addActionListener(new ActionListener(){
		    public void actionPerformed(ActionEvent e){
			JComboBox jcb = (JComboBox) e.getSource();
			int newView = jcb.getSelectedIndex();
			if (cache != null){
			    DTEDFrameSubframeInfo dfsi = cache.getSubframeInfo();
			    dfsi.viewType = newView;
// 			    cache.setSubframeInfo(dfsi);
			}	
		    }
		});
		selectedView = viewType;
		break;
	    case 5: 
		selectedView = 2; //DTEDFrameSubframe.COLOREDSHADING
		break;
	    default:
		selectedView = DTEDFrameSubframe.NOSHADING;
	    }

	    viewList.setSelectedIndex(selectedView);
	    viewPanel.add(viewList);

	    // The DTED Contrast Adjuster
	    JPanel contrastPanel = PaletteHelper.createPaletteJPanel("Contrast Adjustment");
	    JSlider contrastSlide = new JSlider(
		JSlider.HORIZONTAL, 1/*min*/, 5/*max*/, 3/*inital*/);
	    java.util.Hashtable dict = new java.util.Hashtable();
	    dict.put(new Integer(1), new JLabel("min"));
	    dict.put(new Integer(5), new JLabel("max"));
	    contrastSlide.setLabelTable(dict);
	    contrastSlide.setPaintLabels(true);
	    contrastSlide.setMajorTickSpacing(1);
	    contrastSlide.setPaintTicks(true);
	    contrastSlide.setSnapToTicks(true);
	    contrastSlide.addChangeListener(new ChangeListener(){
		public void stateChanged(ChangeEvent ce){
		    JSlider slider = (JSlider) ce.getSource();
		    if (slider.getValueIsAdjusting()){
		        fireRequestInfoLine(getName() + 
					    " - Contrast Slider value = " + 
					    slider.getValue());
			slopeAdjust = slider.getValue();
			if (cache != null){
			    DTEDFrameSubframeInfo dfsi = cache.getSubframeInfo();
			    dfsi.slopeAdjust = slopeAdjust;
//   			    cache.setSubframeInfo(dfsi);
			}
		    }
		}
	    });
	    contrastPanel.add(contrastSlide);


	    // The DTED Band Height Adjuster
	    JPanel bandPanel = PaletteHelper.createPaletteJPanel("Band Elevation Spacing");
	    JSlider bandSlide = new JSlider(
		JSlider.HORIZONTAL, 0/*min*/, 1000/*max*/, bandHeight/*inital*/);
	    bandSlide.setLabelTable(bandSlide.createStandardLabels(250));
	    bandSlide.setPaintLabels(true);
	    bandSlide.setMajorTickSpacing(250);
	    bandSlide.setMinorTickSpacing(50);
	    bandSlide.setPaintTicks(true);
	    bandSlide.addChangeListener(new ChangeListener(){
		public void stateChanged(ChangeEvent ce){
		    JSlider slider = (JSlider) ce.getSource();
		    if (slider.getValueIsAdjusting()){
			fireRequestInfoLine(getName() + 
					    " - Band Slider value = " + 
					    slider.getValue());
			bandHeight = slider.getValue();
			if (cache != null){
			    DTEDFrameSubframeInfo dfsi = cache.getSubframeInfo();
			    dfsi.bandHeight = bandHeight;
//   			    cache.setSubframeInfo(dfsi);
			}
		    }
		}
	    });

	    bandPanel.add(bandSlide);

	    JButton redraw = new JButton("Redraw DTED Layer");
	    redraw.addActionListener(this);

	    subbox1.add(levelPanel);
	    subbox1.add(viewPanel);
	    palette.add(subbox1);
	    subbox2.add(contrastPanel);
	    subbox2.add(bandPanel);
	    palette.add(subbox2);
	    subbox3.add(redraw);
	    palette.add(subbox3);
	}

	return palette;
    }


    //----------------------------------------------------------------------
    // ActionListener interface implementation
    //----------------------------------------------------------------------

    /**
     * Used just for the redraw button.
     */
    public void actionPerformed (ActionEvent e) {
	if (currentWorker == null) {
	    fireStatusUpdate(LayerStatusEvent.START_WORKING);
	    currentWorker = new DTEDWorker();
	    currentWorker.execute();
	}
	else setCancelled(true);
    }

    //----------------------------------------------------------------------
    // MapMouseListener interface implementation
    //----------------------------------------------------------------------

    public synchronized MapMouseListener getMapMouseListener(){
	return this;
    }

    public String[] getMouseModeServiceList() {
	String[] services = {"Gestures"};
	return services;
    }

    public boolean mousePressed(MouseEvent e){return false;}
    public boolean mouseReleased(MouseEvent e){
	LatLonPoint ll = projection.inverse(e.getX(), e.getY());
	location = new DTEDLocation(e.getX(), e.getY());
	location.setElevation(cache.getElevation(ll.getLatitude(), ll.getLongitude()));
	location.generate(projection);
	repaint();
	return true;
    }
    public boolean mouseClicked(MouseEvent e){return false;}
    public void mouseEntered(MouseEvent e){}
    public void mouseExited(MouseEvent e){}
    public boolean mouseDragged(MouseEvent e){return false;}
    public boolean mouseMoved(MouseEvent e){return false;}
    public void mouseMoved(){}

}

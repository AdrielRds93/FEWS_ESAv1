/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1999-2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/link/LinkGUIRequest.java,v $
 * $Revision: 1.2 $
 * $Date: 2000/05/08 14:22:30 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.link;

import com.bbn.openmap.LatLonPoint;

import java.util.Properties;
import java.io.IOException;
import java.awt.event.MouseEvent;
import java.awt.event.KeyEvent;

/** 
 */
public class LinkGUIRequest {

    String linkStatus = Link.END_TOTAL;

    /** Version Number of request format. */
    protected static float version = Link.LINK_VERSION;

    public LinkGUIRequest(Link link) throws IOException {
    }

    public String getType(){
	return Link.GUI_REQUEST_HEADER;
    }

    /** 
     * After reading the gesture response, this returns the section
     * ending string terminating the gesture section, either
     * Link.END_TOTAL or Link.END_SECTION.
     * 
     * @return either Link.END_TOTAL or Link.END_SECTION. 
     */
    public String getLinkStatus(){
	return linkStatus;
    }

    public static void write(String[] args,
			     Link link) 
	throws IOException {
	
	// Do a check to make sure the arguments are set in key
	// value pairs.  If there is a leftover arg, leave it off.
	int normedNumArgs = (args.length/2)*2;
	link.dos.writeFloat(version);
	link.dos.writeInt(normedNumArgs);
	for (int i = 0; i < normedNumArgs; i++){
	    link.dos.writeInt(args[i].length());
	    link.dos.writeChars(args[i]);
	}
	
	link.end(Link.END_TOTAL);
    }

    /**
     * Read the link and pull off the gesture, filling in the fields
     * of this object.
     *
     * @param link the link to read from. 
     * @return Link.END_TOTAL or Link.END_SECTION 
     */
    public String read(Link link) throws IOException {
	return link.readDelimiter(false);
    }

}

/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1999-2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/link/LinkRectangle.java,v $
 * $Revision: 1.4 $
 * $Date: 2000/05/08 14:22:32 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.link;

import com.bbn.openmap.omGraphics.OMRect;
import com.bbn.openmap.layer.util.LayerUtils;
import com.bbn.openmap.util.ColorFactory;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

/**
 * Read and write the Link protocol for rectangles.
 */
public class LinkRectangle implements LinkGraphicConstants, LinkPropertiesConstants {

    /**
     * Create a lat/lon rectangle.
     * @param lt1 latitude of north edge, decimal degrees.
     * @param ln1 longitude of west edge, decimal degrees.
     * @param lt2 latitude of south edge, decimal degrees.
     * @param ln2 longitude of east edge, decimal degrees.
     * @param lType line type  - see lineType.
     * @param properties description of drawing attributes.
     * @param dos DataOutputStream
     * @throws IOException
     */
    public static void write (double lt1, double ln1,
			      double lt2, double ln2,
			      int lType, LinkProperties properties, 
			      DataOutputStream dos)
	throws IOException {
	LinkRectangle.write (lt1, ln1, lt2, ln2, lType, -1, properties, dos);
    }

    /**
     * Create a lat/lon rectangle.
     * @param lt1 latitude of north edge, decimal degrees.
     * @param ln1 longitude of west edge, decimal degrees.
     * @param lt2 latitude of south edge, decimal degrees.
     * @param ln2 longitude of east edge, decimal degrees.
     * @param lType line type  - see lineType.
     * @param nsegs number of segment points (only for LINETYPE_GREATCIRCLE
     * or LINETYPE_RHUMB line types, and if &lt; 1, this value is generated
     * internally)
     * @param properties description of drawing attributes.
     * @param dos DataOutputStream
     * @throws IOException
     */
    public static void write (double lt1, double ln1,
			      double lt2, double ln2,
			      int lType, int nsegs, 
			      LinkProperties properties, 
			      DataOutputStream dos)
	throws IOException {
	
	dos.write(Link.RECTANGLE_HEADER.getBytes());
	dos.writeInt(GRAPHICTYPE_RECTANGLE);
	dos.writeInt(RENDERTYPE_LATLON);
	dos.writeInt(lType);
	dos.writeFloat((float) lt1);
	dos.writeFloat((float) ln1);
	dos.writeFloat((float) lt2);
	dos.writeFloat((float) ln2);
	
	dos.writeInt(nsegs);
	properties.write(dos);
    }

    /**
     * Construct an XY rectangle.
     * It doesn't matter which corners of the rectangle are used, as
     * long as they are opposite from each other.
     * @param px1 x pixel position of the first corner relative to the
     * window origin
     * @param py1 y pixel position of the first corner relative to the
     * window origin
     * @param px2 x pixel position of the second corner relative to the
     * window origin
     * @param py2 y pixel position of the second corner relative to the
     * window origin
     * @param properties description of drawing attributes.
     * @param dos DataOutputStream
     * @throws IOException
     */
    public static void write (int px1, int py1, int px2, int py2, 
			      LinkProperties properties,
			      DataOutputStream dos)
	throws IOException { 
	
	dos.write(Link.RECTANGLE_HEADER.getBytes());
	dos.writeInt(GRAPHICTYPE_RECTANGLE);
	dos.writeInt(RENDERTYPE_XY);
	dos.writeInt(px1);
	dos.writeInt(py1);
	dos.writeInt(px2);
	dos.writeInt(py2);
	properties.write(dos);
    }

    /**
     * Construct an XY rectangle relative to a lat/lon point
     * (RENDERTYPE_OFFSET).
     * It doesn't matter which corners of the rectangle are used, as
     * long as they are opposite from each other.
     * @param lt1 latitude of the reference point, decimal degrees.
     * @param ln1 longitude of the reference point, decimal degrees.
     * @param px1 x pixel position of the first corner relative to the
     * reference point
     * @param py1 y pixel position of the first corner relative to the
     * reference point
     * @param px2 x pixel position of the second corner relative to the
     * reference point
     * @param py2 y pixel position of the second corner relative to the
     * reference point
     * @param properties description of drawing attributes.
     * @param dos DataOutputStream
     * @throws IOException
     */
    public static void write (double lt1, double ln1,
			      int px1, int py1, int px2, int py2, 
			      LinkProperties properties,
			      DataOutputStream dos)
	throws IOException { 

	dos.write(Link.RECTANGLE_HEADER.getBytes());
	dos.writeInt(GRAPHICTYPE_RECTANGLE);
	dos.writeInt(RENDERTYPE_OFFSET);
	dos.writeFloat((float) lt1);
	dos.writeFloat((float) ln1);
	dos.writeInt(px1);
	dos.writeInt(py1);
	dos.writeInt(px2);
	dos.writeInt(py2);
	properties.write(dos);
    }

    /** 
     * Read the DataInputStream, and create an OMRect.  Assumes that the
     * LinkRectangle header has been read from the link.
     *
     * @param dis DataInputStream
     * @return OMRect
     * @throws IOException
     * @see com.bbn.openmap.omGraphics.OMRect 
     */
    public static OMRect read(DataInputStream dis)
	throws IOException {

	OMRect rect = null;
	int x1, y1, x2, y2;
	double lt1, ln1, lt2, ln2;

	int renderType = dis.readInt();
	
	switch (renderType){
	case RENDERTYPE_LATLON:
	    int lineType = dis.readInt();
	    lt1 = dis.readFloat();
	    ln1 = dis.readFloat();
	    lt2 = dis.readFloat();
	    ln2 = dis.readFloat();
	    int nsegs = dis.readInt();
	    
	    rect = new OMRect(lt1, ln1, lt2, ln2, lineType, nsegs);
	    break;
	case RENDERTYPE_XY:
	    x1 = dis.readInt();
	    y1 = dis.readInt();
	    x2 = dis.readInt();
	    y2 = dis.readInt();
	    
	    rect = new OMRect(x1, y1, x2, y2);
	    break;
	case RENDERTYPE_OFFSET:
	    lt1 = dis.readFloat();
	    ln1 = dis.readFloat();
	    
	    x1 = dis.readInt();
	    y1 = dis.readInt();
	    x2 = dis.readInt();
	    y2 = dis.readInt();
	    
	    rect = new OMRect(lt1, ln1, x1, y1, x2, y2);
	    break;
	default:
	}

	LinkProperties properties = new LinkProperties(dis);

	if (rect != null){
	    rect.setLineColor(ColorFactory.parseColorFromProperties(
		properties, LPC_LINECOLOR,
		BLACK_COLOR_STRING, true));
	    rect.setFillColor(ColorFactory.parseColorFromProperties(
		properties, LPC_FILLCOLOR,
		CLEAR_COLOR_STRING, true));
	    rect.setSelectColor(ColorFactory.parseColorFromProperties(
		properties, LPC_HIGHLIGHTCOLOR,
		BLACK_COLOR_STRING, true));
	    rect.setLineWidth(LayerUtils.intFromProperties(
		properties, LPC_LINEWIDTH, 1));
	    rect.setAppObject(properties);
	}
	
	return rect;
    }

}

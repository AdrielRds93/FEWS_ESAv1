/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1999-2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/link/LinkText.java,v $
 * $Revision: 1.4 $
 * $Date: 2000/05/08 14:22:32 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.link;

import com.bbn.openmap.layer.util.LayerUtils;
import com.bbn.openmap.omGraphics.OMText;
import com.bbn.openmap.util.ColorFactory;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

/**
 */
public class LinkText implements LinkGraphicConstants, LinkPropertiesConstants {

    public static String DEFAULT_FONT = "-*-SansSerif-normal-o-normal--12-*-*-*-*-*-*";

   /**
     * Creates a text object, with Lat/Lon placement.
     * @param latPoint latitude of the string, in decimal degrees.
     * @param lonPoint longitude of the string, in decimal degrees.
     * @param stuff the string to be displayed.
     * @param font the Font description for the string.
     * @param just the justification of the string.
     * @param properties attributes for the graphic.
     * @param dos DataOutputStream
     * @throws IOException.
     */
    public static void write(double latPoint, double lonPoint,
			     String stuff, String font, int just, 
			     LinkProperties properties, 
			     DataOutputStream dos)
	throws IOException {
	
	dos.write(Link.TEXT_HEADER.getBytes());
	dos.writeInt(GRAPHICTYPE_TEXT);
	dos.writeInt(RENDERTYPE_LATLON);
	dos.writeFloat((float) latPoint);
	dos.writeFloat((float) lonPoint);
	dos.writeInt(just);

	properties.setProperty(LPC_LINKTEXTSTRING, stuff);
	properties.setProperty(LPC_LINKTEXTFONT, font);
	properties.write(dos);
    }

    /**
     * Creates a text object, with XY placement, and default SansSerif
     * font. 
     * @param x1 horizontal window pixel location of the string.
     * @param y1 vertical window pixel location of the string.
     * @param stuff the string to be displayed.
     * @param font the Font description for the string.
     * @param just the justification of the string
     * @param properties attributes for the graphic.
     * @param dos DataOutputStream
     * @throws IOException.
     */
    public static void write(int x1, int y1, String stuff, String font, int just, 
			     LinkProperties properties, DataOutputStream dos)
	throws IOException {

	dos.write(Link.TEXT_HEADER.getBytes());
	dos.writeInt(GRAPHICTYPE_TEXT);
	dos.writeInt(RENDERTYPE_XY);
	dos.writeInt(x1);
	dos.writeInt(y1);
	dos.writeInt(just);

	properties.setProperty(LPC_LINKTEXTSTRING, stuff);
	properties.setProperty(LPC_LINKTEXTFONT, font);
	properties.write(dos);
    }

    /**
     * Rendertype is RENDERTYPE_OFFSET.
     *
     * @param latPoint latitude of center of text/ellipse.
     * @param lonPoint longitude of center of text/ellipse.
     * @param offset_x1 # pixels to the right the center will be moved
     * from lonPoint.
     * @param offset_y1 # pixels down that the center will be moved
     * from latPoint.
     * @param aString the string to be displayed.
     * @param font the Font description for the string.
     * @param just the justification of the string.
     * @param properties attributes for the graphic.
     * @param dos DataOutputStream
     * @throws IOException.
     */
    public static void write(double latPoint, double lonPoint,
			     int offset_x1, int offset_y1, 
			     String stuff, String font, int just, 
			     LinkProperties properties, 
			     DataOutputStream dos)
	throws IOException {

	dos.write(Link.TEXT_HEADER.getBytes());
	dos.writeInt(GRAPHICTYPE_TEXT);
	dos.writeInt(RENDERTYPE_OFFSET);
	dos.writeFloat((float) latPoint);
	dos.writeFloat((float) lonPoint);
	dos.writeInt(offset_x1);
	dos.writeInt(offset_y1);

	properties.setProperty(LPC_LINKTEXTSTRING, stuff);
	properties.setProperty(LPC_LINKTEXTFONT, font);
	properties.write(dos);
    }

    public static OMText read(DataInputStream dis)
	throws IOException {

	OMText text = null;
	double lat = 0;
	double lon = 0;
	int x = 0;
	int y = 0; 
	int i = 0;
	int just = 0;
	int length;
	String string, font;

	int renderType = dis.readInt();
	
	switch (renderType){
	case RENDERTYPE_OFFSET:
	    lat = dis.readFloat();
	    lon = dis.readFloat();	    
	case RENDERTYPE_XY:
	    x = dis.readInt();
	    y = dis.readInt();	   
	    break;
	case RENDERTYPE_LATLON:
	default:
	    lat = dis.readFloat();
	    lon = dis.readFloat();	    
	}
	
	just = dis.readInt();
	
	LinkProperties properties = new LinkProperties(dis);

	string = properties.getProperty(LPC_LINKTEXTSTRING);
	font = properties.getProperty(LPC_LINKTEXTFONT);
	
	if (string == null) string = "";
	if (font == null) font = DEFAULT_FONT;
	
	switch (renderType){
	case RENDERTYPE_OFFSET:
	    text = new OMText(lat, lon, x, y, string, OMText.rebuildFont(font), just);
	    break;
	case RENDERTYPE_XY:
	    text = new OMText(x, y, string, OMText.rebuildFont(font), just);
	    break;
	case RENDERTYPE_LATLON:
	default:
	    text = new OMText(lat, lon, string, OMText.rebuildFont(font), just);
	}
	
	if (text != null){
	    text.setLineColor(ColorFactory.parseColorFromProperties(
		properties, LPC_LINECOLOR,
		BLACK_COLOR_STRING, true));
	    text.setFillColor(ColorFactory.parseColorFromProperties(
		properties, LPC_FILLCOLOR,
		CLEAR_COLOR_STRING, true));
	    text.setSelectColor(ColorFactory.parseColorFromProperties(
		properties, LPC_HIGHLIGHTCOLOR,
		BLACK_COLOR_STRING, true));
	    text.setLineWidth(LayerUtils.intFromProperties(
		properties, LPC_LINEWIDTH, 1));
	    text.setAppObject(properties);
	}

	return text;
    }


}

/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1999-2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/link/LinkManager.java,v $
 * $Revision: 1.2 $
 * $Date: 2000/05/08 14:22:31 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.link;

import java.io.*;
import java.net.Socket;

/**
 * The LinkManager..
 */
public class LinkManager {

    protected String host;
    protected int port;

    /** volatile because we want internal methods to get the message
     * that a link was nulled out. */
    protected volatile ClientLink link;

    /** Constructor. */
    public LinkManager(String host, int port) {
	this.host = host;
	this.port = port;
    }

    /**
     * This should be the only method a multi-threaded object uses to
     * gain use of the thread, i.e., on the client side where a GUI
     * can start a lot of requests.  If the link was not able to be
     * reatined for the requestor, then null will be returned.  Null
     * should be tested for by the callers, so that they can handle
     * the rejection properly.
     *
     * @param waitForLock if true, the caller will block in this
     * method until the link has been locked for the caller.  If
     * false, a null will be returned if the lock on the link couldn't
     * be set for the caller's use.
     * @return a link if the link is locked for the caller's use, null
     * if the link is not available.
     */
    public ClientLink getLink(boolean waitForLock) throws java.io.IOException {

	// NOTE: This should be the only place that the link
	// object gets assigned.  Otherwise, the layer can end up
	// using two different links via different threads.
	if (link == null){
	    synchronized (this){
		if (link == null){
		    ClientLink tmplink = null;
		    try {
			Socket socket = new Socket(host, port);
			tmplink = new ClientLink(socket);
		    } catch (java.net.UnknownHostException uhe){
			System.err.println("LinkLayer: error trying to contact host:" +
					   host);
			tmplink = null;
			throw new java.io.IOException("No Contact with host:" + host + 
						      " on port:"+ port);
		    }
		    link = tmplink;
		}
	    }
	} 

	try {
	    while (!link.setLocked(true)){
		
		// This handles the case where we don't want to wait
		// for the link to become available.
		if (!waitForLock){
		    return null;
		}
		
		// We will wait here for the link to not be in use.
		// Catch a link == null in case the link was shut down
		// in finLink() from another thread.  IF we didn't
		// catch the lock, we stay in the loop.
		try {
		    Thread.sleep(300);
		} catch (java.lang.InterruptedException ie){}
	    }
	} catch (NullPointerException npe){
	    // since probably means link is null, so just return null
	    // in case some other thread tries to do something
	    // tricky..
	    return null;
	}
    
	return link;
    }
    
    /**
     *  When a getLink() is called, and the link is reserved for that
     *  caller, finLink() MUST be called to release the link for
     *  others.  If it is not called, noone else will be able to use
     *  it.
     */
    public void finLink() throws IOException {
	if (link.isCloseLink()){
	    link.close();
	    link = null;
	} else {
	    link.setLocked(false);
	}
    }

    /** 
     * Set the link to null.
     */
    public void resetLink(){
	if (link != null){
	    try {
		link.close();
	    } catch (IOException ioe){
		// Nice try...
	    }
	}
	link = null;
    }
}

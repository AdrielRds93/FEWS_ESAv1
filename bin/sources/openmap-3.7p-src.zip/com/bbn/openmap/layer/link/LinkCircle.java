/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1999-2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/link/LinkCircle.java,v $
 * $Revision: 1.4 $
 * $Date: 2000/05/08 14:22:30 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.link;

import com.bbn.openmap.omGraphics.OMCircle;
import com.bbn.openmap.layer.util.LayerUtils;
import com.bbn.openmap.util.ColorFactory;
import com.bbn.openmap.LatLonPoint;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

/**
 * Reading and writing a Link protocol version of a circle.
 */
public class LinkCircle implements LinkGraphicConstants, LinkPropertiesConstants {

    /**
     * Write a circle with lat/lon placement.
     * @param latPoint latitude of center point, decimal degrees
     * @param lonPoint longitude of center point, decimal degrees
     * @param w horizontal diameter of circle/ellipse, pixels
     * @param h vertical diameter of circle/ellipse, pixels
     * @param properties attributes for the circle.
     * @param dos DataOutputStream.
     * @throws IOException
     */
    public static void write(double latPoint, double lonPoint,
			     int w, int h, 
			     LinkProperties properties,
			     DataOutputStream dos) throws IOException {
	LinkCircle.write(latPoint, lonPoint, 0, 0, w, h, properties, dos);
    }

    /**
     * Write a circle with x/y placement.
     *
     * @param x1 window position of center point from left of window, in pixels
     * @param y1 window position of center point from top of window, in pixels
     * @param w horizontal diameter of circle/ellipse, pixels
     * @param h vertical diameter of circle/ellipse, pixels
     * @param properties attributes for the circle.
     * @param dos DataOutputStream.
     * @throws IOException
     */
    public static void write(int x1, int y1, int w, int h, 
			     LinkProperties properties,
			     DataOutputStream dos)
	throws IOException { 

	dos.write(Link.CIRCLE_HEADER.getBytes());
	dos.writeInt(GRAPHICTYPE_CIRCLE);
	dos.writeInt(RENDERTYPE_XY);
	dos.writeInt(x1);
	dos.writeInt(y1);
	dos.writeInt(w);
	dos.writeInt(h);
	properties.write(dos);
    }

    /**
     * Writing a circle at a x, y, offset to a Lat/Lon location.
     *
     * @param latPoint latitude of center of circle/ellipse.
     * @param lonPoint longitude of center of circle/ellipse.
     * @param offset_x1 # pixels to the right the center will be moved
     * from lonPoint.
     * @param offset_y1 # pixels down that the center will be moved
     * from latPoint.
     * @param w horizontal diameter of circle/ellipse, pixels.
     * @param h vertical diameter of circle/ellipse, pixels.
     * @param properties attributes for the circle.
     * @param dos DataOutputStream.
     * @throws IOException
     */
    public static void write(double latPoint, double lonPoint,
			     int offset_x1, int offset_y1, 
			     int w, int h,
			     LinkProperties properties,
			     DataOutputStream dos)
	throws IOException { 
	
	dos.write(Link.CIRCLE_HEADER.getBytes());
	dos.writeInt(GRAPHICTYPE_CIRCLE);
	dos.writeInt(RENDERTYPE_OFFSET);
	dos.writeFloat((float) latPoint);
	dos.writeFloat((float) lonPoint);
	dos.writeInt(offset_x1);
	dos.writeInt(offset_y1);
	dos.writeInt(w);
	dos.writeInt(h);
	properties.write(dos);
    }

    /**
     * Write a circle with a certain radius at a Lat/Lon location.
     * Assumes the radius is in decimal degrees.
     *
     * @param latPoint latitude of center point, decimal degrees
     * @param lonPoint longitude of center point, decimal degrees
     * @param radius distance in decimal degrees
     * @param properties attributes for the circle.
     * @param dos DataOutputStream.
     * @throws IOException 
     */
    public static void write(double latPoint, double lonPoint, double radius,
			     LinkProperties properties,
			     DataOutputStream dos)
	throws IOException  {
	LinkCircle.write(latPoint, lonPoint, radius, -1, -1, properties, dos);
    }

    /**
     * Write a circle with a certain radius at a Lat/Lon location,
     * and allows you to specify units of the radius.
     *
     * @param latPoint latitude of center of circle in decimal degrees
     * @param lonPoint longitude of center of circle in decimal degrees
     * @param radius distance
     * @param units integer value for units for distance - KM, MILES,
     * NMILES.  If &lt; 0, assume decimal degrees. 
     * @param properties attributes for the circle.
     * @param dos DataOutputStream.
     * @throws IOException
     */
    public static void write(double latPoint, double lonPoint,
			     double radius, int units,
			     LinkProperties properties,
			     DataOutputStream dos)
	throws IOException {
	LinkCircle.write(latPoint, lonPoint, radius, units, -1, properties, dos);
    }

    /**
     * Write a circle with a certain radius at a Lat/Lon location,
     * and allows you to specify units of the radius, as well as the
     * number of verticies to use to approximate the circle.
     *
     * @param latPoint latitude of center of circle in decimal degrees
     * @param lonPoint longitude of center of circle in decimal degrees
     * @param radius distance
     * @param units integer value for units for distance - OMCircle.KM, OMCircle.MILES,
     * OMCircle.NMILES.  If &lt; 0, assume decimal degrees.
     * @param nverts number of vertices for the poly-circle (if &lt; 3, value
     * is generated internally).
     * @param properties attributes for the circle.
     * @param dos DataOutputStream.
     * @throws IOException
     */
    public static void write(double latPoint, double lonPoint,
			     double radius, int units, int nverts,
			     LinkProperties properties,
			     DataOutputStream dos)
	throws IOException {
	// Write this out...
	dos.write(Link.CIRCLE_HEADER.getBytes());
	dos.writeInt(GRAPHICTYPE_CIRCLE);
	dos.writeInt(RENDERTYPE_LATLON);
	dos.writeFloat((float) latPoint);
	dos.writeFloat((float) lonPoint);
	dos.writeFloat((float) radius);
	dos.writeInt(units);
	dos.writeInt(nverts);
	properties.write(dos);
    }

    /**  
     * Read the circle protocol off the data input, and return an
     * OMCircle.  Assumes the header for the graphic has already been
     * read.
     *
     * @param dis the DataInputStream
     * @return OMCircle
     * @throws IOException
     * @see com.bbn.openmap.omGraphics.OMCircle
     */
    public static OMCircle read(DataInputStream dis)
	throws IOException {

	OMCircle circle = null;
	double lat, lon, radius;
	int x, y, w, h;

	int renderType = dis.readInt();
	
	switch (renderType){
	case RENDERTYPE_LATLON:
	    lat = dis.readFloat();
	    lon = dis.readFloat();
	    radius = dis.readFloat();
	    int units = dis.readInt();
	    int nverts = dis.readInt();
	    
	    circle = new OMCircle(new LatLonPoint(lat, lon), 
				  radius, units, nverts);
	    break;
	case RENDERTYPE_XY:
	    x = dis.readInt();
	    y = dis.readInt();
	    w = dis.readInt();
	    h = dis.readInt();
	    
	    circle = new OMCircle(x, y, w, h);
	    break;
	case RENDERTYPE_OFFSET:
	    lat = dis.readFloat();
	    lon = dis.readFloat();
	    x = dis.readInt();
	    y = dis.readInt();
	    w = dis.readInt();
	    h = dis.readInt();
	    
	    circle = new OMCircle(lat, lon, x, y, w, h);
	    break;
	default:
	}

	LinkProperties properties = new LinkProperties(dis);

	if (circle != null){
	    circle.setLineColor(ColorFactory.parseColorFromProperties(
		properties, LPC_LINECOLOR,
		BLACK_COLOR_STRING, true));
	    circle.setFillColor(ColorFactory.parseColorFromProperties(
		properties, LPC_FILLCOLOR,
		CLEAR_COLOR_STRING, true));
	    circle.setSelectColor(ColorFactory.parseColorFromProperties(
		properties, LPC_HIGHLIGHTCOLOR,
		BLACK_COLOR_STRING, true));
	    circle.setLineWidth(LayerUtils.intFromProperties(
		properties, LPC_LINEWIDTH, 1));
	    circle.setAppObject(properties);
	}

	return circle;
    }


}

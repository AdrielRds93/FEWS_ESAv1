/* **********************************************************************
 * 
 *  BBNT Solutions LLC, A part of GTE
 *  10 Moulton St.
 *  Cambridge, MA 02138
 *  (617) 873-2000
 * 
 *  Copyright (C) 1998, 2000
 *  This software is subject to copyright protection under the laws of 
 *  the United States and other countries.
 * 
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/link/shape/ESRILinkPointRecord.java,v $
 * $Revision: 1.2 $
 * $Date: 2000/05/08 14:22:33 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.link.shape;

import java.io.IOException;
import com.bbn.openmap.layer.shape.*;
import com.bbn.openmap.omGraphics.*;
import com.bbn.openmap.layer.link.*;


/**
 * An ESRI Point record.
 *
 * @author Ray Tomlinson
 * @author Tom Mitchell <tmitchell@bbn.com>
 * @version $Revision: 1.2 $ $Date: 2000/05/08 14:22:33 $
 */
public class ESRILinkPointRecord extends ESRIPointRecord implements ESRILinkRecord{

    /**
     * Initializes this point from the given point.
     *
     * @param x the x coordinate
     * @param y the y coordinate
     */
    public ESRILinkPointRecord(double x, double y) {
	super(x, y);
    }

    /**
     * Initialize a point record from the given buffer.
     *
     * @param b the buffer
     * @param off the offset into the buffer where the data starts
     */
    public ESRILinkPointRecord(byte b[], int off) throws IOException {
	super(b, off);
    }

    /**
     * Generates OMGraphics and adds them to the given list.
     *
     * @param gr the graphics response to write the point to.
     * @param properties the semantic description of how the point should be drawn.
     */
    public void writeLinkGraphics(LinkGraphicList lgl,
				  LinkProperties properties)
	throws IOException {
	lgl.addRectangle((float)y, (float)x, -1, -1, 1, 1, properties);
    }
}

/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/link/shape/ShapeServerStarter.java,v $
 * $Revision: 1.4 $
 * $Date: 2000/05/08 14:22:34 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.link.shape;

import java.util.Properties;
import java.net.Socket;

import com.bbn.openmap.util.Debug;
import com.bbn.openmap.Environment;

import com.bbn.openmap.layer.shape.*;
import com.bbn.openmap.layer.link.*;

public class ShapeServerStarter extends LinkServerStarter{

    protected String shapeFile;
    protected String shapeIndex;

    public ShapeServerStarter(int port, String shapeFile, String shapeIndex){
        super(port);
	this.shapeFile = shapeFile;
	this.shapeIndex = shapeIndex;
    }

    public Thread startNewServer(Socket sock) {
        return(new ShapeLinkServer(sock, shapeFile, shapeIndex));
    }

    public static void main(String[] argv){
	Properties p = System.getProperties();
	// First initialize debugging
	Debug.init(p);
	Environment.init(p);

	int pnumber = -1;
	String ssx = null;
	String shp = null;
	for (int i = 0; i < argv.length; i++){
	    if (argv[i].equals("-port") && argv.length > i+1){
		try {
		    pnumber = Integer.parseInt(argv[i+1]);
		    break;
		} catch (NumberFormatException e) {
		    pnumber = -1;
		}
	    } else if (argv[i].indexOf(".ssx") != -1){
		ssx = argv[i];
	    } else if (argv[i].indexOf(".shp") != -1){
		shp = argv[i];
	    }
	}

	if (pnumber < 0 || ssx == null || shp == null) {
	    System.out.println("Need to start the server with a port number, shape file and spatial index file.");
	    System.err.println("Usage: java com.bbn.openmap.layer.link.shape.ShapeServerStarter <ShapeFile Name.shp> <ShapeFile Spatial Index File.ssx> -port <port number>");
	    System.exit(-1);
	}

	System.out.println("ShapeServerStarter: Starting up on port " + 
			   pnumber + ".");
	ShapeServerStarter serverStarter = new ShapeServerStarter(pnumber, 
								  argv[0],
								  argv[1]);
	
	while (true){
	    serverStarter.run();
	}
    }
}

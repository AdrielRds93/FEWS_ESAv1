/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1999-2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/link/LinkOMGraphicList.java,v $
 * $Revision: 1.2 $
 * $Date: 2000/05/08 14:22:31 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.link;

import com.bbn.openmap.omGraphics.*;
import java.awt.Graphics;
import java.io.*;
import java.util.Vector;

/**
 * This class extends the OMGraphicList by allowing searches on the
 * AppObject contained by the OMGraphics on the list.  The AppObject
 * is where the LinkGraphics store the graphic ID as defined by the
 * server.  It also returns indexes from searches instead of the
 * graphic.  This allows for deletions, replacements and graphic
 * location movement from within the list.
 */
public class LinkOMGraphicList extends OMGraphicList 
    implements LinkPropertiesConstants {

    /**
     * Construct an OMGraphicList.
     */
    public LinkOMGraphicList() {
	super (10, 0);//same values as default Vector
    };
    
    /**
     * Construct an OMGraphicList with an initial capacity. 
     * @param initialCapacity the initial capacity of the list 
     */
    public LinkOMGraphicList(int initialCapacity) {
	super (initialCapacity, 0);//same capInc as Vector
    };

    /**
     * Construct an OMGraphicList with an initial capacity and
     * a standard increment value.
     * @param initialCapacity the initial capacity of the list 
     * @param capacityIncrement the capacityIncrement for resizing 
     */
    public LinkOMGraphicList(int initialCapacity, int capacityIncrement) {
        super (initialCapacity, capacityIncrement);
    };

   /**
     * Get the graphic with the graphic ID. Traverse mode doesn't
     * matter.
     * @param graphicID graphic ID of the wanted graphic.  
     * @return OMGraphic index or Link.UNKNOWN if not found
     */
    public int getOMGraphicIndexWithId(String gid){
	java.util.Vector targets = getTargets();
	int ret = Link.UNKNOWN;

	if (gid != null){
	    int listSize = targets.size();
	    for (int i = 0; i < listSize; i++){
		OMGraphic graphic = (OMGraphic) targets.elementAt(i);
		String id = ((LinkProperties) graphic.getAppObject()).getProperty(LPC_GRAPHICID);
		if (id.equals(gid)){
		    return i;
		}
	    }
	}
	return Link.UNKNOWN;
    }

}

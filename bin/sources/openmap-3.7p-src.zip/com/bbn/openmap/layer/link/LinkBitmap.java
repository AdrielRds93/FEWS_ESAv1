/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1999-2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/link/LinkBitmap.java,v $
 * $Revision: 1.4 $
 * $Date: 2000/05/08 14:22:30 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.link;

import com.bbn.openmap.omGraphics.OMBitmap;
import com.bbn.openmap.layer.util.LayerUtils;
import com.bbn.openmap.util.ColorFactory;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

/**
 * Reading and writing the Link protocol version of a bitmap..
 */
public class LinkBitmap implements LinkGraphicConstants, LinkPropertiesConstants {

    /**
     * Lat/Lon placement.  
     *
     * @param lt latitude of the top of the image.
     * @param ln longitude of the left side of the image.
     * @param w width of the image, in pixels.
     * @param h height of the image, in pixels.
     * @param bytes bytes for the bitmap.
     * @param properties attributes for the bitmap.
     * @param dos DataOutputStream.
     * @throws IOException
     */
    public static void write(double lt, double ln, int w, int h,
			     byte[] bytes, 
			     LinkProperties properties,
			     DataOutputStream dos)
	throws IOException {
	
	dos.write(Link.BITMAP_HEADER.getBytes());
	dos.writeInt(GRAPHICTYPE_BITMAP);
	dos.writeInt(RENDERTYPE_LATLON);
	dos.writeFloat((float) lt);
	dos.writeFloat((float) ln);
	dos.writeInt(w);
	dos.writeInt(h);
	
	dos.writeInt(bytes.length); 
	dos.write(bytes,0,bytes.length);

	properties.write(dos);
    }
  
    /**
     * XY placement. 
     *
     * @param x1 window location of the left side of the image.
     * @param y1 window location of the top of the image.
     * @param w width of the image, in pixels.
     * @param h height of the image, in pixels.
     * @param bytes bytes for the bitmap.
     * @param properties attributes for the bitmap.
     * @param dos DataOutputStream.
     * @throws IOException
     */
    public static void write(int x1, int y1, int w, int h, byte[] bytes, 
			     LinkProperties properties,
			     DataOutputStream dos)
	throws IOException {

	dos.write(Link.BITMAP_HEADER.getBytes());
	dos.writeInt(GRAPHICTYPE_BITMAP);
	dos.writeInt(RENDERTYPE_XY);
	dos.writeInt(x1);
	dos.writeInt(y1);
	dos.writeInt(w);
	dos.writeInt(h);
	
	dos.writeInt(bytes.length);
	dos.write(bytes,0,bytes.length);
	
	properties.write(dos);
    }

    /**
     * Lat/lon placement with XY offset.
     *
     * @param lt latitude of the top of the image, before the offset.
     * @param ln longitude of the left side of the image, before the offset.
     * @param offset_x1 number of pixels to move image to the right.
     * @param offset_y1 number of pixels to move image down.
     * @param w width of the image, in pixels.
     * @param h height of the image, in pixels.
     * @param bytes bytes for the bitmap.
     * @param properties attributes for the bitmap.
     * @param dos DataOutputStream.
     * @throws IOException
     */
    public static void write(double lt, double ln, int offset_x1, int offset_y1,
			     int w, int h, byte[] bytes,
			     LinkProperties properties,
			     DataOutputStream dos)
	throws IOException {

	dos.write(Link.BITMAP_HEADER.getBytes());
	dos.writeInt(GRAPHICTYPE_BITMAP);
	dos.writeInt(RENDERTYPE_OFFSET);
	dos.writeFloat((float) lt);
	dos.writeFloat((float) ln);
	dos.writeInt(offset_x1);
	dos.writeInt(offset_y1);
	dos.writeInt(w);
	dos.writeInt(h);
	
	dos.writeInt(bytes.length);	
	dos.write(bytes,0,bytes.length);

	properties.write(dos);
    }

    /** 
     * Read a Bitmap off a DataInputStream.  Assumes the Bitmap
     * header has already been read.
     *
     * @param dis DataInputStream to read from.
     * @return OMBitmap
     * @throws IOException
     * @see com.bbn.openmap.omGraphics.OMBitmap 
     */
    public static OMBitmap read(DataInputStream dis)
	throws IOException {

	OMBitmap bitmap = null;
	double lat = 0;
	double lon = 0;
	int x = 0;
	int y = 0;
	int w = 0;
	int h = 0;
	int length, i;
	String url;

	int renderType = dis.readInt();
	
	switch (renderType){
	case RENDERTYPE_OFFSET:
	    lat = dis.readFloat();
	    lon = dis.readFloat();
	    // Fall through...		
	case RENDERTYPE_XY:
	    x = dis.readInt();
	    y = dis.readInt();
	    break;
	case RENDERTYPE_LATLON:
	default:
	    lat = dis.readFloat();
	    lon = dis.readFloat();
	}
	
	w = dis.readInt();
	h = dis.readInt();
	length = dis.readInt();
	
	byte[] bytes = new byte[length];
	dis.readFully(bytes);
	
	switch (renderType){
	case RENDERTYPE_OFFSET:
	    bitmap = new OMBitmap(lat, lon, x, y, w, h, bytes);
	    break;
	case RENDERTYPE_XY:
	    bitmap = new OMBitmap(x, y, w, h, bytes);
	    break;
	case RENDERTYPE_LATLON:
	default:
	    bitmap = new OMBitmap(lat, lon, w, h, bytes);
	}
	
	LinkProperties properties = new LinkProperties(dis);

	if (bitmap != null){
	    bitmap.setLineColor(ColorFactory.parseColorFromProperties(
		properties, LPC_LINECOLOR,
		BLACK_COLOR_STRING, true));
	    bitmap.setFillColor(ColorFactory.parseColorFromProperties(
		properties, LPC_FILLCOLOR,
		CLEAR_COLOR_STRING, true));
	    bitmap.setSelectColor(ColorFactory.parseColorFromProperties(
		properties, LPC_HIGHLIGHTCOLOR,
		BLACK_COLOR_STRING, true));
	    bitmap.setLineWidth(LayerUtils.intFromProperties(
		properties, LPC_LINEWIDTH, 1));
	    bitmap.setAppObject(properties);
	}

	return bitmap;
    }
}

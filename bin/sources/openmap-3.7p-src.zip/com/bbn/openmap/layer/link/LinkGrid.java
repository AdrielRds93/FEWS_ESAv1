/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1999-2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/link/LinkGrid.java,v $
 * $Revision: 1.2 $
 * $Date: 2000/05/08 14:22:31 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.link;

import com.bbn.openmap.omGraphics.OMGrid;
import com.bbn.openmap.util.Debug;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

/** 
 * Reading and writing the Link protocol version of a grid object.
 * It is assumed that the client will know how to render/handle this
 * grid when it arrives, since it doesn't have any implicit drawing
 * attributes, despite having a semantics object.
 */
public class LinkGrid implements LinkGraphicConstants {

    /**
     * Lat/Lon placement.  
     *
     * @param lt latitude of the top of the grid.
     * @param ln longitude of the left side of the grid.
     * @param rows number of vertical points of the grid.
     * @param columns number of horizontal points of the grid.
     * @param orientation the direction of the vertical axits of the
     * grid, in radians from up ( North).
     * @param vResolution degrees/point between rows of the grid.
     * @param hRsolution degrees/point between columns of the grid.
     * @param major designation of the presentation of the data, as
     * columns (COLUMN_MAJOR) or rows (ROW_MAJOR).
     * @param data data points of the grid.
     * @param properties description of drawing attributes.
     * @param dos the data output stream to write the object to.
     * @throws IOException 
     */
    public static void write(double lt, double ln, int rows, int columns,
                             float orientation, float vResolution, float hResolution,
			     int major, int[] data, 
			     LinkProperties properties,
			     DataOutputStream dos)
	throws IOException {
	
	dos.write(Link.GRID_HEADER.getBytes());
	dos.writeInt(GRAPHICTYPE_GRID);
	dos.writeInt(RENDERTYPE_LATLON);
	dos.writeFloat((float) lt);
	dos.writeFloat((float) ln);
	dos.writeInt(rows);
	dos.writeInt(columns);
	dos.writeFloat(orientation);
	dos.writeFloat(vResolution);
	dos.writeFloat(hResolution);
	dos.writeInt(major);

	dos.writeInt(data.length); 
	for (int i = 0; i < data.length; i++){
	    dos.writeInt(data[i]);
	}

	properties.write(dos);
    }
  
    /**
     * XY placement. 
     *
     * @param x1 window location of the left side of the grid.
     * @param y1 window location of the top of the grid.
     * @param rows number of vertical points of the grid.
     * @param columns number of horizontal points of the grid.
     * @param orientation the direction of the vertical axits of the
     * grid, in radians from up ( North).
     * @param vResolution pixels/point between rows of the grid.
     * @param hRsolution pixels/point between columns of the grid.
     * @param major designation of the presentation of the data, as
     * columns (COLUMN_MAJOR) or rows (ROW_MAJOR).
     * @param data data points of the grid.
     * @param properties description of drawing attributes.
     * @param dos the data output stream to write the object to.
     * @throws IOException
     */
    public static void write(int x1, int y1, int rows, int columns, 
			     float orientation, float vResolution, float hResolution,
			     int major, int[] data, 
			     LinkProperties properties, 
			     DataOutputStream dos)
	throws IOException {

	dos.write(Link.GRID_HEADER.getBytes());
	dos.writeInt(GRAPHICTYPE_GRID);
	dos.writeInt(RENDERTYPE_XY);
	dos.writeInt(x1);
	dos.writeInt(y1);

	dos.writeInt(rows);
	dos.writeInt(columns);
	dos.writeFloat(orientation);
	dos.writeFloat(vResolution);
	dos.writeFloat(hResolution);
	dos.writeInt(major);

	dos.writeInt(data.length); 
	for (int i = 0; i < data.length; i++){
	    dos.writeInt(data[i]);
	}
	
	properties.write(dos);
    }

    /**
     * Lat/lon placement with XY offset.
     *
     * @param lt latitude of the top of the image, before the offset.
     * @param ln longitude of the left side of the image, before the offset.
     * @param offset_x1 number of pixels to move image to the right.
     * @param offset_y1 number of pixels to move image down.
     * @param rows number of vertical points of the grid.
     * @param columns number of horizontal points of the grid.
     * @param orientation the direction of the vertical axits of the
     * grid, in radians from up ( North).
     * @param vResolution pixels/point between rows of the grid.
     * @param hRsolution pixels/point between columns of the grid.
     * @param major designation of the presentation of the data, as
     * columns (COLUMN_MAJOR) or rows (ROW_MAJOR).
     * @param data data points of the grid.
     * @param properties description of drawing attributes.
     * @param dos the data output stream to write the object to.
     * @throws IOException
     */
    public static void write(double lt, double ln, int offset_x1, int offset_y1,
			     int rows, int columns, 
			     float orientation, float vResolution, float hResolution,
			     int major, int[] data, 
			     LinkProperties properties, 
			     DataOutputStream dos)
	throws IOException {

	dos.write(Link.GRID_HEADER.getBytes());
	dos.writeInt(GRAPHICTYPE_GRID);
	dos.writeInt(RENDERTYPE_OFFSET);
	dos.writeFloat((float) lt);
	dos.writeFloat((float) ln);
	dos.writeInt(offset_x1);
	dos.writeInt(offset_y1);

	dos.writeInt(rows);
	dos.writeInt(columns);
	dos.writeFloat(orientation);
	dos.writeFloat(vResolution);
	dos.writeFloat(hResolution);
	dos.writeInt(major);

	dos.writeInt(data.length); 
	for (int i = 0; i < data.length; i++){
	    dos.writeInt(data[i]);
	}

	properties.write(dos);
    }

    /** 
     * Read a Grid off a DataInputStream.  Assumes the Grid header has already been read.
     *
     * @param dis DataInputStream to read from.
     * @return OMGrid
     * @throws IOException
     * @see com.bbn.openmap.omGraphics.OMGrid
     */
    public static OMGrid read(DataInputStream dis)
	throws IOException {

	Debug.message("linkdetail", "LinkGrid: reading from link.");

	OMGrid grid = null;
	double lat = 0;
	double lon = 0;
	int x = 0;
	int y = 0;

	int renderType = dis.readInt();
	
	switch (renderType){
	case RENDERTYPE_OFFSET:
	    lat = dis.readFloat();
	    lon = dis.readFloat();
	    Debug.message("linkdetail", "LinkGrid: Offset Lat/Lon = " + 
			  lat + "/" + lon + " with");
	    // Fall through...		
	case RENDERTYPE_XY:
	    x = dis.readInt();
	    y = dis.readInt();
	    Debug.message("linkdetail", "LinkGrid: x/y = " + 
			  x + "/" + y);
	    break;
	case RENDERTYPE_LATLON:
	default:
	    lat = dis.readFloat();
	    lon = dis.readFloat();
	    Debug.message("linkdetail", "LinkGrid: Lat/Lon = " + 
			  lat + "/" + lon);
	}
	
	int rows = dis.readInt();
	int columns = dis.readInt();
	float orientation = dis.readFloat();
	float vResolution = dis.readFloat();
	float hResolution = dis.readFloat();
	int major = dis.readInt();

	int length = dis.readInt();
	
	Debug.message("linkdetail", "LinkGrid details: rows = " + rows + 
		      ", columns = " + columns + ", orientation = " + orientation +
		      ", vertical resolution = " + vResolution + 
		      ", horizontal resolution = " + hResolution + 
		      ", major dimension = " + 
		      (major == LinkGraphicConstants.COLUMN_MAJOR?"COLUMN_MAJOR":"ROW_MAJOR") +
		      ", with number of points = " + length);

	int[][] data;
	if (major == LinkGraphicConstants.COLUMN_MAJOR){
	    data = new int[columns][rows];
	} else {
	    data = new int[rows][columns];
	}

	for (int i = 0; i < data.length; i++){
	    for (int j = 0; j < data[0].length; j++){
		data[i][j] = dis.readInt();
// 		    Debug.message("linkdetail", "LinkGrid reading " + 
// 				  (rows*i + j) + " " +
// 				  (major != LinkGraphicConstants.COLUMN_MAJOR?"column":"row")+ 
// 				  " " + j + " = " + Integer.toHexString(data[i][j]) + 
// 				  " (" + data[i][j] + ")");
	    }
// 	    Debug.message("linkdetail", "LinkGrid reading " + 
// 			  (major == LinkGraphicConstants.COLUMN_MAJOR?"column":"row")+ 
// 			  " " + i);
	}

	Debug.message("linkdetail", "LinkGrid read all the data.");

	switch (renderType){
	case RENDERTYPE_OFFSET:
	    grid = new OMGrid(lat, lon, x, y, vResolution, hResolution, data);
	    break;
	case RENDERTYPE_XY:
	    grid = new OMGrid(x, y, vResolution, hResolution, data);
	    break;
	case RENDERTYPE_LATLON:
	default:
	    grid = new OMGrid(lat, lon, vResolution, hResolution, data);
	}

	Debug.message("linkdetail", "LinkGrid created OMGrid.");

	LinkProperties properties = new LinkProperties(dis);

	if (grid != null){
	    grid.setMajor(major == LinkGraphicConstants.COLUMN_MAJOR?true:false);
	    grid.setOrientation(orientation);
	    grid.setAppObject(properties);
	}

	Debug.message("linkdetail", "LinkGrid done.");

	return grid;
    }
}

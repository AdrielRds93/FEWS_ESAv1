/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1999-2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/link/TestServerStarter.java,v $
 * $Revision: 1.5 $
 * $Date: 2000/05/08 14:22:32 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.link;

import java.util.*;
import java.net.*;
import java.io.*;

/**
 * The LinkServerStarter is the object that listens for Link clients
 * on a specific port.  If a Link client contacts it, it uses the
 * LinkServerFactory to create a LinkServer to serve the client on
 * it's own thread.  If you want to create a new type of LinkServer,
 * you should also create a new LinkServerStarter to launch it
 * properly.  Generally, the main() is the only thing youwould need to
 * modify, to change the type of LinkServerFactory (and therefore, the
 * LinkServer) used for the client.
 */
public class TestServerStarter extends LinkServerStarter{

    /** Starts the LinkServerStarter listening to the specified port. */
    public TestServerStarter(int port){
	super(port);
    }

    /**
     * From the LinkServerFactory interface, starts up a new
     * LinkServer to handle a client. 
     * @param socket socket to use to communicate to the client.
     */
    public Thread startNewServer(Socket socket){
	return(new TestLinkServer(socket));
    }

    /** 
     * Start up the server. This is the method to change if you want
     * to customize how the LinkServer will handle clients - port,
     * arguments, LinkServerFactory, etc.
     */
    public static void main(String[] argv){
	int pnumber = -1;

	for (int i = 0; i < argv.length; i++){
	    if (argv[i].equals("-port") && argv.length > i+1){
		try {
		    pnumber = Integer.parseInt(argv[i+1]);
		    break;
		} catch (NumberFormatException e) {
		    pnumber = -1;
		}
	    }
	}

	if (pnumber < 0) {
	    System.out.println("Need to start the server with a port number.");
	    System.out.println("Usage: java com.bbn.openmap.layer.link.TestServerStarter -port <port number>");
	    System.exit(0);
	}

	System.out.println("TestServerStarter: Starting up on port " + 
			   pnumber + ".");

	TestServerStarter serverStarter = new TestServerStarter(pnumber);
	while (true){
	    serverStarter.run();
	}
    }
}

/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1999-2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/link/LinkUtil.java,v $
 * $Revision: 1.2 $
 * $Date: 2000/05/08 14:22:32 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */
package com.bbn.openmap.layer.link;

import java.io.*;

public class LinkUtil {

    /** 
     * readString reads an expected number of characters off a
     * DataInput and creates a String from it.
     *
     * @param length the number of characters to be read.. 
     */
    protected static String readString(DataInput dis, int length)
	throws IOException, ArrayIndexOutOfBoundsException {
	String ret = null;
	char[] chars = new char[length];

	for (int i = 0; i < length; i++){
	    chars[i] = dis.readChar();
	}
	ret = new String(chars);
	return ret;
    }

    /** Provided as a readability convenience. */
    public static int setMask(int value, int mask){
	return (value | mask);
    }

    /** Provided as a readability convenience. */
    public static int unsetMask(int value, int mask){
	return (value & ~mask);
    }

    /** Provided as a readability convenience. */
    public static boolean isMask(int value, int mask){
	if ((value & mask) == 0){
	    return false;
	}
	return true;
    }

}

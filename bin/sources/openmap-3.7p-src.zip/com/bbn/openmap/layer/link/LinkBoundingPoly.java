/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1999-2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/link/LinkBoundingPoly.java,v $
 * $Revision: 1.3 $
 * $Date: 2000/05/08 14:22:30 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.link;

import com.bbn.openmap.LatLonPoint;
import com.bbn.openmap.util.Debug;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

/** 
 * LinkBoundingPoly objects are used to describe simple polygons that
 * cover a certain area.  If the area described is in coordinates, the
 * polygon should not be sued for areas covering a pole or straddling
 * the dateline.  More than one LinkBoundingPolys should be used for
 * areas like that.
 */
public class LinkBoundingPoly{
    
    public double maxX;
    public double maxY;
    public double minX;
    public double minY;
    protected double[] points;
    
    /** 
     * The constructor to use when reading the bounding polygon off
     * an input stream. 
     * @param dis DataInputStream to read from.
     */
    public LinkBoundingPoly(DataInput dis) throws IOException {
	read(dis);
    }

    /**  
     * The constructor to use to create a LinkBoundingPoly to write
     * to an output stream.
     *
     * @param poly a series of alternating x, y points describing a polygon.
     */
    public LinkBoundingPoly(double[] poly){
	points = poly;
    }

    /**
     * Create a LinkBoundingPoly out of minimum and max x, y, values. 
     *
     * @param minX minimum X value.
     * @param miny minimum Y value.
     * @param maxX maximum X value.
     * @param maxY maximum Y value.
     */
    public LinkBoundingPoly(double minX, double minY,
			    double maxX, double maxY){
	points = new double[10];
	
	Debug.message("link", "LinkBoundingPoly: Creating link bounding poly with " +
		      minX + ", " + minY + 
		      ", " + maxX + ", "+ maxY);
	
	points[0] = minY;
	points[1] = minX;
	points[2] = maxY;
	points[3] = minX;
	points[4] = maxY;
	points[5] = maxX;
	points[6] = minY;
	points[7] = maxX;
	points[8] = minY;
	points[9] = minX;
    }

    /** 
     * Write the polygon on the output stream.  If the number of
     * points is an odd number, the last number will be left off.
     *
     * @param dos the DataOutput to write to. 
     */
    public void write(DataOutput dos) throws IOException {
	// round down to a multiple of two.
	int length = (points.length/2)*2;
	
	dos.writeInt(length);
	for (int i = 0; i < length; i++){
	    dos.writeFloat((float) points[i]);
	}
    }

    /**
     * Read the bounding polygon off the input stream.
     *
     * @param dis DataInputStream to read from.
     */
    public void read(DataInput dis) throws IOException {

	Debug.message("link", "LinkBoundingPoly: read()");

	int polyLength = dis.readInt();
	points = new double[polyLength];
	double x, y;

	for (int i = 0; i < points.length; i+=2){
	    y = dis.readFloat();
	    x = dis.readFloat();

	    points[i] = y;
	    points[i+1] = x;

	    if (x < minX) minX = x;
	    if (x > maxX) maxX = x;
	    if (y < minY) minY = y;
	    if (y > maxY) maxY = y;
	}
    }

    /** 
     * Return the polygon points, as a series of alternating x and y
     * values.
     *
     * @return double[] of alternating x, y, points.
     */
    public double[] getPoints(){
	return points;
    }

    /**
     * Convert the points to Lat/Lon points.  There is no guarantee
     * that the points really translate into latitude and longitude
     * points.
     *
     * @return LatLonPoints 
     */
    public LatLonPoint[] getLatLonPoints(){
	LatLonPoint[] boundingPoly = new LatLonPoint[points.length/2];
	double lat, lon;
	for (int i = 0; i < points.length; i+=2){
	    lat = points[i];
	    lon = points[i+1];
	    boundingPoly[i] = new LatLonPoint(lat, lon);
	}
	return boundingPoly;
    }

    public String toString(){
	StringBuffer s = new StringBuffer();
	s.append("  LinkBoundingPoly has " + points.length/2 + " points.");
	for (int i = 0; i < points.length; i+=2){
	    s.append("\n    |Lat = " + points[i] + ", Lon = " + points[i+1] + "|");
	}
	return s.toString();
    }
}

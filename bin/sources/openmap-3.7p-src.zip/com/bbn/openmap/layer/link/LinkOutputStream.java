/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1999-2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/link/LinkOutputStream.java,v $
 * $Revision: 1.2 $
 * $Date: 2000/05/08 14:22:31 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.link;

import java.io.DataOutputStream;
import java.io.OutputStream;

/**
 * Extend DataOutputStream so we can reset the written byte count.
 *
 * @see     java.io.DataOutputStream
 */
public class LinkOutputStream extends DataOutputStream {
    /**
     * Creates a new link output stream to write data to the specified 
     * underlying output stream.
     *
     * @param   out   the underlying output stream, to be saved for later 
     *                use.
     */
    public LinkOutputStream(OutputStream out) {
	super(out);
    }

    /** 
     * Reset the written bytecount back to 0.
     *
     * @return the previous value of <code>written</code>
     */
    public int clearWritten() { 
      int temp = written;
      written = 0;
      return temp;
    }
}

/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1999-2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/link/GraphicUpdate.java,v $
 * $Revision: 1.2 $
 * $Date: 2000/05/08 14:22:29 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.link;

import com.bbn.openmap.Layer;
import com.bbn.openmap.omGraphics.OMGraphic;

/** 
 * A simple object used by the GestureLinkResponse to associate an
 * action with a particular graphic, either with the graphic's ID for
 * MODIFY-type actions, or with the graphic for UPDATE-type
 * actions.
 */
public class GraphicUpdate implements LinkPropertiesConstants {
    /** A masked integer describing the action for the graphic. See
     *  GestureLinkResponse fo the masks. */
    public int action = 0;
    /** The graphic's ID. */
    public String id = null;
    /** The graphic, for updates. */
    public OMGraphic graphic = null;
    /** Constructor for modify-type actions. */
    public GraphicUpdate(int graphicAction, String gid){
	action = graphicAction;
	id = gid;
    }
    /** Constructor for update-type actions. */
    public GraphicUpdate(int graphicAction, OMGraphic omg){
	action = graphicAction;
	id = ((LinkProperties) graphic.getAppObject()).getProperty(
		    LPC_GRAPHICID);
	graphic = omg;
    }
}


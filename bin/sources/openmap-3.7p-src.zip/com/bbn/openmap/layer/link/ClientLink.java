/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1999-2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/link/ClientLink.java,v $
 * $Revision: 1.2 $
 * $Date: 2000/05/08 14:22:29 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.link;

import com.bbn.openmap.omGraphics.*;
import com.bbn.openmap.proj.Projection;

import java.awt.Color;
import java.awt.event.MouseEvent;
import java.awt.event.KeyEvent;
import java.io.*;
import java.net.Socket;
import javax.swing.JComponent;

/**
 * The ClientLink provides the method to close the link down, since it
 * makes that decision.  The server should remain connected until the
 * client is finished.  The server can request to be disconnected,
 * however, and the ClientLink provides a method for the client to
 * check if that request has been made.
 */
public class ClientLink extends Link{

    /** Constructor. */
    public ClientLink(Socket socket) throws IOException {
	super(socket);
    }

    /** Close the socket of the link. */
    public void close() throws IOException {
	socket.close();
    }

    /**
     * A method used by the client after a communication exchange.
     * Since the client is the side of the link that can close the
     * link, it can find out if the server wants to close down the
     * link with this method.
     *
     * @return true if the link should be shut down.
     */
    public boolean isCloseLink(){
	return closeLink;
    }
}

/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1999-2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/link/LinkRaster.java,v $
 * $Revision: 1.4 $
 * $Date: 2000/05/08 14:22:31 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.link;

import com.bbn.openmap.omGraphics.OMRaster;
import com.bbn.openmap.util.ColorFactory;
import com.bbn.openmap.util.Debug;

import javax.swing.ImageIcon;
import java.awt.Color;
import java.awt.Image;
import java.awt.image.PixelGrabber;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

/**
 * Read and write a Link protocol versions of a raster.
 */
public class LinkRaster implements LinkGraphicConstants, LinkPropertiesConstants {

    /**
     * Writes an image, Lat/Lon placement with a direct
     * colormodel.
     *
     * @param lt latitude of the top of the image.
     * @param ln longitude of the left side of the image.
     * @param w width of the image, in pixels.
     * @param h height of the image, in pixels.
     * @param pix color values for the pixels.
     * @param properties description of drawing attributes. Not used,
     * but included to be consistant with the protocol graphics
     * format.
     * @param dos DataOutputStream
     * @throws IOException
     */
    public static void write(double lt, double ln,
			     int w, int h, int[] pix, 
			     LinkProperties properties,
			     DataOutputStream dos)
	throws IOException {

	dos.write(Link.RASTER_HEADER.getBytes());
	dos.writeInt(GRAPHICTYPE_RASTER);
	dos.writeInt(RENDERTYPE_LATLON);
	dos.writeInt(COLORMODEL_DIRECT);
	dos.writeFloat((float) lt);
	dos.writeFloat((float) ln);
	dos.writeInt(w);
	dos.writeInt(h);
	dos.writeInt(pix.length);
	
	for (int i = 0; i < pix.length; i++){
	    dos.writeInt(pix[i]);
	}
	properties.write(dos);
    }
  
    /**
     * Write an image, XY placement with a direct colormodel.
     *
     * @param x1 window location of the left side of the image.
     * @param y1 window location of the top of the image.
     * @param w width of the image, in pixels.
     * @param h height of the image, in pixels.
     * @param pix color values for the pixels.
     * @param properties description of drawing attributes. Not used,
     * but included to be consistant with the protocol graphics
     * format.
     * @param dos DataOutputStream
     * @throws IOException
     */
    public static void write(int x1, int y1,
			     int w, int h,
			     int[] pix, 
			     LinkProperties properties, 
			     DataOutputStream dos)
	throws IOException {

	dos.write(Link.RASTER_HEADER.getBytes());
	dos.writeInt(GRAPHICTYPE_RASTER);
	dos.writeInt(RENDERTYPE_XY);
	dos.writeInt(COLORMODEL_DIRECT);
	dos.writeInt(x1);
	dos.writeInt(y1);
	dos.writeInt(w);
	dos.writeInt(h);
	dos.writeInt(pix.length);
	
	for (int i = 0; i < pix.length; i++){
	    dos.writeInt(pix[i]);
	}
	properties.write(dos);
    }

    /**
     * Write an image, Lat/lon placement with XY offset with a
     * direct colormodel.  
     *
     * @param lt latitude of the top of the image, before the offset.
     * @param ln longitude of the left side of the image, before the offset.
     * @param offset_x1 number of pixels to move image to the right.
     * @param offset_y1 number of pixels to move image down.
     * @param w width of the image, in pixels.
     * @param h height of the image, in pixels.
     * @param pix color values for the pixels.
     * @param properties description of drawing attributes. Not used,
     * but included to be consistant with the protocol graphics
     * format.
     * @param dos DataOutputStream
     * @throws IOException
     */
    public static void write(double lt, double ln,
			     int offset_x1, int offset_y1,
			     int w, int h,
			     int[] pix, 
			     LinkProperties properties, 
			     DataOutputStream dos)
	throws IOException {

	dos.write(Link.RASTER_HEADER.getBytes());
	dos.writeInt(GRAPHICTYPE_RASTER);
	dos.writeInt(RENDERTYPE_OFFSET);
	dos.writeInt(COLORMODEL_DIRECT);
	dos.writeFloat((float) lt);
	dos.writeFloat((float) ln);
	dos.writeInt(offset_x1);
	dos.writeInt(offset_y1);
	dos.writeInt(w);
	dos.writeInt(h);
	dos.writeInt(pix.length);
	
	for (int i = 0; i < pix.length; i++){
	    dos.writeInt(pix[i]);
	}
	properties.write(dos);
    }

   /**
     * Write an image, Lat/Lon placement with an ImageIcon.
     *
     * @param lt latitude of the top of the image.
     * @param ln longitude of the left side of the image.
     * @param image java.awt.Image to use for image.
     * @param image_width width of image in pixels.
     * @param image_height height of image in pixels.
     * @param properties description of drawing attributes. Not used,
     * but included to be consistant with the protocol graphics
     * format.
     * @param dos DataOutputStream
     * @throws IOException
     */
    public static void write(double lt, double ln, Image image,
			     int image_width, int image_height, 
			     LinkProperties properties, 
			     DataOutputStream dos)
        throws IOException, InterruptedException {

	int[] pixels = new int[image_width * image_height];
		
	PixelGrabber pixelgrabber = new PixelGrabber(image, 0, 0,
						     image_width,image_height,
						     pixels, 0, image_width);
	pixelgrabber.grabPixels();
 	
	LinkRaster.write(lt, ln, image_width, image_height,
			 pixels, properties, dos); 
    }

    /**
     * Write an image, X/Y placement with an ImageIcon.
     *
     * @param x1 window location of the left side of the image.
     * @param y1 window location of the top of the image.
     * @param image java.awt.Image to use for image.
     * @param image_width width of image in pixels.
     * @param image_height height of image in pixels.
     * @param properties description of drawing attributes. Not used,
     * but included to be consistant with the protocol graphics
     * format.
     * @param dos DataOutputStream
     * @throws IOException
     */
    public static void write(int x1, int y1, Image image, 
			     int image_width, int image_height, 
			     LinkProperties properties, 
			     DataOutputStream dos)
	throws IOException, InterruptedException {
	    int[] pixels = new int[image_width * image_height];
	    
	    PixelGrabber pixelgrabber = new PixelGrabber(image, 0, 0,
							 image_width, image_height,
							 pixels, 0, image_width);
	    pixelgrabber.grabPixels();
	    
	    LinkRaster.write(x1, y1, image_width, image_height, 
			     pixels, properties, dos); 
    }
    
    /**
     * Write an image, Lat/Lon with X/Y placement with an ImageIcon.  
     *
     * @param lt latitude of the top of the image, before the offset.
     * @param ln longitude of the left side of the image, before the offset.
     * @param offset_x1 number of pixels to move image to the right.
     * @param offset_y1 number of pixels to move image down.
     * @param image java.awt.Image to use for image.
     * @param image_width width of image in pixels.
     * @param image_height height of image in pixels.
     * @param properties description of drawing attributes. Not used,
     * but included to be consistant with the protocol graphics
     * format.
     * @param dos DataOutputStream
     * @throws IOException
     */
    public static void write(double lt, double ln, int offset_x1, int offset_y1,
			     Image image, int image_width, int image_height, 
			     LinkProperties properties, 
			     DataOutputStream dos)
	throws IOException, InterruptedException {
	    int[] pixels = new int[image_width * image_height];
	    
	    PixelGrabber pixelgrabber = new PixelGrabber(image, 0, 0,
							 image_width, image_height,
							 pixels, 0, image_width);
	    pixelgrabber.grabPixels();
 	
	    LinkRaster.write(lt, ln, offset_x1, offset_y1, 
			     image_width, image_height, pixels, 
			     properties, dos); 
    }
    
    /**
     * Write an image, Lat/Lon placement with an ImageIcon.
     *
     * @param lt latitude of the top of the image.
     * @param ln longitude of the left side of the image.
     * @param ii ImageIcon to use for image.
     * @param properties description of drawing attributes. Not used,
     * but included to be consistant with the protocol graphics
     * format.
     * @param dos DataOutputStream
     * @throws IOException
     */
    public static void write(double lt, double ln, ImageIcon ii,
			     LinkProperties properties, 
			     DataOutputStream dos)
	throws IOException,InterruptedException {

	int image_width, image_height;
	Image image;
	
	image_width = ii.getIconWidth();
	image_height = ii.getIconHeight();
	image = ii.getImage();
	LinkRaster.write(lt, ln, image, image_width, image_height, properties, dos);	
    }

    /**
     * Write an image, X/Y placement with an ImageIcon.
     *
     * @param x1 window location of the left side of the image.
     * @param y1 window location of the top of the image.
     * @param ii ImageIcon to use for image.
     * @param properties description of drawing attributes. Not used,
     * but included to be consistant with the protocol graphics
     * format.
     * @param dos DataOutputStream
     * @throws IOException
     */
    public static void write(int x1, int y1, ImageIcon ii, 
			     LinkProperties properties,
			     DataOutputStream dos)
	throws IOException, InterruptedException {


	int image_width, image_height;
	Image image;
	
	image_width = ii.getIconWidth();
	image_height = ii.getIconHeight();
	image = ii.getImage();
	LinkRaster.write(x1, y1, image, image_width, image_height,
			 properties, dos);
    }
 
    /**
     * Write an image, Lat/Lon with X/Y placement with an ImageIcon.  
     *
     * @param lt latitude of the top of the image, before the offset.
     * @param ln longitude of the left side of the image, before the offset.
     * @param offset_x1 number of pixels to move image to the right.
     * @param offset_y1 number of pixels to move image down.
     * @param ii ImageIcon to use for image.
     * @param properties description of drawing attributes. Not used,
     * but included to be consistant with the protocol graphics
     * format.
     * @param dos DataOutputStream
     * @throws IOException
     */
    public static void write(double lt, double ln,
			     int offset_x1, int offset_y1,
			     ImageIcon ii, 
			     LinkProperties properties, 
			     DataOutputStream dos)
	throws IOException, InterruptedException {

	int image_width, image_height;
	Image image;
	
	image_width = ii.getIconWidth();
	image_height = ii.getIconHeight();
	image = ii.getImage();
	LinkRaster.write(lt, ln, offset_x1, offset_y1, image, 
			 image_width, image_height, properties, dos);

    }

  ////////////////////////////////////// IMAGEICON LOADED FROM AN URL

    /**
     * Write an image, Lat/Lon placement with an ImageIcon.
     *
     * @param lt latitude of the top of the image.
     * @param ln longitude of the left side of the image.
     * @param url URL to download the image from.
     * @param properties description of drawing attributes. Not used,
     * but included to be consistant with the protocol graphics
     * format.
     * @param dos DataOutputStream
     * @throws IOException
     */
    public static void write(double lt, double ln, String url,
			     LinkProperties properties, 
			     DataOutputStream dos)
	throws IOException {

	dos.write(Link.RASTER_HEADER.getBytes());
	dos.writeInt(GRAPHICTYPE_RASTER);
	dos.writeInt(RENDERTYPE_LATLON);
	dos.writeInt(COLORMODEL_URL);
	dos.writeFloat((float) lt);
	dos.writeFloat((float) ln);
	properties.setProperty(LPC_LINKRASTERIMAGEURL, url);
	properties.write(dos);
    }

    /**
     * Write an image, X/Y placement with an ImageIcon.
     *
     * @param x1 window location of the left side of the image.
     * @param y1 window location of the top of the image.
     * @param url URL to download the image from.
     * @param properties description of drawing attributes. Not used,
     * but included to be consistant with the protocol graphics
     * format.
     * @param dos DataOutputStream
     * @throws IOException
     */
    public static void write(int x1, int y1, String url, 
			     LinkProperties properties, DataOutputStream dos)
	throws IOException {

	dos.write(Link.RASTER_HEADER.getBytes());
	dos.writeInt(GRAPHICTYPE_RASTER);
	dos.writeInt(RENDERTYPE_XY);
	dos.writeInt(COLORMODEL_URL);
	dos.writeInt(x1);
	dos.writeInt(y1);
	properties.setProperty(LPC_LINKRASTERIMAGEURL, url);
	properties.write(dos);
    }
  
    /**
     * Write an image, Lat/Lon with X/Y placement with an ImageIcon.  
     *
     * @param lt latitude of the top of the image, before the offset.
     * @param ln longitude of the left side of the image, before the offset.
     * @param offset_x1 number of pixels to move image to the right.
     * @param offset_y1 number of pixels to move image down.
     * @param url URL to download the image from.
     * @param properties description of drawing attributes. Not used,
     * but included to be consistant with the protocol graphics
     * format.
     * @param dos DataOutputStream
     * @throws IOException
     */
    public static void write(double lt, double ln,
			     int offset_x1, int offset_y1,
			     String url, 
			     LinkProperties properties, 
			     DataOutputStream dos)
	throws IOException {

	dos.write(Link.RASTER_HEADER.getBytes());
	dos.writeInt(GRAPHICTYPE_RASTER);
	dos.writeInt(RENDERTYPE_OFFSET);
	dos.writeInt(COLORMODEL_URL);
	dos.writeFloat((float) lt);
	dos.writeFloat((float) ln);
	dos.writeInt(offset_x1);
	dos.writeInt(offset_y1);
	properties.setProperty(LPC_LINKRASTERIMAGEURL, url);
	properties.write(dos);
    }

    ////////////////////////////////////// BYTE PIXELS with COLORTABLE

    /**
     * Lat/Lon placement with a indexed colormodel, which is using a
     * colortable and a byte array to contruct the int[] pixels.  
     *
     * @param lt latitude of the top of the image.
     * @param ln longitude of the left side of the image.
     * @param w width of the image, in pixels.
     * @param h height of the image, in pixels.
     * @param bytes colortable index values for the pixels.
     * @param colorTable color array corresponding to bytes
     * @param trans transparency of image.
     * @param properties description of drawing attributes. Not used,
     * but included to be consistant with the protocol graphics
     * format.
     * @param dos DataOutputStream
     * @throws IOException
     */
    public static void write(double lt, double ln, int w, int h,
			     byte[] bytes, Color[] colorTable,
			     int trans, 
			     LinkProperties properties, 
			     DataOutputStream dos)
	throws IOException {

	dos.write(Link.RASTER_HEADER.getBytes());
	dos.writeInt(GRAPHICTYPE_RASTER);
	dos.writeInt(RENDERTYPE_LATLON);
	dos.writeInt(COLORMODEL_INDEXED);
	dos.writeFloat((float) lt);
	dos.writeFloat((float) ln);
	dos.writeInt(w);
	dos.writeInt(h);
	dos.writeInt(bytes.length);
	dos.write(bytes,0,bytes.length);
	dos.writeInt(colorTable.length);
	
	int i;
	for (i = 0; i < colorTable.length; i++){
	    dos.writeInt(colorTable[i].getRGB());
	}
	dos.writeInt(trans);
	
	properties.write(dos);
    }
  
    /**
     * XY placement with a indexed colormodel, which is using a
     * colortable and a byte array to contruct the int[] pixels. 
     *
     * @param x1 window location of the left side of the image.
     * @param y1 window location of the top of the image.
     * @param w width of the image, in pixels.
     * @param h height of the image, in pixels.
     * @param bytes colortable index values for the pixels.
     * @param colorTable color array corresponding to bytes
     * @param trans transparency of image.
     * @param properties description of drawing attributes. Not used,
     * but included to be consistant with the protocol graphics
     * format.
     * @param dos DataOutputStream
     * @throws IOException
     */
    public static void write(int x1, int y1, int w, int h,
			     byte[] bytes, Color[] colorTable,
			     int trans, LinkProperties properties, 
			     DataOutputStream dos)
	throws IOException {

	dos.write(Link.RASTER_HEADER.getBytes());
	dos.writeInt(GRAPHICTYPE_RASTER);
	dos.writeInt(RENDERTYPE_XY);
	dos.writeInt(COLORMODEL_INDEXED);
	dos.writeInt(x1);
	dos.writeInt(y1);
	dos.writeInt(w);
	dos.writeInt(h);
	dos.writeInt(bytes.length);
	dos.write(bytes, 0, bytes.length);
	dos.writeInt(colorTable.length);
	
	int i;
	for (i = 0; i < colorTable.length; i++){
	    dos.writeInt(colorTable[i].getRGB());
	}
	dos.writeInt(trans);
	
	properties.write(dos);
    }

    /**
     * Lat/lon placement with XY offset with a indexed colormodel,
     * which is using a colortable and a byte array to construct the
     * int[] pixels.
     *
     * @param lt latitude of the top of the image, before the offset.
     * @param ln longitude of the left side of the image, before the offset.
     * @param offset_x1 number of pixels to move image to the right.
     * @param offset_y1 number of pixels to move image down.
     * @param w width of the image, in pixels.
     * @param h height of the image, in pixels.
     * @param bytes colortable index values for the pixels.
     * @param colorTable color array corresponding to bytes
     * @param trans transparency of image.
     * @param properties description of drawing attributes. Not used,
     * but included to be consistant with the protocol graphics
     * format.
     * @param dos DataOutputStream
     * @throws IOException
     */
    public static void write(double lt, double ln,
			     int offset_x1, int offset_y1,
			     int w, int h, byte[] bytes,
			     Color[] colorTable, int trans, 
			     LinkProperties properties,
			     DataOutputStream dos)
	throws IOException {

	dos.write(Link.RASTER_HEADER.getBytes());
	dos.writeInt(GRAPHICTYPE_RASTER);
	dos.writeInt(RENDERTYPE_OFFSET);
	dos.writeInt(COLORMODEL_INDEXED);
	dos.writeFloat((float) lt);
	dos.writeFloat((float) ln);
	dos.writeInt(offset_x1);
	dos.writeInt(offset_y1);
	dos.writeInt(w);
	dos.writeInt(h);
	dos.writeInt(bytes.length);
	dos.write(bytes, 0, bytes.length);
	dos.writeInt(colorTable.length);
	
	int i;
	 
	for (i = 0; i < colorTable.length; i++){
	    dos.writeInt(colorTable[i].getRGB());
	}
	dos.writeInt(trans);
	
	properties.write(dos);
    }

    /** 
     * Read the DataInputStream, and create an OMRaster.  Assumes that the
     * LinkRaster header has been read from the link.
     *
     * @param dis DataInputStream
     * @return OMRaster
     * @throws IOException
     * @see com.bbn.openmap.omGraphics.OMRaster 
     */
    public static OMRaster read(DataInputStream dis) throws IOException {

	OMRaster raster = null;
	double lat = 0;
	double lon = 0;
	int x = 0;
	int y = 0;
	int w = 0;
	int h = 0;
	int length, i;
	String url;

	Debug.message("link", "LinkRaster | Reading Raster graphic");

	int renderType = dis.readInt();
	int colorModel = dis.readInt();

	if (Debug.debugging("link")){
	    System.out.println("LinkRaster | Rendertype = " + 
			       renderType + ", colorModel = " + colorModel);
	}
	
	switch (renderType){
	case RENDERTYPE_OFFSET:
	    lat = dis.readFloat();
	    lon = dis.readFloat();
	    // Fall through...		
	case RENDERTYPE_XY:
	    x = dis.readInt();
	    y = dis.readInt();
	    break;
	case RENDERTYPE_LATLON:
	default:
	    lat = dis.readFloat();
	    lon = dis.readFloat();
	    if (Debug.debugging("link")){
		System.out.println("LinkRaster | Location: lat = " + 
				   lat + ", lon = " + lon);
	    }
	}
	
	// Now act differently depending on the colormodel
	if (colorModel != COLORMODEL_URL){

	    w = dis.readInt();
	    h = dis.readInt();

	    if (Debug.debugging("link")){
		System.out.println("LinkRaster | Size: width = " + 
				   w + ", height = " + h);
	    }

	    if (colorModel == COLORMODEL_INDEXED) {
	        
		length = dis.readInt();		
		
		byte[] bytes = new byte[length];
		
		if (Debug.debugging("link")){
		    System.out.println("LinkRaster | Reading " + 
				       length + " bytes.");
		}
		dis.readFully(bytes);

		if (Debug.debugging("link")){
		    System.out.println("LinkRaster | read bytes.");
		}

		length = dis.readInt();

		if (Debug.debugging("link")){
		    System.out.println("LinkRaster | " + 
				       length + " Colors.");
		}

		Color[] colorTable = new Color[length];
		for (i = 0; i < length; i++){
		    int colorvalue = dis.readInt();
		    colorTable[i] = ColorFactory.createColor(colorvalue, true);
		    if (Debug.debugging("linkdetail")){
			System.out.println( "LinkRaster | Color " + i + 
					    " =  " + colorTable[i] + 
					    " from " + 
					    Integer.toHexString(colorvalue));
		    }
		}

		int trans = dis.readInt();
		if (Debug.debugging("link")){
		    System.out.println("LinkRaster | Transparency =  " + 
				       trans);
		}

		switch (renderType){
		case RENDERTYPE_OFFSET:
		    raster = new OMRaster(lat, lon, x, y, 
					  w, h, bytes, colorTable, trans);
		    break;
		case RENDERTYPE_XY:
		    raster = new OMRaster(x, y, w, h, bytes, colorTable, trans);
		    break;
		case RENDERTYPE_LATLON:
		default:
		    raster = new OMRaster(lat, lon, w, h, bytes, colorTable, trans);
		}
		
	    } else { // must be COLORMODEL_DIRECT
		length = dis.readInt();
		int[] pix = new int[length];
		if (Debug.debugging("link")){
		    System.out.println("LinkRaster | Reading " + 
				       length + " pixels.");
		}

		for (i = 0; i < length; i++){
		    pix[i] = dis.readInt();
		}
		switch (renderType){
		case RENDERTYPE_OFFSET:
		    raster = new OMRaster(lat, lon, x, y, w, h, pix);
		    break;
		case RENDERTYPE_XY:
		    raster = new OMRaster(x, y, w, h, pix);
		    break;
		case RENDERTYPE_LATLON:
		default:
		    raster = new OMRaster(lat, lon, w, h, pix);
		}
	    }
	}
	
	LinkProperties properties = new LinkProperties(dis);

	if (colorModel == COLORMODEL_URL){
	    url = properties.getProperty(LPC_LINKRASTERIMAGEURL);

	    if (url != null){
		switch (renderType){
		case RENDERTYPE_OFFSET:
		    raster = new OMRaster(lat, lon, x, y, new ImageIcon(url));
		    break;
		case RENDERTYPE_XY:
		    raster = new OMRaster(x, y, new ImageIcon(url));
		    break;
		case RENDERTYPE_LATLON:
		default:
		    raster = new OMRaster(lat, lon, new ImageIcon(url));
		}
	    }
	}

	if (raster != null){
	    raster.setAppObject(properties);
	}

	return raster;
    }
}

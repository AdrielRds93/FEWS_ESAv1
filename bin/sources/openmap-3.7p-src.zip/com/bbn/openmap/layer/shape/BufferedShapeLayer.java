/* **********************************************************************
 * 
 *  BBNT Solutions LLC, A part of GTE
 *  10 Moulton St.
 *  Cambridge, MA 02138
 *  (617) 873-2000
 * 
 *  Copyright (C) 1998, 2000
 *  This software is subject to copyright protection under the laws of 
 *  the United States and other countries.
 * 
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/shape/BufferedShapeLayer.java,v $
 * $Revision: 1.6 $
 * $Date: 2000/05/08 14:22:53 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */
package com.bbn.openmap.layer.shape;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.*;
import java.io.File;
import java.util.*;
import com.bbn.openmap.util.Debug;
import com.bbn.openmap.layer.util.LayerUtils;
import com.bbn.openmap.*;
import com.bbn.openmap.event.*;
import com.bbn.openmap.omGraphics.*;
import com.bbn.openmap.proj.Projection;
import com.bbn.openmap.util.SwingWorker;

/**
 * An OpenMap Layer that displays shape files.  This loads the data up
 * front and then just reprojects/repaints when needed.  Note that the
 * ESRIRecords have been updated so that the OMGraphics that get
 * created from them are loaded with an Integer object that notes the
 * number of the record as it was read from the .shp file.  This lets
 * you align the object with the correct attribute data in the .dbf
 * file.
 */
public class BufferedShapeLayer extends ShapeLayer {

    /**
     * Master list of graphics.
     */
    protected OMGraphicList[] masterList = new OMGraphicList[0];

    /**
     * Bounding rectangles.
     */
    protected ESRIBoundingBox[] masterBounds = new ESRIBoundingBox[0];


    /**
     * Initializes an empty shape layer.
     */
    public BufferedShapeLayer() {
	super();
    }


    /**
     * Initializes this layer from an argv style vector.  This is
     * invoked when the layer is initialized from an overlay table.
     * @param argv command line style arguments from the overlay table
     */
    public void setArgs(String[] argv) {
	super.setArgs(argv);
	getWholePlanet();
    }


    /**
     * Initializes this layer from the given properties.
     * @param props the <code>Properties</code> holding settings for
     * this layer
     */
    public void setProperties (String prefix, Properties props) {
	super.setProperties(prefix, props);
	getWholePlanet();
    }


    /**
     * Get the graphics for the entire planet.
     */
    protected void getWholePlanet () {

	if (Debug.debugging("shape")) {
	    Debug.output(getName()+
		    "|BufferedShapeLayer.getWholePlanet(): "+
		    "fetching all graphics.");
	}
	try {
	    ESRIRecord records[] = spatialIndex.locateRecords(
		    -180d, -90d, 180d, 90d);
	    int nRecords = records.length;

	    masterList = new OMGraphicList[nRecords];    
	    masterBounds = new ESRIBoundingBox[nRecords];

	    
	    for (int i=0; i < nRecords; i++) {
		OMGraphicList list = new OMGraphicList(10);
	   	records[i].addOMGraphics(list, lineColor, fillColor);

		// Remember recordNumber to work with .dbf file
		list.setAppObject(new Integer(records[i].getRecordNumber()));
		masterList[i] = list; 

		masterBounds[i] = records[i].getBoundingBox(); 
	    }


	} catch (java.io.IOException ex) {
	    ex.printStackTrace();
	    return;
	}
	if (Debug.debugging("shape")) {
	    Debug.output(getName()+
		    "|BufferedShapeLayer.getWholePlanet(): "+
		    "finished fetch.");
	}
    }


    /**
     * Gets the layer graphics.
     * @return OMGraphicList
     */
    protected OMGraphicList computeGraphics() {

	if (spatialIndex == null) return null;

	// grab local
	Projection proj = projection;

	LatLonPoint ul = proj.getUpperLeft();
	LatLonPoint lr = proj.getLowerRight();
	double ulLat = ul.getLatitude();
	double ulLon = ul.getLongitude();
	double lrLat = lr.getLatitude();
	double lrLon = lr.getLongitude();

	OMGraphicList list = new OMGraphicList(100,100); 

	// check for dateline anomaly on the screen.  we check for ulLon >=
	// lrLon, but we need to be careful of the check for equality because
	// of floating point arguments...
	if ((ulLon > lrLon) ||
		MoreMath.approximately_equal(ulLon, lrLon, .001d))
	{
	    if (Debug.debugging("shape")) {
		Debug.out.println("Dateline is on screen");
	    }
	    double ymin = Math.min(ulLat, lrLat);
	    double ymax = Math.max(ulLat, lrLat);

	    // grab local refs
	    ESRIPoint min, max;

	    int size = masterBounds.length;
	    list.clear(); 
	    for (int i=0; i < size; i++) {
		min = masterBounds[i].min;
		max = masterBounds[i].max;
		if (SpatialIndex.intersects(
			    ulLon, ymin, 180.0d, ymax,
			    min.x, min.y, max.x, max.y) ||
			SpatialIndex.intersects(
			    -180.0d, ymin, lrLon, ymax,
			    min.x, min.y, max.x, max.y))
		{
		    list.addOMGraphic(masterList[i]); 
		}
	    }
	} else {
	    double xmin = Math.min(ulLon, lrLon);
	    double xmax = Math.max(ulLon, lrLon);
	    double ymin = Math.min(ulLat, lrLat);
	    double ymax = Math.max(ulLat, lrLat);

	    // grab local refs
	    ESRIPoint min, max;

	    int size = masterBounds.length;
	    list.clear(); 
	    for (int i=0; i < size; i++) {
		min = masterBounds[i].min;
		max = masterBounds[i].max;
		if (SpatialIndex.intersects(
			    xmin, ymin, xmax, ymax,
			    min.x, min.y, max.x, max.y))
		{
		    list.addOMGraphic(masterList[i]); 
		}
	    }
	}

	list.generate(projection, true);//all new graphics
	return list;
    }
}

/* **********************************************************************
 * 
 *  BBNT Solutions LLC, A part of GTE
 *  10 Moulton St.
 *  Cambridge, MA 02138
 *  (617) 873-2000
 * 
 *  Copyright (C) 1998-2000
 *  This software is subject to copyright protection under the laws of 
 *  the United States and other countries.
 * 
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/shape/areas/AreaDrawParams.java,v $
 * $Revision: 1.3 $
 * $Date: 2000/05/08 14:22:56 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */
package com.bbn.openmap.layer.shape.areas;

import java.awt.*;
import javax.swing.ImageIcon;

/**
 * A simple class, a structure really, to hold drawing parameters for
 * graphic objects.  
 */
public class AreaDrawParams {
    public String id;

    public Paint fill = null;
    public Color line = null;
    public Color select = null;
    public Stroke stroke = null;

    // For jdk 1.1 compatability, use these instead.
//     public Color fill = null;
//     public Color line = null;
//     public Color select = null;

    public ImageIcon image = null;
    public String name = "";

    public AreaDrawParams(){}

}

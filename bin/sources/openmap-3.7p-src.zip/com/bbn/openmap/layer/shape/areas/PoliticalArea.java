/* **********************************************************************
 * 
 *  BBNT Solutions LLC, A part of GTE
 *  10 Moulton St.
 *  Cambridge, MA 02138
 *  (617) 873-2000
 * 
 *  Copyright (C) 1998-2000
 *  This software is subject to copyright protection under the laws of 
 *  the United States and other countries.
 * 
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/shape/areas/PoliticalArea.java,v $
 * $Revision: 1.8 $
 * $Date: 2000/05/08 14:22:57 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */
package com.bbn.openmap.layer.shape.areas;

import com.bbn.openmap.*;
import com.bbn.openmap.omGraphics.*;
import com.bbn.openmap.layer.*;
import com.bbn.openmap.layer.util.*;
import com.bbn.openmap.util.Debug;
import com.bbn.openmap.image.BufferedImageHelper;
import com.bbn.openmap.layer.shape.*;

import java.awt.*;
import java.awt.image.*;
import java.awt.event.MouseEvent;
import java.net.URL;
import java.util.Vector;

/**
 * A PoliticalArea is a region that has a name (like "Oklahoma"),
 * an identifier (like "OK"), and a list of OMGraphics that
 * define its geography (ie: the polygons that define it's
 * borders).<P>
 * NOTE: The name of this class is somewhat misleading - the graphic
 * doesn;t have to represent an area - the graphic can be any graphic
 * created from the shapefile.  This class just provides a way to
 * associate an id with the graphic.  
 */
public class PoliticalArea {
    public final String name;  
    public final String id;
    protected OMGraphicList graphics; 

    protected Color overallFillColor = null;
    protected Color overallLineColor = null;
    protected Color overallSelectColor = null;
    protected TexturePaint overallFillPattern = null;
    
    /** 
     * Create a political area with a name, and an identifier which is
     * used as a key by the AreaHandler.
     */
    public PoliticalArea(String name , String identifier){
	this.name = name;
	this.id=identifier;
	graphics = new OMGraphicList();
    }
    
    /**
     * Set the fill-color of all the graphics in the Vector 
     * @param c java.awt.Color
     */
    public void setFillColor(Color c){
	graphics.setFillColor(c);
	overallFillColor = c;
    }

    /**
     * Get the color used for the fill color for all the graphics in
     * the political area, if one was set.
     *
     * @return Color if set, null if it wasn't. 
     */
    public Color getFillColor(){
	return overallFillColor;
    }

    /** 
     * Set the fill pattern of all the graphics in the Vector.  This
     * will override the fill color, if you've set that as well. There
     * are sections of code in this method that need to be commented
     * out if you are not using jdk 1.2.x.
     *
     * @param fillPatternURL url of image file to use as fill.  
     */
    public void setFillPattern(URL fillPatternURL){
	// This is kind of tricky.  Look at the list, find out which
	// members are OMGraphic2D objects, and set the Paint for
	// those graphics.

	TexturePaint texture = null;
	try {
	    
	    if (fillPatternURL != null){
		BufferedImage bi = BufferedImageHelper.getBufferedImage(fillPatternURL, 0, 0, -1, -1);
		texture = new TexturePaint(bi, new Rectangle(0,0, bi.getWidth(), bi.getHeight()));
		overallFillPattern = texture;
	    }
	} catch (InterruptedException ie){
	    Debug.error("PoliticalArea.setFillPattern(): error getting texture image - \n" + ie);
	}

	Vector list = graphics.getTargets();
	int size = list.size();

	for (int i = 0; i < size; i++){
	    OMGraphic graphic = (OMGraphic)list.elementAt(i);
	    if (graphic instanceof OMGraphic2D){
		((OMGraphic2D)graphic).setPaint(texture);
	    }
	}
    }


   /** 
     * Set the fill pattern of all the graphics in the Vector.  This
     * will override the fill color, if you've set that as well. There
     * are sections of code in this method that need to be commented
     * out if you are not using jdk 1.2.x.
     *
     * @param texture TexturePaint object to use as fill.  
     */
    public void setFillPattern(TexturePaint texture){
	// This is kind of tricky.  Look at the list, find out which
	// members are OMGraphic2D objects, and set the Paint for
	// those graphics.

	Vector list = graphics.getTargets();
	int size = list.size();

	for (int i = 0; i < size; i++){
	    OMGraphic graphic = (OMGraphic)list.elementAt(i);
	    if (graphic instanceof OMGraphic2D){
		((OMGraphic2D)graphic).setPaint(texture);
	    }
	}
    }

    /**
     * Get the TexturePaint used as fill for all the graphics in
     * the political area, if one was set.
     *
     * @return TexturePaint if set, null if it wasn't. 
     */
    public TexturePaint getFillPattern(){
	return overallFillPattern;
    }

     /**
     * Set the line-color of all the graphics in the Vector 
     * @param c java.awt.Color
     */
    public void setLineColor(Color c){
	graphics.setLineColor(c);
	overallLineColor = c;
    }

    /**
     * Get the color used for the line color for all the graphics in
     * the political area, if one was set.
     *
     * @return Color if set, null if it wasn't. 
     */
    public Color getLineColor(){
	return overallLineColor;
    }

    /**
     * Set the select-color of all the graphics in the Vector 
     * @param c java.awt.Color
     */
    public void setSelectColor(Color c){
	graphics.setSelectColor(c);
	overallSelectColor = c;
    }

    /**
     * Get the color used for the select color for all the graphics in
     * the political area, if one was set.
     *
     * @return Color if set, null if it wasn't. 
     */
    public Color getSelectColor(){
	return overallSelectColor;
    }

    /**
     * Get the value of graphics.
     * @return Value of graphics.
     */
    public OMGraphicList getGraphics() {
	return graphics;
    }
    
    /**
     * Set the value of graphics.
     * @param v  Value to assign to graphics.
     */
    public void setGraphics(OMGraphicList  v) {
	this.graphics = v;
    }
    
    /** 
     * Add a new omgraphic to the list of graphics in this area
     */ 
    public void addGraphic(OMGraphic g) {	
	this.graphics.add(g);
    }    
}

/* **********************************************************************
 *
 *  BBNT Solutions LLC, A part of GTE
 *  10 Moulton St.
 *  Cambridge, MA 02138
 *  (617) 873-2000
 *
 *  Copyright (C) 1998-2000
 *  This software is subject to copyright protection under the laws of
 *  the United States and other countries.
 *
 * **********************************************************************
 *
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/shape/areas/AreaHandler.java,v $
 * $Revision: 1.17 $
 * $Date: 2000/07/27 14:47:58 $
 * $Author: dietrick $
 *
 * **********************************************************************
 */

package com.bbn.openmap.layer.shape.areas;

import com.bbn.openmap.MoreMath;
import com.bbn.openmap.image.BufferedImageHelper;
import com.bbn.openmap.layer.shape.CSVInfoFile;
import com.bbn.openmap.layer.shape.ESRIRecord;
import com.bbn.openmap.layer.shape.SpatialIndex;
import com.bbn.openmap.layer.util.LayerUtils;
import com.bbn.openmap.omGraphics.OMGraphic;
import com.bbn.openmap.omGraphics.OMGraphicList;
import com.bbn.openmap.util.Debug;

import javax.swing.ImageIcon;
import java.awt.Color;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.TexturePaint;
import java.awt.image.BufferedImage;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Hashtable;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.Vector;

/**
 * An object to organize graphics in a shapefile and their corresponding
 * attributes in OpenMap.  A properties object can determine
 * how areas/graphics are to colored, or you can grab the graphics directly and
 * color them yourself.  It's called AreaHandler because it was
 * originally intended to be a management tool for political boundary
 * areas, but it should work for all shapefiles, really.  This object
 * uses a CSV file created from the CBF file that usually accompanies
 * the shapefile.  Also, this class does inflict a startup burden on
 * the map.  Because all the organizational effort occurs in
 * setProperties(), it occurs even if the handler isn't used in an
 * active Layer.
 * <P>
 * NOTE: There are sections in this file that require jdk 1.2 -
 * namely, the areas that let you set stroke and paint setting on the
 * graphics.  To make this object jdk 1.1 compatible, follow the
 * instructions in the code at the applicable areas.
 * <P>
 * CAUTION!  This is a work in progress.  Although it works,
 * it doesn't know how to fetch graphics spatially and maintain their
 * unique attributes at the same time.  It just returns all it's
 * graphics that are contained in the shapefile, and that may be slow.
 * This will get worked out in future versions.
 */
public class AreaHandler {

    /** The known political areas, based on the list of OMGraphics
     *  each entry contains. */
    protected Hashtable politicalAreas;
    /** The property that lists special colored areas. */
    public static final String areasProperty = ".areas";
    /** The property that specifies a color for a area:
     *  layer.MA.color.  The fillColor will be overridden by the
     *  fillPattern, if a fillPattern is specified. */
    public static final String fillColorProperty = ".fillColor";
    /** The property that specifies a line color for an area:
     *  layer.MA.linecolor. */
    public static final String lineColorProperty = ".lineColor";
    /** The property that specifies an URL for a image file to be used
     *  as a texture fill pattern for an area: layer.MA.fillPattern.
     *  If the fillPattern is null, the fillColor will be used. */
    public static final String fillPatternProperty = ".fillPattern";
    /** A property that is a multiplier for the size of the fill
     *  pattern image. */
    public static final String fillPatternScaleProperty = ".fillPatternScale";
    /** A property that sets an image URL to use for point
     *  objects. Only one image for all point objects. */
    public static final String pointImageURLProperty = ".pointImageURL";
    /** The property that specifies an index location for the area
     *  search key for a shape graphic in the database file.
     *  Default is 1.*/
    public static final String keyIndexProperty = ".keyIndex";
    /** The property that specifies an index location for the area
     *  name for a shape graphic in the database file. Default is 0.*/
    public static final String nameIndexProperty = ".nameIndex";
    /** The resource name, URL or file name of the serialized graphics
     *  file. */
    public static final String CacheFileProperty = ".cacheFile";
    /** The name of the property that holds the name of the shape file. */
    public final static String shapeFileProperty = ".shapeFile";
    /** The name of the property that holds the name of the spatial
     * index file.  */
    public final static String spatialIndexProperty = ".spatialIndex";
    /** The name of the property that holds the name of the CSV file
     *  with the area attributes, like the name and the
     *  abbreviation (or search Key). */
    public final static String csvFileProperty = ".csvFile";
    /** Set if the CSVFile has a header record.  Default is true. */
    public final static String csvHeaderProperty = ".csvFileHasHeader";

    /** The list of areas that have special coloring needs. */
    protected Vector areasItems = new Vector();
    /** The index of the column that holds the name of the area. */
    protected int nameIndex = 0;
    /** The index of the column that holds the search key of the area. */
    protected int keyIndex = 1;
    /** The URL location of the cached graphics file. */
    protected URL cacheURL = null;
    /** The graphics list */
    protected OMGraphicList omgraphics = null;

    /** Default draw parameters of the graphics that don't have
     *  something specific set for it. */
    protected AreaDrawParams defaultDrawParams;
    /** The fill color of all areas that don't have a specified color. */
    protected Color defaultFillColor = null;
    /** The line color of all areas that don't have a specified color. */
    protected Color defaultLineColor = Color.black;
    /** The location of the CSV attribute file. */
    protected CSVInfoFile infoFile = null;
    /** Flag that specifies that the first line consists of header
     *  information, and should not be mapped to a graphic. */
    protected boolean csvHasHeader = true;

    protected Properties originalProperties = null;
    protected String originalPrefix = null;
    protected SpatialIndex spatialIndex = null;
    protected Hashtable drawingParams;
    protected ImageIcon pointIcon = null;

    /**
     * Construct a default route layer.  Initializes omgraphics to
     * a new OMGraphicList, and invokes createGraphics to create
     * the canned list of routes.
     */
    public AreaHandler() {}

    /**
     * Initializes this object from the given properties.
     *
     * @param props the <code>Properties</code> holding settings for
     * this object
     */
    public void setProperties (String prefix, Properties props) {
	if (Debug.debugging("areas")){
	    Debug.output("AreaHandler: setting properties");
	}

	originalPrefix = prefix;
	originalProperties = props;
	// These will get initialized when someone asks for it.
	// Otherwise, it delays the startup of the map.
	politicalAreas = null;
    }

    /**
     * Go through the properties, loading the shapefile, information
     * file and attributes files, and resolve how everything should be
     * drawn.  Might take awhile if the files are large.
     * @param prefix property file entry header name
     * @param props the properties to look through.
     */
    public void initialize(String prefix, Properties props){

	if (prefix == null || props == null){
	    Debug.error("AreaHandler: initialize received bad input:\n\tprefix: "
			+ prefix + "\n\tproperties: " + (props == null?"null":"OK"));
	    politicalAreas = null;
	    return;
	}

	defaultDrawParams = new AreaDrawParams();
	defaultDrawParams.id = "default";

	// Set the default fill color.
	defaultDrawParams.fill /*defaultFillColor*/ =
	    LayerUtils.parseColorFromProperties(props,
						prefix + fillColorProperty,
						"00000000");
	// Set the default line color.
	defaultDrawParams.line /*defaultLineColor*/ =
	    LayerUtils.parseColorFromProperties(props,
						prefix + lineColorProperty,
						"FF000000");

	if (Debug.debugging("areas")){
	    Debug.output("AreaHandler: default fill color " +
			 prefix + fillColorProperty + " = " +
			 props.getProperty(prefix + fillColorProperty) +
			 ", default line color " +
			 prefix + lineColorProperty + " = " +
			 props.getProperty(prefix + lineColorProperty));
	}

	// This is a jdk1.2 section, since it's dealing with the
	// setting up of fill patterns.  The default fill pattern is
	// an image URL to be loaded in.  Comment this section out for
	// jdk 1.1 compatibility.

	TexturePaint defaultTexture = null;

	String textureImageURLString = props.getProperty(prefix + fillPatternProperty);
	try {
	    URL textureImageURL = LayerUtils.getResourceOrFileOrURL(this, textureImageURLString);
	    int textureScaleFactor =
		LayerUtils.intFromProperties(props, prefix + fillPatternScaleProperty, 1);

	    if (textureImageURL != null){
		BufferedImage bi =
		    BufferedImageHelper.getBufferedImage(textureImageURL, 0, 0, -1, -1);

		if (textureScaleFactor != 1){
		    Image image = bi.getScaledInstance(bi.getWidth()*textureScaleFactor,
						       bi.getHeight()*textureScaleFactor,
						       Image.SCALE_SMOOTH);

		    bi = BufferedImageHelper.getBufferedImage(image, 0, 0, -1, -1);
		}

		defaultTexture =
		    new TexturePaint(bi, new Rectangle(0,0, bi.getWidth(),
						       bi.getHeight()));
	    } else {
		Debug.message("areas", "AreaHandler:  no texture image set for default drawing parameters.");
	    }
	} catch (MalformedURLException murle){
	    Debug.error("AreaHandler.setProperties(): bad texture URL - \n" +
			textureImageURLString);
	    defaultTexture = null;
	} catch (InterruptedException ie){
	    Debug.error("AreaHandler.setProperties(): bad problems getting texture URL - \n" + ie);
	    defaultTexture = null;
	}

	if (defaultTexture != null){
	    defaultDrawParams.fill = defaultTexture;
	}

	drawingParams = new Hashtable();
	drawingParams.put(defaultDrawParams.id.toUpperCase().intern(),
			  defaultDrawParams);

	// End jdk 1.2 section.

	//  OK, Get the graphics.  We are not expecting that all the
	//  graphics in the file are not too much to handle.  Also, we
	//  test for the serialized graphics file first, and if it
	//  isn't designated, then look for a shapefile and spatial
	//  index file to create an OMGraphicsList.
	String cacheFile = props.getProperty(prefix + CacheFileProperty);

	// First find the resource, if not, then try as a file-URL...
	try {
	    cacheURL = LayerUtils.getResourceOrFileOrURL(this, cacheFile);

	    if (cacheURL != null){
		omgraphics = readCachedGraphics(cacheURL);
	    } else {
		//  The cached file not found, read in the shape file
		//  and the spatial index file, and create the
		//  graphics.
		String shapeFileName = props.getProperty(prefix +
							 shapeFileProperty);
		String spatialIndexFileName
		    = props.getProperty(prefix + spatialIndexProperty);

		if ((shapeFileName != null) &&
		    (spatialIndexFileName != null)) {

		    spatialIndex =
			SpatialIndex.locateAndSetShapeData(shapeFileName, spatialIndexFileName);

		    // Now, get the attribute file
		    String csvFile = props.getProperty(prefix +
						       csvFileProperty);
                    System.err.println("#############" + csvFile);
		    URL infofileURL = null;
		    if (csvFile != null){
			infofileURL =
			    LayerUtils.getResourceOrFileOrURL(this, csvFile);
		    }

		    // Read them in.
		    if (infofileURL != null){
			infoFile = new CSVInfoFile(csvFile);
			infoFile.setHeadersExist(LayerUtils.booleanFromProperties(props, prefix + csvHeaderProperty, true));
			infoFile.loadData(true);
		    }

		} else {
		    Debug.error("AreaHandler: One of the following properties was null:" +
				"\n\t" + prefix + shapeFileProperty +
				"\n\t" + prefix + spatialIndexProperty);
		    spatialIndex = null;
		}
	    }
	} catch (java.net.MalformedURLException murle){
	    omgraphics = new OMGraphicList();
	} catch (java.io.IOException ioe){
	    omgraphics = new OMGraphicList();
	}

	String defaultPointImageURLString = props.getProperty(prefix +
							      pointImageURLProperty);
	try{
	    if (defaultPointImageURLString != null){
		URL imageURL = new URL(defaultPointImageURLString);
		pointIcon = new ImageIcon(imageURL);
		if (Debug.debugging("areas")){
		    Debug.output("AreaHandler: have point Icon - " +
				 defaultPointImageURLString);
		}
	    }
	} catch (MalformedURLException murle){
	    Debug.error("AreaHandler.setProperties: point image URL not so good: \n\t" + defaultPointImageURLString);
	}

	// Now, match the attributes to the graphics.  Find the
	// indexes of the name and the search key.  Also figure out
	// which areas have special coloring needs.
	keyIndex = LayerUtils.intFromProperties(props, prefix + keyIndexProperty, keyIndex);
	nameIndex = LayerUtils.intFromProperties(props, prefix + nameIndexProperty, nameIndex);
	String areas = props.getProperty(prefix+areasProperty);

	if (areas == null) areas = "";

	StringTokenizer tokenizer = new StringTokenizer(areas," ");
	// All this uses the properties to set the individual colors
	// of any area
	String currentArea;
	String currentAreaColorStr;
	String currentAreaFillPatternStr;
	Color currentAreaColor;
	while(tokenizer.hasMoreTokens()){
	    currentArea = tokenizer.nextToken();

	    AreaDrawParams newParams = new AreaDrawParams();
	    newParams.id = currentArea;

	    if (Debug.debugging("areas")){
		Debug.output("AreaHandler: setting SPECIALIZED attributes for " +
			     newParams.id);
	    }

	    areasItems.addElement(currentArea);
	    // Set the fill color of the specified area.
	    currentAreaColorStr = props.getProperty(prefix + areasProperty +
						    "." + currentArea +
						    fillColorProperty);
	    if (currentAreaColorStr != null){
		currentAreaColor = GetColorFromString(currentAreaColorStr);
		newParams.fill = currentAreaColor;
	    }

	    // Set the line color of the specified area.
	    currentAreaColorStr = props.getProperty(prefix + areasProperty +
						    "." + currentArea +
						    lineColorProperty);
	    if (currentAreaColorStr != null){
		currentAreaColor = GetColorFromString(currentAreaColorStr);
		newParams.line = currentAreaColor;
	    }

	    currentAreaFillPatternStr = props.getProperty(prefix + areasProperty +
							  "." + currentArea +
							  fillPatternProperty);
	    try {
		URL currentTextureImageURL =
		    LayerUtils.getResourceOrFileOrURL(this, currentAreaFillPatternStr);

		if (currentTextureImageURL != null){
		    TexturePaint texture = null;
		    BufferedImage bi =
			BufferedImageHelper.getBufferedImage(currentTextureImageURL,
							     0, 0, -1, -1);

		    texture = new TexturePaint(bi, new Rectangle(0,0, bi.getWidth(),
								 bi.getHeight()));
		    newParams.fill = texture;
		}

	    } catch (MalformedURLException murle){
		Debug.error("AreaHandler.setProperties(): problem getting texture: \n" +
			    currentAreaFillPatternStr);
	    } catch (InterruptedException ie){
		Debug.error("AreaHandler: error getting texture image - \n" + ie);
	    }

	    drawingParams.put(newParams.id.toUpperCase().intern(), newParams);
	}

	if (Debug.debugging("areas")){
	    Debug.output("AreaHandler: finished initialization");
	}
    }

    /**
     * Read a cache of OMGraphics
     */
    public OMGraphicList readCachedGraphics(URL url)
	throws java.io.IOException {

	if (Debug.debugging("areas")){
	    Debug.output("Reading cached graphics");
	}

	OMGraphicList omgraphics = new OMGraphicList();

	if (url != null){
	    omgraphics.readGraphics(url);
	}
	return omgraphics;
    }

    /**
     * Get all the graphics from the shapefile, colored appropriately.
     */
    public OMGraphicList getGraphics(){
	return getGraphics(90d, -180d, -90d, 180d);
    }

    /**
     * Get the graphics for a particular lat/lon area.
     *
     * @param ullat upper left latitude, in decimal degrees.
     * @param ullat upper left longitude, in decimal degrees.
     * @param ullat lower right latitude, in decimal degrees.
     * @param ullat lower right longitude, in decimal degrees.
     * @return OMGraphicList
     */
    public OMGraphicList getGraphics(double ulLat, double ulLon,
				     double lrLat, double lrLon){

	if (spatialIndex == null) {
	    initialize(originalPrefix, originalProperties);
	    if (spatialIndex == null){ // Still@@!#!!!
		return new OMGraphicList();
	    }
	    spatialIndex.setPointIcon(pointIcon);
	}

	OMGraphicList list = null;
	AreaDrawParams drawParams;

	// check for dateline anomaly on the screen.  we check for ulLon >=
	// lrLon, but we need to be careful of the check for equality because
	// of floating point arguments...
	if ((ulLon > lrLon) ||
	    MoreMath.approximately_equal(ulLon, lrLon, .001d))
	{
	    if (Debug.debugging("areas")) {
		Debug.output("AreaHandler.getGraphics(): Dateline is on screen");
	    }

	    double ymin = Math.min(ulLat, lrLat);
	    double ymax = Math.max(ulLat, lrLat);

	    try {
		ESRIRecord records1[] = spatialIndex.locateRecords(
		    ulLon, ymin, 180.0d, ymax);
		ESRIRecord records2[] = spatialIndex.locateRecords(
		    -180.0d, ymin, lrLon, ymax);
		int nRecords1 = records1.length;
		int nRecords2 = records2.length;
		list = new OMGraphicList(nRecords1+nRecords2);
		for (int i = 0; i < nRecords1; i++) {
		    drawParams = getDrawParams(records1[i].getRecordNumber());
		    list.addOMGraphic(RecordList(records1[i], drawParams));
		}
		for (int i = 0; i < nRecords2; i++) {
		    drawParams = getDrawParams(records2[i].getRecordNumber());
		    list.addOMGraphic(RecordList(records2[i], drawParams));
		}
	    } catch (java.io.IOException ex) {
		ex.printStackTrace();
	    }
	} else {

	    double xmin = Math.min(ulLon, lrLon);
	    double xmax = Math.max(ulLon, lrLon);
	    double ymin = Math.min(ulLat, lrLat);
	    double ymax = Math.max(ulLat, lrLat);

	    try {
		ESRIRecord records[] = spatialIndex.locateRecords(
		    xmin, ymin, xmax, ymax);
		int nRecords = records.length;
		list = new OMGraphicList(nRecords);
		for (int i = 0; i < nRecords; i++) {
		    drawParams = getDrawParams(records[i].getRecordNumber());
		    list.addOMGraphic(RecordList(records[i], drawParams));
		}
	    } catch (java.io.IOException ex) {
		ex.printStackTrace();
	    }
	}
	return list;
    }

    /**
     * Return the graphic name, given the infofile vector on the
     * graphic.  The AreaHandler knows which one is the name.  Returns
     * an empty string if something goes wrong.
     */
    public String getName(Vector vector){
	try {
	    String string = (String)vector.elementAt(nameIndex);
	    return string;
	} catch (ClassCastException cce){
	    return "";
	}
    }

    /**
     * Get the name of the object at record number.  The record number
     * is the shapefile record number, which is one greater than the
     * index number.  Returns an empty string if something goes wrong.
     */
    public String getName(Integer integer){
	try {
	    if (infoFile != null){
		Vector vector = infoFile.getRecord(integer.intValue() - 1);
		String string = (String)vector.elementAt(nameIndex);
		return string;
	    }
	} catch (ClassCastException cce){}
	return "";
    }

    /**
     * Given the shapefile record number, find the drawing parameters
     * that should be used for the shape.  Note, this recordNumber is
     * the shapefile record number, which starts at one.  All our
     * indexes start at 0, so this is taken into account here.  Don't
     * make the adjustment elsewhere.  Returns the default coloring if the
     * key for the drawing parameters isn't found.
     */
    public AreaDrawParams getDrawParams(int recordNumber){
	if (infoFile == null) return defaultDrawParams;

	// OFF BY ONE!!!  The shape record numbers
	// assigned to the records start with 1, while
	// everything else we do starts with 0...
	Vector info = infoFile.getRecord(recordNumber-1);
	if (info == null) {
	    if (Debug.debugging("areas")){
		Debug.output("AreaHandler.getDrawParameters: record " +
			     recordNumber + " has no info");
	    }
	    return defaultDrawParams;
	}

	String key = ((String)info.elementAt(keyIndex)).toUpperCase().intern();

	AreaDrawParams adp = (AreaDrawParams)drawingParams.get(key);
	if (adp == null){
	    if (Debug.debugging("areas")){
		Debug.output("AreaHandler.getDrawParameters: record " +
			     recordNumber + " has key " + key +
			     " and DEFAULT attributes");
	    }
	    return defaultDrawParams;
	} else{
	    // Only bother with this the first time around.
	    if (adp.name == null){
		String name = (String)info.elementAt(nameIndex);
		if (name != null){
		    adp.name = name;
		} else {
		    adp.name = "";
		}
	    }

	    if (Debug.debugging("areas")){
		Debug.output("AreaHandler.getDrawParameters: record " +
			     recordNumber + " has key " + key +
			     " and SPECIALIZED attributes");
	    }
	    return adp;
	}
    }

    /**
     * Gets the record graphics for a record with multiple graphics.
     * @return OMGraphicList
     */
    protected OMGraphicList RecordList(ESRIRecord rec, AreaDrawParams drawParams){
	int recNumber=rec.getRecordNumber();
	OMGraphicList recList = new OMGraphicList(10,10);

	if (drawParams != null){
	    rec.addOMGraphics(recList, drawParams.line,
			      drawParams.stroke, drawParams.fill);
	} else {
	    rec.addOMGraphics(recList, defaultDrawParams.line,
			      defaultDrawParams.stroke, defaultDrawParams.fill);
	}
	// Remember recordNumber to work with .dbf file
	recList.setAppObject(new Integer(recNumber));

	return recList;
    }

    /**
     * Find a PoliticalArea named by the search key.  If the shapefile
     * is large, the first query will take a little extra time on the
     * first query to read in the files.
     *
     * @param area_key the lookup key, of which the index for the
     * column was designated in the properties file.
     */
    public PoliticalArea findPoliticalArea(String area_key){

	if (politicalAreas == null){
	    Debug.message("areas", "AreaHandler: initializing graphic attributes");
	    initialize(originalPrefix, originalProperties);
	    omgraphics = getGraphics();
	    infoFile.loadIntoGraphics(omgraphics);
	    politicalAreas = determinePoliticalAreas(omgraphics);
	    Debug.message("areas", "AreaHandler: completed initialization");
	}

	if (politicalAreas != null){
	    String key = area_key.toUpperCase().intern(); // Just to be sure.
	    PoliticalArea area = (PoliticalArea)politicalAreas.get(key);
	    return area;
	} else {
	    Debug.error("AreaHandler: initialization failed for " + originalPrefix +
			"\n\tNo data will be displayed");
	    return null;
	}
    }

    /**
     * Find the graphics that are represented by an search key.  If
     * the shapefile is large, the first query will take a little
     * extra time on the first query to read in the files.
     *
     * @param area_key the lookup key, of which the index for the
     * column was designated in the properties file.
     */
    public OMGraphicList findGraphics(String area_key){
	PoliticalArea area = findPoliticalArea(area_key);
	if (area == null){
	    return null;
	} else {
	    return area.getGraphics();
	}
    }

    /**
     * DeterminePoliticalAreas goes over a list of omgraphics, and
     * spits out a hashtable that holds PoliticalArea objects for
     * every area key.
     * @param graphiclist the list of graphics.  The top level graphic
     * entries on the list represent areas.
     */
    public Hashtable determinePoliticalAreas(OMGraphicList graphiclist){
	if (Debug.debugging("areas")){
	    Debug.output("AreaHandler: Determining political areas from OMGraphicList");
	}

	Hashtable poli_areas = new Hashtable();

	// Simple case.  No graphics means an empty list of regions.
	String name = null;
	String key = null;

	if (graphiclist != null)	{
	    int size = graphiclist.size();
	    for (int i = 0; i < size; i++){
		OMGraphic graphic = graphiclist.getOMGraphicAt(i);
		// below should be a vector like [ "Massachusetts", "MA" ];

		Object obj = graphic.getAppObject();
		if (obj == null){
		    if (Debug.debugging("verbose")){
			Debug.error("AreaHandler: Caught a null app object for graphic #"+ i);
		    }
		    continue;
		}

		if (obj instanceof Vector){
		    Vector pair = (Vector)obj;

		    name = (String)pair.elementAt(nameIndex);
		    key = ((String)pair.elementAt(keyIndex)).toUpperCase().intern();
		    if (Debug.debugging("areas")){
		      Debug.output("AreaHandler: looking at " +
				   name + ", " + key);
		    }
		} else if (obj instanceof String){
  		    // Assume that the key is stored here, I guess.
		    key = (String) obj;
		    if (Debug.debugging("areas")){
		        Debug.output("AreaHandler: String app object, looking at " + key);
		    }
		} else {
		    if (Debug.debugging("verbose")){
			Debug.output("AreaHandler: Unidentified app object type " +
				     obj);
		    }
		}

		// Get the political area object for this keyiation.
		PoliticalArea area = (PoliticalArea)poli_areas.get(key);

		if (area == null) { // key is not in table
		    area = new PoliticalArea(name, key);
		    poli_areas.put(key, area); // add it to the table
		}

		// Add the graphic to the list for this political area.
		area.addGraphic(graphic);
	    }

	    if (Debug.debugging("areas")){
		Debug.output("AreaHandler: Finished determinePoliticalAreas: " +
			     poli_areas.size() + " areas defined.");
	    }
	}

	return poli_areas;
    }

    /**
     * This function would return a Color object for string such as
     * red, green,..  (all that are available from java.awt.color
     * class).  It can also return a specific color represented by HEX
     * or Octal number like 0xffeeffee
     */
    protected Color GetColorFromString(String token){
	String tokstring = token;

	Color result = Color.black;

	if (Debug.debugging("areas")){
	    Debug.output("AreaHandler: GetColorFromString(" +
			 tokstring + ")");
	}

	// Thank the heavens for Emacs macros!
	if (tokstring.equals("black"))
	    result =  Color.black;
	else if (tokstring.equals("blue"))
	    result =  Color.blue;
	else if (tokstring.equals("cyan"))
	    result =  Color.cyan;
	else if (tokstring.equals("darkGray"))
	    result =  Color.darkGray;
	else if (tokstring.equals("gray"))
	    result =  Color.gray;
	else if (tokstring.equals("green"))
	    result =  Color.green;
	else if (tokstring.equals("lightGray"))
	    result =  Color.lightGray;
	else if (tokstring.equals("magenta"))
	    result =  Color.magenta;
	else if (tokstring.equals("orange"))
	    result =  Color.orange;
	else if (tokstring.equals("pink"))
	    result =  Color.pink;
	else if (tokstring.equals("red"))
	    result =  Color.red;
	else if (tokstring.equals("white"))
	    result =  Color.white;
	else if (tokstring.equals("yellow"))
	    result =  Color.yellow;
	else
	    // decode a hex color string.
	    result = Color.decode(tokstring);

	if (Debug.debugging("areas")){
	    Debug.output("AreaHandler.GetColorFromToken returns (" +
			 result + ")");
	}
	return result;
    }

    /**
     * This main function basically reads in the data sources (the
     * shape file and the csv information file, and creates a
     * serialized graphics file that will act like a cache later.
     */
    public static void main(String[] argv){
	String propertiesFile = null;
	String prefix = null;
	String outputFile = null;

	Debug.init();

	if (argv.length < 6) printUsage();

	for (int i = 0; i < argv.length; i++) {
	    if (argv[i].equalsIgnoreCase("-props")) {
		propertiesFile = argv[++i];
	    } else if (argv[i].equalsIgnoreCase("-prefix")) {
		prefix = argv[++i];
	    } else if (argv[i].equalsIgnoreCase("-file")) {
		outputFile = argv[++i];
	    }
	}

	if (propertiesFile == null ||
	    prefix == null ||
	    outputFile == null) {
	    printUsage();
	}

	try {
	    //  Let's make a file
	    AreaHandler ah = new AreaHandler();
	    Properties properties = new Properties();
	    // Read in the properties.
	    URL propertiesURL = new URL(propertiesFile);
	    InputStream is = propertiesURL.openStream();
	    properties.load(is);
	    // Set the properties in the handler.
	    ah.setProperties(prefix, properties);
	    // Write the saved graphics.
	    ah.getGraphics().writeGraphics(outputFile);

	} catch (java.net.MalformedURLException murle){
	    Debug.error("Bad URL for properties file : " +
			       propertiesFile);
	    printUsage();
	} catch (java.io.IOException ioe){
	    Debug.error("IOException creating cached graphics file: " +
			       outputFile);
	    printUsage();
	}
    }

    public static void printUsage(){
	Debug.output("Usage: java com.bbn.openmap.layer.shape.areas.AreaHandler -props <URL to properties file> -prefix <handler property prefix> -file <path to output file>");
	System.exit(-1);
    }

}

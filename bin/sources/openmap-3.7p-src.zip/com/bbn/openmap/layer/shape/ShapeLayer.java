/* **********************************************************************
 * 
 *  BBNT Solutions LLC, A part of GTE
 *  10 Moulton St.
 *  Cambridge, MA 02138
 *  (617) 873-2000
 * 
 *  Copyright (C) 1998, 2000
 *  This software is subject to copyright protection under the laws of 
 *  the United States and other countries.
 * 
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/shape/ShapeLayer.java,v $
 * $Revision: 1.40 $
 * $Date: 2000/05/25 22:29:49 $
 * $Author: dietrick $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.shape;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.*;
import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.*;
import javax.swing.ImageIcon;

import com.bbn.openmap.*;
import com.bbn.openmap.event.*;
import com.bbn.openmap.layer.util.LayerUtils;
import com.bbn.openmap.omGraphics.*;
import com.bbn.openmap.proj.Projection;
import com.bbn.openmap.util.Debug;
import com.bbn.openmap.util.SwingWorker;

/**
 * An OpenMap Layer that displays shape files.  Note that the
 * ESRIRecords have been updated so that the OMGraphics that get
 * created from them are loaded with an Integer object that notes the
 * number of the record as it was read from the .shp file.  This lets
 * you align the object with the correct attribute data in the .dbf
 * file.
 * <p>
 * <code><pre>
 * ############################
 * # Properties for a shape layer
 * shapeLayer.class=com.bbn.openmap.layer.shape.ShapeLayer
 * shapeLayer.prettyName=Name_for_Menu
 * shapeLayer.shapeFile=&ltpath to shapefile (.shp)&gt
 * shapeLayer.spatialIndex=&ltpath to generated spatial index file (.ssx)&gt
 * shapeLayer.lineColor=ff000000
 * shapeLayer.fillColor=ff000000
 * shapeLayer.pointImageURL=&ltURL for image to use for point objects&gt
 * ############################
 * </pre></code>
 *
 * @author Tom Mitchell <tmitchell@bbn.com>
 * @version $Revision: 1.40 $ $Date: 2000/05/25 22:29:49 $
 * @see SpatialIndex 
 */
public class ShapeLayer extends Layer implements ComponentListener {

    /** The name of the property that holds the name of the shape file. */ 
    public final static String shapeFileProperty = ".shapeFile";

    /**
     * The name of the property that holds the name of the
     * spatial index file.
     */
    public final static String spatialIndexProperty = ".spatialIndex";

    /** The name of the property that holds the line color of the graphics. */
    public final static String lineColorProperty = ".lineColor";

    /** The name of the property that holds the fill color of the graphics. */
    public final static String fillColorProperty = ".fillColor";

    /** The URL of an image to use for point objects. */
    public final static String pointImageURLProperty = ".pointImageURL";

    // Note that shadows are really in the eye of the beholder
    // The X,Y shadow offset just pushes the resulting picture in the
    // direction of the offset and draws it there. By setting the
    // fill and line colors, you make it seem shadowy. By drawing
    // a layer as a shadow, and then again as a regular layer, you
    // get the proper effect.

    /** The name of the property that holds the offset of the shadow. */
    public final static String shadowXProperty = ".shadowX";
    public final static String shadowYProperty = ".shadowY";

    /*** The holders of the shadow offset. ***/
    protected int shadowX = 0;
    protected int shadowY = 0;

    /** The default line color. (black) */
    public final static String defaultLineColorString = "0"; // black

    /** The default fill color. (none) */
    public final static String defaultFillColorString = "-1"; // none

    /** The spatial index of the shape file to be rendered. */
    protected SpatialIndex spatialIndex;

    /** The most recent projection. */
    protected Projection projection;

    /** The most recent projection identifier. */
    protected String projID;

    /** List of graphics currently rendered. */
    protected OMGraphicList omgraphics;

    /** The color to outline the shapes. */
    protected Color lineColor;

    /** The color to fill the shapes. */
    protected Color fillColor;

    /** */
    protected boolean cancelled = false;

    /** */
    protected ShapeWorker currentWorker;

    /**
     * Initializes an empty shape layer.
     */
    public ShapeLayer() {
        addComponentListener(this);
    }

    /**
     * Initializes this layer from an argv style vector.  This is
     * invoked when the layer is initialized from an overlay table.
     *
     * @param argv command line style arguments from the overlay table
     */
    public void setArgs(String[] argv) {
	Debug.message("shape", "ShapeLayer.setArgs(argv)");
	String shapeFileName = argv[0];
	String spatialIndexFileName = argv[1];

	spatialIndex = 
	    SpatialIndex.locateAndSetShapeData(shapeFileName, spatialIndexFileName);
	
	String lineColorArg = argv[2];
	lineColor = LayerUtils.parseColor(lineColorArg);
	if (Debug.debugging("shape")){
	    Debug.output("ShapeLayer|" + getName() + 
			 ": From " + lineColorArg + 
			 " to " + lineColor);
	}

	String fillColorArg = argv[3];
	fillColor =  LayerUtils.parseColor(fillColorArg);
	if (Debug.debugging("shape")){
	    Debug.output("ShapeLayer|" + getName() + 
			 ": From " + fillColorArg + 
			 " to " + fillColor);
	}
    }

    /**
     * Initializes this layer from the given properties.
     *
     * @param props the <code>Properties</code> holding settings for this layer
     */
    public void setProperties (String prefix, Properties props) {
	super.setProperties(prefix, props);
	String shapeFileName = props.getProperty(prefix + shapeFileProperty);
	String spatialIndexFileName
	    = props.getProperty(prefix + spatialIndexProperty);

	if ( ( shapeFileName != null ) && ( spatialIndexFileName != null ) ) {

	    spatialIndex = 
		SpatialIndex.locateAndSetShapeData(shapeFileName, 
						   spatialIndexFileName);

	    String imageURLString = 
		props.getProperty(prefix + pointImageURLProperty);
	    try{
		if (imageURLString != null){
		    URL imageURL = new URL(imageURLString);
		    ImageIcon imageIcon = new ImageIcon(imageURL);
		    spatialIndex.setPointIcon(imageIcon);
		}
	    } catch (MalformedURLException murle){
		Debug.error("ShapeLayer.setProperties: point image URL not so good: \n\t"
			    + imageURLString);
	    }

	} else {
	    Debug.error("One of the following properties was null:");
	    Debug.error("\t" + prefix + shapeFileProperty);
	    Debug.error("\t" + prefix + spatialIndexProperty);
	}

	lineColor =
	    LayerUtils.parseColorFromProperties(props,
						prefix + lineColorProperty,
						defaultLineColorString);

	fillColor =
	    LayerUtils.parseColorFromProperties(props,
						prefix + fillColorProperty,
						defaultFillColorString);

	String shadowXString =
	    props.getProperty(prefix + shadowXProperty);
	if (shadowXString != null) {
	    try {
		shadowX = Integer.valueOf(shadowXString).intValue();
	    } catch (NumberFormatException e) {
		shadowX = 0;
		Debug.error("ShapeLayer: Unable to parse " + 
			    shadowXProperty + " = " + shadowXString);
	    }
	}

	String shadowYString =
	    props.getProperty(prefix + shadowYProperty);
	if (shadowYString != null) {
	    try {
		if (shadowYString != null)
		    shadowY = Integer.valueOf(shadowYString).intValue();
	    } catch (NumberFormatException e) {
		shadowY = 0;
		Debug.error("ShapeLayer: Unable to parse " + 
			    shadowYProperty + " = " + shadowYString);
	    }
	}
    }
    
    /**
     *
     */
    protected synchronized void computeLayer() {
	if (projection == null) {
	    Debug.message("shape", 
			  "ShapeLayer says the projection is null");
	    return;
	}

	if (isVisible()) {
	    
	    if (omgraphics != null) {

		// If we already have graphics, just slap 'em up there.
		// This is probably because this layer was hidden and
		// is now being shown.
		repaint();

	    } else if (currentWorker == null) {

		// No graphics.  If we're not already computing graphics,
		// then compute new graphics.
		currentWorker = new ShapeWorker();
//   		Debug.output("Executing...");
		currentWorker.execute();
//   		Debug.output("Done executing.");

	    } else {

		// We're already computing.  Set the cancel flag and
		// return.  The DcwWorker management code will fire
		// up a new computation when the current worker stops.
		cancelled = true;
	    }
	}
	
    }

    /**
     * Gets the record graphics for a record with multiple graphics.
     * @return OMGraphicList
     */
    protected OMGraphicList RecordList(ESRIRecord rec, Color lineColor, Color fillColor){
	int recNumber=rec.getRecordNumber();
	OMGraphicList recList = new OMGraphicList(10,10);
	rec.addOMGraphics(recList, lineColor, fillColor);
	
	// Remember recordNumber to work with .dbf file
	recList.setAppObject(new Integer(recNumber)); 
	return recList;
    }

    /**
     * Return the projection of the current map.
     * @return projection
     */
    public Projection getProjection(){
	return projection;
    }

    /**
     * Gets the layer graphics.
     * @return OMGraphicList
     */
    protected OMGraphicList computeGraphics() {

	if (spatialIndex == null) {
	    Debug.message("shape", "ShapeLayer: spatialIndex is null!");
	    return null;
	}

	LatLonPoint ul = projection.getUpperLeft();
	LatLonPoint lr = projection.getLowerRight();
	double ulLat = ul.getLatitude();
	double ulLon = ul.getLongitude();
	double lrLat = lr.getLatitude();
	double lrLon = lr.getLongitude();

	OMGraphicList list = null;

	// check for dateline anomaly on the screen.  we check for ulLon >=
	// lrLon, but we need to be careful of the check for equality because
	// of floating point arguments...
	if ((ulLon > lrLon) ||
		MoreMath.approximately_equal(ulLon, lrLon, .001d))
	{
	    if (Debug.debugging("shape")) {
		Debug.output("ShapeLayer.computeGraphics(): Dateline is on screen");
	    }

	    double ymin = Math.min(ulLat, lrLat);
	    double ymax = Math.max(ulLat, lrLat);

	    try {
		ESRIRecord records1[] = spatialIndex.locateRecords(
		    ulLon, ymin, 180.0d, ymax);
		ESRIRecord records2[] = spatialIndex.locateRecords(
		    -180.0d, ymin, lrLon, ymax);
		int nRecords1 = records1.length;
		int nRecords2 = records2.length;
		list = new OMGraphicList(nRecords1+nRecords2);
		for (int i = 0; i < nRecords1; i++) {
		    list.addOMGraphic(RecordList(records1[i], lineColor, fillColor));
		}
		for (int i = 0; i < nRecords2; i++) {
		    list.addOMGraphic(RecordList(records2[i], lineColor, fillColor));
		}
	    } catch (java.io.IOException ex) {
		ex.printStackTrace();
	    }
	} else {

	    double xmin = Math.min(ulLon, lrLon);
	    double xmax = Math.max(ulLon, lrLon);
	    double ymin = Math.min(ulLat, lrLat);
	    double ymax = Math.max(ulLat, lrLat);

	    try {
		ESRIRecord records[] = spatialIndex.locateRecords(
		    xmin, ymin, xmax, ymax);
		int nRecords = records.length;
		list = new OMGraphicList(nRecords);
		for (int i = 0; i < nRecords; i++) {
		    list.addOMGraphic(RecordList(records[i], lineColor, fillColor));
		}
	    } catch (java.io.IOException ex) {
		ex.printStackTrace();
	    }
	}

	list.generate(projection, true);//all new graphics
	return list;
    }

    /**
     *
     */
    protected synchronized void workerComplete (ShapeWorker worker) {
	if (!cancelled) {
	    currentWorker = null;
	    omgraphics = (OMGraphicList)worker.get();
	    repaint();
	}
	else{
	    cancelled = false;
	    currentWorker = new ShapeWorker();
	    currentWorker.execute();
	}
    }

    /** 
     * Implementing the ProjectionPainter interface.
     */
    public synchronized void renderDataForProjection(Projection proj, java.awt.Graphics g){
	if (proj == null){
	    Debug.error("ShapeLayer.renderDataForProjection: null projection!");
	    return;
	} else if (!proj.equals(projection)){
	    projection = proj.makeClone();
	    omgraphics = computeGraphics();
	}
	paint(g);
    }

    /**
     * Handles projection change notification events.  Throws out
     * old graphics, and requests new graphics from the spatial index
     * based on the bounding rectangle of the new <code>Projection</code>.
     *
     * @param ev the new projection event
     */
    public void projectionChanged(ProjectionEvent ev) {

	Projection newProj = ev.getProjection();
	String newPID = newProj.getProjectionID();
	if (newPID == projID) {// projection not really different
	    Debug.message("shape", 
			  "ShapeLayer: projection not different, returning...");
	    repaint();
	    return;
	}
	projection = newProj;
	projID = newPID;

	// kill old list
	omgraphics = null;

	// redo the layer
	computeLayer();
    }

    /**
     * Renders the layer on the map.
     *
     * @param g a graphics context
     */
    public void paint (Graphics g) {
	// grab local for thread safety
	OMGraphicList omg = omgraphics;

	if (omg != null){
	    if (Debug.debugging("shape"))
		Debug.output("ShapeLayer.paint(): " + omg.size() +
			     " omg" + " shadow=" + shadowX + "," + shadowY);
	    
	    if (shadowX != 0 || shadowY != 0){
		Graphics shadowG = g.create();
		shadowG.translate(shadowX, shadowY);
		omg.render(shadowG);
	    } else {
		omg.render(g);
	    }
	    if (Debug.debugging("shape")){
		Debug.output("ShapeLayer.paint(): done");
	    }
	}
    }
    
    /**
     *
     */
    class ShapeWorker extends SwingWorker {

	public ShapeWorker () {
	    super();
	}

	/** 
	 * Compute the value to be returned by the <code>get</code> method. 
	 */
	public Object construct() {
	    fireStatusUpdate(LayerStatusEvent.START_WORKING);

	    try {
		if (Debug.debugging("shape")) {
		    Debug.output(getName()+"|ShapeLayer.ShapeWorker.construct(): getting graphics...");
		}
		long start = System.currentTimeMillis();
		OMGraphicList list = computeGraphics();
		long stop = System.currentTimeMillis();
		if (Debug.debugging("shape")) {
		    int size = list.size();
		    Debug.output(getName()+"|ShapeLayer.ShapeWorker.construct(): fetched "+size+" graphics in "+ (stop-start)/1000d +" seconds");
		}
		return list;
	    } catch (OutOfMemoryError e) {
		omgraphics = null;
		String msg = getName() + "|ShapeLayer.ShapeWorker.construct(): " + e;
		Debug.error(msg);
		e.printStackTrace();
		fireRequestMessage(new InfoDisplayEvent(this, msg));
		fireStatusUpdate(LayerStatusEvent.FINISH_WORKING);
		return null;
	    }
	}

	/**
	 * Called on the event dispatching thread (not on the worker thread)
	 * after the <code>construct</code> method has returned.
	 */
	public void finished() {
	    fireStatusUpdate(LayerStatusEvent.FINISH_WORKING);
	    workerComplete(this);
	}
    }

    //----------------------------------------------------------------------
    // Component Listener implementation
    //----------------------------------------------------------------------
    /**
     * Empty.
     */
    public void componentResized(ComponentEvent e) {}

    /**
     * Empty.
     */
    public void componentMoved(ComponentEvent e) {}

    /**
     * When component gets shown, compute the graticule.
     *
     * @param e a component event
     */
    public void componentShown(ComponentEvent e) {
	computeLayer();
    }

    /**
     * Empty.
     */
    public void componentHidden(ComponentEvent e) {}
}

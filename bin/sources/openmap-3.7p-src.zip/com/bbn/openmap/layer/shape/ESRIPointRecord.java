/* **********************************************************************
 * 
 *  BBNT Solutions LLC, A part of GTE
 *  10 Moulton St.
 *  Cambridge, MA 02138
 *  (617) 873-2000
 * 
 *  Copyright (C) 1998, 2000
 *  This software is subject to copyright protection under the laws of 
 *  the United States and other countries.
 * 
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/layer/shape/ESRIPointRecord.java,v $
 * $Revision: 1.9 $
 * $Date: 2000/05/08 14:22:54 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.layer.shape;

import java.io.IOException;
import javax.swing.ImageIcon;
import com.bbn.openmap.omGraphics.*;

/**
 * An ESRI Point record.
 *
 * @author Ray Tomlinson
 * @author Tom Mitchell <tmitchell@bbn.com>
 * @version $Revision: 1.9 $ $Date: 2000/05/08 14:22:54 $
 */
public class ESRIPointRecord extends ESRIRecord {

    /** The x coordinate. */
    protected double x;

    /** The y coordinate. */
    protected double y;

    /** A BufferedImage to use at the point. */
    protected ImageIcon ii;

    /**
     * Initializes this point from the given point.
     *
     * @param x the x coordinate
     * @param y the y coordinate
     */
    public ESRIPointRecord(double x, double y) {
	this.x = x;
	this.y = y;
    }

    /**
     * Initialize a point record from the given buffer.
     *
     * @param b the buffer
     * @param off the offset into the buffer where the data starts
     */
    public ESRIPointRecord(byte b[], int off) throws IOException {
	super(b, off);

	int ptr = off+8;

	int shapeType = readLEInt(b, ptr);
	ptr += 4;
	if (shapeType != SHAPE_TYPE_POINT) {
	    throw new IOException("Invalid point record.  Expected shape " +
				  "type " + SHAPE_TYPE_POINT +
				  " but found " + shapeType);
	}

	x = readLEDouble(b, ptr);
	ptr += 8;

	y = readLEDouble(b, ptr);
	ptr += 8;
    }

    /**
     * Initialize a point record from the given buffer.
     *
     * @param b the buffer
     * @param off the offset into the buffer where the data starts
     */
    public ESRIPointRecord(byte b[], int off, ImageIcon imageIcon) throws IOException {
	super(b, off);

	int ptr = off+8;

	int shapeType = readLEInt(b, ptr);
	ptr += 4;
	if (shapeType != SHAPE_TYPE_POINT) {
	    throw new IOException("Invalid point record.  Expected shape " +
				  "type " + SHAPE_TYPE_POINT +
				  " but found " + shapeType);
	}

	x = readLEDouble(b, ptr);
	ptr += 8;

	y = readLEDouble(b, ptr);
	ptr += 8;

	ii = imageIcon;
    }

    /**
     * Gets this record's bounding box.
     *
     * @return a bounding box
     */
    public ESRIBoundingBox getBoundingBox() {
	return new ESRIBoundingBox(x, y);
    }

    /**
     * Yields the length of this record's data portion. Always 20.
     *
     * @return number of bytes equal to the size of this record's data
     */
    public int getRecordLength() {
	return 20;
    }

    /**
     * Writes this point to the given buffer at the given offset.
     *
     * @param b the buffer
     * @param off the offset
     * @return the number of bytes written
     */
    public int write(byte[] b, int off) {
 	int nBytes = super.write(b, off);
 	nBytes += writeLEInt(b, off + nBytes, SHAPE_TYPE_POINT);
 	nBytes += writeLEDouble(b, off + nBytes, x);
 	nBytes += writeLEDouble(b, off + nBytes, y);
 	return nBytes;
    }

    /**
     * Generates OMGraphics and adds them to the given list.
     *
     * @param list the graphics list
     */
    public void addOMGraphics(OMGraphicList list,
			      java.awt.Color lineColor, 
			      java.awt.Color fillColor){
	OMGraphic g;
	if (ii == null){

	    g = new OMRect(y, x, -1, -1, 1, 1);

	    // These used to be set to fill->blue and line->clear.
	    // Anybody remember why?  Seems like that ought to be
	    // something that someone ought to decide for themselves.Seems
	    // like the right thing to do for a point is to have the line
	    // color be the fill color for the one internal pixel, and
	    // that clear should be the color for the exterior of that
	    // pixel.
	    g.setFillColor(lineColor);
	    g.setLineColor(OMColor.clear);
	} else {
	    g = new OMRaster(y, x,
			      -ii.getIconWidth()/2, -ii.getIconHeight()/2,
			     ii);

	}
	list.add(g);
    }

    /**
     * Generates 2D OMGraphics and adds them to the given list.  If
     * you are using jdk1.1.X, you'll have to comment out this method,
     * because jdk1.1.X doesn't know about the java.awt.Stroke and
     * java.awt.Paint interfaces.
     *
     * @param list the graphics list
     * @param lineColor line color
     * @param stroke the Stroke object to describe how to draw the
     * border of the shape - if null, the BasicStroke will be used.
     * @param fill the Paint object to describe the fill parameters.  
     */
    public void addOMGraphics(OMGraphicList list,
			      java.awt.Color lineColor, 
			      java.awt.Stroke stroke,
			      java.awt.Paint fill){
	if (ii == null){
	    OMRect2D r = new OMRect2D(y, x, -1, -1, 1, 1);
	    // Same color discussion as above in the jdk1.1 compatabile
	    // method.
	    r.setPaint(lineColor);
	    r.setStroke(stroke);
	    r.setLineColor(OMGraphic.clear);
	    list.add(r);
	} else {
	    list.add(new OMRaster(y, x,
				  -ii.getIconWidth()/2, -ii.getIconHeight()/2,
				  ii));
	}
    }	    

    /**
     * Gets this record's shape type as an int.  Shape types
     * are enumerated on the ShapeUtils class.
     *
     * @return the shape type as an int
     */
    public int getShapeType() {
	return SHAPE_TYPE_POINT;
    }
}

/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/util/Closable.java,v $
 * $Revision: 1.2 $
 * $Date: 2000/05/08 14:23:29 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.util;

/** Objects that implement this interface can be registered with
 * BinaryFile to have associated file resources closed when file limits
 * are hit.  */
public interface Closable {
    /** close/reclaim associated resources
     * @param done <code>true</code> indicates that this is a permanent
     * closure.  <code>false</code> indicates that the object may be used
     * again later, as this is only an attempt to temporarily reclaim resources
     * @return <code>true</code> indicates the object is still usable.
     * <code>false</code> indicates that the object is now unusable, and
     * any references to it should be released so the garbage collector
     * can do its job. */
    public boolean close(boolean done);
}

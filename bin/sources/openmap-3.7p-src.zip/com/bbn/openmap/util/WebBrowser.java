// **********************************************************************
//
//  BBNT Solutions LLC, A part of GTE
//  10 Moulton St.
//  Cambridge, MA 02138
//  (617) 873-2000
//
//  Copyright (C) 1996, 2000
//  This software is subject to copyright protection under the laws of
//  the United States and other countries.
//
// **********************************************************************
//
// $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/util/WebBrowser.java,v $
// $RCSfile: WebBrowser.java,v $
// $Revision: 1.9 $
// $Date: 2000/05/08 14:23:30 $
// $Author: wjeuerle $
//
// **********************************************************************

package com.bbn.openmap.util;

import java.io.*;
import java.util.Vector;
import java.net.URL;
import java.net.MalformedURLException;

import com.bbn.openmap.Environment;
import com.bbn.openmap.InformationDelegator;
import com.bbn.openmap.event.InfoDisplayEvent;
import com.bbn.openmap.util.Debug;

/** WebBrower - handles the WebBrowser process on behalf of OM. */
public class WebBrowser {
    static int fileNumber = 0;
    static int tempID = 0;
    Process proc = null;
    Vector tmpfiles = null;		// vector of tmp pathnames
    InformationDelegator info = null;

    /**
     * Create a webbrowser.
     *
     */
    public WebBrowser() {
	tmpfiles = new Vector();
    }


    /** 
     * Get the launch cmd.
     * @param url URL to show
     * @return String
     *
     */
    protected String generateLaunchCmd(String url) {
	//HACK, needs to be OS/web-browser specific
	return Environment.get(Environment.WebBrowser) + " " + url;
    }

    /**
     * Write temporary file to temporary directory, and generate URL.
     * @param text text String
     * @return String file URL
     */
    protected String writeFileAndGenerateURL(String text) {

	// generate a tmpfile (this name is not unique...)
	String tmpfile = "OpenMap-" + Environment.generateUniqueString() + ".html";
	Debug.message("www",
	    "WebBrowser.writeAndGenerateURL: filename: " + tmpfile);
	String tmppath = Environment.get(Environment.TmpDir) +
	    Environment.get("file.separator") + tmpfile;
	Debug.message("www",
	    "WebBrowser.writeAndGenerateURL: writing to file: " + tmppath);

	// write the info to the full path name
	try {
	    FileOutputStream fs = new FileOutputStream(tmppath);
	    PrintWriter out = new PrintWriter(fs);
	    out.println(text);
	    out.close();			// close the streams
	} catch (IOException e) {
	    System.err.println("WebBrowser.writeAndGenerateURL: " + e);
	    postErrorMessage("Cannot write to temp file:" +
		    Environment.get("line.separator") +
		    "\"" + tmppath + "\"");
	    return null;
	}

	// construct the URL
	String url = "file://" + tmppath;

	// remember the file and return the url
	tmpfiles.addElement(tmppath);
	return url;	// http://ipswich.bbn.com/openmap/info/tmp-123456.html
    }

    /**
     * Points a web browser that's already running where
     * to go next.
     * @param url URL to go
     */
    protected void sendTo(String url) {
	//Should work for Unix or Windows.

	String cmd;
	String arch = Environment.get("os.arch");

	if (Environment.isApplet()) {
	  try {
	      java.applet.Applet applet = Environment.getApplet();
	      java.applet.AppletContext ac = applet.getAppletContext();
	      ac.showDocument(new URL(url), "otherFrame");
	  } catch (java.net.MalformedURLException e) {
	      System.err.println("WebBrowser.sendTo: " + e);
	      postErrorMessage("Cannot show document: " +
		      Environment.get("line.separator") + e);
	  }
	  return;
	}

	if (arch.equals("x86")) {
	    // Windows HACK
	    cmd = new String(Environment.get(Environment.WebBrowser) +
			     " " + url);
	}
	else {
	    // Assume Unix HACK
	    cmd = new String (Environment.get(Environment.WebBrowser) +
			      " -remote OpenURL(" + url + ")");
	}

	try {
	    Debug.message("www", "WebBrowser.sendTo: " + cmd);
	    Runtime.getRuntime().exec(cmd).waitFor();
	} catch (IOException e) {
	    System.err.println("WebBrowser.sendTo: " + e);
	    postErrorMessage("Cannot start WebBrowser: " +
		    Environment.get("line.separator") + e);
	} catch (InterruptedException f) {
	    System.err.println("WebBrowser.sendTo: interrupted");
	}
    }

    /**
     * Removes temporary files that we've generated over the lifetime
     * of the WebBrowser process.
     *
     */
    protected void removeTemporaries() {

	File fp = null;

	// remove any temporaries we've generated
	int size = tmpfiles.size();
	for (int i = 0; i < size; i++) {
	    fp = new File((String)tmpfiles.elementAt(i));
	    fp.delete();
	}

	// remove any tmp files over one day old
	//HACK unimplemented!
    }

    public void setInfoDelegator(InformationDelegator info) {
	this.info = info;
    }


    /**
     * Creates a new web browser process, or points the current
     * one to the url argument.
     * @param urlString URL
     *
     */
    public void launch (String urlString) {
	String launchCmd = null;
      
        // launch the program with the url as an argument
        if ((proc == null) && !(Environment.isApplet())) {
	    try {
		launchCmd = generateLaunchCmd(urlString);
		Debug.message("www", "WebBrowser.launch: " + launchCmd);
		proc = Runtime.getRuntime().exec(launchCmd);
	    } catch (IOException e) {
	        System.err.println("WebBrowser.launch: " + e);
		postErrorMessage("Cannot start WebBrowser: " +
			Environment.get("line.separator") + "\"" +
			launchCmd + "\"");
	    }
	}

	// send the new url to the web browser that's already running
	else {
	    sendTo(urlString);
	}
    }


    private void postErrorMessage(String message) {
	info.requestMessage(new InfoDisplayEvent(this, message));
    }

    /**
     * Writes out temporary text file, and creates a new web browser process
     * or points the current one at the file.
     * @param text String
     *
     */
    public void writeAndLaunch (String text) {
	String cmd = null;

	// launch the program with the url as an argument
	if ((proc == null) && !(Environment.isApplet())) {
	    try {
		cmd = generateLaunchCmd(writeFileAndGenerateURL(text));
		proc = Runtime.getRuntime().exec(cmd);
	    } catch (IOException e) {
		System.err.println("WebBrowser.writeAndLaunch: " + e);
		postErrorMessage("Cannot start WebBrowser: " +
			Environment.get("line.separator") +
			"\"" + cmd + "\"");
	    }
	}

	// send the new url to the web browser that's already running
	else sendTo(writeFileAndGenerateURL(text));
    }

    /**
     * Calls the Process function of the same name to determine if the
     * process has finished, and what its exit value was.
     * <p>
     * If it is finished, then it removes the temporary files and
     * nullifies itself.
     */
    public void exitValue() {
	if (proc == null)
	    return;

	try {
	    proc.exitValue();
	    Debug.message("www", "WebBrowser.exitValue: WebBrowser died");
	    removeTemporaries();	// remove temporary files
	    proc = null;		// go down
	} catch (IllegalStateException e) {
	} catch (IllegalThreadStateException f) {
	}
    }
}

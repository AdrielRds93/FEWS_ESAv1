/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998-2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/util/PaletteHelper.java,v $
 * $Revision: 1.13 $
 * $Date: 2000/07/13 21:19:19 $
 * $Author: dietrick $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.util;


/*  AWT & Schwing  */
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.*;

import com.bbn.openmap.Layer;


/**
 * Helps create palette GUI widgets.
 * HACK: need to move helpful/generic code out of CSpecPalette into here.
 */
public class PaletteHelper {


    /**
     * This class has only static methods, so there isn't any need to 
     * instantiate an object.
     */
    private PaletteHelper() {}


    /**
     * Create a panel containing a checkbox.
     * @param boxlabel the string to use for the box title
     * @param buttons the list of button names
     * @param checked the initial state of each checkbox item
     * @param al the actionlistener to invoke for a button.  the actioncommand
     * is set to a string containing the integer index of the button.
     * @return the JPanel the the buttons are placed in
     * @see javax.swing.AbstractButton#setActionCommand(String)
     * @see javax.swing.JCheckBox
     */
    public static JPanel createCheckbox(
	    String boxlabel,
	    String[] buttons,
	    boolean[] checked,
	    ActionListener al
	    )
    {
	JPanel jp = createPaletteJPanel(boxlabel);
	for (int j = 0; j < buttons.length; j++) {
	    JCheckBox jcb = new JCheckBox(buttons[j]);
	    jcb.setActionCommand(Integer.toString(j));//index of checked
	    if (al != null)
		jcb.addActionListener(al);
	    jcb.setSelected(checked[j]);
	    jp.add(jcb);
	}
	return jp;
    }

    /**
     * Create a panel containing a radiobox.
     * @param boxlabel the string to use for the box title
     * @param buttons the list of button names
     * @param initiallySelected the index of the initially selected button.
     * -1 for no button initially selected.
     * @param al the actionlistener to invoke for a button.  the actioncommand
     * is set to a string containing the integer index of the button.
     * @return the JPanel the the buttons are placed in
     * @see javax.swing.AbstractButton#setActionCommand(String)
     * @see javax.swing.JRadioButton
     * @see javax.swing.ButtonGroup
     */
    public static JPanel createRadiobox(String boxlabel,
					String[] buttons,
					int initiallySelected,
					ActionListener al
					) {
	JPanel jp = createPaletteJPanel(boxlabel);

	ButtonGroup buttongroup = new ButtonGroup();

	for (int j = 0; j < buttons.length; j++) {
	    JRadioButton jrb = new JRadioButton(buttons[j]);
	    jrb.setActionCommand(""+j);//index in list
	    jp.add(jrb);
	    buttongroup.add(jrb); 
	    if (al != null) {
		jrb.addActionListener(al);
	    }
	    if (j == initiallySelected) {
		jrb.setSelected(true);
	    } else {
		jrb.setSelected(false);
	    }
	}
	return jp;
    }

    /**
     * Create a panel that does horizontal layout
     * @param title the title of the panel (null allowed)
     * @return the panel that got created
     */
    public static JPanel createHorizontalPanel (String title) {
	JPanel panel = new JPanel();
//	panel.setLayout(new BoxLayout(panel, BoxLayout.X_AXIS));
	panel.setLayout(new GridLayout(1, 0));
	if (title != null) {
	    panel.setBorder(
		    BorderFactory.createTitledBorder(
			BorderFactory.createEtchedBorder(), title));
	} else {
	    panel.setBorder(
			BorderFactory.createEtchedBorder());
	}
	return panel;
    }

    /**
     * Create a panel that does vertical layout
     * @param title the title of the panel (null allowed)
     * @return the panel that got created
     */
    public static JPanel createVerticalPanel (String title) {
	JPanel panel = new JPanel();
//	panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
	panel.setLayout(new GridLayout(0, 1));
	if (title != null) {
	    panel.setBorder(
		    BorderFactory.createTitledBorder(
			BorderFactory.createEtchedBorder(), title));
	} else {
	    panel.setBorder(
			BorderFactory.createEtchedBorder());
	}
	return panel;
    }


    /**
     * Create a panel with a border and title
     * @param title the title of the panel (null allowed)
     * @return the panel that got created
     */
    public static JPanel createPaletteJPanel(String title) {
	JPanel panel = new JPanel();

	if (title != null) {
	    panel.setBorder(
		    BorderFactory.createTitledBorder(
			BorderFactory.createEtchedBorder(), title));
	} else {
	    panel.setBorder(
			BorderFactory.createEtchedBorder());
	}

	panel.setLayout(new GridLayout(0, 1));
	return panel;
    }


    /**
     * Create and add a text entry field to a JComponent.
     * @param title the title of the frame
     * @param entry the name of the entry field
     * @param parent the component to add ourselves to
     * @return the text field
     */
    public static JTextField createTextEntry (String title,
					      String entry,
					      JComponent parent) {

	JPanel pal = PaletteHelper.createHorizontalPanel(null);
	JLabel label = new JLabel(title);
	label.setHorizontalTextPosition(label.RIGHT);
	JTextField tf = new JTextField(entry);
	label.setLabelFor(tf);
	pal.add(label); pal.add(tf);
	parent.add(pal);
	return tf;
    }


    /**
     * Create and add a text area to a JComponent.
     * @param title the title of the frame
     * @param entry the name of the entry field
     * @param parent the component to add ourselves to
     * @param rows the number of rows
     * @param cols the number of columns
     * @return the text area
     */
    public static JTextArea createTextArea (
	    String title, String entry, JComponent parent, int rows, int cols)
    {
	JPanel pal = PaletteHelper.createHorizontalPanel(null);
	JLabel label = new JLabel(title);
	label.setHorizontalTextPosition(label.RIGHT);
	JTextArea ta = new JTextArea(entry, rows, cols);
	JScrollPane jsp = new JScrollPane(ta);
	label.setLabelFor(jsp);
	pal.add(label); pal.add(jsp);
	parent.add(pal);
	return ta;
    }

    /**
     * Get a layer's associated palette as an internal window
     * @param layer the layer to get the palette for
     * @param ifl the listener to associate with the palette
     * @return the frame that the palette is in
     */
    public static JInternalFrame getPaletteInternalWindow (Layer layer, 
							   InternalFrameListener ifl) {
	
	JInternalFrame paletteWindow;

	// create the palette's scroll pane
	Component pal = layer.getGUI();
	if (pal == null)
	    pal = new JLabel("No Palette");
	JScrollPane scrollPane = new JScrollPane(
	    pal,
	    ScrollPaneConstants.
	    VERTICAL_SCROLLBAR_AS_NEEDED,
	    ScrollPaneConstants.
	    HORIZONTAL_SCROLLBAR_AS_NEEDED);
	scrollPane.setAlignmentX(Component.LEFT_ALIGNMENT);
	scrollPane.setAlignmentY(Component.TOP_ALIGNMENT);
	
	
	// create the palette internal window
	paletteWindow = new JInternalFrame(
	    layer.getName() + " Palette",
	    true,		//resizable
	    true,		//closable
	    false,		//maximizable
	    true		//iconifiable
	    );

	// add a window listener that destroys the palette when
	// the window is closed
	paletteWindow.addInternalFrameListener(ifl);
	
	paletteWindow.setContentPane(scrollPane);
	paletteWindow.setOpaque(true);
	paletteWindow.pack();//layout all the components
	
	return paletteWindow;
    }
    
    /**
     * Get a layer's associated palette as a top-level window
     * @param layer the layer to get the palette for
     * @param cl the listener to associate with the palette
     * @return the frame that the palette is in
     */
    public static JFrame getPaletteWindow (Layer layer,
					   ComponentListener cl) {
	
	JScrollPane scrollPane = new JScrollPane(
	    getLayerGUIComponent(layer),
	    ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
	    ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
	scrollPane.setAlignmentX(Component.LEFT_ALIGNMENT);
	scrollPane.setAlignmentY(Component.TOP_ALIGNMENT);
	
	// create the palette internal window
	JFrame paletteWindow = new JFrame(layer.getName() + " Palette");
	
	paletteWindow.addComponentListener(cl);
	paletteWindow.setContentPane(scrollPane);
	paletteWindow.pack();//layout all the components
	
	return paletteWindow;
    }

    /**
     * Get a Component that represents a layer's GUI.
     * @param layer the layer to get the palette for
     * @return the Component that represents the GUI for the layer.
     */
    public static Component getLayerGUIComponent (Layer layer) {
	
	Component pal = layer.getGUI();
	if (pal == null)
	    pal = new JLabel("No Palette");


	JPanel p = new JPanel();
	p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
	p.setAlignmentX(Component.LEFT_ALIGNMENT);
	p.setAlignmentY(Component.BOTTOM_ALIGNMENT);
	p.add(pal);

	return p;
    }
}

/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/util/BinaryFile.java,v $
 * $Revision: 1.4 $
 * $Date: 2000/08/01 16:42:03 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.util;

import java.io.*;
import java.util.Vector;
import com.bbn.openmap.MoreMath;

/**
 * This class wraps a java.io.RandomAccessFile to allow us to choose
 * the byte-order of the underlying file.  It has a user-settable
 * byte-ordering, which is then used to properly implement the various
 * multibyte reading members.
 * @see java.io.RandomAccessFile */
public class BinaryFile {
    private static int openCount = 0;
    private static int classCount = 0;
    
    /** The underlying file input */
    private RandomAccessFile inputFile = null;

    /** The byte order of the underlying file. (<code>true</code> ==
     * MSB-First == big-endian) */
    protected boolean MSBFirst = false;

    /**
     * Constructs a new BinaryFile with the specified file as the input.  The 
     * default byte-order is LSB first.  reads start at the first byte of
     * the file.
     *
     * @param f the file to be opened for reading
     * @exception IOException pass-through errors from opening a
     * RandomAccessFile with f
     * @see java.io.RandomAccessFile
     */
    public BinaryFile(File f) throws IOException {
	classCount++;
	try {
	    inputFile = new RandomAccessFile(f, "r");
	} catch (FileNotFoundException fnfe) {
	    throw fnfe;
	} catch (IOException i) {
	    if (f.canRead()) {
		closeClosable();
		inputFile = new RandomAccessFile(f, "r");
	    } else {
		throw i;
	    }
	}	
	
	openCount++; 
	//System.out.println("open " + f + " oc: " + openCount + " cc: " + classCount);
    }

    /**
     * Constructs a new BinaryFile with the specified file as the input.  The 
     * byte-order is undefined.  reads start at the first byte of the file.
     *
     * @param name the name of the file to be opened for reading
     * @exception IOException pass-through errors from opening a 
     * RandomAccessFile with f
     */
    public BinaryFile(String name) throws IOException {
	this(new File(name));
    }

    /**
     * Set the byte-ordering used to read shorts, int, etc.
     *
     * @param	msbfirst	<code>true</code> = MSB first,
     * <code>false</code> = LSB first
     */
    public void byteOrder(boolean msbfirst) {
	MSBFirst = msbfirst;
    }

    /** Accessor for the byte ordering used to read multibyte types.
     * @return byte ordering */
    public boolean byteOrder() {
	return MSBFirst;
    }

    /** Skip over n bytes in the input file
     * @param n the number of bytes to skip
     * @return the actual number of bytes skipped.  annoying, isn't it?
     * @exception IOException Any IO errors that occur in skipping bytes
     * in the underlying file
     */
    public int skipBytes(int n) throws IOException {
	return inputFile.skipBytes(n);
    }

    /** Get the index of the next character to be read
     * @return the index
     * @exception IOException Any IO errors that occur in accessing
     * the underlying file
     */
    public long getFilePointer() throws IOException {
	return inputFile.getFilePointer();
    }

    /** Set the index of the next character to be read
     *
     * @param pos the position to seek to
     * @exception IOException Any IO Errors that occur in seeking the
     * underlying file.
     */
    public void seek(long pos) throws IOException {
	inputFile.seek(pos);
    }

    /** Retrieve the length of the file being accessed
     * @return the length of the file (counted in bytes)
     * @exception IOException Any IO errors that occur in accessing the
     * underlying file.
     */
    public long length() throws IOException {
	return inputFile.length();
    }

    /** Return how many bytes left to be read in the file.
     * @return the number of bytes remaining to be read (counted in bytes)
     * @exception IOException Any IO errors encountered in accessing the file
     */
    public long available() throws IOException {
	return(length() - getFilePointer());
    }

    /** closes the underlying file
     * @exception IOException Any IO errors encountered in accessing the file
     */
    public void close() throws IOException {
	if (inputFile != null) {
	    //System.out.println("close");
	    try {inputFile.close();} catch (Exception e) {e.printStackTrace();}
	    inputFile = null;
	    openCount--;
	}
    }

    /** Read from the file
     * @return one byte from the file.  -1 for EOF
     * @exception IOException Any IO errors encountered in reading from the file
     */
    public int read() throws IOException {
	return inputFile.read();
    }

    /** Read from the file
     * @param b The byte array to read into
     * @param off the first array position to read into
     * @param len the number of bytes to read
     * @return the number of bytes read
     * @exception IOException Any IO errors encountered in reading from the file
     */
    public int read(byte b[], int off, int len) throws IOException {
	return inputFile.read(b, off, len);
    }

    /** Read from the file
     * @param b the byte array to read into.  Equivelent to 
     * <code>read(b, 0, b.length)</code>
     * @return the number of bytes read
     * @exception IOException Any IO errors encountered in reading from the file
     * @see java.io.RandomAccessFile#read(byte[])
     */
    public int read(byte b[]) throws IOException {
	return inputFile.read(b);
    }

    /** Read from the file
     * @param howmany the number of bytes to read
     * @param allowless if we can return fewer bytes than requested
     * @return the array of bytes read.
     * @exception FormatException Any IO Exceptions, plus an end-of-file
     * encountered after reading some, but now enough, bytes when allowless
     * was <code>false</code>
     * @exception EOFException Encountered an end-of-file while allowless 
     * was <code>false</code>, but NO bytes had been read.
     */
    public byte[] readBytes(int howmany, boolean allowless) throws EOFException, FormatException {
	byte foo[] = new byte[howmany];
	int gotsofar = 0;
	try {
	    while (gotsofar < howmany) {
		int err = inputFile.read(foo, gotsofar, howmany - gotsofar);
		if (err == -1) {
		    if (allowless) {
			//return a smaller array, so the caller can tell how much
			//they really got
			byte retval[] = new byte[gotsofar];
			System.arraycopy(foo, 0, retval, 0, gotsofar);
			return retval;
		    } else { //some kind of failure...
			if (gotsofar > 0) {
			    throw new FormatException("EOF while reading data");
			} else {
			    throw new EOFException();
			}
		    }
		}
		gotsofar += err;
	    }
	} catch (IOException i) {
	    throw new FormatException("readBytes IOException: " + i.getMessage());
	}
	return foo;
    }

    /** Reads and returns a single byte, cast to a char
     * @return the byte read from the file, cast to a char
     * @exception EOFException the end-of-file has been reached, so no chars
     * where available
     * @exception FormatException a rethrown IOException
     */
    public char readChar() throws EOFException, FormatException {
	try {
	    int retv = inputFile.read();
	    if (retv == -1) {
		throw new EOFException("Error in ReadChar, EOF reached");
	    }
	    return (char)retv;
	} catch (IOException i) {
	    throw new FormatException("readChar IOException: " + i.getMessage());
	}
    }

    /**
     * Reads and returns a short
     * @return the 2 bytes merged into a short, according to the current byte
     * ordering
     * @exception EOFException there were less than 2 bytes left in the file
     * @exception FormatException rethrow of IOExceptions encountered while
     * reading the bytes for the short
     * @see #read(byte[])
     */
    public short readShort() throws EOFException, FormatException {
	//MSBFirst must be set when we are called
	return MoreMath.BuildShort(readBytes(2, false), MSBFirst);
    }

    /**
     * Reads and returns a long
     * @return the 4 bytes merged into a long, according to the current
     * byte ordering
     * @exception EOFException there were less than 4 bytes left in the file
     * @exception FormatException rethrow of IOExceptions encountered while
     * reading the bytes for the integer
     * @see #read(byte[])
     */
    public int readInteger() throws EOFException, FormatException {
	//MSBFirst must be set when we are called
	return MoreMath.BuildInteger(readBytes(4, false), MSBFirst);
    }

    public void readIntegerArray(int vec[], int offset, int len)
	throws EOFException, FormatException {
	for (int i = 0; i < len; i++) {
	    vec[offset++] = readInteger();
	}
    }

    /**
     * Reads and returns a long
     * @return the 8 bytes merged into a long, according to the current byte
     * ordering
     * @exception EOFException there were less than 8 bytes left in the file
     * @exception FormatException rethrow of IOExceptions encountered while 
     * reading the bytes for the long
     * @see #read(byte[])
     */
    public long readLong() throws EOFException, FormatException {
	return MoreMath.BuildLong(readBytes(8, false), MSBFirst);
    }

    /**
     * Reads and returns a float
     * @return the 4 bytes merged into a float, according to the current
     * byte ordering
     * @exception EOFException there were less than 4 bytes left in the file
     * @exception FormatException rethrow of IOExceptions encountered while
     * reading the bytes for the float
     * @see #read(byte[])
     */
    public float readFloat() throws EOFException, FormatException {
	return Float.intBitsToFloat(readInteger());
    }

    public void readFloatArray(float vec[], int offset, int len)
	throws EOFException, FormatException {
	for (int i = 0; i < len; i++) {
	    vec[offset++] = readFloat();
	}
    }

    /**
     * Reads and returns a double
     * @return the 8 bytes merged into a double, according to the current byte ordering
     * @exception EOFException there were less than 8 bytes left in the file
     * @exception FormatException rethrow of IOExceptions encountered while reading the bytes for the short
     * @see #read(byte[])
     */
    public double readDouble() throws EOFException, FormatException {
	return Double.longBitsToDouble(readLong());
    }

    /**
     * Reads <code>length</code> bytes and returns a string composed of the
     * bytes cast to chars
     * @param length the number of bytes to read into the string
     * @return the composed string
     * @exception EOFException there were less than <code>length</code>
     * bytes left in the file
     * @exception FormatException rethrow of IOExceptions encountered while
     * reading the bytes for the short
     */
    public String readFixedLengthString(int length) throws EOFException, FormatException {
	byte foo[] = readBytes(length, false);
	return new String(foo, 0, length);
    }

    /**
     * Read a bytes and throw an InvalidCharException if it doesn't match
     * <code>expected</code>
     * @param expected what the next char is claimed to be
     * @exception EOFException there wasn't a byte, so we can't check for a match
     * @exception InvalidCharException throws when the character read doesn't
     * match <code>expected</code>  The .c member of the thrown exception is
     * the actual char read
     * @exception FormatException some other error from reading the file
     */
    public void assertChar(char expected) throws EOFException, FormatException {
	char c = readChar();
	if (c != expected) {
	    throw new InvalidCharException("AssertChar: expected " + expected + 
					   " got " + c, c);
	}
    }

    /**
     * Reads a string until the specified delimiter or EOF is encountered
     *
     * @param delim the end-of-string delimiter
     * @return the string that was read
     * @exception FormatException rethrow of IOExceptions from the read methods
     */
    public String readToDelimiter(char delim) throws FormatException {
	StringBuffer buildretval = new StringBuffer();
	char tmp;
	try {
	    while ((tmp = readChar()) != delim)
		buildretval.append(tmp);
	} catch (EOFException e) {
	    //allowable
	}
	return buildretval.toString();
    }

    /**
     * Makes sure that the file has been closed.
     * @exception Throwable what it throws.
     */
    public void finalize() throws Throwable {
	close();
	classCount--;
    }

    /**
     * Maintains a list of objects that can be closed so that
     * other files can be opened.
     */
    private static Vector closableList = new Vector();
    
    /** 
     * Add an object that can be closed if needed.  Duplicates are allowed.
     * @param it the object that can be closed
     */
    public static synchronized void addClosable(Closable it) {
	closableList.addElement(it);
    }

    /**
     * Remove an object from the closable list.
     * @param it the object to remove
     */
    public static synchronized void removeClosable(Closable it) {
	for (int i = 0; i < closableList.size(); i++)
	  if (closableList.elementAt(i) == it) {
		closableList.removeElementAt(i);
		i--;  //in case its in the list more than once
	  }
    }

    public static synchronized void closeClosable() {
	System.out.println("closeClosable " + closableList.size());
	for (int i = 0; i < closableList.size(); i++) {
	    Closable c = (Closable)closableList.elementAt(i);
	    if (!c.close(false)) {
		closableList.removeElementAt(i);
		i--;
	    }
	}
    }
}

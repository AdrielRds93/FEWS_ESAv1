/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/util/AssertionException.java,v $
 * $Revision: 1.5 $
 * $Date: 2000/05/08 14:23:28 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */


package com.bbn.openmap.util;

/**
 * Signals that an assertion has failed.
 *
 * @author unascribed
 * @version $Revision: 1.5 $, $Date: 2000/05/08 14:23:28 $
 * @see Assert
 */
public class AssertionException extends RuntimeException {

    /**
     * Constructs a default <code>AssertionException</code>.
     */
    public AssertionException () {
	this("");
    }

    /**
     * Constructs an <code>AssertionException</code> with the
     * specified detail message.
     *
     * @param s the detail message
     */
    public AssertionException (String s) {
	super(s);
    }
}

/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/util/InvalidCharException.java,v $
 * $Revision: 1.3 $
 * $Date: 2000/05/08 14:23:29 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.util;

/** An invalid character occured on in input stream. */
public class InvalidCharException extends FormatException {
    /** the invalid character that we found */
    public char c;

    /**
     * Construct an object with no detail message
     * @param val the character encountered
     */
    public InvalidCharException(char val) {
	super();
	c = val;
    }
    /**
     * Construct an object with a detail message
     * @param s the detail message
     * @param val the character encountered
     */
    public InvalidCharException(String s, char val) {
	super(s);
	c = val;
    }
}

package com.bbn.openmap.util;

/**
   Use this class to catch a checked exception and throw it as an uncheck one.
   This way, people will find out about it, but don't have to explicitly 
   handle it.
 **/
public class HandleError extends RuntimeException {
  public HandleError(Exception e) { super(e.toString()); }
  public HandleError(String s) { super(s); }
}

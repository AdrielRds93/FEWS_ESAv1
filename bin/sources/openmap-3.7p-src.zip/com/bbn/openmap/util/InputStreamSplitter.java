/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/util/InputStreamSplitter.java,v $
 * $Revision: 1.4 $
 * $Date: 2000/05/08 14:23:29 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.util;

import java.io.*;

/**
 * The <code>InputStreamSplitter</code> is a
 * <code>FilterInputStream</code> that reads and returns data from an
 * input stream, while also sending the data to an output stream.
 * Thus, the <code>InputStreamSplitter</code> can provide a handy
 * sniffing/logging mechanism.  In addition, the output stream could
 * be coupled with a <code>PipedInputStream</code> to create two input
 * sources out of a single source.
 */
public class InputStreamSplitter extends FilterInputStream {

    /**
     * The OutputStream to route the data to.
     */
    protected OutputStream out;

    /**
     * Creates an <code>InputStreamSplitter</code>.
     * @param   in   the underlying input stream
     * @param   out  the output stream
     */
    public InputStreamSplitter(InputStream in, OutputStream out) {
	super(in);
	this.out = out;
    }

    /**
     * Reads the next byte of data from the input stream and writes it
     * to the output stream. The value byte is returned as an
     * <code>int</code> in the range <code>0</code> to
     * <code>255</code>. If no byte is available because the end of
     * the stream has been reached, the value <code>-1</code> is
     * returned. This method blocks until input data is available, the
     * end of the stream is detected, or an exception is thrown. 
     * @return     the next byte of data, or <code>-1</code> if the end of the
     *             stream is reached.
     * @exception  IOException  if an I/O error occurs.
     */
    public int read() throws IOException {
	final int i = super.read();
	if (i >= 0)
	    out.write(i);
	return i;
    }

    /**
     * Reads up to <code>b.length</code> bytes of data from this input
     * stream into an array of bytes, and writes those bytes to the
     * output stream. This method blocks until some input is
     * available. 
     * @param      b   the buffer into which the data is read.
     * @return     the total number of bytes read into the buffer, or
     *             <code>-1</code> if there is no more data because the end of
     *             the stream has been reached.
     * @exception  IOException  if an I/O error occurs.
     * @see        #read(byte[], int, int)
     */
    public int read(byte b[]) throws IOException {
	final int i = super.read(b);
	if (i >= 0)
	    out.write(b, 0, i);
	return i;
    }

    /**
     * Reads up to <code>len</code> bytes of data from this input
     * stream into an array of bytes, and writes those bytes to the
     * output stream. This method blocks until some input is
     * available. 
     * @param      b     the buffer into which the data is read.
     * @param      off   the start offset of the data.
     * @param      len   the maximum number of bytes read.
     * @return     the total number of bytes read into the buffer, or
     *             <code>-1</code> if there is no more data because the end of
     *             the stream has been reached.
     * @exception  IOException  if an I/O error occurs.
     */
    public int read(byte b[], int off, int len) throws IOException {
	final int i = super.read(b, off, len);
	if (i >= 0)
	    out.write(b, off, i);
	return i;
    }

    /**
     * Closes the input and output streams and releases any system
     * resources associated with those streams. 
     * @exception  IOException  if an I/O error occurs.
     */
    public void close() throws IOException {
	super.close();
	out.close();
    }

    /**
     * Flushes the output stream.
     * @exception  IOException  if an I/O error occurs.
     */
    public void flush() throws IOException {
	out.flush();
    }
}

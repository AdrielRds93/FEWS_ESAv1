/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/util/Taskable.java,v $
 * $Revision: 1.2 $
 * $Date: 2000/05/08 14:23:30 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.util;

import java.awt.event.ActionListener;

/**
 * Taskables are ActionListeners that respond to events from Timers.
 * If a Taskable has been added to a Timer's queue, it will receive
 * <code>actionPerformed()</code> notifications each time the timer
 * expires.
 * <p>
 * Some OpenMap Layers are Taskables.  These layers expect to refresh
 * their graphics at a certain rate.
 * @see javax.swing.Timer
 */
public interface Taskable extends ActionListener {

    /**
     * Get the sleep hint in milliseconds.
     * The Taskable implementation should determine the sleep (delay)
     * interval between invocations of its
     * <code>actionPerformed()</code>.
     * <p>
     * NOTE: this is only a hint for the timer.  It's the Taskable's
     * responsibility to determine if too little or too much time has
     * elapsed between invocations of <code>actionPerformed()</code>.
     * @return int milliseconds of sleep interval
     */
    public int getSleepHint ();
}

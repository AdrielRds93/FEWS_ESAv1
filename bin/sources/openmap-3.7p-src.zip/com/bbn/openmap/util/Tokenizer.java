/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/util/Tokenizer.java,v $
 * $Revision: 1.3 $
 * $Date: 2000/05/08 14:23:30 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.util;

/**
 * Tokenizer provides some tools useful for defining tokenizers.
 * You get 1 character pushback.
 */
public class Tokenizer extends java.io.PushbackReader{
    StringBuffer b;
    int lineCount = 0;
  
    public Tokenizer(java.io.Reader in){
	super(in,1);
	this.b = new StringBuffer(80); }
    
    // KRA 25Oct98: class Match requires access to NEWLINE and EOF, YOW!
    static Object NEWLINE = new Object() {
	public String toString() { 
	    return "<newline>"; 
	}
    };
    
    static Object EOF = new Object() {
	public String toString() {return "<EOF>"; 
	}
    };
    
    public boolean isNewline(Object o) { return o == NEWLINE; }
    public boolean isEOF(Object o) { return o == EOF; }
    public boolean isAny(int c) { return c != -1; }
    public boolean isAlpha(int c) {
	return c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z'; }
    public boolean isDigit(int c) { return c >= '0' && c <= '9'; }
    public boolean isAlphanumeric(int c) {return isAlpha(c) || isDigit(c); }
    
    public void bpush(int c) {
	this.b.append((char) c); }	// Yow!
    
    public String bclear() {
	// YOW! Carefully copy string so it won't have 80 charaters under it.
	String result = this.b.toString();
	this.b.setLength(0); 
	int L = result.length();
	char[] chars = new char[L];
	result.getChars(0, L, chars, 0);
	return new String(chars); 
    }
    
    /** 
     * Read the next character.  Convert alternative 
     * line breaks to '\n'.  Thank you Bill Gates! 
     */
    public int next() {
	int c;
	try { 
	    c = this.read(); 
	    if (c == '\r') {
		int c1 = this.read();
		if (c1 == '\n'){
		    c = '\n'; 
		} else {
		    this.unread(c1);
		    c = '\n'; 
		}
	    } 
	    if (c == '\n') this.lineCount = this.lineCount + 1;
	    //_ System.out.print((char) c + "_");
	    return c;
	} catch (java.io.IOException e) {
	    throw new HandleError(e); 
	}
    }
    
    public void putback(int c) {
	//_ System.out.println("putback: " + (char) c + "'");
	try {
	    if (c != -1) this.unread(c);
	} catch (java.io.IOException e) {
	    throw new HandleError(e);
	}
    }
    
    public Object error(String s) {
	throw new HandleError("at line " + this.lineCount + ": " + s); 
    }
    
}

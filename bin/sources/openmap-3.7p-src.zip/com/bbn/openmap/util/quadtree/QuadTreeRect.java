/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/util/quadtree/QuadTreeRect.java,v $
 * $Revision: 1.6 $
 * $Date: 2000/08/03 16:31:11 $
 * $Author: dietrick $
 * 
 * **********************************************************************
 */


package com.bbn.openmap.util.quadtree;

import java.util.*;
import java.io.Serializable;

public class QuadTreeRect implements Serializable {

    static final long serialVersionUID = -5585535433679092922L;

    public double north;
    public double south;
    public double west;
    public double east;
    
    public QuadTreeRect (double n, double w, double s, double e){
	north = n;
	west = w;
	south = s;
	east = e;
    }
    
    public boolean within(QuadTreeRect rect){
	return within(rect.north, rect.west, rect.south, rect.east);
    }

    public boolean within(double n, double w, double s, double e){

	// We check for equality for the northern and western border
	// because the rectangles, out of convention for this package,
	// will contain points that exactly match those borders.

	// Thanks to Paul Tomblin for pointing out that the old code
	// wasn't entirely coorect, and supplied the better algorithm.

        if (s >= north)
                return false;
        if (n < south)
                return false;
        if (w > east)
                return false;
        if (e <= west)
                return false;
        return true;
    }

    public boolean pointWithinBounds(double lat, double lon){
	if (lon >= west && lon < east && 
	    lat <= north && lat > south){
	    return true;
	} else return false;
    }
    
    /** A utility method to figure out the closest distance of a
     * border to a point.
     * @param lat up-down location in QuadTree Grid (latitude, y)
     * @param lon left-right location in QuadTree Grid (longitude, x)
     * @param closest distance to the point.
     * */
    public double borderDistance(double lat, double lon){
	double nsdistance = Math.min((Math.abs(lat - north)),
				     (Math.abs(lat - south)));
	double ewdistance = Math.min((Math.abs(lon - east)),
				     (Math.abs(lon - west)));
	double distance = Math.sqrt(Math.pow(nsdistance, 2.0) - 
				    Math.pow(ewdistance, 2.0));
	return distance;
    }

}

/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/util/quadtree/QuadTreeLeaf.java,v $
 * $Revision: 1.4 $
 * $Date: 2000/08/03 16:31:10 $
 * $Author: dietrick $
 * 
 * **********************************************************************
 */


package com.bbn.openmap.util.quadtree;

import java.util.*;
import java.io.Serializable;

public class QuadTreeLeaf implements Serializable{

    static final long serialVersionUID = 7885745536157252519L;

    public double latitude;
    public double longitude;
    public Object object;

    public QuadTreeLeaf (double lat, double lon, Object obj){
	latitude = lat;
	longitude = lon;
	object = obj;
    }
}

/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/util/Assert.java,v $
 * $Revision: 1.6 $
 * $Date: 2000/05/08 14:23:28 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */


package com.bbn.openmap.util;

/**
 * Assert provides an assertion facility in Java comparable to the
 * assert macros in C/C++.  This class was taken from a FAQ on dejanews,
 * and is of unknown origin.  Here is the original entry in the FAQ:
 * <p>
 * <pre>
 * 11.6 How can I write C/C++ style assertions in Java?
 *
 * A.  The two classes shown below provide an assertion facility in Java.
 *     Set Assert.enabled to true to enable the assertions, and to false to
 *     disable assertions in production code. The AssertionException is not
 *     meant to be caught--instead, let it print a trace.
 *
 *     With a good optimizing compiler there will be no run time overhead
 *     for many uses of these assertions when Assert.enabled is set to false.
 *     However, if the condition in the assertion may have side effects, the
 *     condition code cannot be optimized away. For example, in the assertion
 * 	<code>Assert.assert(size() <= maxSize, "Maximum size exceeded");</code>
 *     the call to size() cannot be optimized away unless the compiler can
 *     see that the call has no side effects. C and C++ use the preprocessor
 *     to guarantee that assertions will never cause overhead in production
 *     code. Without a preprocessor, it seems the best we can do in Java is
 *     to write
 *	<code>Assert.assert(Assert.enabled && size() <= maxSize, "Too big");</code>
 *     In this case, when Assert.enabled is false, the method call can always
 *     be optimized away, even if it has side effects.
 * </pre>
 * </p>
 *
 * @author unascribed
 * @author Maintained by: Tom Mitchell (tmitchell@bbn.com)
 * @version $Revision: 1.6 $, $Date: 2000/05/08 14:23:28 $
 */
public final class Assert {

    /**
     * Don't allow construction, all methods are static.
     */
    private Assert () {}

    /**
     * Globally enable or disable assertions.
     */
    public static final boolean enabled = true;


    /**
     * Assert a condition to be true.  If it is not true,
     * an exception is thrown.
     *
     * @param b An expression expected to be true
     * @param s Exception string if expression is false
     * @exception AssertionException if expression is false
     */
    public static final void assertTrue(boolean b, String s) {
	if (enabled && !b)
	    throw new AssertionException(s);
    }


    /**
     * Assert a condition to be true.  If it is not true,
     * an exception is thrown.
     *
     * @param b An expression expected to be true
     * @param s Exception string if expression is false
     * @exception AssertionException if expression is false
     */
    public static final void assertTrue(boolean b) {
	assertTrue(b, "");
    }
}

/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/util/FormatException.java,v $
 * $Revision: 1.2 $
 * $Date: 2000/05/08 14:23:29 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.util;
/**
 * This class is used for exceptions that result from some format errors
 * of the VPF data */
public class FormatException extends Exception {
    /** Construct a FormatException without a detail message */
    public FormatException() { super(); }
    /** Construct a FormatException with a detail message
     * @param s the detail message */
    public FormatException(String s) { super(s); }
}

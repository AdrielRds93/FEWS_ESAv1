/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/event/InfoDisplayListener.java,v $
 * $Revision: 1.5 $
 * $Date: 2000/05/08 14:22:01 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.event;


/**
 * Listens for requests to display information.
 */
public interface InfoDisplayListener extends java.util.EventListener {

    /**
     * Request to have a URL displayed in a Browser.
     * @param event InfoDisplayEvent
     */
    public void requestURL (InfoDisplayEvent event);

    /** 
     * Request to have a message displayed in a dialog window.
     * @param event InfoDisplayEvent
     */
    public void requestMessage (InfoDisplayEvent event);
    
    /** 
     * Request to have an information line displayed in an
     * application status window.
     * @param event InfoDisplayEvent
     */
    public void requestInfoLine (InfoDisplayEvent event);

    /** 
     * Request that plain text or html text be displayed in a
     * browser.
     * @param event InfoDisplayEvent
     */
    public void requestBrowserContent (InfoDisplayEvent event);

    /**
     * Request that the MapBean cursor be set to a certain type.
     * @param Cursor java.awt.Cursor to set over the MapBean.
     */
    public void requestCursor (java.awt.Cursor cursor);

}

//Title: DistanceMouseMode.
//Version: 2.0
//Copyright:
//
// THIS SOFTWARE IS PROVIDED BY THE AUTHOR "AS IS" AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR OR DSTO BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
// OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
// LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
// OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
// SUCH DAMAGE.
//
//Author: R. Wathelet
//Company: Theatre Operations Branch, Defence Science & Technology Organisation (DSTO)

package com.bbn.openmap.event;

import com.bbn.openmap.proj.GreatCircle;
import com.bbn.openmap.proj.*;
import com.bbn.openmap.MapBean;
import com.bbn.openmap.LatLonPoint;
import com.bbn.openmap.MoreMath;
import com.bbn.openmap.InformationDelegator;
import com.bbn.openmap.omGraphics.*;

import java.awt.Point;
import java.awt.Color;
import java.text.*;
import java.awt.geom.AffineTransform;
import java.awt.geom.GeneralPath;
import java.awt.Graphics2D;
import java.awt.event.*;
import java.util.Vector;

/**
 * This mouse mode draws a rubberband line and circle between each
 * mouse click as the mouse is moved and displays the cumulative
 * distance in nautical miles (nm), kilometers (km), statute miles
 * (miles) and the azimuth angle in decimal degrees from north on the
 * status bar.  Several distance segments are allowed. To erase
 * (terminate) double click the mouse.
 * <p>
 * To use this mouse mode in the OpenMap demo (in setWidgets):
 * create the mouse mode, such as <p>
 *   DistanceMouseMode distMode = new DistanceMouseMode(true, id, DistanceMouseMode.DISTANCE_ALL);
 * <p>Add the distance mouse mode to the mouse delegator
 *   md.addMouseMode(distMode);
 * <p>
 * This class can easily be extended, for example to create waypoints for objects.
 * <p>
 * NOTE: If some lines are not properly erased (because the mouse went
 * outside the map for example), just use the redraw from the menu.
 */
public class DistanceMouseMode extends AbstractMouseMode {

    /**
     * Mouse mode identifier, is "Distance".
     * This is returned on getID()
     */
    public final static transient String modeID = "Distance".intern();

    /**
     * rPoint1 is the anchor point of a line segment
     */
    public LatLonPoint rPoint1;
    /**
     * rPoint2 is the new (current) point of a line segment
     */
    public LatLonPoint rPoint2;
    /**
     * Flag, true if the mouse has already been pressed
     */
    public boolean mousePressed = false;
    /**
     * Vector to store all distance segments, first point and last point pairs
     */
    public Vector segments = new Vector();
    /**
     * Distance of the current segment
     */
    public double distance = 0;
    /**
     * The cumulative distance from the first mouse click
     */
    public double totalDistance = 0;
    /**
     * Value formater. Change this as required
     */
    public DecimalFormat df = new DecimalFormat("0.##");
    /**
     * The info delegator that will display the distance information
     */
    public InformationDelegator infoDelegator = new InformationDelegator();

    /**
     * To display distance in nautical miles
     */
    public static int DISTANCE_NM = 0;
    /**
     * To display distance in kilometers
     */
    public static int DISTANCE_KM = 1;
    /**
     * To display distance in miles
     */
    public static int DISTANCE_MILE = 2;
    /**
     * To display distance in all 3 units, nautical miles, miles and kilometers
     */
    public static int DISTANCE_ALL = 3;

    /**
     * The line type to be displayed, see OMGraphic.
     * LINETYPE_GREATCIRCLE, LINETYPE_RHUMB, LINETYPE_STRAIGHT
     * default LINETYPE_GREATCIRCLE
     */
    public static int lineType = OMGraphic.LINETYPE_GREATCIRCLE;

    /**
     * To display the rubberband circle, default true
     */
    private boolean displayCircle = true;

    // The unit type, default nm
    private int unit = 0;

    // Flag to display the azimuth angle. Default true
    boolean showAngle = true;

    // The map bean
    MapBean theMap;

    /**
     * Construct a DistanceMouseMode.
     * Default constructor.  Sets the ID to the modeID, and the
     * consume mode to true.
     * You need to setInfoDelegator, setUnits and setLineType if you use this constructor.
     */
    public DistanceMouseMode(){
	this(true);
        // if you really want to change the cursor shape
	// setModeCursor(cursor.getPredefinedCursor(cursor.CROSSHAIR_CURSOR));
    }

    /**
     * Construct a DistanceMouseMode.
     * Lets you set the consume mode. If the events are consumed,
     * then a MouseEvent is sent only to the first MapMouseListener
     * that successfully processes the event. If they are not
     * consumed, then all of the listeners get a chance to act on the event.
     * You need to setInfoDelegator, setUnits and setLineType if you use this constructor.
     * @param consumeEvents the mode setting.
     */
    public DistanceMouseMode(boolean consumeEvents){
	super(modeID, consumeEvents);
        // if you really want to change the cursor shape
	// setModeCursor(cursor.getPredefinedCursor(cursor.CROSSHAIR_CURSOR));
    }
    
    /**
     * Construct an DistanceMouseMode. For convenience for derived classes.
     * @param name the ID of the mode.
     * @param consumeEvents if true, events are propagated to
     * the first MapMouseListener that successfully processes the
     * event, if false, events are propagated to all MapMouseListeners.
     * You need to setInfoDelegator, setUnits and setLineType if you use this constructor.
     */
    public DistanceMouseMode(String name, boolean consumeEvents){
	super(name, consumeEvents);
        // if you really want to change the cursor shape
	// setModeCursor(cursor.getPredefinedCursor(cursor.CROSSHAIR_CURSOR));
    }

    /**
     * Construct a DistanceMouseMode.
     * Lets you set the consume mode. If the events are consumed,
     * then a MouseEvent is sent only to the first MapMouseListener
     * that successfully processes the event. If they are not
     * consumed, then all of the listeners get a chance to act on the event.
     * You need to the setLineType if you use this constructor.
     * @param consumeEvents the mode setting.
     * @param id the calling object's info delegator.
     * @param units the unit of distance that will be dispalyed such as
     * DISTANCE_NM, DISTANCE_KM, DISTANCE_MILE or all 3 types DISTANCE_ALL
     */
    public DistanceMouseMode(boolean consumeEvents, InformationDelegator id, int units){
	super(modeID, consumeEvents);
        // if you really want to change the cursor shape
	//  setModeCursor(cursor.getPredefinedCursor(cursor.CROSSHAIR_CURSOR));
        infoDelegator = id;
        unit = units;
    }

    /**
     * Construct a DistanceMouseMode.
     * Lets you set the consume mode. If the events are consumed,
     * then a MouseEvent is sent only to the first MapMouseListener
     * that successfully processes the event. If they are not
     * consumed, then all of the listeners get a chance to act on the event.
     * You need to the setLineType if you use this constructor.
     * @param consumeEvents the mode setting.
     * @param id the calling object's info delegator.
     * @param units the unit of distance that will be dispalyed such as
     *      DISTANCE_NM, DISTANCE_KM, DISTANCE_MILE or all 3 types DISTANCE_ALL
     * @param lType the line type that will be dispalyed such as
     *      LINETYPE_GREATCIRCLE, LINETYPE_RHUMB, LINETYPE_STRAIGHT
     */
    public DistanceMouseMode(boolean consumeEvents, InformationDelegator id,
                             int units, int lType){
	super(modeID, consumeEvents);
        // if you really want to change the cursor shape
	//  setModeCursor(cursor.getPredefinedCursor(cursor.CROSSHAIR_CURSOR));
        infoDelegator = id;
        unit = units;
        lineType = lType;
    }

    /**
     * Construct a DistanceMouseMode.
     * Lets you set the consume mode. If the events are consumed,
     * then a MouseEvent is sent only to the first MapMouseListener
     * that successfully processes the event. If they are not
     * consumed, then all of the listeners get a chance to act on the event.
     * @param consumeEvents the mode setting.
     * @param id the calling object's info delegator.
     */
    public DistanceMouseMode(boolean consumeEvents, InformationDelegator id){
	super(modeID, consumeEvents);
        // if you really want to change the cursor shape
	//  setModeCursor(cursor.getPredefinedCursor(cursor.CROSSHAIR_CURSOR));
        infoDelegator = id;
    }
    
    /**
     * Construct a DistanceMouseMode. For convenience for derived classes.
     * Lets you set the consume mode. If the events are consumed,
     * then a MouseEvent is sent only to the first MapMouseListener
     * that successfully processes the event. If they are not
     * consumed, then all of the listeners get a chance to act on the event.
     * @param name the ID of the mode.
     * @param consumeEvents the mode setting.
     * @param id the calling object's info delegator.
     */
    public DistanceMouseMode(String name, boolean consumeEvents, InformationDelegator id){
	super(name, consumeEvents);
        // if you really want to change the cursor shape
	//  setModeCursor(cursor.getPredefinedCursor(cursor.CROSSHAIR_CURSOR));
        infoDelegator = id;
    }

    /**
     * Process a mouseClicked event.
     * Erase all drawn lines and circles upon a double mouse click
     * @param e mouse event.
     */
    public void mouseClicked(MouseEvent e) {
	if (e.getSource() instanceof MapBean) {
	    // if double (or more) mouse clicked
	    if (e.getClickCount() >= 2) {
		// end of distance path
		mousePressed = false;
		// add the last point to the line segments
		segments.addElement(rPoint2);
		// erase all line segments
		eraseLines();
		// erase the last circle
		eraseCircle();
		// cleanup
		cleanUp();
	    }
	}
    }

    /**
     * Process a mouse pressed event.
     * Add the mouse location to the segment vector.
     * Calculate the cumulative total distance.
     * @param e mouse event.
     */
    public void mousePressed(MouseEvent e) {
	if (e.getSource() instanceof MapBean) {
	    // mouse has now been pressed
	    mousePressed = true;
	    // erase the old circle if any
	    eraseCircle();
	    // anchor the new first point of the line
	    rPoint1 = theMap.getProjection().inverse(e.getPoint());
	    // ensure the second point is not yet set.
	    rPoint2 = null;
	    // add the anchor point to the list of line segments
	    segments.addElement(rPoint1);
	    // add the distance to the total distance
	    totalDistance = totalDistance + distance;
	}   
    }

    /**
     * Draw a rubberband line and circle as the mouse is moved.
     * Calculate distance and azimuth angle as the mouse moves.
     * Display distance and azimuth angle in on the infoDelegator.
     * @param e mouse event.
     */
    public void mouseMoved(MouseEvent e) {
	if (e.getSource() instanceof MapBean) {
	    // only when the mouse has already been pressed
	    if (mousePressed) {
		double lat1, lat2, long1, long2;
		// set the map bean
		theMap = (MapBean)(e.getSource());
		// erase the old line and circle first
		paintRubberband(rPoint1, rPoint2);
		// get the current mouse location in latlon
		rPoint2 = theMap.getProjection().inverse(e.getPoint());
		// paint the new line and circle up to the current mouse location
		paintRubberband(rPoint1, rPoint2);
		// lat, lon of anchor point
		lat1  = rPoint1.getLatitude();
		long1 = rPoint1.getLongitude();
		// lat, lon of current mouse position
		lat2  = rPoint2.getLatitude();
		long2 = rPoint2.getLongitude();
		// calculate great circle distance in nm
		distance = getGreatCircleDist(lat1, long1, lat2, long2, DISTANCE_NM);
		// calculate azimuth angle dec deg
		double azimuth = getSphericalAzimuth(lat1, long1, lat2, long2);
		// convert total distance into all distance units
		String distNM   = df.format(totalDistance+distance);
		String distKM   = df.format((totalDistance+distance)*1.8520000);
		String distMILE = df.format((totalDistance+distance)*1.1507794);
		// setup the distance info to be displayed
		String unitInfo = null;
		// what unit is asked for
		switch(unit){
		case 0: unitInfo = distNM + "nm ";
		    break;
		case 1: unitInfo = distKM + "km ";
		    break;
		case 2: unitInfo = distMILE + "miles ";
		    break;
		case 3: unitInfo = distNM + "nm  " + distKM + "km  " + distMILE + "miles  ";
		    break;
		default: unitInfo = " error ";
		    break;
		}
		// add the mouse lat, lon
		String infoLine = rPoint2.toString() + "  distance ";
		// add the units
		infoLine = infoLine + unitInfo;
		// add the azimuth angle if need be
		if (showAngle) infoLine = infoLine + "   angle " + df.format(azimuth);
		// setup the info event
		InfoDisplayEvent info = new InfoDisplayEvent(this, infoLine);
		// ask the infoDelegator to display the info
		infoDelegator.requestInfoLine(info);
	    }
	}
    }

    /**
     * Process a mouseEntered event.
     * Record the mouse source object, a map bean.
     * @param e mouse event.
     */
    public void mouseEntered(MouseEvent e) {
	// get the map bean
	if (e.getSource() instanceof MapBean)
	    theMap = (MapBean)(e.getSource());
    }

    /**
     * Process a mouseExited event.
     * If a line is being drawn (and mouse go off the map), it will be erased.
     * The anchor point rPoint1 is kept in case the mouse
     * comes back on the screen. Then, a new line will be
     * drawn with the original mouse press position.
     * @param e mouse event.
     */
    public void mouseExited(MouseEvent e) {
	if (e.getSource() instanceof MapBean) {
	    // erase the old line first
	    paintRubberband(rPoint1, rPoint2);
	    // set the second point to null so that a new line will be re-drawn if
	    // the mouse comes back, and the line will use the old starting point.
	    rPoint2 = null;
	}
    }

    /**
     * Draw a rubberband line between two points
     * @param pt1 the anchor point.
     * @param pt2 the current (mouse) position.
     */
    public void paintLine(LatLonPoint pt1, LatLonPoint pt2){
	Graphics2D g = (Graphics2D)(theMap.getGraphics());
	g.setXORMode(java.awt.Color.lightGray);
	g.setColor(java.awt.Color.darkGray);
	if (pt1 != null && pt2 != null) {
	    // the line connecting the segments
	    OMLine2D cLine = new OMLine2D(
		pt1.getLatitude(),
		pt1.getLongitude(),
		pt2.getLatitude(),
		pt2.getLongitude(),
		lineType);
	    // get the map projection
	    Projection proj = theMap.getProjection();
	    // prepare the line for rendering
	    cLine.generate(proj);
	    // render the line graphic
	    cLine.render(g);
	}
    }

    /**
     * Draw a rubberband circle between two points
     * @param pt1 the anchor point.
     * @param pt2 the current (mouse) position.
     */
    public void paintCircle(LatLonPoint pt1, LatLonPoint pt2){
	// do all this only if want to display the rubberband circle
	if(displayCircle) {
	    Graphics2D g = (Graphics2D)(theMap.getGraphics());
	    g.setXORMode(java.awt.Color.lightGray);
	    g.setColor(java.awt.Color.darkGray);
	    if (pt1 != null && pt2 != null) {
		// first convert degrees to radians
		double radphi1 = ProjMath.degToRad(pt1.getLatitude());
		double radlambda0 = ProjMath.degToRad(pt1.getLongitude());
		double radphi = ProjMath.degToRad(pt2.getLatitude());
		double radlambda = ProjMath.degToRad(pt2.getLongitude());
		// calculate the circle radius
		double dRad = GreatCircle.spherical_distance(
		    radphi1, radlambda0,  radphi, radlambda);
		// convert into decimal degrees
		double rad = ProjMath.radToDeg(dRad);
		// make the circle
		OMCircle2D circle = new OMCircle2D(pt1.getLatitude(), pt1.getLongitude(), rad);
		// get the map projection
		Projection proj = theMap.getProjection();
		// prepare the circle for rendering
		circle.generate(proj);
		// render the circle graphic
		circle.render(g);
	    }
	} // end if(displayCircle)
    }

    /**
     * Draw a rubberband line and circle between two points
     * @param pt1 the anchor point.
     * @param pt2 the current (mouse) position.
     */
    public void paintRubberband(LatLonPoint pt1, LatLonPoint pt2){
	paintLine(pt1, pt2);
	paintCircle(pt1, pt2);
    }

    /**
     * Erase all line segments.
     */
    public void eraseLines(){
	for (int i=0; i<segments.size()-1; i++) {
	    paintLine((LatLonPoint)(segments.elementAt(i)),
		      (LatLonPoint)(segments.elementAt(i+1)));
	}
    }

    /**
     * Erase the current segment circle.
     */
    public void eraseCircle(){
	paintCircle(rPoint1, rPoint2);
    }

    /**
     * Reset the segments and distances
     */
    public void cleanUp(){
	// a quick way to clean the vector
	segments = new Vector();
	// reset the total distance
	totalDistance = 0.0;
	distance = 0.0;
    }

    /**
     * Return the distance in the chosen unit between two points (in decimal degrees).
     * Based on spherical arc distance between two points. See class GreatCircle.java
     * @param phi1 latitude in decimal degrees of start point
     * @param lambda0 longitude in decimal degrees of start point
     * @param phi latitude in decimal degrees of end point
     * @param lambda longitude in decimal degrees of end point
     * @param units the unit of distance, DISTANCE_NM, DISTANCE_KM, DISTANCE_MILE or all 3 types DISTANCE_ALL
     * @return double distance in chosen unit
     */
    public double getGreatCircleDist (double phi1, double lambda0, double phi,
				      double lambda, int units) {
	double dist = 0;
	// convert arguments to radians
	double radphi1 = ProjMath.degToRad(phi1);
	double radlambda0 = ProjMath.degToRad(lambda0);
	double radphi = ProjMath.degToRad(phi);
	double radlambda = ProjMath.degToRad(lambda);
	// get the spherical distance in radians between the two points
	double distRad = GreatCircle.spherical_distance(radphi1, radlambda0,
								radphi, radlambda);
	// in the chosen unit
	if (units == 0)
	    dist = distRad * Planet.wgs84_earthEquatorialCircumferenceNMiles / MoreMath.TWO_PI;
	if (units == 1)
	    dist = distRad * Planet.wgs84_earthEquatorialCircumferenceKM / MoreMath.TWO_PI;
	if (units == 2)
	    dist = distRad * Planet.wgs84_earthEquatorialCircumferenceMiles / MoreMath.TWO_PI;

	return dist;
    }

    /**
     * Return the azimuth angle in decimal degrees from north.
     * Based on spherical_azimuth. See class GreatCircle.java
     * @param phi1 latitude in decimal degrees of start point
     * @param lambda0 longitude in decimal degrees of start point
     * @param phi latitude in decimal degrees of end point
     * @param lambda longitude in decimal degrees of end point
     * @return double azimuth angle in degrees
     */
    public double getSphericalAzimuth (double phi1, double lambda0, double phi, double lambda) {
	// convert arguments to radians
	double radphi1 = ProjMath.degToRad(phi1);
	double radlambda0 = ProjMath.degToRad(lambda0);
	double radphi = ProjMath.degToRad(phi);
	double radlambda = ProjMath.degToRad(lambda);
	// get the spherical azimuth in radians between the two points
	double az = GreatCircle.spherical_azimuth(radphi1, radlambda0, radphi, radlambda);
	return ProjMath.radToDeg(az);
    }

    /**
     * Set the information delegator.
     * @param id the information delegator that displays the distance values.
     */
    public void setInfoDelegator(InformationDelegator id) {
	infoDelegator = id;
    }

    /**
     * Return the information delegator.
     */
    public InformationDelegator getInfoDelegator() {
	return infoDelegator;
    }

    /**
     * Set the map bean.
     * @param aMap a map bean
     */
    public void setMapBean(MapBean aMap) {
	theMap = aMap;
    }

    /**
     * Return the map bean.
     */
    public MapBean getMapBean() {
	return theMap;
    }

    /**
     * Set the unit of distance to be display
     * @param units either DISTANCE_NM, DISTANCE_KM, DISTANCE_MILE or
     * all 3 types DISTANCE_ALL
     */
    public void setUnit(int units) {
	unit = units;
    }
    /**
     * Return the unit of distance to be display
     * either DISTANCE_NM, DISTANCE_KM, DISTANCE_MILE or
     * all 3 types DISTANCE_ALL
     */
    public int getUnit() {
	return unit;
    }

    /**
     * Switch the display of the azimuth angle on or off
     * @param onOff true to display the azimuth angle, false to turn off
     */
    public void showAzimuth(boolean onOff) {
	showAngle = onOff;
    }

    /**
     * Set the line type to be drawn see also OMGraphic
     * @param lype either LINETYPE_GREATCIRCLE, LINETYPE_RHUMB, LINETYPE_STRAIGHT
     */
    public void setLineType(int lype) {
	lineType = lype;
    }
    /**
     * Return the line type
     * either LINETYPE_GREATCIRCLE, LINETYPE_RHUMB, LINETYPE_STRAIGHT
     */
    public int getLineType() {
	return lineType;
    }

    /**
     * Set the drawing of the rubberband circle on/off
     * @param off true or false
     */
    public void showCircle(boolean onOff) {
	displayCircle = onOff;
    }

}

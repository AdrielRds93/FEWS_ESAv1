/* **********************************************************************
 * 
 *  BBNT Solutions LLC, A part of GTE
 *  10 Moulton St.
 *  Cambridge, MA 02138
 *  (617) 873-2000
 * 
 *  Copyright (C) 1998, 2000
 *  This software is subject to copyright protection under the laws of 
 *  the United States and other countries.
 * 
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/event/LayerEvent.java,v $
 * $Revision: 1.7 $
 * $Date: 2000/05/08 14:22:01 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.event;

import com.bbn.openmap.Layer;

/**
 * An event to request that layers be added, removed, or shuffled around.
 */
public class LayerEvent extends java.util.EventObject
{
    public transient static final int ADD = 400;
    public transient static final int REMOVE = 401;
    public transient static final int REPLACE = 402;

    private transient Layer[] layers;
    private transient int type;

    /**
     * Construct a LayerEvent.
     * @param source Object
     * @param type type of LayerEvent
     * @param layers Layer[]
     */
    public LayerEvent(Object source, int type, Layer[] layers) {
	super(source);
	this.layers = layers;
	this.type = type;
    }

    /**
     * Get the Layers affected by this event.
     * @return Layer[]
     */
    public Layer[] getLayers() {
	return layers;
    }

    /**
     * Get the type of LayerEvent.
     * @return int type
     */
    public int getType() {
	return type;
    }
}

/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/event/ZoomEvent.java,v $
 * $Revision: 1.6 $
 * $Date: 2000/05/08 14:22:03 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.event;

/**
 * An event to request that the map zoom in or out.
 * Event specifies the type and amount of zoom of the map.
 */
public class ZoomEvent extends java.util.EventObject
    implements java.io.Serializable
{
    /**
     * Specifies that the amount should be used as a multiplier to the
     * current scale.
     */
    public transient static final int RELATIVE = 301;

    /**
     * Specifies that the amount should be used as the new scale.
     */
    public transient static final int ABSOLUTE = 302;

    /**
     * The type of zooming.
     */
    protected int type;

    /**
     * The zoom factor.
     */
    protected double amount;

    /**
     * Construct a ZoomEvent.
     * @param source the creator of the ZoomEvent.
     * @param type the type of the event, refering to how to use the amount.
     * @param amount the value of the ZoomEvent.
     */
    public ZoomEvent (Object source, int type, double amount)
    {
	super(source);
	switch (type) {
	    case RELATIVE:
	    case ABSOLUTE:
		break;
	    default:
		throw new IllegalArgumentException("Invalid type: " + type);
	}
	this.type = type;
	this.amount = amount;
    }

    /**
     * Check if the type is RELATIVE.
     * @return boolean
     */
    public boolean isRelative ()
    {
	return (type == RELATIVE);
    }

    /**
     * Check if the type is ABSOLUTE.
     * @return boolean
     */
    public boolean isAbsolute ()
    {
	return (type == ABSOLUTE);
    }

    /**
     * Get the amount of zoom.
     * @return double
     */
    public double getAmount ()
    {
	return amount;
    }

    /**
     * Stringify the object.
     * @return String
     */
    public String toString ()
    {
	return "#<ZoomEvent " + (isRelative() ? "Relative " : "") 
	  + (isAbsolute() ? "Absolute " : "") + amount + ">";
    }
}

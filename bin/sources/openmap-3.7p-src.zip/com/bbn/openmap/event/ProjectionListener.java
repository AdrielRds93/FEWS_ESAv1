/* **********************************************************************
 * 
 *  BBNT Solutions LLC, A part of GTE
 *  10 Moulton St.
 *  Cambridge, MA 02138
 *  (617) 873-2000
 * 
 *  Copyright (C) 1998, 2000
 *  This software is subject to copyright protection under the laws of 
 *  the United States and other countries.
 * 
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/event/ProjectionListener.java,v $
 * $Revision: 1.5 $
 * $Date: 2000/05/08 14:22:02 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.event;


import java.util.EventListener;

/**
 * Interface for listening to ProjectionEvents.
 * <p>
 * ProjectionEvent is fired when something fundamental about the
 * MapBean changes (e.g. when width, height, scale, type, center, etc
 * changes).
 */
public interface ProjectionListener extends java.util.EventListener {

    /**
     * Invoked when there has been a fundamental change to the Map.
     * <p>
     * Layers are expected to recompute their graphics (if this makes sense),
     * and then <code>repaint()</code> themselves.
     * @param e ProjectionEvent
     */
    public void projectionChanged (ProjectionEvent e);
}

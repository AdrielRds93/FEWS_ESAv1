/* **********************************************************************
 * 
 *  BBNT Solutions LLC, A part of GTE
 *  10 Moulton St.
 *  Cambridge, MA 02138
 *  (617) 873-2000
 * 
 *  Copyright (C) 1998, 2000
 *  This software is subject to copyright protection under the laws of 
 *  the United States and other countries.
 * 
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/event/NavMouseMode.java,v $
 * $Revision: 1.17 $
 * $Date: 2000/05/08 14:22:02 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.event;

import java.awt.event.MouseEvent;
import java.awt.Graphics;
import java.awt.Point;

import com.bbn.openmap.LatLonPoint;
import com.bbn.openmap.MapBean;
import com.bbn.openmap.proj.Projection;
import com.bbn.openmap.proj.Proj;

import com.bbn.openmap.util.Debug;

/**
 * The Navigation Mouse Mode interprets mouse clicks and mouse drags
 * to recenter and rescale the map.  The map is centered on the
 * location where a click occurs.  If a box is drawn by clicking down
 * and dragging the mouse, the map is centered on the dot in the
 * center of the box, and the scale is adjusted so the screen fills
 * the area designated by the box.
 * <p>
 * You MUST add this MouseMode as a ProjectionListener to the MapBean
 * to get it to work.  If you use a MouseDelegator with the bean, it
 * will take care of that for you.
 */
public class NavMouseMode extends AbstractMouseMode{

    /**
     * Mouse Mode identifier, which is "Navigation".
     */
    public final static transient String modeID = "Navigation".intern();

    protected Point point1, point2;
    protected boolean autoZoom = false;

    /**
     * Construct a NavMouseMode.
     * Sets the ID of the mode to the modeID, the consume mode to
     * true, and the cursor to the crosshair. 
     */
    public NavMouseMode () {
	this(true);
    }

    /**
     * Construct a NavMouseMode.
     * Lets you set the consume mode.  If the events are consumed,
     * then a MouseEvent is sent only to the first MapMouseListener
     * that successfully processes the event.  If they are not
     * consumed, then all of the listeners get a chance to act on the
     * event.
     * @param shouldConsumeEvents the mode setting.
     */
    public NavMouseMode (boolean shouldConsumeEvents) {
	super(modeID, shouldConsumeEvents);
	// override the default cursor
	setModeCursor(cursor.getPredefinedCursor(cursor.CROSSHAIR_CURSOR));
    }

    /**
     * Handle a mousePressed MouseListener event.  Erases the old
     * navigation rectangle if there is one, and then keeps the press
     * point for reference later.
     * @param e MouseEvent to be handled
     */
    public void mousePressed(MouseEvent e) {
	if (Debug.debugging("mousemode")) {
	    System.out.println(getID()+"|NavMouseMode.mousePressed()");
 	}
	if (! mouseSupport.fireMapMousePressed(e) && 
	    e.getSource() instanceof MapBean) {
	    // set the new first point
	    point1 = e.getPoint();
	    // ensure the second point isn't set.
	    point2 = null;
	}
    }

    /**
     * Handle a mouseReleased MouseListener event.
     * If there was no drag events, or if there was only a small
     * amount of dragging between the occurence of the mousePressed
     * and this event, then recenter the map.  Otherwise we get the
     * second corner of the navigation rectangle and try to figure
     * out the best scale and location to zoom in to based on that
     * rectangle.
     * @param e MouseEvent to be handled
     */
    public void mouseReleased(MouseEvent e) {
	if (Debug.debugging("mousemode")) {
	    System.out.println(getID()+"|NavMouseMode.mouseReleased()");
 	}
	Object obj = e.getSource();
	if (! mouseSupport.fireMapMouseReleased(e)) {
	    if (!(obj instanceof MapBean) || 
		!autoZoom || point1 == null) return;
	    MapBean map = (MapBean)obj;
	    Projection projection = map.getProjection();

	    synchronized (this) {
		point2 = e.getPoint();
		int dx = Math.abs(point2.x -point1.x);
		int dy = Math.abs(point2.y -point1.y);

		// Dont bother redrawing if the rectangle is too small
		if ((dx < 5) || (dy < 5)) {
		    // clean up the rectangle, since point2 has the old value.
		    paintRectangle(map, point1, point2); 

		    // If rectangle is too small in both x and y then
		    // recenter the map
		    if ((dx < 5) && (dy < 5)) {
			LatLonPoint llp = projection.inverse(e.getPoint());
			map.setCenter(llp);
		    }
		    return;
		}

		// Figure out the new scale
		com.bbn.openmap.LatLonPoint ll1 = projection.inverse(point1);
		com.bbn.openmap.LatLonPoint ll2 = projection.inverse(point2);


		double deltaDegrees;
		int deltaPix;
		dx = Math.abs(point2.x - point1.x);
		dy = Math.abs(point2.y - point1.y);

		if (dx < dy) {
		    double dlat = Math.abs(ll1.getLatitude() - ll2.getLatitude());
		    deltaDegrees = dlat;
		    deltaPix = projection.getHeight();
		} else {
		    double dlon;
		    double lat1, lon1, lon2;

		    // point1 is to the right of point2. switch the
		    // LatLonPoints so that ll1 is west (left) of ll2.
		    if (point1.x > point2.x) {
			lat1 = ll1.getLatitude();
			lon1 = ll1.getLongitude();
			ll1.setLatLon(ll2);
			ll2.setLatLon(lat1, lon1);
		    }

		    lon1 = ll1.getLongitude();
		    lon2 = ll2.getLongitude();

		    // allow for crossing dateline
		    if (lon1 > lon2) {
			dlon = (180-lon1) + (180+lon2);
		    } else {
			dlon = lon2-lon1;
		    }

//		    dlon = Math.abs(ll1.getLongitude() - ll2.getLongitude());
		    deltaDegrees = dlon;
		    deltaPix = projection.getWidth();
		}

		/*
		double deltaDegrees = (Math.abs(point2.x - point1.x)) <
		    (Math.abs(point2.y - point1.y)) ? 
		    Math.abs(ll1.getLatitude() - ll2.getLatitude()) : 
		    Math.abs(ll1.getLongitude() - ll2.getLongitude());
		// 	    double deltaLat = Math.abs(ll1.getLatitude()
		// 				      - ll2.getLatitude());
		int deltaPix = (Math.abs(point2.x - point1.x)) < 
		    (Math.abs(point2.y - point1.y)) ? 
		    projection.getHeight() : projection.getWidth();
		    */
		double pixPerDegree = ((Proj)projection).getPlanetPixelCircumference()/360;
		double newScale = pixPerDegree/(deltaPix/deltaDegrees);

		// Figure out the center of the rectangle
		int centerx = Math.min(point1.x, point2.x) +
//		    (int)Math.abs((point2.x - point1.x)/2);
		    dx/2;
		int centery = Math.min(point1.y, point2.y) + 
//		    (int)Math.abs((point2.y - point1.y)/2);
		    dy/2;
		com.bbn.openmap.LatLonPoint center = projection.inverse(centerx, 
									centery);

		// Fire events on main map to change view to match rect1
		// 	  System.out.println("point1: " +point1);
		// 	  System.out.println("point2: " +point2);
		//        System.out.println("Centerx: " +centerx + 
		//             " Centery: " + centery);
//		System.out.println("New Scale: " + newScale);
//		System.out.println("New Center: " +center);

		// Set the parameters of the projection and then set
		// the projection of the map.  This way we save having
		// the MapBean fire two ProjectionEvents.
		Proj p = (Proj)projection;
		p.setScale(newScale);
		p.setCenter(center);
		map.setProjection(p);
	    }
	    // reset the points
	    point1 = null;
	    point2 = null;
	}
    }

    /* HACK mouseClicked() gets called incorrectly from Swing JDK
     * 1.1.X when making menu selections.  For now we've put the
     * recentering logic into mouseReleased() (which doesn't get
     * called incorrectly).
     * HACK we need to see if the same problem occurs in JDK 1.2
     *
     * handle a mouseClicked MouseListener event.  The Mode centers
     * the map on the point that was clicked.  This method also resets
     * point1 and point2 to null.
     *
     * @param e MouseEvent to be handled
     *
    public void mouseClicked (MouseEvent e) {
	if (Debug.debugging("mousemode")) {
	    System.out.println(getID()+"|NavMouseMode.mouseClicked()");
 	}
	Object obj = e.getSource();
	if (!mouseSupport.fireMapMouseClicked(e) && (obj instanceof MapBean)) {
	    // the mouse click wasn't handled by any of my delgates, so
	    // I'll do something with it.
	    if (obj instanceof MapBean) {
		Projection projection = ((MapBean)obj).getProjection();
		LatLonPoint llp = projection.inverse(e.getPoint());
//		System.out.println("LLP: " + llp);
		((MapBean)obj).setCenter(llp);
	    }
	}
    }
     */

    /**
     * Handle a mouseEntered MouseListener event. The boolean autoZoom
     * is set to true, which will make the delegate ask the map to
     * zoom in to a box that is drawn.
     * @param e MouseEvent to be handled
     */
    public void mouseEntered(MouseEvent e) {
	if (Debug.debugging("mousemode")) {
	    System.out.println(getID()+"|NavMouseMode.mouseEntered()");
 	}
	if (! mouseSupport.fireMapMouseEntered(e)) {
	    autoZoom = true;
	}
    }

    /**
     * Handle a mouseExited MouseListener event. The boolean autoZoom
     * is set to false, which will cause the delegate to NOT ask the
     * map to zoom in on a box.  If a box is being drawn, it will be
     * erased.  The point1 is kept in case the mouse comes back on the
     * screen with the button still down.  Then, a new box will be
     * drawn with the original mouse press position.
     * @param e MouseEvent to be handled
     */
    public void mouseExited(MouseEvent e) {
	if (Debug.debugging("mousemode")) {
	    System.out.println(getID()+"|NavMouseMode.mouseExited()");
 	}
	if (! mouseSupport.fireMapMouseExited(e) && 
	    e.getSource() instanceof MapBean) {
	    // don't zoom in, because the mouse is off the window.
	    autoZoom = false;
	    // clean up the last box drawn
	    paintRectangle((MapBean)e.getSource(), point1, point2);
	    // set the second point to null so that a new box will be
	    // drawn if the mouse comes back, and the box will use the old
	    // starting point, if the mouse button is still down.
	    point2 = null;
	}
    }

    // Mouse Motion Listener events
    ///////////////////////////////

    /**
     * Handle a mouseDragged MouseMotionListener event. A rectangle is
     * drawn from the mousePressed point, since I'm assuming that I'm
     * drawing a box to zoom the map to.  If a previous box was drawn,
     * it is erased.
     * @param e MouseEvent to be handled
     */
    public void mouseDragged(MouseEvent e){
	if (Debug.debugging("mousemode")) {
	    System.out.println(getID()+"|NavMouseMode.mouseDragged()");
 	}
	if (! mouseSupport.fireMapMouseDragged(e) && 
	    e.getSource() instanceof MapBean) {
	    if (!autoZoom) return;

	    // clean up the old rectangle, since point2 has the old value.
	    paintRectangle((MapBean)e.getSource(), point1, point2);	
	    // paint new rectangle
	    point2 = e.getPoint();
	    paintRectangle((MapBean)e.getSource(), point1, point2);
	}
    }

    /**
     * Handle a mouseMoved MouseMotionListener event. Nothing happens.
     * @param e MouseEvent to be handled
     */
    public void mouseMoved(MouseEvent e){
	if (Debug.debugging("mousemode")) {
	    System.out.println(getID()+"|NavMouseMode.mouseMoved()");
 	}
	if (! mouseSupport.fireMapMouseMoved(e)) {
	}
    }

    /**
     * Draws or erases boxes between two screen pixel points.  The
     * graphics from the map is set to XOR mode, and this method uses
     * two colors to make the box disappear if on has been drawn at
     * these coordinates, and the box to appear if it hasn't.
     * @param pt1 one corner of the box to drawn, in window pixel
     * coordinates.
     * @param pt2 the opposite corner of the box.
     */
    protected void paintRectangle(MapBean map, Point pt1, Point pt2){
	Graphics g = map.getGraphics();
	g.setXORMode(java.awt.Color.lightGray);
	g.setColor(java.awt.Color.darkGray);

	if (pt1 != null && pt2 != null){
	    g.drawRect(pt1.x < pt2.x ? pt1.x : pt2.x, 
		       pt1.y < pt2.y ? pt1.y : pt2.y, 
		       Math.abs(pt2.x - pt1.x), 
		       Math.abs(pt2.y - pt1.y));
	    g.drawRect(pt1.x < pt2.x ? pt1.x + (pt2.x - pt1.x)/2 - 1 : 
		       pt2.x + (pt1.x - pt2.x)/2 - 1, 
		       pt1.y < pt2.y ? pt1.y + (pt2.y - pt1.y)/2 - 1 : 
		       pt2.y + (pt1.y - pt2.y)/2 - 1, 2, 2);
	}
    }
}

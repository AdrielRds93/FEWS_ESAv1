/* **********************************************************************
 * 
 *  BBNT Solutions LLC, A part of GTE
 *  10 Moulton St.
 *  Cambridge, MA 02138
 *  (617) 873-2000
 * 
 *  Copyright (C) 1998, 2000
 *  This software is subject to copyright protection under the laws of 
 *  the United States and other countries.
 * 
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/event/SelectMouseMode.java,v $
 * $Revision: 1.8 $
 * $Date: 2000/05/08 14:22:03 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.event;

import java.awt.event.*;

/**
 * The SelectMouseMode delegates handling of mouse events to the
 * listeners.  This MouseMode type is ideal for Layers that want to
 * receive MouseEvents.  The simplest way to set this up is for the
 * Layer to implement the MapMouseListener interface, and indicate
 * that it wants to receive events when the mouse mode is the
 * SelectMouseMode.  Here's a code snippet for a Layer that would do
 * this:
 * <code><pre>
 *  public MapMouseListener getMapMouseListener() {
 *	return this;
 *  }
 *  public String[] getMouseModeServiceList() {
 *	return new String[] {
 *	    SelectMouseMode.modeID
 *	};
 *  }
 * </pre></code>
 * <p>
 * This class is functionally the same as the AbstractMouseMode,
 * except that it actually calls the fire methods in the
 * MapMouseSupport object to propagate the events.
 */
public class SelectMouseMode extends AbstractMouseMode {

    /**
     * Mouse Mode identifier, which is "Gestures".
     * This is returned on getID()
     */
    public final static transient String modeID = "Gestures".intern();

    /**
     * Construct a SelectMouseMode.
     * Default constructor.  Sets the ID to the modeID, and the
     * consume mode to true. 
     */
    public SelectMouseMode(){
	this(true);
    }

    /**
     * Construct a SelectMouseMode.
     * The constructor that lets you set the consume mode. 
     * @param consumeEvents the consume mode setting.
     */
    public SelectMouseMode(boolean consumeEvents){
	super(modeID, consumeEvents);
    }

    /**
     * Fires the MapMouseSupport method.
     * @param e mouse event.
     */
    public void mouseClicked(MouseEvent e) {
	mouseSupport.fireMapMouseClicked(e);
    }

    /**
     * Fires the MapMouseSupport method.
     * @param e mouse event.
     */
    public void mousePressed(MouseEvent e) {
	mouseSupport.fireMapMousePressed(e);
    }

    /**
     * Fires the MapMouseSupport method.
     * @param e mouse event.
     */
    public void mouseReleased(MouseEvent e) {
	mouseSupport.fireMapMouseReleased(e);
    }

    /**
     * Fires the MapMouseSupport method.
     * @param e mouse event.
     */
    public void mouseEntered(MouseEvent e) {
	mouseSupport.fireMapMouseEntered(e);
    }

    /**
     * Fires the MapMouseSupport method.
     * @param e mouse event.
     */
    public void mouseExited(MouseEvent e) {
	mouseSupport.fireMapMouseExited(e);
    }

    /**
     * Fires the MapMouseSupport method.
     * @param e mouse event.
     */
    public void mouseDragged(MouseEvent e) {
	mouseSupport.fireMapMouseDragged(e);
    }

    /**
     * Fires the MapMouseSupport method.
     * @param e mouse event.
     */
    public void mouseMoved(MouseEvent e) {
	mouseSupport.fireMapMouseMoved(e);
    }
}

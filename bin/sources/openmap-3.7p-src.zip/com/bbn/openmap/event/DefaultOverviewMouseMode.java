/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/event/DefaultOverviewMouseMode.java,v $
 * $Revision: 1.1 $
 * $Date: 2000/08/03 14:56:11 $
 * $Author: dietrick $
 * 
 * **********************************************************************
 */
package com.bbn.openmap.event;

import com.bbn.openmap.gui.OverviewMapHandler;
import com.bbn.openmap.LatLonPoint;
import com.bbn.openmap.MapBean;
import com.bbn.openmap.proj.Proj;
import com.bbn.openmap.proj.Projection;
import com.bbn.openmap.util.Debug;

import java.awt.event.*;

/** 
 * A MouseMode that handles drawing a box, or clicking on a point,
 * but directs the updates to the ControlledMapSupport of the
 * overview map handler, instead of the overview MapBean, which
 * would have been the normal behavior.  
 */
public class DefaultOverviewMouseMode extends NavMouseMode {
    
    OverviewMapHandler overviewMapHandler;
    
    /**
     * Construct a OverviewMouseMode.
     * Sets the ID of the mode to the modeID, the consume mode to
     * true, and the cursor to the crosshair. 
     */
    public DefaultOverviewMouseMode (OverviewMapHandler omh) {
	super(true);
	overviewMapHandler = omh;
    }
    
    /**
     * Handle a mouseReleased MouseListener event.  If there was
     * no drag events, or if there was only a small amount of
     * dragging between the occurence of the mousePressed and this
     * event, then recenter the source map.  Otherwise we get the
     * second corner of the navigation rectangle and try to figure
     * out the best scale and location to zoom in to based on that
     * rectangle.
     * @param e MouseEvent to be handled 
     */
    public void mouseReleased(MouseEvent e) {
	if (Debug.debugging("mousemode")) {
	    System.out.println(getID()+"|DefaultOverviewMouseMode.mouseReleased()");
	}
	Object obj = e.getSource();
	if (! mouseSupport.fireMapMouseReleased(e)) {
	    if (!(obj instanceof MapBean) || 
		!autoZoom || point1 == null) return;
	    MapBean map = (MapBean)obj;
	    Projection projection = map.getProjection();
	    
	    synchronized (this) {
		point2 = e.getPoint();
		int dx = Math.abs(point2.x -point1.x);
		int dy = Math.abs(point2.y -point1.y);
		
		// Dont bother redrawing if the rectangle is too small
		if ((dx < 5) || (dy < 5)) {
		    // clean up the rectangle, since point2 has the old value.
		    paintRectangle(map, point1, point2); 
		    
		    // If rectangle is too small in both x and y then
		    // recenter the map
		    if ((dx < 5) && (dy < 5)) {
			LatLonPoint llp = projection.inverse(e.getPoint());
			overviewMapHandler.getControlledMapListeners().setCenter(llp);
		    }
		    return;
		}
		
		// Figure out the new scale
		com.bbn.openmap.LatLonPoint ll1 = projection.inverse(point1);
		com.bbn.openmap.LatLonPoint ll2 = projection.inverse(point2);
		
		
		double deltaDegrees;
		int deltaPix;
		dx = Math.abs(point2.x - point1.x);
		dy = Math.abs(point2.y - point1.y);
		    
		if (dx < dy) {
		    double dlat = Math.abs(ll1.getLatitude() - ll2.getLatitude());
		    deltaDegrees = dlat;
		    deltaPix = projection.getHeight();
		} else {
		    double dlon;
		    double lat1, lon1, lon2;
		    
		    // point1 is to the right of point2. switch the
		    // LatLonPoints so that ll1 is west (left) of ll2.
		    if (point1.x > point2.x) {
			lat1 = ll1.getLatitude();
			lon1 = ll1.getLongitude();
			ll1.setLatLon(ll2);
			ll2.setLatLon(lat1, lon1);
		    }
		    
		    lon1 = ll1.getLongitude();
		    lon2 = ll2.getLongitude();
		    
		    // allow for crossing dateline
		    if (lon1 > lon2) {
			dlon = (180-lon1) + (180+lon2);
		    } else {
			dlon = lon2-lon1;
		    }
		    
		    deltaDegrees = dlon;
		    deltaPix = projection.getWidth();
		}
		
		double pixPerDegree = ((Proj)projection).getPlanetPixelCircumference()/360;
		double newScale = pixPerDegree/(deltaPix/deltaDegrees);
		
		// Figure out the center of the rectangle
		int centerx = Math.min(point1.x, point2.x) + dx/2;
		int centery = Math.min(point1.y, point2.y) + dy/2;
		com.bbn.openmap.LatLonPoint center = projection.inverse(centerx, 
									centery);
		
		// Set the parameters of the projection and then set
		// the projection of the map.  This way we save having
		// the MapBean fire two ProjectionEvents.
		Proj p = (Proj)projection;
		overviewMapHandler.getControlledMapListeners().setScale(newScale);
		overviewMapHandler.getControlledMapListeners().setCenter(center);
	    }
	    // reset the points
	    point1 = null;
		point2 = null;
	}
    }
}

/* **********************************************************************
 * 
 *  BBNT Solutions LLC, A part of GTE
 *  10 Moulton St.
 *  Cambridge, MA 02138
 *  (617) 873-2000
 * 
 *  Copyright (C) 1998, 2000
 *  This software is subject to copyright protection under the laws of 
 *  the United States and other countries.
 * 
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/event/ProjectionEvent.java,v $
 * $Revision: 1.4 $
 * $Date: 2000/05/08 14:22:02 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.event;


import com.bbn.openmap.proj.Projection;

/**
 * An event with an updated MapBean projection.
 */
public class ProjectionEvent extends java.util.EventObject {

    protected Projection projection;

    /**
     * Construct a ProjectionEvent.
     * @param source Object
     * @param aProj Projection
     */
    public ProjectionEvent (Object source, Projection aProj) {
	super(source);
	projection = aProj;
    }

    /**
     * Get the Projection.
     * @return Projection
     */
    public Projection getProjection () {
	return projection;
    }
}

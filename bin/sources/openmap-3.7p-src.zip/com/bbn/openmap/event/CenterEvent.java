/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/event/CenterEvent.java,v $
 * $Revision: 1.4 $
 * $Date: 2000/05/08 14:22:00 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.event;

/**
 * An event to request the map should recenter to a new latitude and
 * longitude.
 */
public class CenterEvent extends java.util.EventObject
{
    private transient double latitude;
    private transient double longitude;

    /**
     * Construct a CenterEvent.
     * @param source the source bean
     * @param lat double latitude in decimal degrees
     * @param lon double longitude in decimal degrees
     */
    public CenterEvent (Object source, double lat, double lon)
    {
	super(source);
	latitude = lat;
	longitude = lon;
    }

    /**
     * Get the latitude of the center.
     * @return double latitude in decimal degrees
     */
    public double getLatitude() {
	return latitude;
    }

    /**
     * Get the latitude of the center.
     * @return double latitude in decimal degrees
     */
    public double getLongitude() {
	return longitude;
    }
}

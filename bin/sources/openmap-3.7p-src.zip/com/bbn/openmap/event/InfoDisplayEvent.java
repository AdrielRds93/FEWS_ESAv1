/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/event/InfoDisplayEvent.java,v $
 * $Revision: 1.5 $
 * $Date: 2000/05/08 14:22:01 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.event;

import com.bbn.openmap.Layer;

/**
 * An event to request that information be displayed.
 */
public class InfoDisplayEvent extends java.util.EventObject {

    /**   
     * The requester may send information along with the event if the
     * event represents an information display request from the layer,
     * this variable contains the information needed to process the
     * event.  
     */
    protected String information = null;

    /**
     * Construct an InfoDisplayEvent.
     * @param source Object
     */
    public InfoDisplayEvent (Object source)
    {
	this (source, null);
    }

    /**
     * Construct an InfoDisplayEvent.
     * @param source Object
     * @param info String information
     */
    public InfoDisplayEvent (Object source, String info)
    {
	super(source);
	information = info;
    }

    /**
     * Get the associated Layer or null.
     * Returns a Layer, if the Layer is the source of the event,
     * otherwise null.
     * @return Layer or null
     */
    public Layer getLayer ()
    {
	Object obj = getSource();
	return (obj instanceof Layer)
	    ? (Layer)obj
	    : null;
    }

    /**
     * Get the information.
     * @return String information
     */
    public String getInformation ()
    {
	return information;
    }

    /**
     * Set the information.
     * @param info String
     */
    public void setInformation(String info){
	information = info;
    }
}

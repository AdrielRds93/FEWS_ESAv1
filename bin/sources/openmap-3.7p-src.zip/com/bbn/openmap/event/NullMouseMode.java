/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/event/NullMouseMode.java,v $
 * $Revision: 1.6 $
 * $Date: 2000/05/08 14:22:02 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.event;
import java.awt.event.MouseEvent;

/**
 * The NullMouseMode takes no action on mouse events and does not
 * keep a list of map mouse listeners. It is intended to be used when
 * you need a mouse mode that does nothing as an alternative to one
 * that does something. If you don't have one that does something you
 * don't need any MouseModes at all.  
 */
public class NullMouseMode extends AbstractMouseMode {

    /**
     * Mouse Mode identifier, which is "None".
     */
    public final static transient String modeID = "None".intern();

    /**
     * Construct a NullMouseMode.
     * Default constructor sets the ID to the modeID string and the
     * consume events parameter to true. 
     */
    public NullMouseMode() {
	this(modeID, true);
    }

    /**
     * Construct a NullMouseMode.
     * Constructor that lets you set the name and the consume mode.
     * @param id the ID name.
     * @param consumeEvents the consume mode.
     */
    public NullMouseMode(String id, boolean consumeEvents){
	super(id, consumeEvents);
    }

    /**
     * IGNORED.
     */
    public void addMapMouseListener(MapMouseListener mml){}

    /**
     * IGNORED.
     */
    public void removeMapMouseListener(MapMouseListener mml){}
}

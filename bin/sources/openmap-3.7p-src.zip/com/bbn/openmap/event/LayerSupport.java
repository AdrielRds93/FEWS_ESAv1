/* **********************************************************************
 * 
 *  BBNT Solutions LLC, A part of GTE
 *  10 Moulton St.
 *  Cambridge, MA 02138
 *  (617) 873-2000
 * 
 *  Copyright (C) 1998, 2000
 *  This software is subject to copyright protection under the laws of 
 *  the United States and other countries.
 * 
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/event/LayerSupport.java,v $
 * $Revision: 1.3 $
 * $Date: 2000/05/08 14:22:01 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.event;

import java.io.Serializable;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;

/**
 * This is a utility class that can be used by beans that need support
 * for handling LayerListeners and firing LayerEvents.  You can use an
 * instance of this class as a member field of your bean and delegate
 * work to it.
 */
public class LayerSupport implements java.io.Serializable 
{
    /**
     * Construct a LayerSupport.
     * @param sourceBean  The bean to be given as the source for any events.
     */
    public LayerSupport(Object sourceBean) {
	source = sourceBean;
    }

    /**
     * Add a LayerListener to the listener list.
     *
     * @param listener  The LayerListener to be added
     */
    public synchronized void addLayerListener(LayerListener listener) {
	if (listeners == null) {
	    listeners = new java.util.Vector();
	}
	listeners.addElement(listener);
    }

    /**
     * Remove a LayerListener from the listener list.
     *
     * @param listener  The LayerListener to be removed
     */
    public synchronized void removeLayerListener(LayerListener listener) {
	if (listeners == null) {
	    return;
	}
	listeners.removeElement(listener);
    }

    /**
     * Send a layer event to all registered listeners.
     *
     * @param type the event type: one of ADD, REMOVE, REPLACE
     * @param layers the list of layers
     * @see LayerEvent
     */
    public void fireLayer(int type, com.bbn.openmap.Layer[] layers)
    {
	java.util.Vector targets;
	synchronized (this) {
	    if (listeners == null) {
	    	return;
	    }
	    targets = (java.util.Vector) listeners.clone();
	}
        LayerEvent evt = new LayerEvent(source, type, layers);

	for (int i = 0; i < targets.size(); i++) {
	    LayerListener target = (LayerListener)targets.elementAt(i);
	    target.setLayers(evt);
	}
    }


    private void writeObject(ObjectOutputStream s) throws IOException {
        s.defaultWriteObject();

	java.util.Vector v = null;
	synchronized (this) {
	    if (listeners != null) {
	        v = (java.util.Vector) listeners.clone();
            }
	}

	if (v != null) {
	    for(int i = 0; i < v.size(); i++) {
	        LayerListener l = (LayerListener)v.elementAt(i);
	        if (l instanceof Serializable) {
	            s.writeObject(l);
	        }
            }
        }
        s.writeObject(null);
    }


    private void readObject(ObjectInputStream s) throws ClassNotFoundException, IOException {
        s.defaultReadObject();
      
        Object listenerOrNull;
        while(null != (listenerOrNull = s.readObject())) {
	  addLayerListener((LayerListener)listenerOrNull);
        }
    }

    transient private java.util.Vector listeners;
    private Object source;
    private int layerSupportSerializedDataVersion = 1;
}

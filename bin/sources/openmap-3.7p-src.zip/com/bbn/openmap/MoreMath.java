/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/MoreMath.java,v $
 * $Revision: 1.13 $
 * $Date: 2000/08/21 22:58:14 $
 * $Author: dietrick $
 * 
 * **********************************************************************
 */

package com.bbn.openmap;
import java.lang.Math;


/**
 * MoreMath provides functions that are not part of the standard Math class.
 * <p> <pre>
 * Functions:
 *	asinh(double x) - hyperbolic arcsine
 *	sinh(double x) - hyperbolic sine
 *
 * Need to Implement:
 * Function                Definition                              
 * Hyperbolic cosine       (e^x+e^-x)/2                            
 * Hyperbolic tangent      (e^x-e^-x)/(e^x+e^-x)                   
 * Hyperbolic arc cosine   2 log  (sqrt((x+1)/2) + sqrt((x-1)/2))  
 * Hyperbolic arc tangent  (log  (1+x) - log (1-x))/2
 * </pre>
 */
public class MoreMath {

    /**
     * 2*Math.PI
     */
    final public static transient double TWO_PI = Math.PI*2.0d;

    /**
     * 2*Math.PI
     */
    final public static transient double TWO_PI_D = Math.PI*2.0d;

    /**
     * Math.PI/2
     */
    final public static transient double HALF_PI = Math.PI/2.0d;

    /**
     * Math.PI/2
     */
    final public static transient double HALF_PI_D = Math.PI/2.0d;

    // cannot construct
    private MoreMath() {}

    /**
     * Checks if a ~= b.
     * Use this to test equality of floating point numbers.
     * <p>
     * @param a double
     * @param b double
     * @param epsilon the allowable error
     * @return boolean
     */
    final public static boolean approximately_equal(double a, double b, double epsilon) {
	return (Math.abs(a-b) <= epsilon);
    }

    /**
     * Hyperbolic arcsin.
     * <p>
     * Hyperbolic arc sine: log (x+sqrt(1+x^2))                    
     * @param x double
     * @return double asinh(x)
     */
    public static final double asinh(double x) {
	return Math.log(x + Math.sqrt(x * x + 1));
    }

    /**
     * Hyperbolic sin.
     * <p>
     * Hyperbolic sine: (e^x-e^-x)/2                            
     * @param x double
     * @return double sinh(x)
     */
    public static final double sinh(double x) {
	return (Math.pow(Math.E,x) - Math.pow(Math.E,-x)) / 2.0d;
    }

    // HACK - are there functions that already exist?
    /**
     * Return sign of number.
     * @param x short
     * @return int sign -1, 1
     */
    public static final int sign(short x) {
	return (x < 0) ? -1 : 1;
    }

    /**
     * Return sign of number.
     * @param x int
     * @return int sign -1, 1
     */
    public static final int sign(int x) {
	return (x < 0) ? -1 : 1;
    }

    /**
     * Return sign of number.
     * @param x long
     * @return int sign -1, 1
     */
    public static final int sign(long x) {
	return (x < 0) ? -1 : 1;
    }

    /**
     * Return sign of number.
     * @param x double
     * @return int sign -1, 1
     */
    public static final int sign(double x) {
	return (x < 0d) ? -1 : 1;
    }

    /**
     * Check if number is odd.
     * @param x short
     * @return boolean
     */
    public static final boolean odd(short x) {
	return !even(x);
    }

    /**
     * Check if number is odd.
     * @param x int
     * @return boolean
     */
    public static final boolean odd(int x) {
	return !even(x);
    }

    /**
     * Check if number is odd.
     * @param x long
     * @return boolean
     */
    public static final boolean odd(long x) {
	return !even(x);
    }

    /**
     * Check if number is even.
     * @param x short
     * @return boolean
     */
    public static final boolean even(short x) {
	return ((x & 0x1) == 0);
    }

    /**
     * Check if number is even.
     * @param x int
     * @return boolean
     */
    public static final boolean even(int x) {
	return ((x & 0x1) == 0);
    }

    /**
     * Check if number is even.
     * @param x long
     * @return boolean
     */
    public static final boolean even(long x) {
	return ((x & 0x1) == 0);
    }

    /**
     * Converts a byte in the range of -128 to 127 to an int
     * in the range 0 - 255.
     * @param b (-128 &lt;= b &lt;= 127)
     * @return int (0 &lt;= b &lt;= 255)
     */
    public static final int signedToInt(byte b) {
	return ((int)b & 0xff);
    }

    /**
     * Converts a short in the range of -32768 to 32767 to
     * an int in the range 0 - 65535.
     * @param b (-32768 &lt;= b &lt;= 32767)
     * @return int (0 &lt;= b &lt;= 65535)
     */
    public static final int signedToInt(short w) {
	return ((int)w & 0xffff);
    }

    /**
     * Convert an int in the range of -2147483648 to 2147483647 to a long in
     * the range 0 to 4294967295.
     * @param x (-2147483648 &lt;= x &lt;= 2147483647)
     * @return long (0 &lt;= x &lt;= 4294967295)
     */
    public static final long signedToLong(int x) {
	return ((long)x & 0xFFFFFFFFL);
    }

    /**
     * Converts an int in the range of 0 - 65535 to an int in the range
     * of 0 - 255.
     * @param w int (0 &lt;= w &lt;= 65535)
     * @return int (0 &lt;= w &lt;= 255)
     */
    public static final int wordToByte(int w) {
	return w>>8;
    }

    /**
     * Build short out of bytes (in big endian order).
     * @param bytevec[] bytes
     * @param offset byte offset
     * @return short
     */
    public static final short BuildShortBE(byte bytevec[], int offset) {
	return (short)(((int)(bytevec[0+offset]) << 8) |
		       (signedToInt(bytevec[1+offset])));
    }

    /**
     * Build short out of bytes (in little endian order).
     * @param bytevec[] bytes
     * @param offset byte offset
     * @return short
     */
    public static final short BuildShortLE(byte bytevec[], int offset) {
	return (short)(((int)(bytevec[1+offset]) << 8) |
		       (signedToInt(bytevec[0+offset])));
    }

    /**
     * Build short out of bytes.
     * @param bytevec[] bytes
     * @param offset byte offset
     * @param MSBFirst BE or LE?
     * @return short
     */
    public static final short BuildShort(byte bytevec[], int offset,
					 boolean MSBFirst) {
	if (MSBFirst) {
	    return(BuildShortBE(bytevec, offset));
	} else {
	    return(BuildShortLE(bytevec, offset));
	}
    }

    /**
     * Build short out of bytes (in big endian order).
     * @param bytevec[] bytes
     * @param MSBFirst BE or LE?
     * @return short
     */
    public static final short BuildShortBE(byte bytevec[], boolean MSBFirst) {
	return BuildShortBE(bytevec, 0);
    }

    /**
     * Build short out of bytes (in little endian order).
     * @param bytevec[] bytes
     * @param MSBFirst BE or LE?
     * @return short
     */
    public static final short BuildShortLE(byte bytevec[], boolean MSBFirst) {
	return BuildShortLE(bytevec, 0);
    }

    /**
     * Build short out of bytes.
     * @param bytevec[] bytes
     * @param MSBFirst BE or LE?
     * @return short
     */
    public static final short BuildShort(byte bytevec[], boolean MSBFirst) {
	return BuildShort(bytevec, 0, MSBFirst);
    }

    /**
     * Build int out of bytes (in big endian order).
     * @param bytevec[] bytes
     * @param offset byte offset
     * @return int
     */
    public static final int BuildIntegerBE(byte bytevec[], int offset) {
	return(((int)(bytevec[0+offset]) << 24) |
	       (signedToInt(bytevec[1+offset]) << 16) |
	       (signedToInt(bytevec[2+offset]) << 8) |
	       (signedToInt(bytevec[3+offset])));
    }

    /**
     * Build int out of bytes (in little endian order).
     * @param bytevec[] bytes
     * @param offset byte offset
     * @return int
     */
    public static final int BuildIntegerLE(byte bytevec[], int offset) {
	return(((int)(bytevec[3+offset]) << 24) |
	       (signedToInt(bytevec[2+offset]) << 16) |
	       (signedToInt(bytevec[1+offset]) << 8) |
	       (signedToInt(bytevec[0+offset])));
    }       

    /**
     * Build int out of bytes.
     * @param bytevec[] bytes
     * @param offset byte offset
     * @param MSBFirst BE or LE?
     * @return int
     */
    public static final int BuildInteger(byte bytevec[], int offset,
					 boolean MSBFirst) {
	if (MSBFirst)
	    return BuildIntegerBE(bytevec, offset);
	else
	    return BuildIntegerLE(bytevec, offset);
    }

    /**
     * Build int out of bytes (in big endian order).
     * @param bytevec[] bytes
     * @return int
     */
    public static final int BuildIntegerBE(byte bytevec[]) {
	return BuildIntegerBE(bytevec, 0);
    }

    /**
     * Build int out of bytes (in little endian order).
     * @param bytevec[] bytes
     * @return int
     */
    public static final int BuildIntegerLE(byte bytevec[]) {
	return BuildIntegerLE(bytevec, 0);
    }

    /**
     * Build int out of bytes.
     * @param bytevec[] bytes
     * @param MSBFirst BE or LE?
     * @return int
     */
    public static final int BuildInteger(byte bytevec[], boolean MSBFirst) {
	if (MSBFirst)
	    return BuildIntegerBE(bytevec, 0);
	else
	    return BuildIntegerLE(bytevec, 0);
    }
 
    /**
     * Build long out of bytes (in big endian order).
     * @param bytevec[] bytes
     * @param offset byte offset
     * @return long
     */
    public static final long BuildLongBE(byte bytevec[], int offset) {
	    return(((long)signedToInt(bytevec[0+offset]) << 56) |
		   ((long)signedToInt(bytevec[1+offset]) << 48) |
		   ((long)signedToInt(bytevec[2+offset]) << 40) |
		   ((long)signedToInt(bytevec[3+offset]) << 32) |
		   ((long)signedToInt(bytevec[4+offset]) << 24) |
		   ((long)signedToInt(bytevec[5+offset]) << 16) |
		   ((long)signedToInt(bytevec[6+offset]) << 8)  | 
		   ((long)signedToInt(bytevec[7+offset])));
    }
 
    /**
     * Build long out of bytes (in little endian order).
     * @param bytevec[] bytes
     * @param offset byte offset
     * @return long
     */
    public static final long BuildLongLE(byte bytevec[], int offset) {
	    return(((long)signedToInt(bytevec[7+offset]) << 56) | 
		   ((long)signedToInt(bytevec[6+offset]) << 48) |
		   ((long)signedToInt(bytevec[5+offset]) << 40) | 
		   ((long)signedToInt(bytevec[4+offset]) << 32) |
		   ((long)signedToInt(bytevec[3+offset]) << 24) |
		   ((long)signedToInt(bytevec[2+offset]) << 16) |
		   ((long)signedToInt(bytevec[1+offset]) << 8)  | 
		   ((long)signedToInt(bytevec[0+offset])));
    }
 
    /**
     * Build long out of bytes.
     * @param bytevec[] bytes
     * @param offset byte offset
     * @param MSBFirst BE or LE?
     * @return long
     */
    public static final long BuildLong(byte bytevec[], int offset,
				       boolean MSBFirst) {
	if (MSBFirst)
	    return BuildLongBE(bytevec, offset);
	else
	    return BuildLongLE(bytevec, offset);
    }

    /**
     * Build long out of bytes (in big endian order).
     * @param bytevec[] bytes
     * @return long
     */
    public static final long BuildLongBE(byte bytevec[]) {
	return BuildLongBE(bytevec, 0);
    }
 
    /**
     * Build long out of bytes (in little endian order).
     * @param bytevec[] bytes
     * @return long
     */
    public static final long BuildLongLE(byte bytevec[]) {
	return BuildLongLE(bytevec, 0);
    }

    /**
     * Build long out of bytes.
     * @param bytevec[] bytes
     * @param MSBFirst BE or LE?
     * @return long
     */
    public static final long BuildLong(byte bytevec[], boolean MSBFirst) {
	if (MSBFirst)
	    return BuildLongBE(bytevec, 0);
	else
	    return BuildLongLE(bytevec, 0);
    }

    /*
    public static final void main(String[] args) {
	byte[] b = new byte[4];
	b[0] = (byte)0xff;
	b[1] = (byte)0x7f;
	com.bbn.openmap.util.Debug.output("32767="+BuildShortLE(b, 0));
	b[0] = (byte)0x7f;
	b[1] = (byte)0xff;
	com.bbn.openmap.util.Debug.output("32767="+BuildShortBE(b, 0));
	b[1] = (byte)0xff;
	b[2] = (byte)0xff;
	b[3] = (byte)0xff;
	com.bbn.openmap.util.Debug.output("2147483647="+BuildIntegerBE(b, 0));
	com.bbn.openmap.util.Debug.output("maxuint="+signedToLong(0xffffffff));
    }
    */

    // rest of the file added by oa

    private static final double[] CACHED_X_DIV_Y_ANGLES = new double[1002];
    private static final double[] CACHED_Y_DIV_X_ANGLES = new double[1002];

    public static double atan2(double y, double x) {
        if (x == 0.0) return y >= 0 ? Math.PI / 2 : -Math.PI / 2;
        double res = atan(y / x);
        if (x < 0 && y >= 0) return Math.PI + res;
        if (x < 0 && y < 0) return res - Math.PI;
        return res;
    }

    public static double atan(double a) {
        if (a != a) return Double.NaN;
        double absA = Math.abs(a);
        boolean ydivx = absA <= 1.0;
        double permile = ydivx ? absA * 1000.0 : 1000.0 / absA;

        int permil1 = (int) permile;
        int permil2 = permil1 + 1;
        double value1 = permilAtan(permil1, ydivx);
        double value2 = permilAtan(permil2, ydivx);
        double res = value1 + (permile - permil1) * (value2 - value1);
        return a < 0 ? -res : res;
    }

    private static double permilAtan(int permil, boolean ydivx) {
        if (permil == 0 && ydivx) return 0.0;
        double[] cachedValues = ydivx ? CACHED_Y_DIV_X_ANGLES : CACHED_X_DIV_Y_ANGLES;
        double res = cachedValues[permil];
        if (res != 0.0) return res;
        double a = ydivx ? permil / 1000.0 : 1000.0 / permil;
        res = Math.atan(a);
        cachedValues[permil] = res;
        return res;
    }

    private static final double[] PER_THOUSAND_CACHED_ASIN = new double[1001];
    private static final double[] PER_HUNDERD_THOUSAND_ASIN = new double[3001];
    private static final double[] PER_TEN_MILLION_ASIN = new double[3001];
    private static final double[] PER_BILLION_ASIN = new double[3001];

    /**
     * 11 times (java 6) faster implementation of {@link Math#sin(double)}
     * accuracy of 0.001 degrees
     */
    public static double asin(double a) {
        //noinspection ConstantConditions
        if (a != a) return Double.NaN;
        if (a == 0.0) return 0.0;
        if (a == 1.0) return Math.PI / 2.0;
        if (a == -1.0) return -Math.PI / 2.0;
        if (a < -1.0 || a > 1.0) return Double.NaN;
        if (a <= -0.999997 || a >= 0.999997) return asin(PER_BILLION_ASIN, a, 1e9, 0.999997);
        if (a <= -0.9997 || a >= 0.9997) return asin(PER_TEN_MILLION_ASIN, a, 1e7, 0.9997);
        if (a <= -0.97 || a >= 0.97) return asin(PER_HUNDERD_THOUSAND_ASIN, a, 1e5, 0.97);
        return asin(PER_THOUSAND_CACHED_ASIN, a, 1000.0, 0.0);
    }

    private static double asin(double[] cachedValues, double a, double scale, double offset) {
        double absA = Math.abs(a);
        double scaledAbsA = (absA - offset) * scale;
        int pos1 = (int) scaledAbsA;
        int pos2 = pos1 + 1;
        double value1 = asin(cachedValues, pos1, scale, offset);
        double value2 = asin(cachedValues, pos2, scale, offset);
        double res = value1 + (scaledAbsA - pos1) * (value2 - value1);
        return a < 0 ? -res : res;
    }

    private static double asin(double[] cachedValues, int pos, double scale, double offset) {
        double res = cachedValues[pos];
        if (res != 0.0) return res;
        res = Math.asin(pos / scale + offset);
        cachedValues[pos] = res;
        return res;
    }
}

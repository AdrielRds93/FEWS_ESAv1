/* **********************************************************************
 * 
 *  BBNT Solutions LLC, A part of GTE
 *  10 Moulton St.
 *  Cambridge, MA 02138
 *  (617) 873-2000
 * 
 *  Copyright (C) 1998, 2000
 *  This software is subject to copyright protection under the laws of 
 *  the United States and other countries.
 * 
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/ProjectionPainter.java,v $
 * $Revision: 1.2 $
 * $Date: 2000/05/31 21:25:47 $
 * $Author: dietrick $
 * 
 * **********************************************************************
 */

package com.bbn.openmap;

import com.bbn.openmap.proj.Projection;
import java.awt.Graphics;

/**
 *  The ProjectionPainter interface is intended for objects that can
 *  manage graphics and draw them into a Java Graphics object.  The
 *  idea is that the ProjectionPainter, all within one thread, gathers
 *  the graphics that reside within the projection, and render them
 *  into the Graphics that has been set up for that projection.  The
 *  height and width of the projection should match the Graphics
 *  height and width, in case some of the graphics from the
 *  ProjectionPainter depend on them to place themselves within the
 *  Graphics.<P> This is different from the usual paradigm of OpenMap
 *  components.  Since OpenMap components are Swing components, they
 *  usually ready themselves, call repaint() on themselves, and then
 *  wait for the Swing thread to call paint and supply a Graphics
 *  object.  This leads to uncertainty as to when the painting is
 *  actually completed, which can be an issue if you are trying to
 *  create an image, or something like that.<P> Some layers kick off a
 *  SwingWorker thread to do the work.  If a layer is modified to
 *  implement this interface, the layer should do all the graphics
 *  collection work and rendering in the calling thread, so the caller
 *  knows that the contribution to the map from this ProjectionPainter
 *  is complete.
 */
public interface ProjectionPainter {

    /**
     * Given a projection and Graphics, paint graphic objects inside
     * the Graphics.  When this function returns, everything should be
     * all set.  
     * @param proj a com.bbn.openmap.proj.Projection that describes a map.
     * @param g a java.awt.Graphics to draw into.
     */
    public void renderDataForProjection(Projection proj, Graphics g);

}

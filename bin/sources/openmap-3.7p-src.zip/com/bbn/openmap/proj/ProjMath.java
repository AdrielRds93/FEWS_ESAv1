/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 *           restricted rights as set forth in the DFARS.
 *  
 *                         BBNT Solutions LLC
 *                            A Part of  
 *                               GTE      
 *                        10 Moulton Street
 *                       Cambridge, MA 02138
 *                          (617) 873-3000
 *  
 *        Copyright 1998-2000 by BBNT Solutions LLC,
 *              A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/proj/ProjMath.java,v $
 * $Revision: 1.14 $
 * $Date: 2000/05/08 14:23:25 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.proj;

import com.bbn.openmap.MoreMath;

/**
 * Math functions used by projection code.
 */
public final class ProjMath {

/**
     * North pole latitude in radians.
     */
    public final static transient double NORTH_POLE_D = MoreMath.HALF_PI_D;


    /**
     * South pole latitude in radians.
     */
    public final static transient double SOUTH_POLE_D = -NORTH_POLE_D;


    /**
     * Dateline longitude in radians.
     */
    public final static transient double DATELINE_D = Math.PI;



    /**
     * Longitude range in radians.
     */
    public final static transient double LON_RANGE_D = MoreMath.TWO_PI_D;


    // cannot construct
    private ProjMath() {}


    /**
     * rounds the quantity away from 0.
     * <p>
     * @param x in value
     * @return double
     * @see #qint(double)
     */
    final public static double roundAdjust(double x) {
	return qint_old(x);
    }


    /**
     * Rounds the quantity away from 0.
     * <p>
     * @param x value
     * @return double
     */
    final public static double qint(double x) {
	return qint_new(x);
    }


    final private static double qint_old(double x) {
	return (((int) x) < 0) ? (x - 0.5) : (x + 0.5);
    }
    final private static double qint_new(double x) {
	// -1 or +1 away from zero
	return (x <= 0.0) ? (x - 1.0) : (x + 1.0);
    }


    /**
     * Calculate the shortest arc distance btwn two lons.
     * <p>
     * @param lon1 radians
     * @param lon2 radians
     * @return double distance
     */
    final public static double lonDistance(double lon1, double lon2) {
	return Math.min(
	    Math.abs(lon1-lon2),
	    ((lon1 < 0) ? lon1+Math.PI : Math.PI-lon1) +
	    ((lon2 < 0) ? lon2+Math.PI : Math.PI-lon2)
	    );
    }

    /**
     * Convert between decimal degrees and scoords.
     * <p>
     * @param deg degrees
     * @return long scoords
     *
     */
    final public static long DEG_TO_SC (double deg) {
	return (long) (deg * 3600000);
    }


    /**
     * Convert between decimal degrees and scoords.
     * <p>
     * @param deg scoords
     * @return double decimal degrees
     *
     */
    final public static double SC_TO_DEG (int sc) {
	return ((double)(sc) / (60.0 * 60.0 * 1000.0));
    }


    /**
     * Convert radians to degrees.
     * <p>
     * @param rad radians
     * @return double decimal degrees
     */
    final public static double radToDeg (double rad) {
	return (rad * (180.0d / Math.PI));
    }


    /**
     * Convert degrees to radians.
     * <p/>
     *
     * @param deg degrees
     * @return double radians
     */
    final public static double degToRad(double deg) {
        return (deg * (Math.PI / 180.0d));
    }

    /**
     * Generate a hashCode value for a lat/lon pair.
     * <p>
     * @param lat latitude
     * @param lon longitude
     * @return int hashcode
     *
     */
    final public static int hashLatLon (double lat, double lon) {
	if (lat == -0d) lat = 0d;//handle negative zero (anything else?)
	if (lon == -0d) lon = 0d;
	long tmp = Double.doubleToLongBits(lat);
	long hash = (tmp<<5) | (tmp>>27);//rotate the lat bits
	return (int) (hash ^ Double.doubleToLongBits(lon));//XOR with lon
    }



    /**
     * Converts an array of decimal degrees double lat/lons to double
     * radians in place.
     * <p>
     * @param degs double[] lat/lons in decimal degrees
     * @return double[] lat/lons in radians
     */
    final public static double[] arrayDegToRad (double[] degs) {
	for (int i=0; i<degs.length; i++) {
	    degs[i] = degToRad(degs[i]);
	}
	return degs;
    }


    /**
     * Converts an array of radian double lat/lons to decimal degrees
     * in place.
     * <p>
     * @param rads double[] lat/lons in radians
     * @return double[] lat/lons in decimal degrees
     */
    final public static double[] arrayRadToDeg (double[] rads) {
	for (int i=0; i<rads.length; i++) {
	    rads[i] = radToDeg(rads[i]);
	}
	return rads;
    }

    /**
     * Sets radian longitude to something sane.
     * <p>
     * @param lon double longitude in radians
     * @return double longitude (-PI &lt;= lambda &lt; PI)
     * @see com.bbn.openmap.LatLonPoint#wrap_longitude(double)
     */
    public final static double wrap_longitude (double lon) {
	if ((lon < -DATELINE_D) || (lon > DATELINE_D)) {
	    lon += DATELINE_D;
	    lon = (lon % LON_RANGE_D);
	    lon += (lon < 0) ? DATELINE_D : -DATELINE_D;
	}
	return lon;
    }


    /**
     * Converts units (km, nm, miles, etc) to decimal degrees for a spherical
     * planet.
     * This does not check for arc distances &gt; 1/2 planet circumference,
     * which are better represented as (2pi - calculated arc).
     * @param u units double value
     * @param uCircumference units circumference of planet
     * @return double decimal degrees
     */
    final public static double sphericalUnitsToDeg (
	    double u, double uCircumference)
    {
	return 360d*(u/uCircumference);
    }


    /**
     * Converts units (km, nm, miles, etc) to arc radians for a spherical
     * planet.
     * This does not check for arc distances &gt; 1/2 planet circumference,
     * which are better represented as (2pi - calculated arc).
     * @param u units double value
     * @param uCircumference units circumference of planet
     * @return double arc radians
     */
    final public static double sphericalUnitsToRad (
	    double u, double uCircumference)
    {
	return MoreMath.TWO_PI*(u/uCircumference);
    }


    /**
     * Calculate the geocentric latitude given a geographic latitude.
     * According to John Synder:<br>
     * "The geographic or geodetic latitude is the angle which a line
     * perpendicular to the surface of the ellipsoid at the given point makes
     * with the plane of the equator.  ...The geocentric latitude is the angle
     * made by a line to the center of the ellipsoid with the equatorial
     * plane". (<i>Map Projections --A Working Manual</i>, p 13)
     * <p>
     * Translated from Ken Anderson's lisp code <i>Freeing the Essence of
     * Computation</i>
     * @param lat double geographic latitude in radians
     * @param flat double flatening factor
     * @return double geocentric latitude in radians
     * @see #geographic_latitude
     */
    public final static double geocentric_latitude (double lat, double flat) {
	double f = 1.0d - flat;
	return Math.atan((f*f) * Math.tan(lat));
    }


    /**
     * Calculate the geographic latitude given a geocentric latitude.
     * Translated from Ken Anderson's lisp code <i>Freeing the Essence of
     * Computation</i>
     * @param lat double geocentric latitude in radians
     * @param flat double flatening factor
     * @return double geographic latitude in radians
     * @see #geocentric_latitude
     */
    public final static double geographic_latitude (double lat, double flat) {
	double f = 1.0d - flat;
	return Math.atan(Math.tan(lat) / (f*f));
    }


    /*
    public static void main(String[] args) {
	double degs = sphericalUnitsToRad(
		Planet.earthEquatorialRadius/2,
		Planet.earthEquatorialRadius);
	Debug.output("degs = " + degs);
	double LAT_DEC_RANGE = 90.0d;
	double LON_DEC_RANGE = 360.0d;
	double lat, lon;
	for (int i = 0; i < 100; i++) {
	    lat = com.bbn.openmap.LatLonPoint.normalize_latitude(
		    (double)Math.random()*LAT_DEC_RANGE);
	    lon = com.bbn.openmap.LatLonPoint.wrap_longitude(
		    (double)Math.random()*LON_DEC_RANGE);
	    Debug.output(
		    "(" + lat + "," + lon + ") : (" +
		    degToRad(lat) + "," + degToRad(lon) + ") : (" +
		    radToDeg(degToRad(lat)) + "," + radToDeg(degToRad(lon)) +
		    ")");
	}
    }
    */
}

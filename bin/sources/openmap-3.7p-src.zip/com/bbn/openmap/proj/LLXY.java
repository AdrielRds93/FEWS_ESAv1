/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 *           restricted rights as set forth in the DFARS.
 *  
 *                         BBNT Solutions LLC
 *                            A Part of  
 *                               GTE      
 *                        10 Moulton Street
 *                       Cambridge, MA 02138
 *                          (617) 873-3000
 *  
 *        Copyright 1998-2000 by BBNT Solutions LLC,
 *              A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/proj/LLXY.java,v $
 * $Revision: 1.3 $
 * $Date: 2000/05/08 14:23:24 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.proj;

import com.bbn.openmap.LatLonPoint;
import com.bbn.openmap.util.Debug;

import java.awt.Point;


/**
 * Implements the LLXY projection.
 */
public class LLXY extends Cylindrical {

    /**
     * The LLXY name.
     */
    public final static transient String LLXYName = "LLXY";

    /**
     * The LLXY type of projection.
     */
    public final static transient int LLXYType = 6304;

    // world<->screen coordinate offsets
    protected int hy, wx;
    protected double cLon;
    protected double llscale;
    
    /**
     * Construct a LLXY projection.
     * <p>
     * @param center LatLonPoint center of projection
     * @param scale double scale of projection
     * @param width width of screen
     * @param height height of screen
     *
     */
    public LLXY (LatLonPoint center, double scale, int width, int height)
    {
	super(center, scale, width, height, LLXYType);
    }

    public LLXY (LatLonPoint center, double scale, int width, int height,
		 int type)
    {
	super(center, scale, width, height, type);
    }


//    protected void finalize() {
//	Debug.message("LLXY", "LLXY finalized");
//    }


    /**
     * Return stringified description of this projection.
     * <p>
     * @return String
     * @see Projection#getProjectionID
     *
     */
    public String toString() {
	return "LLXY[" + super.toString();
    }


    /**
     * Called when some fundamental parameters change.
     * <p>
     * Each projection will decide how to respond to this change.
     * For instance, they may need to recalculate "constant" paramters
     * used in the forward() and inverse() calls.<p>
     *
     */
    protected void computeParameters() {
	Debug.message("LLXY", "LLXY.computeParameters()");
	super.computeParameters();

	// compute the offsets
	hy = height/2;
	wx = width/2;
	cLon = ProjMath.radToDeg(ctrLon);
	llscale = scale * .000000006;
    }


    /**
     * Sets radian latitude to something sane.  This is an abstract
     * function since some projections don't deal well with extreme
     * latitudes.<p>
     *
     * @param lat double latitude in radians
     * @return double latitude (-PI/2 &lt;= y &lt;= PI/2)
     * @see com.bbn.openmap.LatLonPoint#normalize_latitude(double)
     *
     */
    public double normalize_latitude(double lat) {
	if (lat > NORTH_POLE) {
	    return NORTH_POLE;
	} else if (lat < SOUTH_POLE) {
	    return SOUTH_POLE;
	}
	return lat;
    }

    /**
     * Checks if a LatLonPoint is plot-able.
     * <p>
     * A point is always plot-able in the LLXY projection.
     * <p>
     * @param lat double latitude in decimal degrees
     * @param lon double longitude in decimal degrees
     * @return boolean
     */
    public boolean isPlotable(double lat, double lon) {
	return true;
    }


    /**
     * Projects a point from Lat/Lon space to X/Y space.
     * <p>
     * @param pt LatLonPoint
     * @param p Point retval
     * @return Point p
     */
    public Point forward (LatLonPoint pt, Point p) {
	// same as forward_x and forward_y, and convert to screen coords
	
	p.x = (int) (wx + Math.round((pt.getLongitude() - cLon) / llscale));
	p.y = (int) (hy - Math.round(pt.getLatitude() / llscale));

  	if (Debug.debugging("LLXYf")) {
	    Debug.out.println("LLXY.forward(pt.lon_:" + pt.getLongitude()
			       + ", pt.lat_:" + pt.getLatitude() + ")" );
	    Debug.out.println("LLXY.forward   x:" + p.x + ", y:" + p.y);
	}
	return p;
    }


    /**
     * Forward projects a lat,lon coordinates.
     * <p>
     * @param lat raw latitude in decimal degrees
     * @param lon raw longitude in decimal degrees
     * @param p Resulting XY Point
     * @return Point p
     */
    public Point forward (double lat, double lon, Point p) {
	// same as forward_x and forward_y, and convert to screen coords
	p.x = (int) (wx + Math.round((lon - cLon) / llscale));
	p.y = (int) (hy - Math.round(lat / llscale));

  	if (Debug.debugging("LLXYf")) {
	    Debug.out.println("LLXY.forward(lon:" + lon
			       + ", lat:" + lat+  ")");
	    Debug.out.println("LLXY.forward   x:" + p.x + ", y:" + p.y +
			       " ctrLon:" + cLon + " wx:" + wx + " hy:" + hy);
	}
	return p;
    }


    /**
     * Forward projects lat,lon into XY space and returns a Point.
     * <p>
     * @param lat double latitude in radians
     * @param lon double longitude in radians
     * @param p Resulting XY Point
     * @param isRadian bogus argument indicating that lat,lon
     * arguments are in radians
     * @return Point p
     */
    public Point forward (
	double lat, double lon, Point p, boolean isRadian)
    {
	// same as forward_x and forward_y, and convert to screen coords
	p.x = (int) (wx + Math.round((ProjMath.radToDeg(lon) - cLon) / llscale));
	p.y = (int) (hy - Math.round(ProjMath.radToDeg(lat) / llscale));
  	if (Debug.debugging("LLXYf")) {
	    Debug.out.println("LLXY.forward(lon:" + ProjMath.radToDeg(lon)
  		      + ", lat:" + ProjMath.radToDeg(lat) + " isRadian:" + isRadian + ")");
	    Debug.out.println("LLXY.forward   x:" + p.x + ", y:" + p.y
			       + " scale: " + scale + " llscale:" + llscale);
	}
	return p;
    }


    /**
     * Inverse project a Point.
     * <p>
     * @param point x,y Point
     * @param llp resulting LatLonPoint
     * @return LatLonPoint llp
     *
     */
    public LatLonPoint inverse (Point pt, LatLonPoint llp) {
	// convert from screen to world coordinates
	int x = pt.x - wx;
	int y = hy - pt.y;

	// inverse project
	llp.setLatitude((double)y * llscale);
	llp.setLongitude((((double)x) + cLon) * llscale);

	return llp;
    }


    /**
     * Inverse project x,y coordinates into a LatLonPoint.
     * <p>
     * @param x integer x coordinate
     * @param y integer y coordinate
     * @param llp LatLonPoint
     * @return LatLonPoint llp
     * @see Proj#inverse(Point)
     *
     */
    public LatLonPoint inverse (int x, int y, LatLonPoint llp) {
	// convert from screen to world coordinates
	x -= wx;
	y = hy - y;

	// inverse project
	llp.setLatitude((double)y * llscale);
	llp.setLongitude((((double)x) + cLon) * llscale);

	return llp;
    }
}

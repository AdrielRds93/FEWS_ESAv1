/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/proj/LineType.java,v $
 * $Revision: 1.3 $
 * $Date: 2000/05/08 14:23:24 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.proj;

/**
 * LineType constants.
 */
public final class LineType {

    // cannot construct
    private LineType () {}

    /**
     * Straight lines are the easiest and fastest to draw.  Use them
     * if you're concerned about speed of projecting.
     */
    final public static transient int Straight = 1;

    /**
     * Rhumb lines follow a constant bearing.
     */
    final public static transient int Rhumb = 2;

    /**
     * Great circle lines follow the shortest path between two points
     * on a sphere.
     */
    final public static transient int GreatCircle = 3;
}

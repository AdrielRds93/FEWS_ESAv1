/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998-2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/proj/ProjectionFactory.java,v $
 * $Revision: 1.10 $
 * $Date: 2000/07/27 14:43:50 $
 * $Author: dietrick $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.proj;

import com.bbn.openmap.LatLonPoint;


/**
 * Create Projections.
 *
 */
public class ProjectionFactory {

    private ProjectionFactory(){}

    protected static LatLonPoint llp = new LatLonPoint();

    /**
     * Create a projection.
     * <p>
     * @param projType projection type
     * @param centerLat center latitude in decimal degrees
     * @param centerLon center latitude in decimal degrees
     * @param scale double scale
     * @param width pixel width of projection
     * @param height pixel height of projection
     * @return Projection
     *
     */
    public static Projection makeProjection (int projType,
					     double centerLat,
					     double centerLon,
					     double scale,
					     int width,
					     int height)
    {
	llp.setLatLon(centerLat, centerLon);
	switch (projType) {
	    case CADRG.CADRGType:
		return new CADRG(llp, scale, width, height);
	    case Mercator.MercatorType:
		return new Mercator(llp, scale, width, height);
	    case MercatorView.MercatorViewType:
		return new MercatorView(llp, scale, width, height);
	    case LLXY.LLXYType:
		return new LLXY(llp, scale, width, height);
	    case LLXYView.LLXYViewType:
		return new LLXYView(llp, scale, width, height);
	    case Orthographic.OrthographicType:
		return new Orthographic(llp, scale, width, height);
	    case OrthographicView.OrthographicViewType:
		return new OrthographicView(llp, scale, width, height);
//	    case MassStatePlane.MassStatePlaneType:
//	        return new MassStatePlane(llp, scale, width, height);
	    case Gnomonic.GnomonicType:
		return new Gnomonic(llp, scale, width, height);
	    default:
		System.err.println("Unknown projection type " + projType +
				   " in ProjectionFactory.create()");
		return null;
	}
    }


    /**
     * Makes a new projection based on the given projection and given type.
     * <p>
     * The <code>centerLat</code>, <code>centerLon</code>, <code>scale</code>,
     * <code>width</code>, and <code>height</code> parameters are taken from
     * the given projection, and the type is taken from the type argument.
     * <p>
     * @param newProjType the type for the resulting projection
     * @param p the projection from which to copy other parameters
     */
    public static Projection makeProjection (int newProjType, Projection p) {
	LatLonPoint ctr = p.getCenter();
	return makeProjection(newProjType,
			      ctr.getLatitude(), ctr.getLongitude(),
			      p.getScale(), p.getWidth(), p.getHeight());
    }

    /** 
     * Return an int representing the OpenMap projection, given the
     * name of the projection. Useful for setting a projection based
     * on the name stated in a properties file.
     */
    public static int getProjType(String projName){

	int projType = Mercator.MercatorType;

	if (projName == null){}
	else if (projName.equalsIgnoreCase(Mercator.MercatorName))
	    projType = Mercator.MercatorType;
	else if (projName.equalsIgnoreCase(MercatorView.MercatorViewName))
	    projType = MercatorView.MercatorViewType;
	else if (projName.equalsIgnoreCase(Orthographic.OrthographicName))
	    projType = Orthographic.OrthographicType;
	else if (projName.equalsIgnoreCase(OrthographicView.OrthographicViewName))
	    projType = OrthographicView.OrthographicViewType;
	else if (projName.equalsIgnoreCase(LLXY.LLXYName))
	    projType = LLXY.LLXYType;
	else if (projName.equalsIgnoreCase(LLXYView.LLXYViewName))
	    projType = LLXYView.LLXYViewType;
	else if (projName.equalsIgnoreCase(CADRG.CADRGName))
	    projType = CADRG.CADRGType;
	else if (projName.equalsIgnoreCase(Gnomonic.GnomonicName))
	    projType = Gnomonic.GnomonicType;

	return projType;
    }

}

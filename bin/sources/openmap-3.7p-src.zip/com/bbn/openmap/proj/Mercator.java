/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 *           restricted rights as set forth in the DFARS.
 *  
 *                         BBNT Solutions LLC
 *                            A Part of  
 *                               GTE      
 *                        10 Moulton Street
 *                       Cambridge, MA 02138
 *                          (617) 873-3000
 *  
 *        Copyright 1998-2000 by BBNT Solutions LLC,
 *              A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/proj/Mercator.java,v $
 * $Revision: 1.22 $
 * $Date: 2000/05/08 14:23:24 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.proj;

import com.bbn.openmap.LatLonPoint;
import com.bbn.openmap.MoreMath;
import com.bbn.openmap.util.Debug;

import java.awt.*;


/**
 * Implements the Mercator projection.
 */
public class Mercator extends Cylindrical {

    /**
     * The Mercator name.
     */
    public final static transient String MercatorName = "Mercator";

    /**
     * The Mercator type of projection.
     */
    public final static transient int MercatorType = 2;

    // maximum number of segments to draw for rhumblines.
    protected static int MAX_RHUMB_SEGS = 512;

    // HACK epsilon: skirt the edge of the infinite.  If this is too small
    // then we get too close to +-INFINITY when we forward project.  Tweak
    // this if you start getting Infinity or NaN's for forward().
    protected static double epsilon = 0.01d;

    // world<->screen coordinate offsets
    protected int hy, wx;

    // almost constant projection parameters
    protected double tanCtrLat;
    protected double asinh_of_tanCtrLat;

       
    /**
     * Construct a Mercator projection.
     * <p>
     * @param center LatLonPoint center of projection
     * @param scale double scale of projection
     * @param width width of screen
     * @param height height of screen
     *
     */
    public Mercator (LatLonPoint center, double scale, int width, int height)
    {
	super(center, scale, width, height, MercatorType);
    }

    public Mercator (LatLonPoint center, double scale, int width, int height, int type)
    {
	super(center, scale, width, height, type);
    }


//    protected void finalize() {
//	Debug.message("mercator", "Mercator finalized");
//    }


    /**
     * Return stringified description of this projection.
     * <p>
     * @return String
     * @see Projection#getProjectionID
     *
     */
    public String toString() {
	return "Mercator[" + super.toString();
    }


    /**
     * Called when some fundamental parameters change.
     * <p>
     * Each projection will decide how to respond to this change.
     * For instance, they may need to recalculate "constant" paramters
     * used in the forward() and inverse() calls.<p>
     *
     */
    protected void computeParameters() {
	Debug.message("mercator", "Mercator.computeParameters()");
	super.computeParameters();

	// do some precomputation of stuff
	tanCtrLat = Math.tan(ctrLat);
	asinh_of_tanCtrLat = MoreMath.asinh(tanCtrLat);

	// compute the offsets
	hy = height/2;
	wx = width/2;
    }


    /**
     * Sets radian latitude to something sane.  This is an abstract
     * function since some projections don't deal well with extreme
     * latitudes.<p>
     *
     * @param lat double latitude in radians
     * @return double latitude (-PI/2 &lt;= y &lt;= PI/2)
     * @see com.bbn.openmap.LatLonPoint#normalize_latitude(double)
     *
     */
    public double normalize_latitude(double lat) {
	if (lat > NORTH_POLE - epsilon) {
	    return NORTH_POLE - epsilon;
	} else if (lat < SOUTH_POLE + epsilon) {
	    return SOUTH_POLE + epsilon;
	}
	return lat;
    }

//    protected double forward_x(double lambda) {
//	return scaled_radius * wrap_longitude(lambda - ctrLon) + (double)wx;
//    }

//    protected double forward_y(double phi) {
//	return (double)hy - (scaled_radius *
//	    (MoreMath.asinh((double)Math.tan(phi)) -
// 	     asinh_of_tanCtrLat));
//    }


    /**
     * Checks if a LatLonPoint is plot-able.
     * <p>
     * A point is always plot-able in the Mercator projection (even the North
     * and South poles since we normalize latitude).
     * <p>
     * @param lat double latitude in decimal degrees
     * @param lon double longitude in decimal degrees
     * @return boolean
     */
    public boolean isPlotable(double lat, double lon) {
	return true;
    }


    /**
     * Projects a point from Lat/Lon space to X/Y space.
     * <p>
     * @param pt LatLonPoint
     * @param p Point retval
     * @return Point p
     */
    public Point forward (LatLonPoint pt, Point p) {
	// first convert to radians, and handle infinity
	double phi = normalize_latitude(pt.radlat_);
	double lambda = pt.radlon_;	// already wrapped

	// same as forward_x and forward_y, and convert to screen coords
	p.x = (int) (Math.round(scaled_radius * wrap_longitude(lambda - ctrLon)) + wx);
	p.y = (int) (hy - Math.round(scaled_radius *
                      (MoreMath.asinh(Math.tan(phi)) -
                       asinh_of_tanCtrLat)));
	return p;
    }


    /**
     * Forward projects a lat,lon coordinates.
     * <p>
     * @param lat raw latitude in decimal degrees
     * @param lon raw longitude in decimal degrees
     * @param p Resulting XY Point
     * @return Point p
     */
    public Point forward (double lat, double lon, Point p) {
	// first convert to radians, and normalize
	double phi = normalize_latitude(ProjMath.degToRad(lat));
	double lambda = wrap_longitude(ProjMath.degToRad(lon));

	// same as forward_x and forward_y, and convert to screen coords
	p.x = (int) (Math.round(scaled_radius * wrap_longitude(lambda - ctrLon)) + wx);
	p.y = (int) (hy - Math.round(scaled_radius *
                      (MoreMath.asinh(Math.tan(phi)) -
                       asinh_of_tanCtrLat)));
	return p;
    }


    /**
     * Forward projects lat,lon into XY space and returns a Point.
     * <p>
     * @param lat double latitude in radians
     * @param lon double longitude in radians
     * @param p Resulting XY Point
     * @param isRadian bogus argument indicating that lat,lon
     * arguments are in radians
     * @return Point p
     */
    public Point forward (
	double lat, double lon, Point p, boolean isRadian)
    {
	// first normalize
	double phi = normalize_latitude(lat);
	double lambda = wrap_longitude(lon);

	// same as forward_x and forward_y, and convert to screen coords
	p.x = (int) (Math.round(scaled_radius * wrap_longitude(lambda - ctrLon)) + wx);
	p.y = (int) (hy - Math.round(scaled_radius *
                      (MoreMath.asinh(Math.tan(phi)) -
                       asinh_of_tanCtrLat)));
	return p;
    }


    /**
     * Inverse project a Point.
     * <p>
     * @param point x,y Point
     * @param llp resulting LatLonPoint
     * @return LatLonPoint llp
     *
     */
    public LatLonPoint inverse (Point pt, LatLonPoint llp) {
	// convert from screen to world coordinates
	int x = pt.x - wx;
	int y = hy - pt.y;

	// inverse project
 	double wc = asinh_of_tanCtrLat * scaled_radius;
	llp.setLatitude(ProjMath.radToDeg(
            MoreMath.atan(MoreMath.sinh((y + wc)/scaled_radius))));
	llp.setLongitude(ProjMath.radToDeg(
		(double)x / scaled_radius + ctrLon));

	return llp;
    }


    /**
     * Inverse project x,y coordinates into a LatLonPoint.
     * <p>
     * @param x integer x coordinate
     * @param y integer y coordinate
     * @param llp LatLonPoint
     * @return LatLonPoint llp
     * @see Proj#inverse(Point)
     *
     */
    public LatLonPoint inverse (int x, int y, LatLonPoint llp) {
	// convert from screen to world coordinates
	x -= wx;
	y = hy - y;

	// inverse project
 	double wc = asinh_of_tanCtrLat * scaled_radius;
	llp.setLatitude(ProjMath.radToDeg(
            MoreMath.atan(MoreMath.sinh((y + wc)/scaled_radius))));
	llp.setLongitude(ProjMath.radToDeg(
		(double)x / scaled_radius + ctrLon));

	return llp;
    }


    /**
     * Computes the best stepping factor for a rhumbline.
     * <p>
     * Computes the best stepping factor between two x,y points in
     * order to interpolate points on a rhumb line.  (We calculate
     * rhumb lines by forward projecting the line in the Mercator
     * projection, and then calculating segments along the straight
     * line between them.)
     * <p>
     * @param pt1 Point
     * @param pt2 Point
     * @return int number of points to use
     *
     */
    protected final static int rhumbStep(Point pt1, Point pt2) {
	int step = (int)DrawUtil.distance(pt1.x, pt1.y, pt2.x, pt2.y);

	if (step > 8192) {
	    step = 512;
	} else {
	    step >>= 3;// step/8
	}
	return (step == 0) ? 1 : step;
    }


    /**
     * Calculates the points along a rhumbline between two XY points.
     * <p>
     * Loxodromes are straight in the Mercator projection.  Calculate
     * a bunch of extra points between the two points, inverse project
     * back into LatLons and return all the vertices.
     * @param from Point
     * @param to Point
     * @param include_last include the very last point?
     * @param nsegs number of segments
     * @return double[] of lat, lon, lat, lon, ... in RADIANS!
     */
    protected double[] rhumbProject(
	    Point from, Point to, boolean include_last, int nsegs)
    {

	// calculate pixel distance
	if (nsegs < 1) {
	    // dynamically calculate the number of segments to draw
	    nsegs = DrawUtil.pixel_distance(
		    from.x, from.y, to.x, to.y)>>3;// /8
	    if (nsegs == 0)
		nsegs = 1;
	    else if (nsegs > MAX_RHUMB_SEGS)
		nsegs = MAX_RHUMB_SEGS;
	}

//	Debug.output(
//		"from=("+from.x+","+from.y+")to=("+to.x+","+to.y+")");
	LatLonPoint llp = inverse(from.x, from.y, new LatLonPoint());
	LatLonPoint llp2 = inverse(to.x, to.y, new LatLonPoint());
//	Debug.output(
//		"invfrom=("+llp.getLatitude()+","+llp.getLongitude()+
//		")invto=("+llp2.getLatitude()+","+llp2.getLongitude()+")");
//	Debug.output("nsegs="+nsegs);
	// calculate nsegs(+1) extra vertices between endpoints
	int[] xypts =
	    DrawUtil.lineSegments(
		    from.x, from.y,	// coords
		    to.x, to.y,
		    nsegs,		// number of segs between
		    include_last,	// include last point
		    new int[nsegs<<1]	// retval
		    );

	double[] llpts = new double[xypts.length];
	for (int i=0; i<llpts.length; i+=2) {
//	    System.out.print("("+xypts[i]+","+xypts[i+1]+")");
	    inverse(xypts[i], xypts[i+1], llp);
	    llpts[i] = llp.radlat_;
	    llpts[i+1] = llp.radlon_;
	}
//	Debug.output("");
	return llpts;
    }


    // -------------------------------------------------------------

    /*
    public void testPoint(double lat, double lon) {
	double x, y;
	lon = wrap_longitude(ProjMath.degToRad(lon));
	lat = normalize_latitude(ProjMath.degToRad(lat));
	x = forward_x(lon) - (double)wx;
	y = (double)hy - forward_y(lat);

	Debug.output(
		"(lon="+ProjMath.radToDeg(lon)+",lat="+ ProjMath.radToDeg(lat)+
		") = (x="+x+",y="+y+")");
	lat = inverse_lat((double)hy-y);
	lon = wrap_longitude(inverse_lon(x+(double)wx));
	Debug.output(
		"(x="+x+",y="+y+") = (lon="+
		ProjMath.radToDeg(lon)+",lat="+ProjMath.radToDeg(lat)+")");
    }

    public static void main (String argv[]) {
	Mercator proj=null;
// 	proj = new Mercator(new LatLonPoint(0.0d, -180.0d), 1.0d, 620, 480);
	proj = new Mercator(new LatLonPoint(0.0d, 0.0d), 1.0d, 620, 480);

	// test on unit circle
	proj.setEarthRadius(1.0d);
	Debug.output("setEarthRadius("+proj.getEarthRadius()+")");
	proj.setPPM(1);
	Debug.output("setPPM("+proj.getPPM()+")");
	proj.setScale(1.0d);
	Debug.output("setScale("+proj.getScale()+")");
	Debug.output(proj);

	Debug.output("---testing latitude");
	proj.testPoint(0.0d, 0.0d);
	proj.testPoint(10.0d, 0.0d);
	proj.testPoint(40.0d, 0.0d);
	proj.testPoint(-85.0d, 0.0d);
	proj.testPoint(-80.0d, 0.0d);
	proj.testPoint(-90.0d, 0.0d);
	proj.testPoint(100.0d, 0.0d);
	proj.testPoint(-3272.0d, 0.0d);
	Debug.output("---testing longitude");
	proj.testPoint(0.0d, 10.0d);
	proj.testPoint(0.0d, -10.0d);
	proj.testPoint(0.0d, 90.0d);
	proj.testPoint(0.0d, -90.0d);
	proj.testPoint(0.0d, 175.0d);
	proj.testPoint(0.0d, -175.0d);
	proj.testPoint(0.0d, 180.0d);
	proj.testPoint(0.0d, -180.0d);
	proj.testPoint(0.0d, 190.0d);
	proj.testPoint(0.0d, -190.0d);
	proj.testPoint(0.0d, 370.0d);
	proj.testPoint(0.0d, -370.0d);
	proj.testPoint(0.0d, 550.0d);
	proj.testPoint(0.0d, -550.0d);

	double LAT_RANGE = (double)Math.PI;
	double LON_RANGE = (double)Math.PI*2f;
	double HALF_LAT = (double)Math.PI/2f;
	double HALF_LON = (double)Math.PI;

	System.out.print("timing forward: ");
	long start = System.currentTimeMillis();
	for (int i = 0; i< 100000; i++) {
	    proj.forward_x((double)Math.random()*LON_RANGE-HALF_LON);
	    proj.forward_y((double)Math.random()*LAT_RANGE-HALF_LAT);
	}
	long stop = System.currentTimeMillis();
	Debug.output((stop - start)/1000.0d + " seconds.");
    }
    */
}

/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 *           restricted rights as set forth in the DFARS.
 *  
 *                         BBNT Solutions LLC
 *                            A Part of  
 *                               GTE      
 *                        10 Moulton Street
 *                       Cambridge, MA 02138
 *                          (617) 873-3000
 *  
 *        Copyright 1998-2000 by BBNT Solutions LLC,
 *              A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/proj/unimplemented/LambertConformalConic.java,v $
 * $Revision: 1.5 $
 * $Date: 2000/05/08 14:23:27 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.proj;

import com.bbn.openmap.LatLonPoint;
import com.bbn.openmap.util.Debug;

import java.awt.Point;


/**
 * Implements the LambertConformalConic projection.
 *
 * @author Don Dietrick
 */
public class LambertConformalConic extends com.bbn.openmap.proj.Conic {

    /**
     * The LambertCC name.
     */
    public final static transient String LambertCCName = "LambertCC";

    /**
     * The LambertCC type of projection.
     */
    public final static transient int LambertCCType = 99;

    protected int hy, wx;
    protected double n;
    protected double F;
    protected double Po;
    protected double RF;
    protected double quarterPI = Math.PI/ 4.0;
    protected double halfPI = Math.PI/ 2.0;

    /**
     * Construct a Lambert projection.
     * <p>
     * @param center LatLonPoint center of projection
     * @param scale double scale of projection
     * @param width width of screen
     * @param height height of screen
     *
     */
    public LambertConformalConic(LatLonPoint center, double scale,
				 int width, int height)
    {
	super(center, scale, width, height, LambertCCType);
    }


    //  Should never be called, except for testing.  All values are
    //  MSP defined.
    /*
    protected void computeLCCParameters() {
      Debug.message("proj", "LambertConformalConic.computeLCCParameters() with: h-" + 
		    height + "|w-" + width);

	//HACK - hardcoded MASS State Plane values - These should be
	//defined in all State Plane files that are created, and the
	//computeParameters function should call it in that State
	//Plane File.
 	origin = new LatLonPoint(41.0d, -71.30d);
	parallel1 = new LatLonPoint(41.43f, 0);
	parallel2 = new LatLonPoint(42.41f, 0);

	double p1tan = Math.tan((parallel1.radlat_/2.0) + quarterPI);
	double p2tan = Math.tan((parallel2.radlat_/2.0) + quarterPI);
	double lp2p1tan = Math.log(p2tan/p1tan);
	double p1cos = Math.cos(parallel1.radlat_);
	double p2cos = Math.cos(parallel2.radlat_);
	double lp1p2cos = Math.log(p1cos/p2cos);
	n = lp1p2cos/lp2p1tan;

	F = Math.cos(parallel1.radlat_)*
	  Math.pow(Math.tan(quarterPI + (parallel1.radlat_/2.0)), n)/ n;

	RF = F*EARTH_RADIUS * PPM/scale;
	Po = RF / Math.pow(Math.tan(quarterPI + (origin.radlat_/2.0)), n);

	hy = (int)forward_y(ctrLat, ctrLon) + height/2;
	wx = width/2 - (int)forward_x(ctrLat, ctrLon);

	Debug.message("proj", "computeLCCParameters():\n     Origin = " + 
		      origin.getLatitude() + "," + origin.getLongitude() + 
		      "\n     scale = " + scale +
		      "\n     center = " + ProjMath.radToDeg(ctrLat) + 
		      ", " + ProjMath.radToDeg(ctrLon) +
		      "\n     parallel1 = " + parallel1 + 
		      "\n     parallel2 = " + parallel2 + 
		      "\n     n = " + (double)n + 
		      "\n     F = " + (double)F + 
		      "\n     RF = " + (double)RF + 
		      "\n     Po = " + (double)Po +
		      "\n     hy = " + hy + 
		      "\n     wx = " + wx);

    }
    */
 

    /**
     * Sets radian latitude to something sane.  This is an abstract
     * function since some projections don't deal well with extreme
     * latitudes.<p>
     *
     * @param lat double latitude in radians
     * @return double latitude (-PI/2 &lt;= y &lt;= PI/2)
     * @see com.bbn.openmap.LatLonPoint#normalize_latitude(double)
     *
     */
    public double normalize_latitude(double lat) {
	if (lat > NORTH_POLE) {
	    return NORTH_POLE;
	} else if (lat < SOUTH_POLE) {
	    return SOUTH_POLE;
	}
	return lat;
    }

    /** forward_x() - arguments in radians (-DATELINE <= lambda <
        DATELINE), (SOUTH_POLE <= phi <= NORTH_POLE), returns a raw
        double in world coordinates. */
    protected double forward_x(double phi, double lambda) {
        double diff = (double)(lambda-origin.radlon_);
	if (diff > halfPI) diff -= Math.PI;
	if (diff < -halfPI) diff += Math.PI;
        double theta = n* diff;
	double sintheta = Math.sin(theta);
	double rho = RF/(Math.pow(Math.tan(quarterPI + phi/2.0d), n));

	if (Debug.debugging("proj")){
	    Debug.output("LambertConformalConic.forward_x:\n   phi = " + 
			 ProjMath.radToDeg(phi) + 
			 "\n   lambda = " +  ProjMath.radToDeg(lambda) + 
			 "\n   origin = " + origin.getLatitude() +
			 "," + origin.getLongitude() + 
			 "\n   rho = " + rho + 
			 "\n   theta = " + ProjMath.radToDeg(theta));
	}
	return rho * sintheta;
    }

    /** forward_y() - arguments in radians (-DATELINE <= lambda <
        DATELINE), (SOUTH_POLE <= phi <= NORTH_POLE), returns a raw
        double value in world coordinates. */
    protected double forward_y(double phi, double lambda) {
        double diff = (double)(lambda-origin.radlon_);
	if (diff > halfPI) diff -= Math.PI;
	if (diff < -halfPI) diff += Math.PI;
        double theta = n* diff;
	double costheta = Math.cos(theta);
	double rho = RF/Math.pow(Math.tan(quarterPI + phi/2.0d), n);

	if (Debug.debugging("proj")){
	    Debug.output("LambertConformalConic.forward_y:\n   phi = " +  
			 ProjMath.radToDeg(phi) + 
			 "\n   lambda = " +  ProjMath.radToDeg(lambda) + 
			 "\n   origin = " + origin.getLatitude() +
			 "," + origin.getLongitude() + 
			 "\n   rho = " + rho + 
			 "\n   theta = " + ProjMath.radToDeg(theta));
	}

	return Po - (rho * costheta);
    }

    /** inverse_lat(x, y) - assumes raw double values in world
     *  coordinates. */
    protected double inverse_lat(double x, double y) {
        double diff = Po - y;
        double rho = Math.sqrt(x*x + (diff * diff));
	return 2.0 * Math.atan(Math.pow((RF/rho), 1/n)) - halfPI;
    }

    /** inverse_lon(x, y) - assumes raw double values in world
     * coordinates. */
    protected double inverse_lon(double x, double y) {
        double theta = Math.atan(x /(Po - y));
	return theta/n + origin.radlon_;
    }

    /**
     * Checks if a LatLonPoint is plot-able.
     * <p>
     * @param lat double latitude in decimal degrees
     * @param lon double longitude in decimal degrees
     * @return boolean
     */
    public boolean isPlotable(double lat, double lon) {
	return true;// not really sure about this...
    }

    /**
     * Projects a point from Lat/Lon space to X/Y space.
     * <p>
     * @param pt LatLonPoint
     * @param p Point retval
     * @return Point p
     */
    public Point forward (LatLonPoint pt, Point p) {
	return forward(pt.radlat_, pt.radlon_, p, true);
    }

    /**
     * Forward projects a lat,lon coordinates.
     * <p>
     * @param lat raw latitude in decimal degrees
     * @param lon raw longitude in decimal degrees
     * @param p Resulting XY Point
     * @return Point p
     */
    public Point forward (double lat, double lon, Point p) {
	return forward(
		ProjMath.degToRad(lat), ProjMath.degToRad(lon), p, true);
    }

    /**
     * Forward projects lat,lon into XY space and returns a Point.
     * <p>
     * @param phi double latitude in radians
     * @param lambda double longitude in radians
     * @param p Resulting XY Point
     * @param isRadian bogus argument indicating that lat,lon
     * arguments are in radians
     * @return Point p
     */
    public Point forward (
	double phi, double lambda, Point p, boolean isRadian)
    {

	// Figure out the point for screen coordinates.  Need to take
	// into account that the origin point of the projection may be
	// off screen, so we need to take the calculated world
	// coordinates of the center of the screen and subtract the
	// screen offset from that.

        double diff = (double)(lambda-origin.radlon_);
	if (diff > halfPI) diff -= Math.PI;
	if (diff < -halfPI) diff += Math.PI;
        double theta = n* diff;

	// x
	double sintheta = Math.sin(theta);
	double rho = RF/Math.pow(Math.tan(quarterPI + phi/2.0d), n);
	p.x = (int)(rho * sintheta + wx);
	
	//y
	double costheta = Math.cos(theta);
	p.y = hy - (int)((double)(Po - (rho * costheta)));

	return p;
    }


    /**
     * Inverse project x,y coordinates into a LatLonPoint.
     * <p>
     * @param x integer x coordinate
     * @param y integer y coordinate
     * @param llp LatLonPoint
     * @return LatLonPoint llp
     * @see Proj#inverse(Point)
     *
     */
    public LatLonPoint inverse (int x, int y, LatLonPoint llp) {
	// convert from screen to world coordinates
	x = x - wx;
	y = hy - y;

	//lat
        double diff = Po - (double) y;
        double rho = Math.sqrt((double)(x*x) + (diff * diff));
	double lat = 2.0 * Math.atan(Math.pow((RF/rho), 1/n)) -
			    Math.PI/2.0; // scale is in RF
	//lon
	double theta;
	if (n < 0){
	    theta = Math.atan(-1.0*((double)x/diff));
	}
	else theta = Math.atan((double)x/diff);
	double lon = theta/n + origin.radlon_;

	llp.setLatLon(lat, lon, true);
	return llp;
    }


    /**
     * Inverse project a Point.
     * <p>
     * @param point x,y Point
     * @param llp resulting LatLonPoint
     * @return LatLonPoint llp
     *
     */
    public LatLonPoint inverse (Point pt, LatLonPoint llp) {
	return inverse (pt.x, pt.y, llp);
    }


    /**
     * Get the upper left (northwest) point of the projection.
     * <p>
     * Returns the upper left point (or closest equivalent) of the
     * projection based on the center point and height and width of
     * screen.
     * <p>
     * @return LatLonPoint
     *
     */
    public LatLonPoint getUpperLeft() {
	LatLonPoint tmp;
	double lat, lon, newLat, newLon;

	//  This shouldn't make a difference of northern or southern
	//  hemisphere.  Need to check all three points across the top
	//  of the screen (left, middle, right), and the topmost will
	//  be there.  Need to check the top left and bottom left to
	//  get the leftmost point, too.

//  	if(true) return inverse(0, 0);
			
	// Get screen coordinate of center for reference:
	//left
	lat = inverse_lat(-wx, hy);
	// middle
	newLat = inverse_lat((width/2)-wx, hy);
	if(newLat > lat) lat = newLat;
	// right
	newLat = inverse_lat(width-wx, hy);
	if(newLat > lat) lat = newLat;

	lon = inverse_lon(-wx, hy);
	newLon = inverse_lon(-wx, hy - height);
	if (newLon < lon) lon = newLon;
	else if (lon < 0 && newLon > 0) lon = newLon;  // dateline

	Debug.message("proj", "LambertConformalConic.getUpperLeft(): " +
		      "lat,lon=" + ProjMath.radToDeg(lat) + "," + ProjMath.radToDeg(lon));

	return new LatLonPoint(ProjMath.radToDeg(lat), ProjMath.radToDeg(lon));
    }


    /**
     * Get the lower right (southeast) point of the projection.
     * <p>
     * Returns the lower right point (or closest equivalent) of the
     * projection based on the center point and height and width of
     * screen.
     * <p>
     * @return LatLonPoint
     *
     */
    public LatLonPoint getLowerRight() {
	LatLonPoint tmp;
	double lat, lon, newLat, newLon;

	//  This shouldn't make a difference of northern or southern
	//  hemisphere.  Need to check all three points across the
	//  bottom of the screen (left, middle, right), and the
	//  topmost will be there.  Need to check the top right and
	//  bottom right to get the rightmost point, too.

//  	if(true) return inverse(width, height);

	//left
	lat = inverse_lat(-wx, hy - height);
	// middle
	newLat = inverse_lat((width/2)-wx, hy - height);
	if(newLat < lat) lat = newLat;
	// right
	newLat = inverse_lat(width - wx, hy - height);
	if(newLat < lat) lat = newLat;

	lon = inverse_lon(width - wx, hy);
	newLon = inverse_lon(width - wx, hy - height);
	if (newLon > lon) lon = newLon;
	else if (lon > 0 && newLon < 0) lon = newLon;  // dateline

	Debug.message("proj", "LambertConformalConic.getLowerRight(): " +
		      "lat,lon=" + ProjMath.radToDeg(lat) + "," + ProjMath.radToDeg(lon));

	return new LatLonPoint(ProjMath.radToDeg(lat), ProjMath.radToDeg(lon));
    }

    /*
    public void testPoint(double lat, double lon) {
	double x, y;
	lon = wrap_longitude(ProjMath.degToRad(lon));
	lat = normalize_latitude(ProjMath.degToRad(lat));
	x = forward_x(lat, lon);
	y = forward_y(lat, lon);

	System.out.println("(lon="+ProjMath.radToDeg(lon)+",lat="+ProjMath.radToDeg(lat)+
			   ") = (x="+x+",y="+y+")");
	lat = inverse_lat(x, y);
	lon = wrap_longitude(inverse_lon(x, y));
	System.out.println("(x="+x+",y="+y+") = (lon="+
			   ProjMath.radToDeg(lon)+",lat="+ProjMath.radToDeg(lat)+")");
    }

    public static void main (String argv[]) {
	LambertConformalConic proj=null;
	// defaults for MassStatePanel
	proj = new LambertConformalConic(new LatLonPoint(41.0d, -71.30d), 1.0d,
					 620, 480);

	System.out.println("testing");
	proj.setEarthRadius(1.0d);
	System.out.println("setEarthRadius("+proj.getEarthRadius()+")");
	proj.setPPM(1);
	System.out.println("setPPM("+proj.getPPM()+")");
	proj.setMinScale(1.0d);
	System.out.println("setMinScale("+proj.getMinScale()+")");
	try {
	    proj.setScale(1.0d);
	} catch (java.beans.PropertyVetoException e) {
	}
	System.out.println("setScale("+proj.getScale()+")");
	System.out.println(proj);
	System.out.println();

	System.out.println("---testing latitude");
	proj.testPoint(0.0d, 0.0d);
	proj.testPoint(10.0d, 0.0d);
	proj.testPoint(40.0d, 0.0d);
	proj.testPoint(-80.0d, 0.0d);
	proj.testPoint(-90.0d, 0.0d);
	proj.testPoint(100.0d, 0.0d);
	proj.testPoint(-3272.0d, 0.0d);
	System.out.println("---testing longitude");
	proj.testPoint(0.0d, 10.0d);
	proj.testPoint(0.0d, -10.0d);
	proj.testPoint(0.0d, 90.0d);
	proj.testPoint(0.0d, -90.0d);
	proj.testPoint(0.0d, 170.0d);
	proj.testPoint(0.0d, -170.0d);
	proj.testPoint(0.0d, 180.0d);
	proj.testPoint(0.0d, -180.0d);
	proj.testPoint(0.0d, 190.0d);
	proj.testPoint(0.0d, -190.0d);
	System.out.println("---testing lat&lon");
	proj.testPoint(100.0d, 370.0d);
	proj.testPoint(-30.0d, -370.0d);
	proj.testPoint(-80.0d, 550.0d);
	proj.testPoint(0.0d, -550.0d);
    }
    */
}

/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/proj/Planet.java,v $
 * $Revision: 1.8 $
 * $Date: 2000/05/08 14:23:25 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.proj;

import com.bbn.openmap.MoreMath;

/**
 * Planet datums and parameters.
 * These values are taken from John Snyder's <i>Map Projections --A Working
 * Manual</i>
 * You should add datums as needed, consult the ellips.dat file.
 */
public class Planet {

    // Solar system id's.  Add new ones as needed.
    final public static transient int Earth = 3;
    final public static transient int Mars = 4;


    // WGS84 / GRS80 datums
    final public static transient double wgs84_earthPolarRadiusMeters = 6356752.3142d;
    final public static transient double wgs84_earthEquatorialRadiusMeters = 6378137.0d;
    final public static transient double wgs84_earthFlat =
	1 - (wgs84_earthPolarRadiusMeters/wgs84_earthEquatorialRadiusMeters);// 1 - (minor/major) = 1/298.257
    final public static transient double wgs84_earthEccen =
	(double)Math.sqrt(2*wgs84_earthFlat - (wgs84_earthFlat*wgs84_earthFlat));// sqrt(2*f - f^2) = 0.081819221f

    final public static transient double wgs84_earthEquatorialCircumferenceMeters =
	MoreMath.TWO_PI*wgs84_earthEquatorialRadiusMeters;
    final public static transient double wgs84_earthEquatorialCircumferenceKM =
	wgs84_earthEquatorialCircumferenceMeters/1000d;
    final public static transient double wgs84_earthEquatorialCircumferenceMiles =
	wgs84_earthEquatorialCircumferenceKM*0.62137119d;//HACK use UNIX units?
    final public static transient double wgs84_earthEquatorialCircumferenceNMiles =
	wgs84_earthEquatorialCircumferenceKM*0.5399568d;//HACK use UNIX units?


    // Mars
    final public static transient double marsEquatorialRadius = 3393400.0d;// meters
    final public static transient double marsEccen = 0.101929d;// eccentricity e
    final public static transient double marsFlat = 0.005208324d;// 1-(1-e^2)^1/2


    // International 1974
    final public static transient double international1974_earthPolarRadiusMeters = 6356911.946d;
    final public static transient double international1974_earthEquatorialRadiusMeters = 6378388d;
    final public static transient double international1974_earthFlat =
	1 - (international1974_earthPolarRadiusMeters/
		international1974_earthEquatorialRadiusMeters);// 1 - (minor/major) = 1/297


    // Extra scale constant for better viewing of maps (do not use this to
    // calculate anything but points to be viewed!)
    public transient static int defaultPixelsPerMeter = 3272;// 3384: mattserver/Map.C, 3488: dcw


    // cannot construct
    private Planet () {}
}

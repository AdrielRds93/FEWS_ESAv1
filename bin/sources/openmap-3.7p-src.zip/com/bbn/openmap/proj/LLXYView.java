/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 *           restricted rights as set forth in the DFARS.
 *  
 *                         BBNT Solutions LLC
 *                            A Part of  
 *                               GTE      
 *                        10 Moulton Street
 *                       Cambridge, MA 02138
 *                          (617) 873-3000
 *  
 *        Copyright 1998-2000 by BBNT Solutions LLC,
 *              A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/proj/LLXYView.java,v $
 * $Revision: 1.4 $
 * $Date: 2000/05/08 14:23:24 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.proj;

import java.awt.Point;
import java.util.*;
import com.bbn.openmap.LatLonPoint;
import com.bbn.openmap.MoreMath;
import com.bbn.openmap.util.Debug;


/**
 * Implements the LLXY projection.
 */
public class LLXYView extends LLXY {

    /**
     * The LLXY name.
     */
    public final static transient String LLXYViewName = "EPSG-4326";

    /**
     * The LLXY type of projection.
     */
    public final static transient int LLXYViewType = 6303;

    /** The "Helper" class manages user-space */
    private LLXYViewHelper helper;
    
    /** User-Space Center in lat/lon */
    protected LatLonPoint uCtr; 
    protected double uCtrLat;
    protected double uCtrLon;

    /** Screen Origin in pixels (center=0,0)   */
    protected int sCtrX, sCtrY;	
    
    /** User Origin in pixels 0,0 = lat/lon center    */
    protected int uCtrX;	
    protected int uCtrY;	
    
    protected int dUSX;		/** delta between U and S, X axis */
    protected int dUSY;		/** delta between U and S, Y axis */

    /**
     * Construct a LLXY projection.
     * <p>
     * @param center LatLonPoint center of projection
     * @param scale double scale of projection
     * @param width width of screen
     * @param height height of screen
     *
     */
    public LLXYView (LatLonPoint center, double scale, int width, int height)
    {
	super(center, scale, width, height, LLXYViewType);
	computeParameters();
    }


    /**
     * Return stringified description of this projection.
     * <p>
     * @return String
     * @see Projection#getProjectionID
     */
    public String toString() {
	return "LLXYView[" + super.toString();
    }


    /**
     * Called when some fundamental parameters change.
     * <p>
     * Each projection will decide how to respond to this change.
     * For instance, they may need to recalculate "constant" paramters
     * used in the forward() and inverse() calls.<p>
     */
    protected void computeParameters() {
	Debug.message("LLXYView", "LLXYView.computeParameters()");
	super.computeParameters();

	// compute the offsets
 	hy = height/2;
 	wx = width/2;
 	cLon = ProjMath.radToDeg(ctrLon);
 	llscale = scale * .000006;	// what the heck is this number?
	
	// We have no way of constructing the User Space at anything
	// other than 0,0 for now.
	if (uCtr == null)
	    {
		uCtrLat = 0.0;
		uCtrLon = 0.0;
		uCtr = new LatLonPoint(uCtrLat, uCtrLon);
	    }
	
	if (helper == null)
	    {
		helper = new LLXYViewHelper(uCtr, scale, width, height);
	    }

	synchronized (helper) {
	    super.computeParameters();
	    
	    // Screen stuff
	    Point temp = new Point();


	    helper.setAllParams(pixelsPerMeter,
				planetRadius,
				planetPixelRadius,
				planetPixelCircumference,
				minscale, maxscale,
				scale,
				scaled_radius,
				width, height,
				uCtrLat,
				uCtrLon);

	    helper.forward (ctrLat, ctrLon, temp, true);
	    sCtrX = temp.x;
	    sCtrY = temp.y;
	    
	    helper.forward (uCtrLat, uCtrLon, temp);
	    uCtrX = temp.x;
	    uCtrY = temp.y;
	    
	    dUSX = sCtrX - uCtrX;
	    dUSY = sCtrY - uCtrY;
	    
	}

	Debug.message("LLXYView",
		      "User Center LL: " + uCtrLon + "," + uCtrLat
		      + " User Center xy: " + uCtrX + "," + uCtrY
		      + " Screen Center LL: "
		      + ProjMath.radToDeg(ctrLon) + ","
		      + ProjMath.radToDeg(ctrLat)
		      + " Screen Center xy: " + sCtrX + "," + sCtrY
		      + " Screen wh: " + width + "x" + height
		      + " Screen halfwh: " + wx + "x" + hy
		      + " Delta xy: " + dUSX + "," + dUSY);
       }

    /**
     * Projects a point from Lat/Lon space to X/Y space.
     * <p>
     * @param pt LatLonPoint
     * @param p Point retval
     * @return Point p
     */
    public Point forward (LatLonPoint pt, Point p) {

	// First translate to user-space
	helper.forward(pt, p);

	// Now translate to screen-space
	p.x = p.x + wx - dUSX;
	p.y = hy - p.y + dUSY;

  	if (Debug.debugging("LLXYViewf")) {
	    Debug.out.println("LLXYView.forward(pt.lon_:" + pt.getLongitude()
		+ ", pt.lat_:" + pt.getLatitude() + ")\n" +
		"LLXYView.forward   x:" + p.x + ", y:" + p.y);
	}
	return p;
    }


    /**
     * Forward projects a lat,lon coordinates.
     * <p>
     * @param lat raw latitude in decimal degrees
     * @param lon raw longitude in decimal degrees
     * @param p Resulting XY Point
     * @return Point p
     */
    public Point forward (double lat, double lon, Point p) {
	
	// First translate to user-space
	helper.forward(lat,lon,p);

	// Now translate to screen-space
	p.x = p.x + wx - dUSX;
	p.y = hy - p.y + dUSY;

  	if (Debug.debugging("LLXYViewf")) {
	    Debug.out.println("LLXYView.forward(lon:" + lon
  		      + ", lat:" + lat+  ")\n" +
		      "LLXYView.forward   x:" + p.x + ", y:" + p.y +
  		      " ctrLon:" + cLon + " wx:" + wx + " hy:" + hy);
	}
	return p;
    }


    /**
     * Forward projects lat,lon into XY space and returns a Point.
     * <p>
     * @param lat double latitude in radians
     * @param lon double longitude in radians
     * @param p Resulting XY Point
     * @param isRadian bogus argument indicating that lat,lon
     * arguments are in radians
     * @return Point p
     */
    public Point forward (
	double lat, double lon, Point p, boolean isRadian)
    {
	// First translate to user-space
	helper.forward(lat, lon, p, isRadian);

	// Now translate to screen-space
	p.x = p.x + wx - dUSX;
	p.y = hy - p.y + dUSY;
	
  	if (Debug.debugging("LLXYViewf")) {
	    Debug.out.println("LLXYView.forward(lon:" + ProjMath.radToDeg(lon)
  		      + ", lat:" + ProjMath.radToDeg(lat) + " isRadian:" + isRadian + ")\n" +
		      "LLXYView.forward   x:" + p.x + ", y:" + p.y
		      + " scale: " + scale + " llscale:" + llscale);
	}
	return p;
    }


    /**
     * Inverse project a Point.
     * <p>
     * @param point x,y Point
     * @param llp resulting LatLonPoint
     * @return LatLonPoint llp
     *
     */
    public LatLonPoint inverse (Point pt, LatLonPoint llp) {
	// convert from screen to user coordinates
	int x = pt.x - wx + dUSX;
	int y = hy - pt.y + dUSY;
	
	// now convert to world coords
	return (helper.inverse(x,y,llp));
    }


    /**
     * Inverse project x,y coordinates into a LatLonPoint.
     * <p>
     * @param x integer x coordinate
     * @param y integer y coordinate
     * @param llp LatLonPoint
     * @return LatLonPoint llp
     * @see Proj#inverse(Point)
     *
     */
    public LatLonPoint inverse (int x, int y, LatLonPoint llp) {
	int tx = x - wx + dUSX;
	int ty = hy - y + dUSY;

	if (Debug.debugging("LLXYViewi")) {
	    // This is only to aid printing....
	    LatLonPoint tllp = helper.inverse(tx, ty, llp);
	    
	    Debug.out.println("xy: " + x + "," + y
			       + " txty: " + tx + "," + ty
			       + " llp: " + tllp.getLongitude()
			       + "," + tllp.getLatitude());
	}

	return(helper.inverse(tx, ty, llp));
    }



    /**  
     * Helper class manages "user space"
     */
    private class LLXYViewHelper extends LLXY {
	
	public LLXYViewHelper( LatLonPoint center, double scale,
			       int width, int height){
	    super(center, scale, width, height, LLXYViewType);
	}
	
	
    	public void setAllParams(int hPixelsPerMeter,
				 double hPlanetRadius,
				 double hPlanetPixelRadius,
				 double hPlanetPixelCircumference,
				 double hMinscale,
				 double hMaxscale,
				 double hScale,
				 double hScaled_radius,
				 int hWidth,
				 int hHeight,
				 double hCtrLat,
				 double hCtrLon)
	{
	    pixelsPerMeter = hPixelsPerMeter;
	    planetRadius = hPlanetRadius;
	    planetPixelRadius = hPlanetPixelRadius;
	    planetPixelCircumference = hPlanetPixelCircumference;
	    minscale = hMinscale;
	    maxscale = hMaxscale;
	    scale = hScale;
	    scaled_radius = hScaled_radius;
	    width = hWidth;
	    height = hHeight;
	    ctrLat = hCtrLat;
	    ctrLon = hCtrLon;
	    this.computeParameters();
	}
			
			    
	public String toString() {
	    return "LLXYViewHelper[" + super.toString();
	}

	/** 
	 * Forward projects a LatLonPoint into USER space.
	 */
	public Point forward (LatLonPoint pt, Point p) {
	    super.forward(pt, p);

	    if (Debug.debugging("LLXYViewHelperf")) {
		Debug.out.println("forward l,l,p: "
				   + pt.getLongitude() + "," + pt.getLatitude()
				   + " help xy: " + p.x + "," + p.y);
	    }

	    p.x = p.x - wx;
	    p.y = hy - p.y;
	    return p;
	}


	public Point forward (double lat, double lon, Point p) {
	    super.forward(lat, lon, p);

	    if (Debug.debugging("LLXYViewHelperf")) {
		Debug.out.println("forward l,l,p: "
				   + lon + "," + lat
				   + " help xy: " + p.x + "," + p.y);
	    }
	    p.x = p.x - wx;
	    p.y = hy - p.y;
	    return p;
	}

	public Point forward (double lat, double lon, Point p, boolean isRadian)
	{
	    super.forward(lat, lon, p, isRadian);
	    if (Debug.debugging("LLXYViewHelperf")) {
		Debug.out.println("forward l,l,p: "
			  + ProjMath.radToDeg(lon) + "," + ProjMath.radToDeg(lat)
			  + " help xy: " + p.x + "," + p.y);
	    }
	    p.x = p.x - wx;
	    p.y = hy - p.y;
	    return p;
	}

	public LatLonPoint inverse (Point pt, LatLonPoint llp) {
	    int x = pt.x + wx;
	    int y = hy - pt.y;
	    
	    if (Debug.debugging("LLXYViewHelperi")) {
		Debug.out.println("inverse helper x,y: " + x + "," + y);
	    }

	    // inverse project, using LLXY.inverse
	    return(super.inverse(x,y,llp));
	}

	public LatLonPoint inverse (int x, int y, LatLonPoint llp) {
	    x = x + wx;
	    y = hy - y;

	    if (Debug.debugging("LLXYViewHelperi")) {
		Debug.out.println("inverse helper x,y: " + x + "," + y);
	    }

	    // inverse project using LLXY.inverse
	    return(super.inverse(x,y,llp));
	}
    }
}

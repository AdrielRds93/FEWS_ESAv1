/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 *           restricted rights as set forth in the DFARS.
 *  
 *                         BBNT Solutions LLC
 *                            A Part of  
 *                               GTE      
 *                        10 Moulton Street
 *                       Cambridge, MA 02138
 *                          (617) 873-3000
 *  
 *        Copyright 1998, 2000 by BBNT Solutions LLC,
 *              A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/proj/AziDist.java,v $
 * $Revision: 1.2 $
 * $Date: 2000/05/08 14:23:22 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */


package com.bbn.openmap.proj;

/**
 * Structure contains azimuth and distance values.
 * Distance units are determined by the operation.
 * @see GreatCircle#ellipsoidalAziDist
 */
public class AziDist {
    public double faz;// forward azimuth
    public double baz;// backward azimuth
    public double distance;// distance
}

/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 *           restricted rights as set forth in the DFARS.
 *  
 *                         BBNT Solutions LLC
 *                            A Part of  
 *                               GTE      
 *                        10 Moulton Street
 *                       Cambridge, MA 02138
 *                          (617) 873-3000
 *  
 *        Copyright 1998-2000 by BBNT Solutions LLC,
 *              A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/proj/Gnomonic.java,v $
 * $Revision: 1.15 $
 * $Date: 2000/05/08 14:23:24 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.proj;

import com.bbn.openmap.LatLonPoint;
import com.bbn.openmap.MoreMath;
import com.bbn.openmap.util.Debug;

import java.awt.*;


/**
 * Implements the Gnomonic projection.
 */
public class Gnomonic extends Azimuth {

    /**
     * The Gnomonic name.
     */
    public final static transient String GnomonicName = "Gnomonic";

    /**
     * The Gnomonic type of projection.
     */
    public final static transient int GnomonicType = 12;

    protected int hy, wx;

    // almost constant projection parameters
    protected double cosCtrLat;
    protected double sinCtrLat;

    public final static transient double epsilon = 0.0001d;
    public final static transient double HEMISPHERE_EDGE=
	(double)((Math.PI/180d)*80d);//80degrees
    public final static transient double hPrime =
	1d/ Math.pow(Math.cos(HEMISPHERE_EDGE),2d);


    protected final static double NORTH_BOUNDARY = NORTH_POLE-epsilon;
    protected final static double SOUTH_BOUNDARY = -NORTH_BOUNDARY;


    /**
     * Construct a Mercator projection.
     * <p>
     * @param center LatLonPoint center of projection
     * @param scale double scale of projection
     * @param w width of screen
     * @param h height of screen
     *
     */
    public Gnomonic(
	LatLonPoint center, double scale, int width, int height)
    {
	super(center, scale, width, height, GnomonicType);
	setMinScale(1000.0d);
    }


    /**
     * Return stringified description of this projection.
     * <p>
     * @return String
     * @see Projection#getProjectionID
     *
     */
    public String toString() {
	return "Gnomonic[" + super.toString();
    }


    /**
     * Called when some fundamental parameters change.
     * <p>
     * Each projection will decide how to respond to this change.
     * For instance, they may need to recalculate "constant" paramters
     * used in the forward() and inverse() calls.<p>
     *
     */
    protected void computeParameters() {
	Debug.message("proj", "Gnomonic.computeParameters()");
	super.computeParameters();

	// minscale is the minimum scale allowable (before integer wrapping
	// can occur)
	minscale = Math.ceil((2*hPrime*planetPixelRadius)/ Integer.MAX_VALUE);
	if (minscale < 1)
	    minscale = 1;
	if (scale < minscale)
	    scale = minscale;

	// maxscale = scale at which a world hemisphere fits in the window
	maxscale = (width < height)
	    ? planetPixelRadius*2*hPrime /(double)width
	    : planetPixelRadius*2*hPrime /(double)height;
	if (maxscale < minscale) {
	    maxscale = minscale;
	}
	if (scale > maxscale) {
	    scale = maxscale;
	}
	scaled_radius = planetPixelRadius/scale;

	// width of the world in pixels at current scale.  We see only
	// one hemisphere.
	world.x = (int)((planetPixelRadius*2*hPrime)/scale);

	// calculate cutoff scale for XWindows workaround
	XSCALE_THRESHOLD = (int)((planetPixelRadius*2*hPrime)/64000);//fudge it a little bit

	// do some precomputation of stuff
	cosCtrLat = Math.cos(ctrLat);
	sinCtrLat = Math.sin(ctrLat);
	
	// compute the offsets
	hy = height/2;
	wx = width/2;
    }


    /**
     * Draw the background for the projection.
     * @param g Graphics
     */
    public void drawBackground(Graphics g) {
	g.setColor(backgroundColor);
	g.fillRect(0, 0, getWidth(), getHeight());
    }

    
    /**
     * Sets radian latitude to something sane.  This is an abstract
     * function since some projections don't deal well with extreme
     * latitudes.<p>
     *
     * @param lat double latitude in radians
     * @return double latitude (-PI/2 &lt;= y &lt;= PI/2)
     * @see com.bbn.openmap.LatLonPoint#normalize_latitude(double)
     *
     */
    public double normalize_latitude(double lat) {
	if (lat > NORTH_BOUNDARY) {
	    return NORTH_BOUNDARY;
	} else if (lat < SOUTH_BOUNDARY) {
	    return SOUTH_BOUNDARY;
	}
	return lat;
    }


    /**
     * Get the distance c of the point from the center of the hemisphere.
     * <p>
     * @param phi1 latitude
     * @param lambda0 longitude
     * @param phi latitude
     * @param lambda longitude
     * @return double c angular distance in radians
     *
     */
    final public static double hemisphere_distance(
	double phi1, double lambda0, double phi, double lambda)
    {
	return GreatCircle.spherical_distance(
	    phi1, lambda0, phi, lambda)/*-epsilon*/;
    }


    /**
     * Check if a given lat/lon is within the visible hemisphere.
     * <p>
     * @param phi1 latitude
     * @param lambda0 longitude
     * @param phi latitude
     * @param lambda longitude
     * @return boolean true if within the visible hemisphere, false if not
     *
     */
    final public static boolean hemisphere_clip(
	double phi1, double lambda0, double phi, double lambda)
    {
	return (GreatCircle.spherical_distance(
	    phi1, lambda0, phi, lambda)/*-epsilon*/ <= HEMISPHERE_EDGE);
    }



    /**
     * Calculate point along edge of hemisphere (using center point and
     * current azimuth).
     * <p>
     * This is invoked for points that aren't visible in the current
     * hemisphere.
     * <p>
     * @param p Point
     * @return Point p
     *
     */
    private Point edge_point(Point p, double current_azimuth) {
	double c = HEMISPHERE_EDGE;
	LatLonPoint tmpll = GreatCircle.spherical_between(
		ctrLat, ctrLon, c/*-epsilon*/, current_azimuth);
	double phi = tmpll.radlat_;
	double lambda = tmpll.radlon_;

	double kPrime = 1d/ Math.cos(c);
	double cosPhi = Math.cos(phi);
	double sinPhi = Math.sin(phi);
	double lambdaMinusCtrLon = lambda-ctrLon;
	double cosLambdaMinusCtrLon = Math.cos(lambdaMinusCtrLon);
	double sinLambdaMinusCtrLon = Math.sin(lambdaMinusCtrLon);

	p.x = (int)(scaled_radius*kPrime*cosPhi*sinLambdaMinusCtrLon) + wx;
	p.y = hy - (int)(scaled_radius*kPrime*
		(cosCtrLat*sinPhi - sinCtrLat*cosPhi*cosLambdaMinusCtrLon));

	return p;
    }


    /**
     * Checks if a LatLonPoint is plot-able.
     * <p>
     * A point is plot-able if it is within the visible hemisphere.
     * <p>
     * @param lat double latitude in decimal degrees
     * @param lon double longitude in decimal degrees
     * @return boolean
     */
    public boolean isPlotable(double lat, double lon) {
	lat = normalize_latitude(ProjMath.degToRad(lat));
	lon = wrap_longitude(ProjMath.degToRad(lon));
	return hemisphere_clip(ctrLat, ctrLon, lat, lon);
    }


    /**
     * Forward project a point.
     * If the point is not within the viewable hemisphere, return flags in
     * AzimuthVar variable if specified.
     * @param phi double latitude in radians
     * @param lambda double longitude in radians
     * @param pt Point
     * @param azVar AzimuthVar or null
     * @return Point pt
     */
    protected Point _forward (
	    double phi, double lambda, Point p, AzimuthVar azVar)
    {
	double c = hemisphere_distance(ctrLat, ctrLon, phi, lambda);
	// normalize invalid point to the edge of the sphere
	if (c > HEMISPHERE_EDGE) {
	    double az =
		GreatCircle.spherical_azimuth(ctrLat, ctrLon, phi, lambda);
	    if (azVar != null) {
		azVar.invalid_forward = true;	// set the invalid flag
		azVar.current_azimuth = az;	// record azimuth of this point
	    }
	    return edge_point(p, az);
	}

	double kPrime = 1d/ Math.cos(c);
	double cosPhi = Math.cos(phi);
	double sinPhi = Math.sin(phi);
	double lambdaMinusCtrLon = lambda-ctrLon;
	double cosLambdaMinusCtrLon = Math.cos(lambdaMinusCtrLon);
	double sinLambdaMinusCtrLon = Math.sin(lambdaMinusCtrLon);

	p.x = (int)(scaled_radius*kPrime*cosPhi*sinLambdaMinusCtrLon) + wx;
	p.y = hy - (int)(scaled_radius*kPrime*
		(cosCtrLat*sinPhi - sinCtrLat*cosPhi*cosLambdaMinusCtrLon));

	return p;
    }


    /**
     * Inverse project x,y coordinates into a LatLonPoint.
     * <p>
     * @param x integer x coordinate
     * @param y integer y coordinate
     * @param llp LatLonPoint
     * @return LatLonPoint llp
     * @see Proj#inverse(Point)
     *
     */
    public LatLonPoint inverse(int x, int y, LatLonPoint llp) {
	// convert from screen to world coordinates
	x = x - wx;
	y = hy - y;


// 	Debug.output("Gnomonic.inverse: x,y=" + x + "," + y);

	double rho = Math.sqrt(x*x + y*y);
	if (rho == 0d) {
	    Debug.message("proj", "Gnomonic.inverse: center!");
	    llp.setLatLon(
		    ProjMath.radToDeg(ctrLat),
		    ProjMath.radToDeg(ctrLon));
	    return llp;
	}

	double c = MoreMath.atan2(rho, scaled_radius);
	double cosC = Math.cos(c);
	double sinC = Math.sin(c);

	// calculate latitude 
	double lat = MoreMath.asin(
	    cosC * sinCtrLat + (y * sinC * (cosCtrLat/rho)));


	// calculate longitude
	double lon = ctrLon + MoreMath.atan2(
		(x*sinC),
		(rho*cosCtrLat*cosC - y*sinCtrLat*sinC));
// 	Debug.output("Gnomonic.inverse: lat,lon=" +
// 			   ProjMath.radToDeg(lat) + "," +
// 			   ProjMath.radToDeg(lon));

	// check if point in outer space
//	if (MoreMath.approximately_equal(lat, ctrLat) &&
//	       MoreMath.approximately_equal(lon, ctrLon) &&
//	       (Math.abs(x-(width/2))<2) &&
//	       (Math.abs(y-(height/2))<2))
	if (Double.isNaN(lat) || Double.isNaN(lon))
	{
//	    Debug.message("proj", "Gnomonic.inverse(): outer space!");
	    lat = ctrLat;
	    lon = ctrLon;
	}
	llp.setLatLon(
		ProjMath.radToDeg(lat),
		ProjMath.radToDeg(lon));
	return llp;
    }


    /**
     * Inverse project a Point.
     * <p>
     * @param point x,y Point
     * @param llp resulting LatLonPoint
     * @return LatLonPoint llp
     *
     */
    public LatLonPoint inverse(Point pt, LatLonPoint llp) {
	return inverse(pt.x, pt.y, llp);
    }


    /**
     * Check if equator is visible on screen.
     * @return boolean
     */
    public boolean overEquator () {
	LatLonPoint llN = inverse(width/2, 0, new LatLonPoint());
	LatLonPoint llS = inverse(width/2, height, new LatLonPoint());
	return MoreMath.sign(llN.radlat_) != MoreMath.sign(llS.radlat_);
    }


    /**
     * Get the upper left (northernmost and westernmost) point of the
     * projection.
     * <p>
     * Returns the upper left point (or closest equivalent) of the
     * projection based on the center point and height and width of
     * screen.
     * <p>
     * @return LatLonPoint
     */
    public LatLonPoint getUpperLeft() {
	LatLonPoint tmp = new LatLonPoint();
	double lat, lon;

	// over north pole
	if (overNorthPole()) {
	    lat = NORTH_POLE;
	    lon = -DATELINE;
	}

	// over south pole
	else if (overSouthPole()) {
	    lon = -DATELINE;
	    if (overEquator()) {
		// get top center for latitude
		tmp = inverse(width/2, 0, tmp);
		lat = tmp.radlat_;
	    } else {
		// get left top corner for latitude
		tmp = inverse(0, 0, tmp);
		lat = tmp.radlat_;
	    }
	}

	// view in northern hemisphere
	else if (ctrLat >= 0d) {
	    // get left top corner for longitude
	    tmp = inverse(0,0,tmp);
	    lon = tmp.radlon_;
	    // get top center for latitude
	    tmp = inverse(width/2, 0, tmp);
	    lat = tmp.radlat_;
	}

	// view in southern hemisphere
	else {
	    // get left bottom corner for longitude
	    tmp = inverse(0, height, tmp);
	    lon = tmp.radlon_;

	    if (overEquator()) {
		// get top center (for latitude)
		tmp = inverse(width/2, 0, tmp);
		lat = tmp.radlat_;
	    } else {
		// get left top corner (for latitude)
		tmp = inverse(0, 0, tmp);
		lat = tmp.radlat_;
	    }
	}
	tmp.setLatLon(lat, lon, true);
//	Debug.output("ul="+tmp);
	return tmp;
    }


    /**
     * Get the lower right (southeast) point of the projection.
     * <p>
     * Returns the lower right point (or closest equivalent) of the
     * projection based on the center point and height and width of
     * screen.
     * <p>
     * This is trivial for most cylindrical projections, but much more
     * complicated for azimuthal projections.
     * <p>
     * @return LatLonPoint
     */
    public LatLonPoint getLowerRight() {
	LatLonPoint tmp = new LatLonPoint();
	double lat, lon;

	// over north pole
	if (overNorthPole()) {
	    lon = DATELINE;
	    if (overEquator()) {
		// get bottom center for latitude
		tmp = inverse(width/2, height, tmp);
		lat = tmp.radlat_;
	    } else {
		// get bottom right corner for latitude
		tmp = inverse(width, height, tmp);
		lat = tmp.radlat_;
	    }
	}

	// over south pole
	else if (overSouthPole()) {
	    lat = SOUTH_POLE;
	    lon = DATELINE;
	}

	// view in northern hemisphere
	else if (ctrLat >= 0d) {
	    // get the right top corner for longitude
	    tmp = inverse(width, 0, tmp);
	    lon = tmp.radlon_;

	    if (overEquator()) {
		// get the bottom center (for latitude)
		tmp = inverse(width/2, height, tmp);
		lat = tmp.radlat_;
	    } else {
		// get the right bottom corner (for latitude)
		tmp = inverse(width, height, tmp);
		lat = tmp.radlat_;
	    }
	}

	// view in southern hemisphere
	else {
	    // get the right bottom corner for longitude
	    tmp = inverse(width,height,tmp);
	    lon = tmp.radlon_;
	    // get bottom center for latitude
	    tmp = inverse(width/2, height, tmp);
	    lat = tmp.radlat_;
	}
	tmp.setLatLon(lat, lon, true);
//	Debug.output("lr="+tmp);
	return tmp;
    }
}

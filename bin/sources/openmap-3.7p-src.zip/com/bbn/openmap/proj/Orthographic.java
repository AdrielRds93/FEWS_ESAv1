/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 *           restricted rights as set forth in the DFARS.
 *  
 *                         BBNT Solutions LLC
 *                            A Part of  
 *                               GTE      
 *                        10 Moulton Street
 *                       Cambridge, MA 02138
 *                          (617) 873-3000
 *  
 *        Copyright 1998-2000 by BBNT Solutions LLC,
 *              A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/proj/Orthographic.java,v $
 * $Revision: 1.21 $
 * $Date: 2000/05/08 14:23:25 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.proj;

import com.bbn.openmap.LatLonPoint;
import com.bbn.openmap.MoreMath;
import com.bbn.openmap.util.Debug;

import java.awt.*;


/**
 * Implements the Orthographic projection.
 */
public class Orthographic extends Azimuth {

    /**
     * The Orthographic name.
     */
    public final static transient String OrthographicName = "Orthographic";

    /**
     * The Orthographic type of projection.
     */
    public final static transient int OrthographicType = 7;

    protected int hy, wx;

    // almost constant projection parameters
    protected double cosCtrLat;
    protected double sinCtrLat;


    public final static transient double epsilon = 0.0001d;
    protected final static transient double NORTH_BOUNDARY = NORTH_POLE-epsilon;
    protected final static transient double SOUTH_BOUNDARY = -NORTH_BOUNDARY;


    /**
     * Construct an Orthographic projection.
     * <p>
     * @param center LatLonPoint center of projection
     * @param scale double scale of projection
     * @param w width of screen
     * @param h height of screen
     *
     */
    public Orthographic(
	LatLonPoint center, double scale, int width, int height)
    {
	super(center, scale, width, height, OrthographicType);
	setMinScale(1000.0d);
    }

    /**
     * Construct an Orthographic projection.
     * <p>
     * @param center LatLonPoint center of projection
     * @param scale double scale of projection
     * @param w width of screen
     * @param h height of screen
     * @param type subclass's type
     *
     */
    public Orthographic(
	LatLonPoint center, double scale, int width, int height, int type)
    {
	super(center, scale, width, height, type);
	setMinScale(1000.0d);
    }


//    protected void finalize() {
//	Debug.message("proj", "Orthographic finalized");
//    }


    /**
     * Return stringified description of this projection.
     * <p>
     * @return String
     * @see Projection#getProjectionID
     *
     */
    public String toString() {
	return "Orthographic[" + super.toString();
    }


    /**
     * Called when some fundamental parameters change.
     * <p>
     * Each projection will decide how to respond to this change.
     * For instance, they may need to recalculate "constant" paramters
     * used in the forward() and inverse() calls.<p>
     *
     */
    protected void computeParameters() {
	Debug.message("proj", "Orthographic.computeParameters()");
	super.computeParameters();

	// do some precomputation of stuff
	cosCtrLat = Math.cos(ctrLat);
	sinCtrLat = Math.sin(ctrLat);
	
	// compute the offsets
	hy = height/2;
	wx = width/2;
    }

    
    /**
     * Sets radian latitude to something sane.  This is an abstract
     * function since some projections don't deal well with extreme
     * latitudes.<p>
     *
     * @param lat double latitude in radians
     * @return double latitude (-PI/2 &lt;= y &lt;= PI/2)
     * @see com.bbn.openmap.LatLonPoint#normalize_latitude(double)
     *
     */
    public double normalize_latitude(double lat) {
	if (lat > NORTH_BOUNDARY) {
	    return NORTH_BOUNDARY;
	} else if (lat < SOUTH_BOUNDARY) {
	    return SOUTH_BOUNDARY;
	}
	return lat;
    }


    /**
     * Check if a given lat/lon is within the visible hemisphere.
     * <p>
     * @param phi1 latitude
     * @param lambda0 longitude
     * @param phi latitude
     * @param lambda longitude
     * @return boolean true if within the visible hemisphere, false if not
     *
     */
    final public static boolean hemisphere_clip(
	double phi1, double lambda0, double phi, double lambda)
    {
	return (GreatCircle.spherical_distance(
	    phi1, lambda0, phi, lambda)/*-epsilon*/ <= MoreMath.HALF_PI);
    }


    /**
     * Calculate point along edge of hemisphere (using center point and
     * current azimuth).
     * <p>
     * This is invoked for points that aren't visible in the current
     * hemisphere.
     * <p>
     * @param p Point
     * @return Point p
     *
     */
    private Point edge_point(Point p, double current_azimuth) {
	LatLonPoint tmpll = GreatCircle.spherical_between(
		ctrLat, ctrLon, MoreMath.HALF_PI/*-epsilon*/, current_azimuth);

	double phi = tmpll.radlat_;
	double lambda = tmpll.radlon_;
	double cosPhi = Math.cos(phi);
	double lambdaMinusCtrLon = lambda-ctrLon;

	p.x = (int)(scaled_radius * cosPhi *
            Math.sin(lambdaMinusCtrLon)) + wx;
	p.y = hy - (int)(scaled_radius *
			 (cosCtrLat * Math.sin(phi) -
			  sinCtrLat * cosPhi *
                      Math.cos(lambdaMinusCtrLon)));
	return p;
    }


    /**
     * Checks if a LatLonPoint is plot-able.
     * <p>
     * A point is plot-able if it is within the visible hemisphere.
     * <p>
     * @param lat double latitude in decimal degrees
     * @param lon double longitude in decimal degrees
     * @return boolean
     */
    public boolean isPlotable(double lat, double lon) {
	lat = normalize_latitude(ProjMath.degToRad(lat));
	lon = wrap_longitude(ProjMath.degToRad(lon));
	return hemisphere_clip(ctrLat, ctrLon, lat, lon);
    }


    /**
     * Forward project a point.
     * If the point is not within the viewable hemisphere, return flags in
     * AzimuthVar variable if specified.
     * @param phi double latitude in radians
     * @param lambda double longitude in radians
     * @param pt Point
     * @param azVar AzimuthVar or null
     * @return Point pt
     */
    protected Point _forward (
	    double phi, double lambda, Point p, AzimuthVar azVar)
    {
	double cosPhi = Math.cos(phi);
	double lambdaMinusCtrLon = lambda-ctrLon;

	// normalize invalid point to the edge of the sphere
	if (!hemisphere_clip(ctrLat, ctrLon, phi, lambda)) {
	    double az =
		GreatCircle.spherical_azimuth(ctrLat, ctrLon, phi, lambda);
	    if (azVar != null) {
		azVar.invalid_forward = true;	// set the invalid flag
		azVar.current_azimuth = az;	// record azimuth of this point
	    }
	    return edge_point(p, az);
	}

	p.x = (int)(scaled_radius * cosPhi *
            Math.sin(lambdaMinusCtrLon)) + wx;
	p.y = hy - (int)(scaled_radius *
			 (cosCtrLat * Math.sin(phi) -
			  sinCtrLat * cosPhi *
                      Math.cos(lambdaMinusCtrLon)));
	return p;
    }


    /**
     * Inverse project x,y coordinates into a LatLonPoint.
     * <p>
     * @param x integer x coordinate
     * @param y integer y coordinate
     * @param llp LatLonPoint
     * @return LatLonPoint llp
     * @see Proj#inverse(Point)
     *
     */
    public LatLonPoint inverse(int x, int y, LatLonPoint llp) {
	// convert from screen to world coordinates
	x = x - wx;
	y = hy - y;

// 	Debug.output("Orthographic.inverse: x,y=" + x + "," + y);

	double rho = Math.sqrt(x*x + y*y);
	if (rho == 0d) {
	    Debug.message("proj", "Orthographic.inverse: center!");
	    llp.setLatLon(
		    ProjMath.radToDeg(ctrLat),
		    ProjMath.radToDeg(ctrLon));
	    return llp;
	}

	double c = MoreMath.asin(rho/scaled_radius);
	double cosC = Math.cos(c);
	double sinC = Math.sin(c);

	// calculate latitude 
	double lat = MoreMath.asin(
	    cosC * sinCtrLat + (y * sinC * (cosCtrLat/rho)));


	// calculate longitude
	double lon;
	if (ctrLat == NORTH_POLE) {
	    lon = ctrLon + MoreMath.atan2(x, -y);
	} else if (ctrLat == SOUTH_POLE) {
	    lon = ctrLon + MoreMath.atan2(x, y);
	} else {
	    lon = ctrLon + MoreMath.atan2(
		(x * sinC),
		(rho * cosCtrLat * cosC - y * sinCtrLat * sinC));
	}
// 	Debug.output("Orthographic.inverse: lat,lon=" +
// 			   ProjMath.radToDeg(lat) + "," +
// 			   ProjMath.radToDeg(lon));

	// check if point in outer space
//	if (MoreMath.approximately_equal(lat, ctrLat) &&
//	       MoreMath.approximately_equal(lon, ctrLon) &&
//	       (Math.abs(x-(width/2))<2) &&
//	       (Math.abs(y-(height/2))<2))
	if (Double.isNaN(lat) || Double.isNaN(lon))
	{
//	    Debug.message("proj", "Orthographic.inverse(): outer space!");
	    lat = ctrLat;
	    lon = ctrLon;
	}
	llp.setLatLon(
		ProjMath.radToDeg(lat),
		ProjMath.radToDeg(lon));
	return llp;
    }


    /**
     * Inverse project a Point.
     * <p>
     * @param point x,y Point
     * @param llp resulting LatLonPoint
     * @return LatLonPoint llp
     *
     */
    public LatLonPoint inverse(Point pt, LatLonPoint llp) {
	return inverse(pt.x, pt.y, llp);
    }


    /**
     * Get the upper left (northernmost and westernmost) point of the
     * projection.
     * <p>
     * Returns the upper left point (or closest equivalent) of the
     * projection based on the center point and height and width of
     * screen.
     * <p>
     * @return LatLonPoint
     */
    public LatLonPoint getUpperLeft() {
	LatLonPoint tmp = new LatLonPoint();
	double lat, lon;

	// over north pole
	if (overNorthPole()) {
	    lat = NORTH_POLE;
	    lon = -DATELINE;
	}

	// over south pole
	else if (overSouthPole()) {
	    lon = -DATELINE;

	    // get the left top corner
	    tmp = inverse(0, 0, tmp);

	    // check for invalid
	    if (MoreMath.approximately_equal(tmp.radlon_, ctrLon, 0.0001d)) {
		lat = ctrLat + MoreMath.HALF_PI;
	    } else {
		// northernmost coord is left top
		lat = tmp.radlat_;
	    }
	}

	// view in northern hemisphere
	else if (ctrLat >= 0d) {
	    // get the left top corner
	    tmp = inverse(0,0,tmp);

	    // check for invalid
	    if (MoreMath.approximately_equal(tmp.radlon_, ctrLon, 0.0001d)) {
		lat = inverse(width/2, 0, tmp).radlat_;
		lon = -DATELINE;
	    } else {
		// westernmost coord is left top
		lon = tmp.radlon_;
		// northernmost coord is center top
		lat = inverse(width/2, 0, tmp).radlat_;
	    }
	}

	// view in southern hemisphere
	else {
	    // get the left top corner
	    tmp = inverse(0, 0, tmp);

	    // check for invalid
	    if (MoreMath.approximately_equal(tmp.radlon_, ctrLon, 0.0001d)) {
		lat = ctrLat + MoreMath.HALF_PI;
		lon = -DATELINE;
	    } else {
		// northernmost coord is left top
		lat = tmp.radlat_;
		// westernmost coord is left bottom
		lon = inverse(0, height-1, tmp).radlon_;
	    }
	}
	tmp.setLatLon(lat, lon, true);
//	Debug.output("ul="+tmp);
	return tmp;
    }


    /**
     * Get the lower right (southeast) point of the projection.
     * <p>
     * Returns the lower right point (or closest equivalent) of the
     * projection based on the center point and height and width of
     * screen.
     * <p>
     * This is trivial for most cylindrical projections, but much more
     * complicated for azimuthal projections.
     * <p>
     * @return LatLonPoint
     */
    public LatLonPoint getLowerRight() {
	LatLonPoint tmp = new LatLonPoint();
	double lat, lon;

	// over north pole
	if (overNorthPole()) {
	    lon = DATELINE;

	    // get the right bottom corner
	    tmp = inverse(width-1, height-1, tmp);

	    // check for invalid
	    if (MoreMath.approximately_equal(tmp.radlon_, ctrLon, 0.0001d)) {
		lat = ctrLat - MoreMath.HALF_PI;
	    } else {
		// southernmost coord is right bottom
		lat = tmp.radlat_;
	    }
	}

	// over south pole
	else if (overSouthPole()) {
	    lat = SOUTH_POLE;
	    lon = DATELINE;
	}

	// view in northern hemisphere
	else if (ctrLat >= 0d) {
	    // get the right bottom corner
	    tmp = inverse(width-1, height-1, tmp);

	    // check for invalid
	    if (MoreMath.approximately_equal(tmp.radlon_, ctrLon, 0.0001d)) {
		lat = ctrLat - MoreMath.HALF_PI;
		lon = DATELINE;
	    } else {
		// southernmost coord is right bottom
		lat = tmp.radlat_;
		// easternmost coord is right top
		lon = inverse(width-1, 0, tmp).radlon_; 
	    }
	}

	// view in southern hemisphere
	else {
	    // get the right bottom corner
	    tmp = inverse(width-1, height-1, tmp);

	    // check for invalid
	    if (MoreMath.approximately_equal(tmp.radlon_, ctrLon, 0.0001d)) {
		lat = inverse(width/2, height-1, tmp).radlat_;
		lon = DATELINE;
	    } else {
		// easternmost coord is right bottom
		lon = tmp.radlon_;
		// southernmost coord is center bottom
		lat = inverse(width/2, height-1, tmp).radlat_;
	    }
	}
	tmp.setLatLon(lat, lon, true);
//	Debug.output("lr="+tmp);
	return tmp;
    }


    /*
    public void testPoint(double lat, double lon) {
	double x, y;
	lon = wrap_longitude(ProjMath.degToRad(lon));
	lat = normalize_latitude(ProjMath.degToRad(lat));
	x = forward_x(lat, lon);
	y = forward_y(lat, lon);

	Debug.output("(lon="+ProjMath.radToDeg(lon)+",lat="+
		ProjMath.radToDeg(lat)+
			   ") = (x="+x+",y="+y+")");
	lat = inverse_lat(x, y);
	lon = wrap_longitude(inverse_lon(x, y));
	Debug.output("(x="+x+",y="+y+") = (lon="+
			   ProjMath.radToDeg(lon)+",lat="+
			   ProjMath.radToDeg(lat)+")");
    }

    public static void main (String argv[]) {
	Orthographic proj=null;
	proj = new Orthographic(new LatLonPoint(40.0d, 0.0d), 1.0d, 620, 480);

	Debug.output("testing");
	proj.setEarthRadius(1.0d);
	Debug.output("setEarthRadius("+proj.getEarthRadius()+")");
	proj.setPPM(1);
	Debug.output("setPPM("+proj.getPPM()+")");
	proj.setMinScale(1.0d);
	Debug.output("setMinScale("+proj.getMinScale()+")");
	try {
	    proj.setScale(1.0d);
	} catch (java.beans.PropertyVetoException e) {
	}
	Debug.output("setScale("+proj.getScale()+")");
	Debug.output(proj);
	Debug.output();

	Debug.output("---testing latitude");
	proj.testPoint(0.0d, 0.0d);
	proj.testPoint(10.0d, 0.0d);
	proj.testPoint(40.0d, 0.0d);
	proj.testPoint(-80.0d, 0.0d);
	proj.testPoint(-90.0d, 0.0d);
	proj.testPoint(100.0d, 0.0d);
	proj.testPoint(-3272.0d, 0.0d);
	Debug.output("---testing longitude");
	proj.testPoint(0.0d, 10.0d);
	proj.testPoint(0.0d, -10.0d);
	proj.testPoint(0.0d, 90.0d);
	proj.testPoint(0.0d, -90.0d);
	proj.testPoint(0.0d, 170.0d);
	proj.testPoint(0.0d, -170.0d);
	proj.testPoint(0.0d, 180.0d);
	proj.testPoint(0.0d, -180.0d);
	proj.testPoint(0.0d, 190.0d);
	proj.testPoint(0.0d, -190.0d);
	Debug.output("---testing lat&lon");
	proj.testPoint(100.0d, 370.0d);
	proj.testPoint(-30.0d, -370.0d);
	proj.testPoint(-80.0d, 550.0d);
	proj.testPoint(0.0d, -550.0d);
    }
    */
}

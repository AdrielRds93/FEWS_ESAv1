/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 *           restricted rights as set forth in the DFARS.
 *  
 *                         BBNT Solutions LLC
 *                            A Part of  
 *                               GTE      
 *                        10 Moulton Street
 *                       Cambridge, MA 02138
 *                          (617) 873-3000
 *  
 *        Copyright 1998-2000 by BBNT Solutions LLC,
 *              A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/proj/Proj.java,v $
 * $Revision: 1.33 $
 * $Date: 2000/07/27 14:43:49 $
 * $Author: dietrick $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.proj;

import com.bbn.openmap.Environment;
import com.bbn.openmap.LatLonPoint;
import com.bbn.openmap.MoreMath;
import com.bbn.openmap.util.Debug;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Point;
import java.util.Vector;


/**
 * Proj is the base class of all Projections.
 * <p>
 * You probably don't want to use this class unless you are hacking your own
 * projections, or need extended functionality.  To be safe you will want to
 * use the Projection interface.
 *
 * <h3>Notes:</h3>
 *
 * <ul>
 *
 * <li>We deal in radians internally.  The outside world usually deals
 * in decimal degrees.  If you have data in radians, DON'T bother
 * converting it into DD's since we'll convert it right back into radians for
 * the projection step.  For more optimization tips, see the OMPoly class.
 *
 * <li>We default to projecting our data using the WGS84 datum.  You
 * can change the appropriate parameters of the projection after
 * construction if you need to use a different datum.  And of course
 * you can derive your own projections from this class as you see fit.
 *
 * <li>The forward() and inverse() methods are currently implemented
 * using the algorithms given in John Synder's <i>Map Projections --A
 * Working Manual</i> for the sphere.  This is sufficient for display
 * purposes, but you should use ellipsoidal algorithms in the
 * GreatCircle class to calculate distance and azimuths on the
 * ellipsoid.  See each projection individually for more information.
 *
 * <li>This class is not thread safe.  If two or more threads are
 * using the same Proj, then they could disrupt each other.
 * Occasionally you may need to call a <code>set</code> method of this
 * class.  This might interfere with another thread that's using the
 * same projection for <code>forwardPoly</code> or another Projection
 * interface method.  In general, you should not need to call any of
 * the <code>set</code> methods directly, but let the MapBean do it
 * for you.
 *
 * <li>All the various <code>forwardOBJ()</code> methods for vector
 * graphics ultimately go through <code>forwardPoly()</code>.
 *
 * </ul>
 *
 * @see Projection
 * @see Cylindrical
 * @see Mercator
 * @see CADRG
 * @see Azimuth
 * @see Orthographic
 * @see Planet
 * @see GreatCircle
 * @see com.bbn.openmap.omGraphics.OMPoly
 *
 */
public abstract class Proj implements Projection, Cloneable {

    // SOUTH_POLE <= phi <= NORTH_POLE   (radians)
    // -DATELINE <= lambda <= DATELINE   (radians)

    /**
     * North pole latitude in radians.
     */
    public final static transient double NORTH_POLE = ProjMath.NORTH_POLE_D;


    /**
     * South pole latitude in radians.
     */
    public final static transient double SOUTH_POLE = ProjMath.SOUTH_POLE_D;


    /**
     * Dateline longitude in radians.
     */
    public final static transient double DATELINE = ProjMath.DATELINE_D;


    /**
     * Minimum width of projection.
     */
    public final static transient int MIN_WIDTH = 10;	// pixels


    /**
     * Minimum height of projection.
     */
    public final static transient int MIN_HEIGHT = 10;	// pixels

    // Used for generating segments of vector objects
    protected static transient int NUM_DEFAULT_CIRCLE_VERTS = 64;
    protected static transient int NUM_DEFAULT_GREAT_SEGS = 512;


    // pixels per meter (an extra scaling factor).
    protected int pixelsPerMeter = Planet.defaultPixelsPerMeter; // PPM
    protected double planetRadius = Planet.wgs84_earthEquatorialRadiusMeters;// EARTH_RADIUS
    protected double planetPixelRadius = planetRadius*pixelsPerMeter; // EARTH_PIX_RADIUS
    protected double planetPixelCircumference = MoreMath.TWO_PI*planetPixelRadius; // EARTH_PIX_CIRCUMFERENCE

    protected int width = 640, height = 480;
    protected double minscale = 1.0d;	// 1:minscale
    protected double maxscale = planetPixelCircumference /(double)width;// good for cylindrical
    protected double scale = maxscale;
    protected double scaled_radius = planetPixelRadius/scale;
    protected double ctrLat=0.0d;		// center latitude in radians
    protected double ctrLon=0.0d;		// center longitude in radians
    protected int type = Mercator.MercatorType;	// Mercator is default
    protected String projID = null;		// identifies this projection
    protected Mercator mercator = null;		// for rhumbline calculations (if needed)
    protected Color backgroundColor = new Color(191,239,255);


    /**
     * Construct a projection.
     * <p>
     * @param center LatLonPoint center of projection
     * @param scale double scale of projection
     * @param w width of screen
     * @param h height of screen
     * @param type projection type
     * @see ProjectionFactory
     *
     */
    public Proj(LatLonPoint center, double s, int w, int h, int type)
    {
	if (Debug.debugging("proj")) {
	    Debug.output("Proj()");
	}
	this.type = type;
	setParms(center, s, w, h);
	projID = null;

	// for rhumbline projecting
	if (!(this instanceof Mercator)) {
	    mercator = new Mercator(center, scale, width, height);
	}
    }

    /**
     * Set the pixels per meter constant.
     * <p>
     * @param ppm int Pixels Per Meter scale-factor constant
     *
     */
    public void setPPM(int ppm) {
	pixelsPerMeter = ppm;
	if (pixelsPerMeter < 1) {
	    pixelsPerMeter = 1;
	}
	computeParameters();
    }

    /**
     * Get the pixels-per-meter constant.
     * <p>
     * @return int Pixels Per Meter scale-factor constant
     *
     */
    public int getPPM() {
	return pixelsPerMeter;
    }

    /**
     * Set the planet radius.
     * <p>
     * @param radius double planet radius in meters
     */
    public void setPlanetRadius(double radius) {
	planetRadius = radius;
	if (planetRadius < 1.0d) {
	    planetRadius = 1.0d;
	}
	computeParameters();
    }

    /**
     * Get the planet radius.
     * <p>
     * @return double radius of planet in meters
     */
    public double getPlanetRadius() {
	return planetRadius;
    }

    /**
     * Get the planet pixel radius.
     * <p>
     * @return double radius of planet in pixels
     */
    public double getPlanetPixelRadius() {
	return planetPixelRadius;
    }

    /**
     * Get the planet pixel circumference.
     * <p>
     * @return double circumference of planet in pixels
     */
    public double getPlanetPixelCircumference() {
	return planetPixelCircumference;
    }

    /**
     * Set the scale of the projection.
     * <p>
     * Sets the projection to the scale 1:s iff minscale &lt; s &lt;
     * maxscale.<br>
     * If s &lt; minscale, sets the projection to minscale.<br>
     * If s &gt; maxscale, sets the projection to maxscale.<br>
     * @param s double scale
     */
    public void setScale (double s) {
	scale = s;
	if (scale < minscale) {
	    scale = minscale;
	    computeParameters();
	} else if (scale > maxscale) {
	    scale = maxscale;
	    computeParameters();
	}
	computeParameters();
	projID = null;
    }

    /**
     * Set the minscale of the projection.
     * <p>
     * Usually you will not need to do this.
     * @param s double minscale
     *
     */
    public void setMinScale(double s) {
	if (s > maxscale)
	    return;

	minscale = s;
	if (scale < minscale) {
	    scale = minscale;
	}
	computeParameters();
	projID = null;
    }

    /**
     * Set the maximum scale of the projection.
     * <p>
     * Usually you will not need to do this.
     * @param s double minscale
     *
     */
    public void setMaxScale(double s) {
	if (s < minscale)
	    return;

	maxscale = s;
	if (scale > maxscale) {
	    scale = maxscale;
	}
	computeParameters();
	projID = null;
    }

    /**
     * Get the scale of the projection.
     * <p>
     * @return double scale value
     *
     */
    public double getScale () {
	return scale;
    }

    /**
     * Get the maximum scale of the projection.
     * <p>
     * @return double max scale value
     *
     */
    public double getMaxScale() {
	return maxscale;
    }

    /**
     * Get minimum scale of the projection.
     * <p>
     * @return double min scale value
     *
     */
    public double getMinScale() {
	return minscale;
    }

    /**
     * Set center point of projection.
     * <p>
     * @param lat double latitude in decimal degrees
     * @param lon double longitude in decimal degrees
     *
     */
    public void setCenter(double lat, double lon) {
	ctrLat = normalize_latitude(ProjMath.degToRad(lat));
	ctrLon = wrap_longitude(ProjMath.degToRad(lon));
	computeParameters();
	projID = null;
    }

    /**
     * Set center point of projection.
     * <p>
     * @param pt LatLonPoint
     */
    public void setCenter (LatLonPoint pt) {
	setCenter(pt.getLatitude(), pt.getLongitude());
    }

    /**
     * Get center point of projection.
     * <p>
     * @return LatLonPoint center of projection
     */
    public LatLonPoint getCenter () {
	return new LatLonPoint(ctrLat, ctrLon, true);
    }

    /**
     * Set projection width.
     * <p>
     * @param width width of projection screen
     *
     */
    public void setWidth (int width) {
	this.width = width;

	if (this.width < MIN_WIDTH) {
	    Debug.message("proj", "Proj.setWidth: width too small!");
	    this.width = MIN_WIDTH;
	}
	computeParameters();
	projID = null;
    }

    /**
     * Set projection height.
     * <p>
     * @param height height of projection screen
     */
    public void setHeight (int height) {
	this.height = height;
	if (this.height < MIN_HEIGHT){
	    Debug.message("proj", "Proj.setHeight: height too small!");
	    this.height = MIN_HEIGHT;
	}
	computeParameters();
	projID = null;
    }

    /**
     * Get projection width.
     * <p>
     * @return width of projection screen
     */
    public int getWidth () {
	return width;
    }

    /**
     * Get projection height.
     * <p>
     * @return height of projection screen
     */
    public int getHeight () {
	return height;
    }

    /**
     * Sets all the projection variables at once before calling
     * computeParameters().
     * <p>
     * @param center LatLonPoint center
     * @param scale double scale
     * @param width width of screen
     * @param height height of screen
     *
     */
    protected void setParms(
	LatLonPoint center, double scale, int width, int height)
    {
	ctrLat = normalize_latitude(center.radlat_);
	ctrLon = wrap_longitude(center.radlon_);

	this.scale = scale;
	if (this.scale < minscale) {
	    this.scale = minscale;
	} else if (this.scale > maxscale) {
	    this.scale = maxscale;
	}

	this.width = width;
	if (this.width < MIN_WIDTH) {
	    Debug.message("proj", "Proj.setParms: width too small!");
	    this.width = MIN_WIDTH;
	}
	this.height = height;
	if (this.height < MIN_HEIGHT) {
	    Debug.message("proj", "Proj.setParms: height too small!");
	    this.height = MIN_HEIGHT;
	}

	computeParameters();
    }


    /**
     * Gets the projection type.
     * <p>
     * @return int projection type
     */
    public int getProjectionType () {
	return type;
    }


    /**
     * Sets the projection ID used for determining equality.
     * The projection ID String is intern()ed for efficient comparison.
     */
    protected void setProjectionID () {
	projID = (":" + type + ":" + scale + ":" + ctrLat + ":" 
		  + ctrLon + ":" + width + ":" + height + ":").intern();
    }


    /**
     * Gets the projection ID used for determining equality.
     * <p>
     * @return the projection ID, as an intern()ed String
     */
    public String getProjectionID () {
	if (projID == null) setProjectionID();
	return projID;
    }


    /**
     * Called when some fundamental parameters change.
     * <p>
     * Each projection will decide how to respond to this change.
     * For instance, they may need to recalculate "constant" paramters
     * used in the forward() and inverse() calls.<p>
     *
     */
    protected abstract void computeParameters();


    /**
     * Sets radian latitude to something sane.
     * <p>
     * Normalizes the latitude according to the particular projection.
     * @param lat double latitude in radians
     * @return double latitude (-PI/2 &lt;= y &lt;= PI/2)
     * @see ProjMath#normalize_latitude(double, double)
     * @see LatLonPoint#normalize_latitude(double)
     *
     */
    public abstract double normalize_latitude (double lat);


    /**
     * Sets radian longitude to something sane.
     * <p>
     * @param lon double longitude in radians
     * @return double longitude (-PI &lt;= x &lt; PI)
     * @see ProjMath#wrap_longitude(double)
     * @see LatLonPoint#wrap_longitude(double)
     *
     */
    public final static double wrap_longitude (double lon) {
	return ProjMath.wrap_longitude(lon);
    }


    /**
     * Stringify the projection.
     * <p>
     * @return stringified projection
     * @see #getProjectionID
     *
     */
    public String toString() {
	return (" radius=" + planetRadius +
		" ppm=" + pixelsPerMeter + " center(" +
		ProjMath.radToDeg(ctrLat) + "," + ProjMath.radToDeg(ctrLon) +
		") scale=" + scale + " maxscale=" + maxscale +
		" minscale=" + minscale +
		" width=" + width + " height=" + height + "]");
    }


    /**
     * Test for equality.
     * <p>
     * @param p Object to compare.
     * @return boolean comparison
     *
     */
    public boolean equals (Object o) {
	if (o == null)
	    return false;
	if (o instanceof Projection)
	    return getProjectionID() == ((Projection)o).getProjectionID();
	return false;
    }


    /**
     * Return hashcode value of projection.
     * <p>
     * @return int hashcode
     */
    public int hashCode() {
	return getProjectionID().hashCode();
    }


    /**
     * Clone the projection.
     * <p>
     * @return Projection clone of this one.
     */
    public Projection makeClone () {
	return (Projection)this.clone();
    }


    /**
     * Copies this projection.
     * <p>
     * @return a copy of this projection.
     */
    public Object clone () {
	try {
	    return super.clone();
	} catch (CloneNotSupportedException e) { 
	    // this shouldn't happen, since we are Cloneable
	    throw new InternalError();
	}
    }


    /**
     * Checks if a LatLonPoint is plot-able.
     * <p>
     * Call this to check and see if a LatLonPoint can be plotted.  This is
     * meant to be used for checking before projecting and rendering Point
     * objects (bitmaps for instance).
     * <p>
     * @param llpoint LatLonPoint
     * @return boolean
     */
    public boolean isPlotable(LatLonPoint llpoint) {
	return isPlotable(llpoint.getLatitude(), llpoint.getLongitude());
    }


    /**
     * Forward project a LatLonPoint.
     * <p>
     * Forward projects a LatLon point into XY space.  Returns a
     * Point.
     * <p>
     * @param point LatLonPoint
     * @param llp LatLonPoint to be projected
     * @return Point (new)
     *
     */
    public final Point forward (LatLonPoint llp) {
	return forward(llp.radlat_, llp.radlon_, new Point(0,0), true);
    }


    /**
     * Forward project lat,lon coordinates.
     * <p>
     * @param lat double latitude in decimal degrees
     * @param lon double longitude in decimal degrees
     * decimal degrees
     * @return Point (new)
     *
     */
    public final Point forward (double lat, double lon) {
	return forward(lat, lon, new Point(0,0));
    }


    /**
     * Inverse project a Point from x,y space to LatLon space.
     * <p>
     * @param point x,y Point
     * @return LatLonPoint (new)
     */
    public final LatLonPoint inverse (Point point) {
	return inverse(point, new LatLonPoint());
    }


    /**
     * Inverse project x,y coordinates.
     * <p>
     * @param x integer x coordinate
     * @param y integer y coordinate
     * @return LatLonPoint (new)
     * @see #inverse(Point)
     *
     */
    public final LatLonPoint inverse (int x, int y) {
	return inverse(x, y, new LatLonPoint());
    }


    /**
     * Forward project a line.
     * <p>
     * @param ll1 LatLonPoint
     * @param ll2 LatLonPoint
     * @param ltype LineType
     * @param nsegs number of segments
     * @return Vector
     *
     */
    public Vector forwardLine (
	    LatLonPoint ll1, LatLonPoint ll2, int ltype, int nsegs)
    {
	double[] rawllpts = new double[4];
	rawllpts[0] = ll1.radlat_;
	rawllpts[1] = ll1.radlon_;
	rawllpts[2] = ll2.radlat_;
	rawllpts[3] = ll2.radlon_;
	return forwardPoly(
		rawllpts,
		ltype,
		nsegs,
		false
		);
    }


    /**
     * Forward project a lat/lon Line.
     * @see #forwardLine(LatLonPoint, LatLonPoint, int, int)
     */
    public Vector forwardLine (LatLonPoint ll1, LatLonPoint ll2, int ltype) {
	return forwardLine(ll1, ll2, ltype, -1);
    }


    /**
     * Forward project a rectangle.
     * <p>
     * @param ll1 LatLonPoint
     * @param ll2 LatLonPoint
     * @param ltype LineType
     * @param nsegs number of segments
     * @param isFilled filled poly?
     * @return Vector
     */
    public Vector forwardRect (
	    LatLonPoint ll1, LatLonPoint ll2, int ltype, int nsegs, boolean isFilled)
    {
	double[] rawllpts = new double[10];
	rawllpts[0] = ll1.radlat_;
	rawllpts[1] = ll1.radlon_;
	rawllpts[2] = ll1.radlat_;
	rawllpts[3] = ll2.radlon_;
	rawllpts[4] = ll2.radlat_;
	rawllpts[5] = ll2.radlon_;
	rawllpts[6] = ll2.radlat_;
	rawllpts[7] = ll1.radlon_;
	// connect:
	rawllpts[8] = ll1.radlat_;
	rawllpts[9] = ll1.radlon_;
	return forwardPoly(rawllpts, ltype, nsegs, isFilled);
    }


    public Vector forwardRect (
	    LatLonPoint ll1, LatLonPoint ll2, int ltype, int nsegs) {
	return forwardRect(ll1, ll2, ltype, nsegs, false);
    }

    /**
     * Forward project a lat/lon Rectangle.
     * @see #forwardRect(LatLonPoint, LatLonPoint, int, int)
     */
    public Vector forwardRect (LatLonPoint ll1, LatLonPoint ll2, int ltype) {
	return forwardRect(ll1, ll2, ltype, -1, false);
    }


    /**
     * Forward project a circle.
     * <p>
     * @param c LatLonPoint center
     * @param radians boolean radius in radians?
     * @param radius radius in radians or decimal degrees
     *
     */
    public Vector forwardCircle(LatLonPoint c, boolean radians, double radius) {
	return forwardCircle(c, radians, radius, -1, false);
    }
    public Vector forwardCircle(
	    LatLonPoint c, boolean radians, double radius, int nverts) {
	return forwardCircle(c, radians, radius, nverts, false);
    }


    /**
     * Forward project a Lat/Lon Circle.
     * <p>
     * Circles have the same restrictions as <a href="#poly_restrictions">
     * polys</a>.<p>
     *
     * @param c LatLonPoint center of circle
     * @param radians radius in radians or decimal degrees?
     * @param radius radius of circle (0 &lt; radius &lt; 180)
     * @param nverts number of vertices of the circle poly.
     * @param isFilled filled poly?
     */
    public Vector forwardCircle(
	    LatLonPoint c, boolean radians, double radius, int nverts, boolean isFilled)
    {
	// HACK-need better decision for number of vertices.
	if (nverts < 3)
	    nverts = NUM_DEFAULT_CIRCLE_VERTS;

	double[] rawllpts = new double[(nverts<<1)+2];//*2 for pairs +2 connect
	GreatCircle.earth_circle(
		c.radlat_, c.radlon_,
		(radians) ? radius : ProjMath.degToRad(radius),
		nverts, rawllpts);
	// connect the vertices.
	rawllpts[rawllpts.length-2] = rawllpts[0];
	rawllpts[rawllpts.length-1] = rawllpts[1];

	// forward project the circle-poly
	return forwardPoly(rawllpts, LineType.Straight, -1, isFilled);
    }


    //HACK
    protected transient static int XTHRESHOLD = 16384;//half range
    protected transient int XSCALE_THRESHOLD = 1000000;//dynamically calculated

    public Vector forwardPoly (
	double[] rawllpts, int ltype, int nsegs) {
	return forwardPoly(rawllpts, ltype, nsegs, false);
    }

    /**
     * Forward project a lat/lon Poly.
     * <p>
     * Delegates to _forwardPoly(), and may do additional clipping for Java
     * XWindows problem.  Remember to specify vertices in radians!
     * @param rawllpts double[] of lat,lon,lat,lon,... in RADIANS!
     * @param ltype line type (straight, rhumbline, greatcircle)
     * @param nsegs number of segment points (only for greatcircle or
     * rhumbline line types, and if &lt; 1, this value is generated internally)
     * @param isFilled filled poly?
     * @return Vector of x[], y[], x[], y[], ... projected poly
     * @see #forwardRaw
     * @see LineType#Straight
     * @see LineType#Rhumb
     * @see LineType#GreatCircle
     */
    public Vector forwardPoly (
	double[] rawllpts, int ltype, int nsegs, boolean isFilled)
    {
	Vector stuff = _forwardPoly(rawllpts, ltype, nsegs, isFilled);
	// @HACK: workaround XWindows bug.  simple clip to a boundary.  this
	// is ugly.
	if (Environment.doingXWindowsWorkaround && (scale <= XSCALE_THRESHOLD)) {
	    int i, j, size = stuff.size();
	    int[] xpts, ypts;
	    for (i=0; i<size; i+=2) {
		xpts = (int[])stuff.elementAt(i);
		ypts = (int[])stuff.elementAt(i+1);
		for (j=0; j<xpts.length; j++) {
		    if (xpts[j] <= -XTHRESHOLD) {
			xpts[j] = -XTHRESHOLD;
		    }
		    else
		    if (xpts[j] >= XTHRESHOLD) {
			xpts[j] = XTHRESHOLD;
		    }
		    if (ypts[j] <= -XTHRESHOLD) {
			ypts[j] = -XTHRESHOLD;
		    }
		    else
		    if (ypts[j] >= XTHRESHOLD) {
			ypts[j] = XTHRESHOLD;
		    }
		}
		stuff.setElementAt(xpts,i);
		stuff.setElementAt(ypts,i+1);
	    }
	}
	return stuff;
    }


    /**
     * Forward project a lat/lon Poly.
     * Remember to specify vertices in radians!
     * @param rawllpts double[] of lat,lon,lat,lon,... in RADIANS!
     * @param ltype line type (straight, rhumbline, greatcircle)
     * @param nsegs number of segment points (only for greatcircle or
     * rhumbline line types, and if &lt; 1, this value is generated internally)
     * @param isFilled filled poly?
     * @return Vector of x[], y[], x[], y[], ... projected poly
     */
    protected abstract Vector _forwardPoly (
	double[] rawllpts, int ltype, int nsegs, boolean isFilled);


    /**
     * Forward project a rhumbline poly.
     * <p>
     * Draws rhumb lines between vertices of poly.  Remember to
     * specify vertices in radians!  Check in-code comments for
     * details about the algorithm.
     * <p>
     * @param rawllpts double[] of lat,lon,lat,lon,... in
     * RADIANS!
     * @param nsegs number of segments to draw for greatcircle
     * or rhumb lines (if &lt; 1, this value is generated internally).
     * @param isFilled filled poly?
     * @return Vector of x[], y[], x[], y[], ... projected poly
     * @see Projection#forwardPoly(double[], int, int)
     */
    protected Vector forwardRhumbPoly(double[] rawllpts, int nsegs, boolean isFilled) {

	// IDEA:
	//	Rhumblines are straight in the Mercator projection.
	//	So we can use the Mercator projection to calculate
	//	vertices along the rhumbline between two points.  But
	//	if there's a better way to calculate loxodromes,
	//	someone please chime in (openmap@bbn.com)...
	//
	// ALG:
	//	Project pairs of vertices through the Mercator
	//	projection into screen XY space, pick intermediate
	//	segment points along the straight XY line, then
	//	convert all vertices back into LatLon space.  Pass the
	//	augmented vertices to _forwardPoly() to be drawn as
	//	straight segments.
	//
	// WARNING:
	//	The algorithm fixes the Cylindrical-wrapping
	//	problem, and thus duplicates some code in
	//	Cylindrical._forwardPoly()
	//
	if (this instanceof Mercator) {//simple
	    return _forwardPoly(
		    rawllpts, LineType.Straight, nsegs, isFilled);
	}

	int i, n, xp, flag=0, xadj=0, totalpts=0;
	Point from = new Point(0,0);
	Point to = new Point(0,0);
	LatLonPoint llp=null;
	int len = rawllpts.length;

	double[][] augllpts = new double[len>>>1][0];

	// lock access to object global
	synchronized (mercator) {

	    // use mercator projection to calculate rhumblines.
	    mercator.setParms(
		    new LatLonPoint(ctrLat, ctrLon, true),
		    scale, width, height);

	    // project everything through the Mercator projection,
	    // building up lat/lon points along the original rhumb
	    // line between vertices.
	    mercator.forward(rawllpts[0], rawllpts[1], from, true);
	    xp = from.x;
	    for (i=0, n=2; n<len; i++, n+=2) {
		mercator.forward(rawllpts[n], rawllpts[n+1], to, true);
		// segment crosses longitude along screen edge
		if (Math.abs(xp - to.x) >= mercator.half_world) {
		    flag += (xp < to.x) ? -1 : 1;//inc/dec the wrap count
		    xadj = flag * mercator.world.x;//adjustment to x coordinates
//		    Debug.output("flag=" + flag + " xadj=" + xadj);
		}
		xp = to.x;
		if (flag != 0) {
		    to.x += xadj;//adjust x coordinate
		}

		augllpts[i] = mercator.rhumbProject(from, to, false, nsegs);
		totalpts+=augllpts[i].length;
		from.x = to.x; from.y = to.y;
	    }
	    llp = mercator.inverse(from);
	}// end synchronized around mercator

	augllpts[i] = new double[2];
	augllpts[i][0] = llp.radlat_;
	augllpts[i][1] = llp.radlon_;
	totalpts+=2;

	// put together all the points
	double[] newllpts = new double[totalpts];
	int pos=0;
	for (i=0; i<augllpts.length; i++) {
//	    Debug.output("copying " + augllpts[i].length + " floats");
	    System.arraycopy(
		    /*src*/augllpts[i], 0,
		    /*dest*/newllpts, pos, augllpts[i].length);
	    pos+=augllpts[i].length;
	}
//	Debug.output("done copying " + totalpts + " total floats");

	// free unused variables
	augllpts = null;

	// now delegate the work to the regular projection code.
	return _forwardPoly(newllpts, LineType.Straight, -1, isFilled);
    }


    /**
     * Forward project a greatcircle poly.
     * <p>
     * Draws great circle lines between vertices of poly.  Remember to
     * specify vertices in radians!
     * <p>
     * @param rawllpts double[] of lat,lon,lat,lon,... in RADIANS!
     * @param nsegs number of segments to draw for greatcircle or
     * rhumb lines (if &lt; 1, this value is generated internally).
     * @param isFilled filled poly?
     * @return Vector of x[], y[], x[], y[], ... projected poly
     * @see Projection#forwardPoly(double[], int, int)
     */
    protected Vector forwardGreatPoly(double[] rawllpts, int nsegs, boolean isFilled) {
 	int i, j, k, totalpts=0;

	Point from = new Point();
	Point to = new Point();

	int end = rawllpts.length>>>1;
	double[][] augllpts = new double[end][0];
	end-=1;//stop before last segment

	// calculate extra vertices between all the original segments.
	forward(rawllpts[0], rawllpts[1], from, true);
	for (i=0, j=0, k=2; i<end; i++, j+=2, k+=2) {
	    forward(rawllpts[k], rawllpts[k+1], to, true);
	    augllpts[i] = getGreatVertices(
		    rawllpts[j], rawllpts[j+1], rawllpts[k], rawllpts[k+1],
		    from, to, false, nsegs);
	    from.x = to.x; from.y = to.y;
	    totalpts += augllpts[i].length;
	}
	augllpts[i] = new double[2];
	augllpts[i][0] = rawllpts[j];
	augllpts[i][1] = rawllpts[j+1];
	totalpts += 2;

	// put together all the points
	double[] newllpts = new double[totalpts];
	int pos=0;
	for (i=0; i<augllpts.length; i++) {
	    System.arraycopy(
		    /*src*/augllpts[i], 0,
		    /*dest*/newllpts, pos, augllpts[i].length);
	    pos+=augllpts[i].length;
	}

	// free unused variables
	augllpts = null;

	// now delegate the work to the regular projection code.
	return _forwardPoly(newllpts, LineType.Straight, -1, isFilled);
    }


    /**
     * Get the vertices along the great circle between two points.
     * <p>
     * @param latp previous double latitude
     * @param lonp previous double longitude
     * @param latn next double latitude
     * @param lonn next double longitude
     * @param from Point
     * @param to Point
     * @param include_last include n or n+1 points of the n segments?
     * @return double[] lat/lon points in RADIANS!
     *
     */
    private double[] getGreatVertices(
	    double latp, double lonp, double latn, double lonn,
	    Point from, Point to, boolean include_last, int nsegs)
    {
	if (nsegs < 1) {
	    // calculate pixel distance
	    int dist = DrawUtil.pixel_distance(from.x, from.y, to.x, to.y);

	    // determine what would be a decent number of segments to draw.
	    // HACK: this is hardcoded calculated by what might look ok on
	    // screen.  We also put a cap on the number of extra segments we
	    // draw.
	    nsegs = dist>>3;// dist/8
	    if (nsegs == 0) {
		nsegs = 1;
	    }
	    else if (nsegs > NUM_DEFAULT_GREAT_SEGS) {
		nsegs = NUM_DEFAULT_GREAT_SEGS;
	    }

//	    Debug.output(
//		    "("+from.x+","+from.y+")("+to.x+","+to.y+") dist="+dist+" nsegs="+nsegs);
	}

	// both of these return double[] radian coordinates!
	double[] radpts;
	return GreatCircle.great_circle(
		latp, lonp, latn, lonn, nsegs, include_last);
    }


    /**
     * Forward projects a raster.
     * <p>
     * HACK: not implemented yet.
     * @param llNW LatLonPoint of NorthWest corner of Image
     * @param llSE LatLonPoint of SouthEast corner of Image
     * @param image raster image
     *
     */
    public Vector forwardRaster(LatLonPoint llNW, LatLonPoint llSE, Image image) {
	Debug.error("Proj.forwardRaster(): unimplemented!");
	return null;
    }


    /**
     * Check for complicated linetypes.
     * <p>
     * This depends on the line and this projection.
     * <p>
     * @param ltype int LineType
     * @return boolean
     *
     */
    public boolean isComplicatedLineType(int ltype) {
	switch (ltype) {
	  case LineType.Straight:
	      return false;
	  case LineType.Rhumb:
	      return (getProjectionType() == Mercator.MercatorType) ? false : true;
	  case LineType.GreatCircle:
	      return true/*(getProjectionType() == Gnomonic.GnomonicType) ? false : true*/;
	  default:
	      Debug.error(
		  "Proj.isComplicatedLineType: invalid LineType!");
	      return false;
	}
    }

    /**
     * Generates a complicated poly.
     * <p>
     * @param llpts LatLonPoint[]
     * @param ltype line type
     * @param connect polygon or polyline
     * @param nsegs number of segments to draw for greatcircle or
     * rhumb lines (if &lt; 1, this value is generated internally).
     * @param isFilled filled poly?
     * @return Vector
     * @see Projection#forwardPoly
     *
     */ 
    protected Vector doPolyDispatch(
	double[] rawllpts, int ltype, int nsegs, boolean isFilled)
    {
	switch (ltype) {
	  case LineType.Rhumb:
	      return forwardRhumbPoly(rawllpts, nsegs, isFilled);
	  case LineType.GreatCircle:
	      return forwardGreatPoly(rawllpts, nsegs, isFilled);
	  case LineType.Straight:
	      Debug.error(
		  "Proj.doPolyDispatch: Bad Dispatch!\n");
	      return new Vector(0);
	  default:
	      Debug.error(
		  "Proj.doPolyDispatch: Invalid LType!\n");
	      return new Vector(0);
	}
    }


    /**
     * Pan the map/projection.
     * <p>
     * Example pans:
     * <ul>
     * <li><code>pan(�180, c)</code> pan south `c' degrees
     * <li><code>pan(-90, c)</code> pan west `c' degrees
     * <li><code>pan(0, c)</code> pan north `c' degrees
     * <li><code>pan(90, c)</code> pan east `c' degrees
     * </ul>
     * @param Az azimuth "east of north" in decimal degrees:
     * <code>-180 &lt;= Az &lt;= 180</code>
     * @param c arc distance in decimal degrees
     */
    public void pan (double Az, double c) {
	setCenter(GreatCircle.spherical_between(
		    ctrLat, ctrLon, ProjMath.degToRad(c),
		    ProjMath.degToRad(Az)));
    }


    /**
     * Pan the map/projection.
     * <ul>
     * <li><code>pan(�180, c)</code> pan south
     * <li><code>pan(-90, c)</code> pan west
     * <li><code>pan(0, c)</code> pan north
     * <li><code>pan(90, c)</code> pan east
     * </ul>
     * @param Az azimuth "east of north" in decimal degrees:
     * <code>-180 &lt;= Az &lt;= 180</code>
     */
    public void pan (double Az) {
	pan(Az, 45d);
    }


    /**
     * pan the map northwest.
     */
    final public void panNW() {
	pan(-45d);
    }
    final public void panNW(double c) {
	pan(-45d);
    }


    /**
     * pan the map north.
     */
    final public void panN() {
	pan(0d);
    }
    final public void panN(double c) {
	pan(0d);
    }


    /**
     * pan the map northeast.
     */
    final public void panNE() {
	pan(45d);
    }
    final public void panNE(double c) {
	pan(45d);
    }


    /**
     * pan the map east.
     */
    final public void panE() {
	pan(90d);
    }
    final public void panE(double c) {
	pan(90d);
    }


    /**
     * pan the map southeast.
     */
    final public void panSE() {
	pan(135d);
    }
    final public void panSE(double c) {
	pan(135d);
    }


    /**
     * pan the map south.
     */
    final public void panS() {
	pan(180d);
    }
    final public void panS(double c) {
	pan(180d);
    }


    /**
     * pan the map southwest.
     */
    final public void panSW() {
	pan(-135d);
    }
    final public void panSW(double c) {
	pan(-135d);
    }


    /**
     * pan the map west.
     */
    final public void panW() {
	pan(-90d);
    }
    final public void panW(double c) {
	pan(-90d);
    }


    /**
     * Draw the background for the projection.
     * @param g Graphics
     *
     */
    abstract public void drawBackground (Graphics g);


    /**
     * Get the background color.
     * @return Color
     */
    public Color getBackgroundColor () {
	return backgroundColor;
    }


    /**
     * Set the background color.
     * @param color Color
     */
    public void setBackgroundColor (Color color) {
	backgroundColor=color;
    }
}

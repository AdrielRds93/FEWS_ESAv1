/* **********************************************************************
 *
 *    Use, duplication, or disclosure by the Government is subject to
 *           restricted rights as set forth in the DFARS.
 *
 *                         BBNT Solutions LLC
 *                            A Part of
 *                               GTE
 *                        10 Moulton Street
 *                       Cambridge, MA 02138
 *                          (617) 873-3000
 *
 *        Copyright 1998, 2000 by BBNT Solutions LLC,
 *              A part of GTE, all rights reserved.
 *
 * **********************************************************************
 *
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/proj/GreatCircle.java,v $
 * $Revision: 1.16 $
 * $Date: 2000/05/08 14:23:24 $
 * $Author: wjeuerle $
 *
 * **********************************************************************
 */


package com.bbn.openmap.proj;

import com.bbn.openmap.LatLonPoint;
import com.bbn.openmap.MoreMath;

/**
 * Methods for calculating great circle and other distances on the sphere and
 * ellipsoid.
 * <p>
 * Spherical equations taken from John Synder's <i>Map Projections --A Working Manual</i>,
 * pp29-31.<br>
 * Latitude/longitude arguments must be in valid radians:
 * -PI&lt;=lambda&lt;PI, -PI/2&lt;=phi&lt;=PI/2
 */
public class GreatCircle {


    // cannot construct
    private GreatCircle () {}


    /**
     * Determine azimuth and distance on the ellipsoid.
     * @param a Semi-major axis of ellipsoid
     * @param finv flattening of the ellipsoid (WGS84 is 1/298.257)
     * @param glat1 Latitude of from station
     * @param glon1 Longitude of from station
     * @param glat2 Latitude of to station
     * @param glon2 Longitude of to station
     * @param ret_val AziDist struct
     * @return AziDist ret_val struct with azimuth and distance
     * @deprecated this has been yanked until we have a more stable and
     * documented algorithm
     */
    public final static AziDist ellipsoidalAziDist(
	    double a,
	    double finv,
	    double glat1,
	    double glon1,
	    double glat2,
	    double glon2,
	    AziDist ret_val)
    {
	return null;
    }


    /**
     * Calculate spherical arc distance between two points.
     * <p>
     * Computes arc distance `c' on the sphere. equation
     * (5-3a). (0 &lt;= c &lt;= PI)
     * <p>
     * @param phi1 latitude in radians of start point
     * @param lambda0 longitude in radians of start point
     * @param phi latitude in radians of end point
     * @param lambda longitude in radians of end point
     * @return double arc distance `c'
     *
     */
    final public static double spherical_distance (
	double phi1, double lambda0, double phi, double lambda)
    {
	double pdiff = Math.sin(((phi-phi1)/2));
	double ldiff = Math.sin((lambda-lambda0)/2);
	double rval = Math.sqrt((pdiff*pdiff) +
		     Math.cos(phi1) * Math.cos(phi) *(ldiff*ldiff));

	return 2.0d * MoreMath.asin(rval);
    }


    /**
     * Calculate spherical azimuth between two points.
     * <p>
     * Computes the azimuth `Az' east of north from phi1, lambda0
     * bearing toward phi and lambda. (5-4b).  (-PI &lt;= Az &lt;= PI).
     * <p>
     * @param phi1 latitude in radians of start point
     * @param lambda0 longitude in radians of start point
     * @param phi latitude in radians of end point
     * @param lambda longitude in radians of end point
     * @return double azimuth east of north `Az'
     *
     */
    final public static double spherical_azimuth (
	double phi1, double lambda0, double phi, double lambda)
    {
	double ldiff = lambda - lambda0;
	double cosphi = Math.cos(phi);

	return MoreMath.atan2(
	    cosphi* Math.sin(ldiff),
	    (Math.cos(phi1) * Math.sin(phi) -
	     Math.sin(phi1) *cosphi*
                 Math.cos(ldiff)));
    }


    /**
     * Calculate point at azimuth and distance from another point.
     * <p>
     * Returns a LatLonPoint at arc distance `c' in direction `Az'
     * from start point.
     * <p>
     * @param phi1 latitude in radians of start point
     * @param lambda0 longitude in radians of start point
     * @param c arc radius in radians (0 &lt; c &lt;= PI)
     * @param Az azimuth (direction) east of north (-PI &lt;= Az &lt; PI)
     * @return LatLonPoint
     *
     */
    final public static LatLonPoint spherical_between(
	double phi1, double lambda0, double c, double Az)
    {
	double cosphi1 = Math.cos(phi1);
	double sinphi1 = Math.sin(phi1);
	double cosAz = Math.cos(Az);
	double sinAz = Math.sin(Az);
	double sinc = Math.sin(c);
	double cosc = Math.cos(c);

	return new LatLonPoint(ProjMath.radToDeg(
            MoreMath.asin(sinphi1*cosc + cosphi1*sinc*cosAz)),
	    ProjMath.radToDeg(MoreMath.atan2(
		sinc*sinAz, cosphi1*cosc - sinphi1*sinc*cosAz) + lambda0));
    }


    /**
     * Calculate point between two points.
     * <p>
     * Same as spherical_between() above except it calculates n equal
     * segments along the length of c.
     * <p>
     * @param phi1 latitude in radians of start point
     * @param lambda0 longitude in radians of start point
     * @param c arc radius in radians (0 &lt; c &lt;= PI)
     * @param Az azimuth (direction) east of north (-PI &lt;= Az &lt; PI)
     * @param n number of points along great circle edge to calculate
     * @return double[n+1] radian lat,lon pairs
     *
     */
    final public static double[] spherical_between(
	double phi1, double lambda0, double c, double Az, int n)
    {
	// full constants for the computation
	double cosphi1 = Math.cos(phi1);
	double sinphi1 = Math.sin(phi1);
	double cosAz = Math.cos(Az);
	double sinAz = Math.sin(Az);
	int end = n<<1;

	// new radian points
	double[] points = new double[end+2];
	points[0] = phi1;
	points[1] = lambda0;

	double inc = c/n; c = inc;
	for (int i=2; i<=end; i+=2, c+=inc) {

	    // partial constants
	    double sinc = Math.sin(c);
	    double cosc = Math.cos(c);

	    // generate new point
	    points[i] =
                MoreMath.asin(sinphi1*cosc + cosphi1*sinc*cosAz);

	    points[i+1] =
	        MoreMath.atan2(
		    sinc*sinAz, cosphi1*cosc - sinphi1*sinc*cosAz) + lambda0;
	}
	return points;
    }


    /**
     * Calculate great circle between two points on the sphere.
     * <p>
     * Folds all computation (distance, azimuth, points between) into
     * one function for optimization. returns n or n+1 pairs of lat,lon
     * on great circle between lat-lon pairs.
     * <p>
     * @param phi1 latitude in radians of start point
     * @param lambda0 longitude in radians of start point
     * @param phi latitude in radians of end point
     * @param lambda longitude in radians of end point
     * @param n number of segments
     * @param include_last return n or n+1 segments
     * @return double[n] or double[n+1] radian lat,lon pairs
     *
     */
    final public static double[] great_circle (
	double phi1, double lambda0, double phi, double lambda,
	int n, boolean include_last)
    {
	// number of points to generate
	int end = include_last ? n+1 : n;
	end<<=1;//*2 for pairs

	// calculate a bunch of stuff for later use
	double cosphi = Math.cos(phi);
	double cosphi1 = Math.cos(phi1);
	double sinphi1 = Math.sin(phi1);
	double ldiff = lambda - lambda0;
	double p2diff = Math.sin(((phi-phi1)/2));
	double l2diff = Math.sin((ldiff)/2);


	// calculate spherical distance
	double c = 2.0d * MoreMath.asin(
            Math.sqrt(p2diff*p2diff + cosphi1*cosphi*l2diff*l2diff));


	// calculate spherical azimuth
	double Az = MoreMath.atan2(
	    cosphi* Math.sin(ldiff),
	    (cosphi1* Math.sin(phi) -
	     sinphi1*cosphi*
                 Math.cos(ldiff)));
	double cosAz = Math.cos(Az);
	double sinAz = Math.sin(Az);


	// generate the great circle line
	double[] points = new double[end];
	points[0] = phi1;
	points[1] = lambda0;

	double inc = c/n; c = inc;
	for (int i=2; i<end; i+=2, c+=inc) {

	    // partial constants
	    double sinc = Math.sin(c);
	    double cosc = Math.cos(c);

	    // generate new point
	    points[i] =
                MoreMath.asin(sinphi1*cosc + cosphi1*sinc*cosAz);

	    points[i+1] =
	        MoreMath.atan2(
		    sinc*sinAz, cosphi1*cosc - sinphi1*sinc*cosAz) + lambda0;
	}
// 	Debug.output("Calculating GreatCircle: ");
// 	for (int i = 0; i< points.length; i++) {
// 	    Debug.output("(" + ProjMath.radToDeg(points[i].lat) + "," +
// 			       ProjMath.radToDeg(points[i].lon) + ") ");
// 	}
	return points;
    }//great_circle()


    /**
     * Calculate earth circle on the sphere.
     * <p>
     * Returns n double lat,lon pairs at arc distance c from point at
     * phi1,lambda0.
     * <p>
     * @param phi1 latitude in radians of center point
     * @param lambda0 longitude in radians of center point
     * @param c arc radius in radians (0 &lt; c &lt; PI)
     * @param n number of points along circle edge to calculate
     * @return double[n] radian lat,lon pairs along earth circle
     *
     */
    final public static double[] earth_circle (
	double phi1, double lambda0, double c, int n)
    {
	return earth_circle(phi1, lambda0, c, n, new double[n<<1]);
    }


    /**
     * Calculate earth circle in the sphere.
     * <p>
     * Returns n double lat,lon pairs at arc distance c from point at
     * phi1,lambda0.
     * <p>
     * @param phi1 latitude in radians of center point
     * @param lambda0 longitude in radians of center point
     * @param c arc radius in radians (0 &lt; c &lt; PI)
     * @param n number of points along circle edge to calculate
     * @param ret_val double[] ret_val array of n*2 number of points along circle edge to calculate
     * @return double[n] radian lat,lon pairs along earth circle
     *
     */
    final public static double[] earth_circle (
	double phi1, double lambda0, double c, int n, double[] ret_val)
    {
	double Az, cosAz, sinAz;
	double cosphi1 = Math.cos(phi1);
	double sinphi1 = Math.sin(phi1);
	double sinc = Math.sin(c);
	double cosc = Math.cos(c);
	int end = n<<1;//*2
//	double[] ret_val = new double[end];

	double inc = MoreMath.TWO_PI/n;
	Az = -Math.PI;

	// generate the points in clockwise order (conforming to
	// internal standard!)
	for (int i = 0; i < end; i+=2, Az+=inc) {
	    cosAz = Math.cos(Az);
	    sinAz = Math.sin(Az);

	    ret_val[i] =
                MoreMath.asin(sinphi1*cosc + cosphi1*sinc*cosAz);
	    ret_val[i+1] =
		MoreMath.atan2(
		    sinc*sinAz, cosphi1*cosc - sinphi1*sinc*cosAz) + lambda0;
	}

	return ret_val;
    }


    /* testing
    public final static void main (String[] args) {
	double phi1 = 34.3;
	double lambda0 = 130.299;
	double phi = -24;
	double lambda = 33.23;

	double dist_sphere = spherical_distance (
		ProjMath.degToRad((double)phi1),
		ProjMath.degToRad((double)lambda0),
		ProjMath.degToRad((double)phi),
		ProjMath.degToRad((double)lambda)
		);
	// meters
	dist_sphere = Planet.wgs84_earthEquatorialCircumferenceMeters*(dist_sphere/MoreMath.TWO_PI);
	Debug.output("sphere distance="+dist_sphere/1000d+" km");

	AziDist invVar = ellipsoidalAziDist (
		Planet.wgs84_earthEquatorialRadiusMeters,//major in meters
		Planet.wgs84_earthFlat,
//		Planet.international1974_earthEquatorialRadiusMeters,//major in meters
//		Planet.international1974_earthFlat,
		ProjMath.degToRad(phi1),
		ProjMath.degToRad(lambda0),
		ProjMath.degToRad(phi),
		ProjMath.degToRad(lambda),
		new AziDist()
		);
	Debug.output("ellipsoid distance="+invVar.distance/1000d+" km");
    }
    */
}

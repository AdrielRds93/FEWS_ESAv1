/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998-2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/omGraphics/OMText2D.java,v $
 * $Revision: 1.3 $ * $Date: 2000/08/02 14:25:38 $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.omGraphics;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Font;
import java.awt.FontMetrics;

/**
 * An extension of the OMText class that allows for rotated text.  [Requires
 * the Java2D API.]
 */
public class OMText2D extends OMText {
    /** the angle by which the text is to be rotated, in radians */
    protected double theta;

    /**
     * Default constructor.  Produces an instance with no location
     * and an empty string for text.  For this instance to be useful
     * it needs text (setData), a location (setX, setY, setLat, setLon)
     * and a renderType (setRenderType).
     */
    public OMText2D () {
        super();
    }

    /**
     * Creates a text object, with Lat/Lon placement, and default
     * SansSerif font.
     * @param lt latitude of the string, in decimal degrees.
     * @param ln longitude of the string, in decimal degrees.
     * @param stuff the string to be displayed.
     * @param just the justification of the string
     * @param theta the rotation of the text, in radians
     */
    public OMText2D(double lt, double ln, String stuff, int just, double theta) {
        super(lt,ln,stuff,just);
	this.theta = theta;
    }

    /**
     * Creates a text object, with Lat/Lon placement.
     * @param lt latitude of the string, in decimal degrees.
     * @param ln longitude of the string, in decimal degrees.
     * @param stuff the string to be displayed.
     * @param font the Font description for the string.
     * @param just the justification of the string
     * @param theta the rotation of the text, in radians
     */
    public OMText2D(double lt, double ln, String stuff,
		    Font font, int just, double theta) {
        super(lt, ln, stuff, font, just);
	this.theta = theta;
    }
  
    /**
     * Creates a text object, with XY placement, and default SansSerif
     * font. 
     * @param px1 horizontal window pixel location of the string.
     * @param py1 vertical window pixel location of the string.
     * @param stuff the string to be displayed.
     * @param just the justification of the string
     * @param theta the rotation of the text, in radians
     */
    public OMText2D(int px1, int py1, String stuff, int just, double theta) { 
        super(px1,py1,stuff,just);
	this.theta = theta;
    }
  
    /**
     * Creates a text object, with XY placement. 
     * @param px1 horizontal window pixel location of the string.
     * @param py1 vertical window pixel location of the string.
     * @param stuff the string to be displayed.
     * @param font the Font description for the string.
     * @param just the justification of the string
     * @param theta the rotation of the text, in radians
     */
    public OMText2D(int px1, int py1, 
		    String stuff, Font font, int just, double theta) { 
        super(px1, py1, stuff, font, just);
	this.theta = theta;
    }

    /**
     * Creates a Text object, with lat/lon placement with XY offset,
     * and default SansSerif font.
     * @param lt latitude of the string, in decimal degrees.
     * @param ln longitude of the string, in decimal degrees.
     * @param offX horizontal offset of string
     * @param offY vertical offset of string
     * @param aString the string to be displayed.
     * @param just the justification of the string
     * @param theta the rotation of the text, in radians
     */
    public OMText2D(double lt, double ln, int offX, int offY,
		    String aString, int just, double theta) { 
        super(lt,ln,offX,offY,aString,just);
	this.theta = theta;
    }

    /**
     * Creates a Text object, with lat/lon placement with XY offset. 
     * @param lt latitude of the string, in decimal degrees.
     * @param ln longitude of the string, in decimal degrees.
     * @param offX horizontal offset of string
     * @param offY vertical offset of string
     * @param aString the string to be displayed.
     * @param font the Font description for the string.
     * @param just the justification of the string
     * @param theta the rotation of the text, in radians
     */
    public OMText2D(double lt, double ln, int offX, int offY,
		    String aString, Font font, int just, double theta) { 
        super(lt, ln, offX, offY, aString, font, just);
	this.theta = theta;
    }

    /**
     * Set the angle by which the text is to rotated.
     * @param theta the number of radians the text is to be rotated.  Measured clockwise from horizontal.
     */
    public void setTheta(double theta) {
        this.theta = theta;
	setNeedToRegenerate(true);
    }

    /**
     * Get the current rotation of the text.
     * @return the text rotation
     */
    public double getTheta() {
        return theta;
    }
    
    /**
     * Renders the text onto the given graphics.
     * Sets the cache field <code>fm</code>.  Mostly a direct copy of
     * OMText.render(Graphics), but not quite.
     *
     * @param g the java.awt.Graphics to put the string on.
     *
     * @see OMText#render(Graphics)
     */
    public synchronized void render (Graphics g) {
        //copy the graphic, so our transform doesn't cascade to others...
        g = g.create();
	String[] pData;

	if (getNeedToRegenerate()) return;
	
	parseData();
	pData = parsedData;

	g.setFont(f);

	if (fm == null) {
	    fm = g.getFontMetrics();
	}

	if (g instanceof Graphics2D){
	    computeBounds();
	    Rectangle rect = polyBounds.getBounds();
	    double rx = rect.getX();
	    double ry = rect.getY();
	    double rw = rect.getWidth();
	    double rh = rect.getHeight();
	    
	    double woffset = 0.0;
	    switch  (justify) {
	    case JUSTIFY_LEFT:
		woffset = 0.0;
		break;
	    case JUSTIFY_CENTER:
		woffset = rw / 2;
		break;
	    case JUSTIFY_RIGHT:
		woffset = rw;
	    }
	    //rotate about our text anchor point
	    ((Graphics2D)g).rotate(theta, rx+woffset, ry);
	}
	
	// display bounding box
	if (showBounds) {
	    g.setColor(getFillColor());
	    g.fillPolygon(polyBounds);
	    g.setColor(boundsDisplayColor);
	    g.drawPolygon(polyBounds);
	}
	g.setColor(getDisplayColor());
	
	int height;
	if (fmHeight == HEIGHT){
	    height = fm.getHeight();
	} else if (fmHeight == ASCENT_LEADING){
	    height = fm.getHeight() - fm.getDescent();
	} else if (fmHeight == ASCENT_DESCENT){
	    height = fm.getAscent() + fm.getDescent();
	} else {
	    height = fm.getAscent();
	}
	

	switch (justify) {
	case JUSTIFY_LEFT:
	    // Easy case, just draw them.
	    for (int i=0; i<parsedData.length; i++) {
		g.drawString(parsedData[i], pt.x, pt.y+(height*i));
	    }
	    break;
	case JUSTIFY_CENTER:
	    computeStringWidths(fm);
	    for (int i=0; i<parsedData.length; i++) {
		g.drawString(parsedData[i],
			     pt.x - (widths[i]/2),
			     pt.y + (height*i));
	    }
	    break;
	case JUSTIFY_RIGHT:
	    computeStringWidths(fm);
	    for (int i=0; i<parsedData.length; i++) {
		g.drawString(parsedData[i],
			     pt.x - widths[i],
			     pt.y + (height*i));
	    }
	    break;
	}
    }
}

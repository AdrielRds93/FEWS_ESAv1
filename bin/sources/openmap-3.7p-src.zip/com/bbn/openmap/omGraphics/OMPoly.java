/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			  BBNT Solutions LLC
 * 			    A Part of GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998-2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/omGraphics/OMPoly.java,v $
 * $Revision: 1.42 $
 * $Date: 2000/07/05 16:49:05 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.omGraphics;

import java.awt.*;
import java.util.Vector;
import java.io.Serializable;
import com.bbn.openmap.MoreMath;
import com.bbn.openmap.util.Debug;
import com.bbn.openmap.LatLonPoint;
import com.bbn.openmap.proj.*;

/**
 * Graphic object that represents a polygon or polyline
 * (multi-line-segment-object).
 * <p>
 * <h3>NOTES:</h3>
 * <ul>
 * <li>See the <a href="com.bbn.openmap.proj.Projection.html#poly_restrictions">
 * RESTRICTIONS</a> on Lat/Lon polygons/polylines.  Not following the
 * guidelines listed may result in ambiguous/undefined shapes!
 * Similar assumptions apply to the other vector graphics that we
 * define: circles, ellipses, rects, lines.
 * <li>LatLon OMPolys store latlon coordinates internally in radian
 * format for efficiency in projecting.  Subclasses should follow this
 * model.
 * <li>Holes in the poly are not supported.
 * <p>
 * </ul>
 * <h3>TODO:</h3>
 * <ul>
 * <li>Polar filled-polygon correction for Cylindrical projections
 * (like OMCircle).
 * </ul>
 * @see OMCircle
 * @see OMRect
 * @see OMLine
 *
 */
public class OMPoly extends OMGraphic implements Serializable {

    /**
     * Translation offsets.
     * For RENDERTYPE_OFFSET, the xy points are relative to the
     * position of fixed latlon point.
     */
    public final static int COORDMODE_ORIGIN = 0;
    /**
     * Delta offsets.
     * For RENDERTYPE_OFFSET, each xy point in the array is relative
     * to the previous point, and the first point is relative to the
     * fixed latlon point.
     */
    public final static int COORDMODE_PREVIOUS = 1;

    /**
     * Radians or decimal degrees.
     * After construction and conversion, this should always be
     * radians.
     */
    protected int units = -1;// this should be set correctly at construction

    /** Internal array of projected x coordinate arrays. */
    protected int[][] xpoints = new int[0][0];
    /** Internal array of projected y coordinate arrays. */
    protected int[][] ypoints = new int[0][0];

    /**
     * For RENDERTYPE_OFFSET, the latitude of the starting point of
     * the poly.  Stored as radians!
     */
    protected double lat = 0.0d;
    /**
     * For RENDERTYPE_OFFSET, the longitude of the starting point of
     * the poly.  Stored as radians!
     */
    protected double lon = 0.0d;

    /**
     * For RENDERTYPE_OFFSET, type of offset.
     * @see #COORDMODE_ORIGIN
     * @see #COORDMODE_PREVIOUS
     */
    protected int coordMode = COORDMODE_ORIGIN;

    protected int[] xs = null;
    protected int[] ys = null;

    /**
     * Poly is a polygon or a polyline.
     * This is true if the fillColor is not clear, false if not.
     */
    protected boolean isPolygon = false;

    /**
     * True if fillColor is equal to lineColor.
     */
    protected boolean isSameColor = false;

    // raw double lats and lons stored internally in radians
    protected double[] rawllpts = null;

    /**
     * Number of segments to draw (used only for
     * LINETYPE_GREATCIRCLE or LINETYPE_RHUMB lines).
     */
    protected int nsegs=-1;


    /**
     * Construct a default OMPoly.
     */
    public OMPoly () {
        super(RENDERTYPE_UNKNOWN, LINETYPE_UNKNOWN, DECLUTTERTYPE_NONE);
    }

    /**
     * Create an OMPoly from a list of double lat/lon pairs.
     * <p>
     * NOTES:
     * <ul>
     * <li>llPoints array is converted into radians IN PLACE for more
     * efficient handling internally if it's not already in radians!
     * For even better performance, you should send us an array
     * already in radians format!
     * <li>If you want the poly to be connected (as a polygon), you
     * need to ensure that the first and last coordinate pairs are the
     * same.
     * </ul>
     * @param llPoints array of lat/lon points, arranged lat, lon,
     * lat, lon, etc.
     * @param units radians or decimal degrees.  Use OMGraphic.RADIANS
     * or OMGraphic.DECIMAL_DEGREES
     * @param lType line type, from a list defined in OMGraphic.
     */
    public OMPoly (double[] llPoints, int units, int lType) {
	this (llPoints, units, lType, -1);
    }

    /**
     * Create an OMPoly from a list of double lat/lon pairs.
     * <p>
     * NOTES:
     * <ul>
     * <li>llPoints array is converted into radians IN PLACE for more
     * efficient handling internally if it's not already in radians!
     * For even better performance, you should send us an array
     * already in radians format!
     * <li>If you want the poly to be connected (as a polygon), you
     * need to ensure that the first and last coordinate pairs are the
     * same.
     * </ul>
     * @param llPoints array of lat/lon points, arranged lat, lon,
     * lat, lon, etc.
     * @param units radians or decimal degrees.  Use OMGraphic.RADIANS
     * or OMGraphic.DECIMAL_DEGREES
     * @param lType line type, from a list defined in OMGraphic.
     * @param nsegs number of segment points (only for
     * LINETYPE_GREATCIRCLE or LINETYPE_RHUMB line types, and if &lt;
     * 1, this value is generated internally)
     */
    public OMPoly (double[] llPoints, int units, int lType, int nsegs) {
        super(RENDERTYPE_LATLON, lType, DECLUTTERTYPE_NONE);
	setLocation(llPoints, units);
	this.nsegs = nsegs;
    }

    /**
     * Create an OMPoly from a list of xy pairs.
     * If you want the poly to be connected, you need to ensure that
     * the first and last coordinate pairs are the same.
     * @param xypoints array of x/y points, arranged x, y, x, y, etc.
     */
    public OMPoly (int[] xypoints) {
        super(RENDERTYPE_XY, LINETYPE_UNKNOWN, DECLUTTERTYPE_NONE);

	setLocation(xypoints);
    }

    /**
     * Create an x/y OMPoly.
     * If you want the poly to be connected, you need to ensure that
     * the first and last coordinate pairs are the same.
     * @param xPoints int[] of x coordinates
     * @param yPoints int[] of y coordinates
     */
    public OMPoly (int[] xPoints, int[] yPoints) {
        super(RENDERTYPE_XY, LINETYPE_UNKNOWN, DECLUTTERTYPE_NONE);

	setLocation(xPoints, yPoints);
    }

    /**
     * Create an x/y OMPoly at an offset from lat/lon.
     * If you want the poly to be connected, you need to ensure that
     * the first and last coordinate pairs are the same.
     * @param latPoint latitude in decimal degrees
     * @param lonPoint longitude in decimal degrees
     * @param xypoints int[] of x,y pairs
     * @param cmode offset coordinate mode
     */
    public OMPoly (double latPoint, double lonPoint,
		   int[] xypoints, int cMode) {
        super(RENDERTYPE_OFFSET, LINETYPE_UNKNOWN, DECLUTTERTYPE_NONE);

	setLocation(latPoint, lonPoint,
		OMGraphic.DECIMAL_DEGREES, xypoints);
	coordMode = cMode;
    }

    /**
     * Create an x/y OMPoly at an offset from lat/lon.
     * If you want the poly to be connected, you need to ensure that
     * the first and last coordinate pairs are the same.
     * @param latPoint latitude in decimal degrees
     * @param lonPoint longitude in decimal degrees
     * @param xPoints int[] of x coordinates
     * @param yPoints int[] of y coordinates
     * @param cmode offset coordinate mode
     */
    public OMPoly (double latPoint, double lonPoint,
		   int[] xPoints, int[] yPoints, 
		   int cMode) {
        super(RENDERTYPE_OFFSET, LINETYPE_UNKNOWN, DECLUTTERTYPE_NONE);

	setLocation(latPoint, lonPoint,
		OMGraphic.DECIMAL_DEGREES, xPoints, yPoints);
	coordMode = cMode;
    }

    /**
     * Set an OMPoly from a list of double lat/lon pairs.
     * <p>
     * NOTES:
     * <ul>
     * <li>llPoints array is converted into radians IN PLACE for more
     * efficient handling internally if it's not already in radians!
     * If you don't want the array to be changed, send in a copy.
     * <li>If you want the poly to be connected (as a polygon), you
     * need to ensure that the first and last coordinate pairs are the
     * same.
     * </ul>
     * This is for RENDERTYPE_LATLON polys.
     * @param llpoints array of lat/lon points, arranged lat, lon,
     * lat, lon, etc.
     * @param units radians or decimal degrees.  Use OMGraphic.RADIANS
     * or OMGraphic.DECIMAL_DEGREES
     */
    public void setLocation (double[] llPoints, int units) {
	this.units = OMGraphic.RADIANS;
	if (units == OMGraphic.DECIMAL_DEGREES) {
	    ProjMath.arrayDegToRad(llPoints);
	}
	rawllpts = llPoints;
	setNeedToRegenerate(true);
	setRenderType(RENDERTYPE_LATLON);
    }

    /**
     * Set an OMPoly from a list of xy pixel pairs.
     * If you want the poly to be connected, you need to ensure that
     * the first and last coordinate pairs are the same.  This is for
     * RENDERTYPE_XY polys.
     * @param xypoints array of x/y points, arranged x, y, x, y, etc.
     */
    public void setLocation (int[] xypoints) {
	int end = xypoints.length>>1;
	xs = new int[end];
	ys = new int[end];
	for (int i=0, j=0; i < end; i++, j+=2) {
	    xs[i] = xypoints[j];
	    ys[i] = xypoints[j+1];
	}
	setNeedToRegenerate(true);
	setRenderType(RENDERTYPE_XY);
    }


    /**
     * Set an OMPoly from a x/y coordinates.
     * If you want the poly to be connected, you need to ensure that
     * the first and last coordinate pairs are the same.  This is for
     * RENDERTYPE_XY polys.
     * @param xPoints int[] of x coordinates
     * @param yPoints int[] of y coordinates
     */
    public void setLocation (int[] xPoints, int[] yPoints) {
	xs = xPoints;
	ys = yPoints;
	setNeedToRegenerate(true);
	setRenderType(RENDERTYPE_XY);
    }

    /**
     * Set the location based on a latitude, longitude, and some xy
     * points.
     * The coordinate mode and the polygon setting are the same as in
     * the constructor used.  This is for RENDERTYPE_OFFSET polys.
     * @param latPoint latitude in decimal degrees
     * @param lonPoint longitude in decimal degrees
     * @param units radians or decimal degrees.  Use OMGraphic.RADIANS
     * or OMGraphic.DECIMAL_DEGREES
     * @param xypoints array of x/y points, arranged x, y, x, y, etc.
     */
    public void setLocation (double latPoint, double lonPoint,
			     int units, int[] xypoints) {
	this.units = OMGraphic.RADIANS; 
	if (units == OMGraphic.DECIMAL_DEGREES) {
	    lat = ProjMath.degToRad(latPoint);
	    lon = ProjMath.degToRad(lonPoint);
	} else {
	    lat = latPoint;
	    lon = lonPoint;
	}
	int end = xypoints.length>>1;
	xs = new int[end];
	ys = new int[end];
	for (int i=0, j=0; i < end; i++, j+=2) {
	    xs[i] = xypoints[j];
	    ys[i] = xypoints[j+1];
	}
	setNeedToRegenerate(true);
	setRenderType(RENDERTYPE_OFFSET);
    }

    /**
     * Set the location based on a latitude, longitude, and some xy
     * points.
     * The coordinate mode and the polygon setting are the same as in
     * the constructor used.  This is for RENDERTYPE_OFFSET polys.
     * @param latPoint latitude in decimal degrees
     * @param lonPoint longitude in decimal degrees
     * @param units radians or decimal degrees.  Use OMGraphic.RADIANS
     * or OMGraphic.DECIMAL_DEGREES
     * @param xPoints int[] of x coordinates
     * @param yPoints int[] of y coordinates
     */
    public void setLocation (double latPoint, double lonPoint,
			     int units, int[] xPoints, int[] yPoints) {
	this.units = OMGraphic.RADIANS; 
	if (units == OMGraphic.DECIMAL_DEGREES) {
	    lat = ProjMath.degToRad(latPoint);
	    lon = ProjMath.degToRad(lonPoint);
	} else {
	    lat = latPoint;
	    lon = lonPoint;
	}
	xs = xPoints;
	ys = yPoints;
	setNeedToRegenerate(true);
	setRenderType(RENDERTYPE_OFFSET);
    }


    /**
     * Return the rawllpts array.
     * NOTE: this is an unsafe method to access the rawllpts array.
     * Use with caution.
     * @return double[] rawllpts of lat, lon, lat, lon
     */
    public double[] getLatLonArray() {
	return rawllpts;
    }


    /**
     * Set the fill color of the poly.
     * If the color value is non-clear, then the poly is a polygon
     * (connected and filled), otherwise it's a polyline (non-filled).
     * @param value Color
     */
    public void setFillColor (Color value) {
	super.setFillColor(value);
	value = getFillColor();
	isPolygon = !isClear(value);
	// lineColor == fillColor ?
	isSameColor = value.equals(getLineColor());
    }


    /**
     * Set the line color of the graphic object.
     * @param value the real line color
     */
    public void setLineColor (Color value) { 
	super.setLineColor(value);
	value = getLineColor();
	// lineColor == fillColor ?
	isSameColor = value.equals(getFillColor());
    }


    /**
     * Check if this is a polygon or a polyline.
     * A polygon is a multi-segment line that has a non-clear fill
     * color.  A polyline is a multi-segment line that has no fill
     * color.
     * @return true if polygon false if polyline
     */
    public boolean isPolygon () {
	return isPolygon;
    }


    /**
     * Set the number of subsegments for each segment in the poly.
     * (This is only for LINETYPE_GREATCIRCLE or LINETYPE_RHUMB line
     * types, and if &lt; 1, this value is generated internally).
     * @param nsegs number of segment points
     */
    public void setNumSegs (int nsegs) {
	this.nsegs = nsegs;
    }


    /**
     * Get the number of subsegments for each segment in the poly.
     * (This is only for LINETYPE_GREATCIRCLE or LINETYPE_RHUMB line
     * types).
     * @return int number of segment points
     */
    public int getNumSegs () {
	return nsegs;
    }


    /*
     * Set whether the OMPoly is a polygon or a polyline.
     * @param value true if polygon false if polyline
     * HACK this is unnecessary since we now force the user to
     * explicitly connect the xy and latlon arrays themself.  during
     * the render, we fillPolygon() only if there is a fill color.
     * And we drawPolyline for all the rest
    public void setPolygon(boolean value) {
	polygon = value;
    }
     */

    /**
     * Prepare the poly for rendering.
     * @param proj Projection
     * @return true if generate was successful
     */
    public boolean generate (Projection proj) {
	int i, npts;

	if (proj == null) {
	    System.err.println("OMPoly: null projection in generate!");
	    return false;
	}

	switch (renderType) {

	case RENDERTYPE_XY:
	    npts = xs.length;
	    xpoints = new int[1][0]; xpoints[0] = xs;
	    ypoints = new int[1][0]; ypoints[0] = ys;
	    break;

	case RENDERTYPE_OFFSET:
	    npts = xs.length;
	    int[] _x = new int[npts];
	    int[] _y = new int[npts];

	    // forward project the radian point
	    Point origin = proj.forward(
		    lat, lon, new Point(0,0), true);//radians

	    if (coordMode == COORDMODE_ORIGIN) {
		for (i = 0; i < npts; i++) {
		    _x[i] = xs[i] + origin.x;
		    _y[i] = ys[i] + origin.y;
		}
	    } else { // CModePrevious offset deltas
		_x[0] = xs[0] + origin.x;
		_y[0] = ys[0] + origin.y;

		for (i=1; i<npts; i++) {
		    _x[i] = xs[i] + _x[i-1];
		    _y[i] = ys[i] + _y[i-1];
		}
	    }
	    xpoints = new int[1][0]; xpoints[0] = _x;
	    ypoints = new int[1][0]; ypoints[0] = _y;
	    break;

	case RENDERTYPE_LATLON:
	    int j;
	    Vector shapes = null;

	    // polygon/polyline project the polygon/polyline.  Vertices should
	    // already be in radians.
	    shapes = proj.forwardPoly(rawllpts, lineType, nsegs, isPolygon);
	    int size = shapes.size();

	    xpoints = new int[size/2][0];
	    ypoints = new int[xpoints.length][0];

	    for (i=0, j=0; i<size; i+=2, j++) {
		xpoints[j] = (int[])shapes.elementAt(i);
		ypoints[j] = (int[])shapes.elementAt(i+1);
	    }
	    break;

	case RENDERTYPE_UNKNOWN:
	    System.err.println("OMPoly.generate: invalid RenderType");
	    return false;
	}
	setNeedToRegenerate(false);
	return true;
    }


    /**
     * Paint the poly. 
     * This works if generate() has been successful.
     * @param g java.awt.Graphics to paint the poly onto.
     */
    public void render (Graphics g) {
	if (getNeedToRegenerate()) return;

	// safety: grab local reference of projected points
	int[][] xpts = xpoints;
	int[][] ypts = ypoints;
	int[] _x, _y;
	int len = xpts.length;

	for (int i = 0; i < len; i++) {
	    _x = xpts[i];
	    _y = ypts[i];

	    // render polygon
	    if (isPolygon) {
		// fill main polygon

		// set the interior coloring parameters
		if (setPaint(g)){
		    g.fillPolygon(_x, _y, _x.length);
		}

		// only draw outline if different color
		if (!isSameColor) {
		    g.setColor(getDisplayColor());
		    g.drawPolyline(_x, _y, _x.length);
		}
	    }

	    // render polyline
	    else {
		// draw main outline
		g.setColor(getDisplayColor());
		g.drawPolyline(_x, _y, _x.length);
	    }
	}
    }


    /**
     * Return the shortest distance from the graphic to an XY-point.
     * This works if generate() has been successful.
     * @param x horizontal pixel location.
     * @param y vertical pixel location.
     * @return the distance of the object to the location given.
     */
    public double distance (int x, int y) {
	double temp, distance = Double.POSITIVE_INFINITY;

	if (getNeedToRegenerate()) {
	    return distance;
	}

	// safety: grab local reference of projected points
	int[][] xpts = xpoints;
	int[][] ypts = ypoints;
	int[] _x, _y;
	int len = xpts.length;

	for (int i = 0; i < len; i++) {
	    _x = xpts[i];
	    _y = ypts[i];

	    // check if point inside polygon
	    if (isPolygon && DrawUtil.inside_polygon(_x,_y,x,y))
		return 0d;		// close as can be

	    // get the closest point
	    temp = DrawUtil.closestPolyDistance(_x, _y, x, y, false);
	    if (temp < distance) distance = temp;
	}
	return distance;
    }
}

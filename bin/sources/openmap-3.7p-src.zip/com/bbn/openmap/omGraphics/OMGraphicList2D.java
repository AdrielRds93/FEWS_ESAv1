/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/omGraphics/OMGraphicList2D.java,v $
 * $Revision: 1.2 $
 * $Date: 2000/05/08 14:23:15 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.omGraphics;

import java.awt.Color;
import java.util.Vector;
import com.bbn.openmap.util.Debug;

/**
 * This class encapsulates a Vector of OMGraphics.
 * <p>
 * This list does everything that the OMGraphicList does, with the
 * addition of handling the methods found in the OMGraphic2D
 * interface.  It will actually check to see if the graphic it is
 * about to subject to the OMGraphic2D method is a OMGraphic2D object.
 * It will bloww of OMGraphics that are not OMGraphic2D objects.
 */
public class OMGraphicList2D extends OMGraphicList
    implements OMGraphic2D
{

    /**
     * Construct an OMGraphicList.
     */
    public OMGraphicList2D() {
	this (10, 0);//same values as default Vector
    }
    
    /**
     * Construct an OMGraphicList with an initial capacity. 
     * @param initialCapacity the initial capacity of the list 
     */
    public OMGraphicList2D(int initialCapacity) {
	this (initialCapacity, 0);//same capInc as Vector
    }

    /**
     * Construct an OMGraphicList with an initial capacity and
     * a standard increment value.
     * @param initialCapacity the initial capacity of the list 
     * @param capacityIncrement the capacityIncrement for resizing 
     */
    public OMGraphicList2D(int initialCapacity, int capacityIncrement) {
        graphics = new Vector(initialCapacity, capacityIncrement);
    }
  
    /** 
     * Set the stroke of all the graphics on the list.
     * @param stroke the stroke object to use.
     */
    public void setStroke(java.awt.Stroke stroke){
	java.util.Vector targets = getTargets();
	int size = targets.size();

	for (int i = 0; i < size; i++){
	    OMGraphic graphic = (OMGraphic) targets.elementAt(i);
	    if (graphic instanceof OMGraphic2D){
		((OMGraphic2D)graphic).setStroke(stroke);
	    }
	}
    }
    
    /**
     * Set the Paint object that is used to fill all the graphics on
     * the list.  
     * @param paint the java.awt.Paint object
     */
    public void setPaint(java.awt.Paint paint){
	java.util.Vector targets = getTargets();
	int size = targets.size();

	for (int i = 0; i < size; i++){
	    OMGraphic graphic = (OMGraphic) targets.elementAt(i);
	    if (graphic instanceof OMGraphic2D){
		((OMGraphic2D)graphic).setPaint(paint);
	    } else if (paint instanceof Color){
		graphic.setFillColor((Color)paint);
	    }
	}
    }
}

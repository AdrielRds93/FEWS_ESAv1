/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			  BBNT Solutions LLC
 * 			    A Part of GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998-2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/omGraphics/OMGraphic.java,v $
 * $Revision: 1.45 $
 * $Date: 2000/07/05 16:49:04 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.omGraphics;

import com.bbn.openmap.proj.LineType;
import com.bbn.openmap.proj.Projection;
import com.bbn.openmap.util.Debug;

import java.awt.Color;
import java.awt.Graphics;
import java.io.Serializable;

/**
 * Base class of OpenMap graphics.
 * <p>
 * The OMGraphics are raster and vector graphic objects that know how
 * to position and render themselves on a given x-y window or lat-lon
 * map projection.  All you have to do is supply the location data
 * (x/y, lat/lon) and drawing information (color, line width) and the
 * graphic handles the rest.
 * <p>
 * This class contains parameters that are common to most types of
 * graphics.  If a parameter doesn't make sense for a particular
 * graphic type, it is ignored.
 * <p>
 * NOTES:
 * <ul>
 * <li>Color values cannot be set to null, but can be set to
 * OMGraphic.clear.
 * <li>XY Rendering: Java specifies that the origin is the top left of
 * the window, x increases to the right, y increases down.
 * <li>LatLon Rendering: Defined by the Projection object.  The center
 * of the window usually corresponds to the center of the projection.
 * OMGraphics should project themselves using the appropriate
 * forward() method listed in the Projection interface
 * <li>Offset Rendering: same as XY, but with origin set to a
 * projected LatLon point.
 * </ul>
 * TODO:
 * <ul>
 * <li>Linewidth.  Wait for the Java 2D API.
 * <li>Stippling.  Wait for the Java 2D API.
 * <li>Alpha transparency for filled vector graphics.  Wait for the
 * Java 2D API.
 * </ul>
 *
 * @see OMBitmap
 * @see OMCircle
 * @see OMLine
 * @see OMPoly
 * @see OMRect
 * @see OMRaster
 * @see OMText
 * @see OMGraphicList
 * @see Projection
 */
public abstract class OMGraphic implements Serializable{
    /**
     * Turns debugging on or off.
     */
    public static final boolean DEBUG = false;


    /** Line type is unknown. */ 
    public final static int LINETYPE_UNKNOWN = 0;
    /** Line will be drawn straight between window points. */
    public final static int LINETYPE_STRAIGHT = LineType.Straight;  
    /** Line will be drawn on a constant bearing between two
     * points. */
    public final static int LINETYPE_RHUMB = LineType.Rhumb;
    /** Line will be drawn on the shortest geographical path between
     * two locations. */
    public final static int LINETYPE_GREATCIRCLE = LineType.GreatCircle;

    /** Render type is unknown. */
    public final static int RENDERTYPE_UNKNOWN = 0;
    /** The graphic should be projected relative to its lat/lon
     * position. */
    public final static int RENDERTYPE_LATLON = 1;
    /** The graphic should be projected relative to its window
     * position. */
    public final static int RENDERTYPE_XY = 2;
    /** The graphic should be projected in window space relative to a
     * lat/lon position. */
    public final static int RENDERTYPE_OFFSET = 3;

    /** The graphic should not be moved or be considered in the
     * placement of other graphics. */
    public final static int DECLUTTERTYPE_NONE = 0;
    /** The graphic should not be moved, but its position should be
     * considered when placing other graphics. */
    public final static int DECLUTTERTYPE_SPACE = 1;
    /** The graphic should be moved if it is going to share window
     * space with another graphic. */
    public final static int DECLUTTERTYPE_MOVE = 2;
    /** The graphic should be moved if it is going to share window
     * space with another graphic, and a line should be drawn from the
     * new position to the original position. */
    public final static int DECLUTTERTYPE_LINE = 3;

    /** The generic graphic type. */
    public final static int GRAPHICTYPE_GRAPHIC = 0;
    /** A bitmap type - OMBitmap. */
    public final static int GRAPHICTYPE_BITMAP = 1;
    /** A text type - OMText. */
    public final static int GRAPHICTYPE_TEXT = 2;
    /** A polygon/polyline type - OMPoly. */
    public final static int GRAPHICTYPE_POLY = 3;
    /** A line type - OMLine. */
    public final static int GRAPHICTYPE_LINE = 4;
    /** A rectangle type - OMRect. */
    public final static int GRAPHICTYPE_RECTANGLE = 5;
    /** A ellipse/circle type - OMCircle. */
    public final static int GRAPHICTYPE_CIRCLE = 6;
    /** A raster type - OMRaster. */
    public final static int GRAPHICTYPE_RASTER = 7;
    /** A grid type - OMGrid. */
    public final static int GRAPHICTYPE_GRID = 8;

    /** The double coordinates are in decimal degrees. */
    public final static int DECIMAL_DEGREES = 0;
    /** The double coordinates are in radians. */
    public final static int RADIANS = 1;

    /** A transparent color.*/
    public final static transient Color clear =
	com.bbn.openmap.util.ColorFactory.createColor(0, true);

    private static long gid = 0;

    /**  The lineType describes the way a line will be drawn between
     *  points.  LINETYPE_STRAIGHT will mean the line is drawn straight
     *  between the pixels of the endpoints of the line, across the
     *  window.  LINETYPE_GREATCIRCLE means the line will be drawn on the
     *  window representing the shortest line along the
     *  land. LINETYPE_RHUMB means a line will be drawn along a constant
     *  bearing between the two points.
     * 
     */
    protected int lineType = LINETYPE_UNKNOWN;
    
    /** The renderType describes the relation of the object to the
     *  window.  RENDERTYPE_LATLON means the object is positioned
     *  relative to lat/lon points.  RENDERTYPE_XY means the object is
     *  positioned relative to window pixel coordinates.
     *  RENDERTYPE_OFFSET means the object is drawn at a pixel offset
     *  to a lat/lon point.
     */
    protected int renderType = RENDERTYPE_UNKNOWN;

    /**  Decluttering is not supported by OpenMap yet.  But, when it
     *   is, these parameters will describe the way the object is
     *   manipulated on the window relative to its neighbors.
     *   DECLUTTERTYPE_NONE means the object will be drawn where its
     *   attributes say it should be.  DECLUTTERTYPE_SPACE indicates
     *   that the window space of the object should be marked as
     *   taken, but the object should not be moved.
     *   DECLUTTERTYPE_MOVE means the object should be moved to the
     *   nearest open location closest to the position indicated by
     *   its attributes.  DECLUTTERTYPE_LINE is the same as MOVE, but
     *   in addition, a line is drawn from the current position to its
     *   original position. 
     */
    protected int declutterType = DECLUTTERTYPE_NONE;

    /**
     * The line width of the vector graphic.
     * This property is only implemented by graphics that use the
     * Java2D API.
     */
    protected float lineWidth = 1.0f;

    /** 
     * the dasing style of the vector graphic. 
     * This property is only implemented by graphics that use the
     * Java2D API.
     */
    protected float[] dash_array = null;
    protected float dash_phase = 0.0f;

    /**  This color is the real foreground color of the object. It is
     * kept so that the object knows how to de-highlight itself. It
     * defaults to black. */
    protected Color lineColor = Color.black;

    /**  The color that the object is displayed with.  This color
     * changes back and forth between the selectColor and the lineColor,
     * depending on the if the object is selected or not.
     */
    protected Color displayColor = lineColor;

    /**  This color is the fill color of the object. It defaults to a
     * black color that is transparent. */
    protected Color fillColor = clear;

    /** This color is the highlight color that can be used when the
     * object is selected.  The default color is black, just like the
     * line color. 
     */
    protected Color selectColor = Color.black;

    /** Flag to indicate that the object needs to be reprojected. */
    protected boolean needToRegenerate = true;

    /**  Flag to indicate that the object has/hasnot been put in a
     * special mode as a result of some event. Set through the
     * select()/deselect methods().
     */
    protected boolean selected = false;


    /**
     * Is this object visible?
     */
    protected boolean visible = true;

    /**
     * Space for an application to associate an OMGraphic with
     * an application object.
     *
     * @see #setAppObject
     * @see #getAppObject
     */
    protected Object appObject;


    /**
     * Checks if the color is clear.
     * @param color Color or null
     * @return true if Color is null or has 0 alpha value
     */
    public static boolean isClear (Color color) {
	return ((color.getRGB() & 0xff000000) == 0);
    }

  //////////////////////////////////////////////////////////  

    /**
     * Construct a default OMGraphic.
     */
    public OMGraphic () {
	this(RENDERTYPE_UNKNOWN, LINETYPE_UNKNOWN, DECLUTTERTYPE_NONE);
    }

    /**
     * Construct an OMGraphic.
     * Standard simple constructor that the child OMGraphics usually
     * call.  All of the other parameters get set to their default
     * values. 
     * @param gType graphic type - ignored
     * @param rType render type
     * @param lType line type
     * @param dcType declutter type
     */
    public OMGraphic(int rType, int lType, int dcType){
	lineType = lType;
	renderType = rType;
	declutterType = dcType;
    }

    /**
     * Construct an OMGraphic.
     * Standard simple constructor that the child OMGraphics usually
     * call.  All of the other parameters get set to their default
     * values. 
     * @deprecated use the version without gType
     * @param gType graphic type - ignored
     * @param rType render type
     * @param lType line type
     * @param dcType declutter type
     */
    public OMGraphic(int gType, int rType, int lType, int dcType){
        this(lType, rType, dcType);
    }

    /**
     * Construct an OMGraphic.
     * More complex constructor that lets you set the rest of the
     * parameters. 
     * @param rType render type
     * @param lType line type
     * @param dcType declutter type
     * @param lw line width
     * @param lc line color
     * @param fc fill color
     * @param sc select color
     */
    public OMGraphic(int rType, int lType, int dcType,
		     int lw, Color lc, Color fc, Color sc){
	this(rType, lType, dcType);
	setLineColor(lc);
	setSelectColor(sc);
	setFillColor(fc);
    }

    /**
     * Construct an OMGraphic.
     * More complex constructor that lets you set the rest of the
     * parameters. 
     * @deprecated use the version without gType
     * @param gType graphic type - ignored
     * @param rType render type
     * @param lType line type
     * @param dcType declutter type
     * @param lw line width
     * @param lc line color
     * @param fc fill color
     * @param sc select color
     */
    public OMGraphic(int gType, int rType, int lType, int dcType,
		     int lw, Color lc, Color fc, Color sc){
	this(rType, lType, dcType, lw, lc, fc, sc);
    }

  //////////////////////////////////////////////////////////

    /**  Set the line type for the graphic, which will affect how the
     * lines will be drawn.  See the definition of the lineType
     * parameter. Accepts LINETYPE_RHUMB, LINETYPE_STRAIGHT and
     * LINETYPE_GREATCIRCLE.  Any weird values get set to
     * LINETYPE_STRAIGHT.  
     *
     * @param value the line type of the graphic.
     * */
    public void setLineType(int value) {
	if (lineType == value) return;
	setNeedToRegenerate(true);		// flag dirty
	
	lineType = value;
    }

    /** Return the line type. 
     *
     * @return the linetype - LINETYPE_RHUMB, LINETYPE_STRAIGHT,
     * LINETYPE_GREATCIRCLE or LINETYPE_UNKNOWN.
     * */
    public int getLineType(){ 
        return lineType;
    }
    
    /**  Set the render type of the graphic.  Accepts
     * RENDERTYPE_LATLON, RENDERTYPE_XY and RENDERTYPE_OFFSET.  All
     * weird values get set to RENDERTYPE_XY. See the definition on
     * the renderType parameter.  
     *
     * @param value the rendertype for the object.
     */
    public void setRenderType(int value){ 
	if (renderType == value) return;
	setNeedToRegenerate(true);		// flag dirty

	renderType = value;
    }

    /** Return the render type. 
     *
     * @return the rendertype of the object - RENDERTYPE_LATLON,
     * RENDERTYPE_XY, RENDERTYPE_OFFSET and RENDERTYPE_UNKNOWN.
     * */
    public int getRenderType(){ 
        return renderType;
    }
    
    /** Set the declutter setting for the graphic.  Accepts
     * DECLUTTERTYPE_SPACE, DECLUTTERTYPE_MOVE, DECLUTTERTYPE_LINE,
     * and DECLUTTERTYPE_NONE. All weird values are set to
     * DECLUTTERTYPE_NONE. <p> Right now, this is unimplemented in
     * OpenMap.  But for information, DECLUTTERTYPE_NONE means the
     * object has no impact on the placement of objects.
     * DECLUTTERTYPE_SPACE means the object shouldn't have things
     * placed on it, but to draw it where the coordinates dictate.
     * DECLUTTERTYPE_MOVE means to put the object in an open space,
     * and DELCUTTERTYPE_LINE adds the feature that if the object is
     * not drawn where it's coordinates say it should be, then a line
     * should be drawn showing where the original position is.  
     *
     * @param value the declutter type value.
     * */
    public void setDeclutterType(int value){ 
	if (declutterType == value) return;
	setNeedToRegenerate(true);	// flag dirty

	declutterType = value;
    }

    /** Return the declutter type. 
     *
     * @return declutter type, see above.
     * */
    public int getDeclutterType(){ 
        return declutterType;
    }
    
    /**  Set the line color of the graphic object.  The line color is
     * the normal display edge color of the object.  This color is
     * used as the display color when the object is NOT selected
     * (hightlighted). The display color is set to the select color in
     * this method if <code>selected</code> boolean attribute is false. 
     *
     * @param value the real line color
     */
    public void setLineColor(Color value){ 
	if (value != null) lineColor = value;
	else lineColor = Color.black;

	if (!selected) displayColor = lineColor;
    }

    /** Return the normal foreground color of the object. 
     * @return the line color
     * */
    public Color getLineColor(){ 
        return lineColor;
    }
    
    /** Set the select color of the graphic object.  The selected
     * color is used as the display color when the object is selected
     * (highlighted). The display color is set to the select color in
     * this method if <code>selected</code> boolean attribute is true.  
     *
     * @param value the selected color.
     * */
    public void setSelectColor(Color value){ 
	if (value != null) selectColor = value;
	else selectColor = Color.black;

	if (selected) displayColor = selectColor;
    }

    /** Return the selected color, which is the line or foreground
     * color used when the graphic is "selected".
     *
     * @return the selected mode line color
     **/
    public Color getSelectColor(){ 
        return selectColor;
    }

    /** Return the color that should be used for display.  This color
     * changes, depending on whether the object is selected or not.
     * The display color is set when the line color or the select
     * color is set, depending on the statue of the
     * <code>selected</code> boolean attribute.  
     * 
     * @return the color used as the edge color or foreground color,
     * in the present selected state.
     * */
    public Color getDisplayColor(){ 
        return displayColor;
    }

    /**
     * Holds an application specific object for later access.
     * This can be used to associate an application object with
     * an OMGraphic for later retrieval.  For instance, when
     * the graphic is clicked on, the application gets the OMGraphic
     * object back from the OMGraphicList, and can then get back
     * to the application level object through this pointer.
     * @param obj Object
     */
    public synchronized void setAppObject(Object obj) {
	appObject = obj;
    }

    /**
     * Gets the application's object pointer.
     * @return Object
     */
    public synchronized Object getAppObject() {
	return appObject;
    }

    /**
     * Set the selected attribute to true, and sets the color to the
     * select color.  
     */
    public void select(){
	selected = true;
	displayColor = getSelectColor();
    }

    /**
     * Set the selected attribute to false, sets the color to the
     * line color.  
     */
    public void deselect(){
	selected = false;
	displayColor = getLineColor();
    }

    /**
     * Set the background color of the graphic object.
     * @param value java.awt.Color
     */
    public void setFillColor(Color value){ 
	if (value != null) {
	    fillColor = value;
	    if (DEBUG) Debug.message("omGraphics",
				     "OMGraphic.setFillColor(): fillColor= "
				     + fillColor);
	}
	else {
	    fillColor = clear;
	    if (DEBUG) Debug.message("omGraphics",
				     "OMGraphic.setFillColor(): fillColor is clear");
	}
    }

    /** Return the background color of the graphic object.
     *
     * @return the color used for the background.
     * */
    public Color getFillColor(){ 
        return fillColor;
    }

    /**
     * This is a method that gets called by the graphic itself when it
     * is being rendered.  It is here to help with jdk 1.2
     * compatability with jdk 1.1.x.  For regular OMGraphics, those
     * that are compatible with jdk1.1.x, this version of this method
     * will suffice - that is, when the graphic is asked how it wants
     * to fill itself, it will just respond by using it's fillColor.
     * When a OMGraphic2D graphic is asked, it will be able to use the
     * precious Paint object it has been blessed with.  
     * @param g the graphics object to set with the fill settings.
     * @return false if the current graphic parameters don't allow a
     * filled graphic to be drawn.  The graphic render methods should
     * boot out of the filled draws if this method returns false.
     * Otherwise, return true if all's well.  
     */
    public boolean setPaint(Graphics g){
	g.setColor(getFillColor());
	return true;
    }

    /**
     * Set the line width to a value between 1 and 10 pixels.
     * Anything outside of these bounds gets set to 1. <br>
     * NOTE: line width is only handled by vector graphics that make
     * use of the Java2D API.  This method is public in the OMGraphic2D
     * interface
     * @see com.bbn.openmap.omGraphics.OMGraphic2D
     * @param value width
     */
    public void setLineWidth (float value){
	if ((value < 1) || (value > 10)) 
	    value = 1;
	if (lineWidth == value) return;
	lineWidth = value;
	setNeedToRegenerate(true);		// flag dirty
    }

    /**
     * Return the line width. <br>
     * This value is only used by 2D graphics.
     * @return int
     */
    public float getLineWidth(){
        return lineWidth;
    }

    /**
     * Set the dash style to use. 
     */
    public void setLineDash(float [] dasharray, float phase){
	dash_array = dasharray;
	dash_phase = phase;
    }
    
    public float []  getLineDash(){
	return dash_array;
    }

    public float getLineDashPhase(){
	return dash_phase;
    }

    /**
     * Sets the regenerate flag for the graphic.
     * This flag is used to determine if extra work needs to be done
     * to prepare the object for rendering.
     * @param value boolean
     */
    public void setNeedToRegenerate (boolean value){ 
        needToRegenerate = value;
    }

    /**
     * Return the regeneration status.
     * @return boolean
     */
    public boolean getNeedToRegenerate(){ 
        return needToRegenerate;
    }


    /**
     * Set the visibility variable.
     * NOTE:<br>
     * This is checked by the OMGraphicList when it iterates through its list
     * for render and gesturing.  It is not checked by the internal OMGraphic
     * methods, although maybe it should be...
     * @param visible boolean
     */
    public void setVisible(boolean visible) {
	this.visible = visible;
    }


    /**
     * Get the visibility variable.
     * @return boolean
     */
    public boolean isVisible() {
	return visible;
    }


//////////////////////////////////////////////////////////////////////////

    /**
     * Prepare the graphic for rendering.
     * This must be done before calling <code>render()</code>!  If a
     * vector graphic has lat-lon components, then we project these
     * vertices into x-y space.  For raster graphics we prepare in a
     * different fashion.
     * <p>
     * If the generate is unsuccessful, it's usually because of some
     * oversight, (for instance if <code>proj</code> is null), and if
     * debugging is enabled, a message may be output to the controlling
     * terminal.
     * <p>
     * @param proj Projection
     * @return boolean true if successful, false if not.
     * @see #regenerate
     */
    public abstract boolean generate (Projection proj);

    /**
     * Paint the graphic.
     * This paints the graphic into the Graphics context.  This is
     * similar to <code>paint()</code> function of
     * java.awt.Components.  Note that if the graphic has not been
     * generated, it will not be rendered.
     * @param g Graphics context to render into
     */
    public abstract void render (Graphics g);

    /**
     * Return the shortest distance from the graphic to an XY-point.
     * @param x X coordinate of the point.
     * @param y Y coordinate of the point.
     * @return double distance, in pixels, from graphic to the point.
     */
    public abstract double distance (int x, int y);

    /**
     * Invoke this to regenerate a "dirty" graphic.
     * This method is a wrapper around the <code>generate()</code>
     * method.  It invokes <code>generate()</code> only if
     * </code>needToRegenerate()</code> on the graphic returns true.
     * To force a graphic to be generated, call
     * <code>generate()</code> directly.
     * @param proj the Projection
     * @return true if generated, false if didn't do it (maybe a
     * problem).
     * @see #generate
     */
    public boolean regenerate (Projection proj) {
	if (proj == null)
	    return false;

	if (getNeedToRegenerate())
	    return generate(proj);

	// handle extra case: OMRasterObject.getNeedToReposition()
	if (this instanceof OMRasterObject)
	    return generate(proj);

	return false;
    }

}

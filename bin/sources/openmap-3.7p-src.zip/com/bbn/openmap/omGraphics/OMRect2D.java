/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998-2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/omGraphics/OMRect2D.java,v $
 * $Revision: 1.8 $
 * $Date: 2000/08/02 14:25:38 $
 * $Author: dietrick $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.omGraphics;

import com.bbn.openmap.proj.Projection;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Stroke;

/**
 * Rect object which takes advantage of the Java2D API.
 * This class requires the Java 2 platform.
 */
public class OMRect2D extends OMRect implements OMGraphic2D {

    /**
     * The Java2D Stroke.
     * This is used for lineWidth.
     */
    protected Stroke stroke = new BasicStroke(lineWidth);

    /** The Java2D Paint
     * This is used for filled graphics
     */
    protected Paint paint;

    /** Default constructor, waiting to be filled. */
    public OMRect2D () {
	super();
    }

    /**
     * Create a lat/lon rectangle.
     * @param lt1 latitude of north edge, decimal degrees.
     * @param ln1 longitude of west edge, decimal degrees.
     * @param lt2 latitude of south edge, decimal degrees.
     * @param ln2 longitude of east edge, decimal degrees.
     * @param lType line type  - see OMGraphic.lineType.
     */
    public OMRect2D (double lt1, double ln1, double lt2, double ln2,
		  int lType) {
	super(lt1, ln1, lt2, ln2, lType);
    }

    /**
     * Create a lat/lon rectangle.
     * @param lt1 latitude of north edge, decimal degrees.
     * @param ln1 longitude of west edge, decimal degrees.
     * @param lt2 latitude of south edge, decimal degrees.
     * @param ln2 longitude of east edge, decimal degrees.
     * @param lType line type  - see OMGraphic.lineType.
     * @param nsegs number of segment points (only for LINETYPE_GREATCIRCLE
     * or LINETYPE_RHUMB line types, and if &lt; 1, this value is generated
     * internally)
     */
    public OMRect2D (double lt1, double ln1, double lt2, double ln2,
		  int lType, int nsegs) {
	super(lt1, ln1, lt2, ln2, lType, nsegs);
    }

    /**
     * Construct an XY rectangle.
     * It doesn't matter which corners of the rectangle are used, as
     * long as they are opposite from each other.
     * @param px1 x pixel position of the first corner relative to the
     * window origin
     * @param py1 y pixel position of the first corner relative to the
     * window origin
     * @param px2 x pixel position of the second corner relative to the
     * window origin
     * @param py2 y pixel position of the second corner relative to the
     * window origin
     */
    public OMRect2D (int px1, int py1, int px2, int py2) { 
	super(px1, py1, px2, py2);
    }

    /**
     * Construct an XY rectangle relative to a lat/lon point
     * (RENDERTYPE_OFFSET).
     * It doesn't matter which corners of the rectangle are used, as
     * long as they are opposite from each other.
     * @param lt1 latitude of the reference point, decimal degrees.
     * @param ln1 longitude of the reference point, decimal degrees.
     * @param px1 x pixel position of the first corner relative to the
     * reference point
     * @param py1 y pixel position of the first corner relative to the
     * reference point
     * @param px2 x pixel position of the second corner relative to the
     * reference point
     * @param py2 y pixel position of the second corner relative to the
     * reference point
     */
    public OMRect2D (double lt1, double ln1,
		  int px1, int py1, int px2, int py2) { 
	super(lt1, ln1, px1, py1, px2, py2);
    }

    /**
     * Set the line width to a value between 1 and 10 pixels.
     * Anything outside of these bounds gets set to 1.
     */
    public void setLineWidth (float w) {
	super.setLineWidth(w);
	stroke = new BasicStroke(getLineWidth());
    }

    /**
     * Set the stroke for the graphic.  Also sets the line width of
     * the graphics from the setting in the Stroke object, if it's a
     * BasicStroke.
     */
    public void setStroke(java.awt.Stroke st){
	if (st == null){
	    if (stroke == null){
		stroke = new BasicStroke();
	    }
	} else {
	    stroke = st;
	}

	if (stroke instanceof BasicStroke){
	    super.setLineWidth((int)((BasicStroke)stroke).getLineWidth());
	}
    }

    /**
     * Set the Paint object used to fill the rectangle
     */
    public void setPaint(java.awt.Paint paint) {
        this.paint = paint;
    }

    /**
     * The call to set the Graphics object to handle the Paint that
     * may be contained in the 2D Rect.  Therefore, there ought to be
     * either a Paint object or a fill color.
     * @param g a java.awt.Graphics object to set.
     * @return true if the paint is set, else true if the fill color
     * is not clear.  
     */
    public boolean setPaint(Graphics g){
	Color color = getFillColor();
	// Because it might not be...
	if (g instanceof Graphics2D){
	    // If we've got a Graphics2D, we use the setPaint. instead
	    // of the setColor.
	    if (paint != null) {
		((Graphics2D)g).setPaint(paint);
		return true;
	    } else if (!isClear(color)){
		((Graphics2D)g).setPaint(color);
		return true;
	    } else {
		return false;
	    }
	} else if (!isClear(color)){
	    g.setColor(color);
	    return true;
	}
	return false;
    }

    /**
     * Prepare the rectangle for rendering.
     * @param proj Projection
     * @return true if generate was successful
     */
    public boolean generate (Projection proj) {
	return super.generate(proj);
    }

    /**
     * Paint the line.
     * @param g Graphics context to render into
     */
    public void render (Graphics g) {
	if (g instanceof Graphics2D) {
	    Graphics2D g2d = ((Graphics2D)g);
	    Stroke oldstroke = g2d.getStroke();
	    g2d.setStroke(stroke);
	    super.render(g);
	    g2d.setStroke(oldstroke);
	} else {
	    super.render(g);
	}
    }

    /**
     * Return the shortest distance from the rect to an XY-point.
     * @param x X coordinate of the point.
     * @param y Y coordinate fo the point.
     * @return double distance from rect to the point
     */
    public double distance (int x, int y) {

	// OK, we need to put in a hack to handle the fact that the
	// OMRect2D could have a null fill color, but contain a
	// paint object, making it opaque.  So, for the purposes of
	// the super.distance measurement, we'll put a color in if
	// there is a paint object, and then set things back after.
	boolean hackUsed = false;
	if (paint != null && isClear(getFillColor())){
	    fillColor = OMColor.black;
	    hackUsed = true;
	}

	double d = super.distance(x,y);
	
	if (hackUsed) setFillColor(null);

	if (lineWidth <= 1)
	    return d;
	// extra calculation for lineWidth
	d -= lineWidth/2;
	return (d < 0d) ? 0d : d;
    }
}

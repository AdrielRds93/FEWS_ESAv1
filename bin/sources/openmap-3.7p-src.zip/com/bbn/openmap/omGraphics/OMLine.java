/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			  BBNT Solutions LLC
 * 			    A Part of GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998-2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/omGraphics/OMLine.java,v $
 * $Revision: 1.25 $
 * $Date: 2000/07/05 16:49:04 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.omGraphics;

import java.io.Serializable;
import java.awt.Point;
import java.awt.Graphics;
import java.util.Vector;

import com.bbn.openmap.LatLonPoint;
import com.bbn.openmap.proj.Projection;
import com.bbn.openmap.proj.DrawUtil;
import com.bbn.openmap.util.Debug;
import com.bbn.openmap.MoreMath;
import com.bbn.openmap.omGraphics.util.ArcCalc;

/**
 * Graphic object that represents a simple line.
 * <p>
 * The OMLine is used to create simple lines, from one point on the
 * window to the other.  If you want to have a line with several
 * parts, use OMPoly as a polyline with no fillColor.
 * <h3>NOTE:</h3>
 * See the <a href="com.bbn.openmap.proj.Projection.html#line_restrictions">
 * RESTRICTIONS</a> on Lat/Lon lines.  Not following the guidelines
 * listed may result in ambiguous/undefined shapes!  Similar
 * assumptions apply to the other vector graphics that we define:
 * circles, ellipses, rects, polys.
 * <p>
 * @see OMPoly
 */
public class OMLine extends OMGraphic implements Serializable {

    protected boolean isPolyline = false;

    /** latlons is a array of 4 floats - lat1, lon1, lat2, lon2. */
    protected double[] latlons = null;

    /** pts is an array of 4 ints - px1, py1, px2, py2. */
    protected int[] pts = null;
  
    /**
     * X coordinate arrays of the projected points.
     */
    protected int[][] xpoints = new int[0][0];

    /**
     * Y coordinate arrays of the projected points.
     */
    protected int[][] ypoints = new int[0][0];

    /** Flag used to create arrow heads on lines. */
    protected boolean doArrowHead = false;
    /** Array (max two) of ArrowHeads to put on the line. */
    protected OMArrowHead[] arrowHead = null;
    /** Used to draw the ArrowHead on the finishing end, the starting
     * end, or both. */
    protected int arrowDirectionType = OMArrowHead.ARROWHEAD_DIRECTION_FORWARD;
    /** Where on the line to put the ArrowHead, from 0-100.  100 is at
     * the normal endpoint, and 0 is at the normal starting
     * point. For BACKWARDS directions, 100 would be at the
     * beginning of the line.*/
    protected int arrowLocation = 100;

    /**
     * Number of segments to draw (used only for
     * LINETYPE_GREATCIRCLE or LINETYPE_RHUMB lines).
     */
    protected int nsegs=-1;

    /**
     * For x-y and offset lines, there is the ability to put a curve
     * in the line.  This setting is the amount of an angle, limited
     * to a semi-circle (PI) that the curve will represent.  In other
     * words, the arc between the two end points is going to look like
     * a 0 degrees of a circle (straight line, which is the default),
     * or 180 degrees of a circle (full semi-circle).  Given in
     * radians, though, not degrees.  The ArcCalc object handles all
     * the details.
     */
    protected ArcCalc arc = null;

    private final static int STRAIGHT_LINE = 0;
    private final static int CURVED_LINE = 1;

    /** Generic constructor, attributes need to filled later. */
    public OMLine () {
	super(RENDERTYPE_UNKNOWN, LINETYPE_UNKNOWN, DECLUTTERTYPE_NONE);
    }

    /**
     * Create a line from lat lon points.
     *
     * @param lat_1 latitude of first point, decimal degrees.
     * @param lon_1 longitude of first point, decimal degrees.
     * @param lat_2 latitude of second point, decimal degrees.
     * @param lon_2 longitude of second point, decimal degrees.
     * @param lineType a choice between LINETYPE_STRAIGHT,
     * LINETYPE_GREATCIRCLE or LINETYPE_RHUMB.
     */
    public OMLine (double lat_1, double lon_1, double lat_2, double lon_2,
		  int lineType)
    {
	this (lat_1, lon_1, lat_2, lon_2, lineType, -1);
    }

    /**
     * Create a line from lat lon points.
     *
     * @param lat_1 latitude of first point, decimal degrees.
     * @param lon_1 longitude of first point, decimal degrees.
     * @param lat_2 latitude of second point, decimal degrees.
     * @param lon_2 longitude of second point, decimal degrees.
     * @param lineType a choice between LINETYPE_STRAIGHT,
     * LINETYPE_GREATCIRCLE or LINETYPE_RHUMB.
     * @param nsegs number of segment points (only for
     * LINETYPE_GREATCIRCLE or LINETYPE_RHUMB line types, and if &lt;
     * 1, this value is generated internally)
     */
    public OMLine (double lat_1, double lon_1, double lat_2, double lon_2,
		  int lineType, int nsegs)
    {
	super(RENDERTYPE_LATLON, lineType, DECLUTTERTYPE_NONE);
	latlons = new double[4];
        latlons[0] = lat_1;
        latlons[2] = lat_2;
        latlons[1] = lon_1;
        latlons[3] = lon_2;
	this.nsegs = nsegs;
    }

    /**
     * Create a line between two xy points on the window.
     * @param x1 the x location of the first point, in pixels from the
     * left of the window.
     * @param y1 the y location of the first point, in pixels from the
     * top of the window.
     * @param x2 the x location of the second point, in pixels from
     * the left of the window.
     * @param y2 the y location of the second point, in pixels from
     * the top of the window.
     */
    public OMLine (int x1, int y1, 
		  int x2, int y2) {
	super(RENDERTYPE_XY, LINETYPE_STRAIGHT, DECLUTTERTYPE_NONE);
	pts = new int[4];
	pts[0] = x1;
	pts[1] = y1;
	pts[2] = x2;
	pts[3] = y2;	
    }

    /**
     * Create a line between two x-y points on the window, where the
     * x-y points are offsets from a lat-lon point.  It assumes that
     * you'll want a straight window line between the points, so if
     * you don't, use the setLineType() method to change it.
     *
     * @param lat_1 the latitude of the reference point of the line,
     * in decimal degrees.
     * @param lon_1 the longitude of the reference point of the line,
     * in decimal degrees.
     * @param x1 the x location of the first point, in pixels from the
     * longitude point.
     * @param y1 the y location of the first point, in pixels from the
     * latitude point.
     * @param x2 the x location of the second point, in pixels from
     * the longitude point.
     * @param y2 the y location of the second point, in pixels from
     * the latitude point.
     */
    public OMLine (double lat_1, double lon_1,
		  int x1, int y1, 
		  int x2, int y2) {
	super(RENDERTYPE_OFFSET, LINETYPE_STRAIGHT, DECLUTTERTYPE_NONE);
	latlons = new double[4];
	pts = new int[4];
        latlons[0] = lat_1;
        latlons[1] = lon_1;
	pts[0] = x1;
	pts[1] = y1;
	pts[2] = x2;
	pts[3] = y2;
    }

    /**
     * Set the lat lon values of the end points of the line from an
     * array of floats - lat1, lon1, lat2, lon2. This does not look at
     * the line render type, so it acts accordingly.  LL1 is only used
     * in RENDERTYPE_LATLON, RENDERTYPE_OFFSET, and LL2 is only used in
     * RENDERTYPE_LATLON.  
     * @param latlons array of floats - lat1, lon1, lat2, lon2 
     */
    public void setLL(double[] lls){
	latlons = lls;
	setNeedToRegenerate(true);
    }

    /**
     * Get the lat lon values of the end points of the line in an
     * array of floats - lat1, lon1, lat2, lon2. Again, this does not
     * look at the line render type, so it acts accordingly.  LL1 is
     * only used in RENDERTYPE_LATLON, RENDERTYPE_OFFSET, and LL2 is
     * only used in RENDERTYPE_LATLON.
     * @return the lat lon array, and all are decimal degrees.
     */
    public double[] getLL(){
	return latlons;
    }

    /**
     * Set the xy values of the end points of the line from an array
     * of ints - x1, y1, x2, y2 .  This does not look at the line render
     * type, so it acts accordingly.  p1 and p2 are only used in
     * RENDERTYPE_XY, RENDERTYPE_OFFSET.
     * @param xys array of ints for the points - x1, y1, x2, y2
     */
    public void setPts(int[] xys){
	pts = xys;
	setNeedToRegenerate(true);
    }

    /**
     * Get the xy values of the end points of the line in an array of
     * ints - x1, y1, x2, y2 . This does not look at the line * render
     * type, so it acts accordingly.  p1 and p2 are only used in
     * RENDERTYPE_XY, RENDERTYPE_OFFSET.
     * @return the array of x-y points, and all are pixel values
     */
    public int[] getPts(){
        return pts;
    }

    /**
     * Check to see if this line is a polyline.
     * This is a polyline if it is LINETYPE_GREATCIRCLE or
     * LINETYPE_RHUMB for RENDERTYPE_LATLON polys.
     * @return true if polyline false if not
     */
    public boolean isPolyline () {
	return isPolyline;
    }

    /**
     * Set the number of segments of the lat/lon line.
     * (This is only for LINETYPE_GREATCIRCLE or LINETYPE_RHUMB line
     * types, and if &lt; 1, this value is generated internally).
     * @param nsegs number of segment points
     */
    public void setNumSegs (int nsegs) {
	this.nsegs = nsegs;
    }

    /**
     * Get the number of segments of the lat/lon line.
     * (This is only for LINETYPE_GREATCIRCLE or LINETYPE_RHUMB line
     * types).
     * @return int number of segment points
     */
    public int getNumSegs () {
	return nsegs;
    }

    /**
     * Turn the ArrowHead on/off.  The ArrowHead is placed on the
     * finishing end.
     * @param value on/off
     */
    public void addArrowHead(boolean value){
        doArrowHead = value;
	if (doArrowHead) {
	    addArrowHead(OMArrowHead.ARROWHEAD_DIRECTION_FORWARD, 100);
	}
    }

    /**
     * Turn the ArrowHead on.  The ArrowHead is placed on the
     * finishing end (OMArrowHead.ARROWHEAD_DIRECTION_FORWARD),
     * beginning end (OMArrowHead.ARROWHEAD_DIRECTION_BACKWARD), or
     * both ends(OMArrowHead.ARROWHEAD_DIRECTION_BOTH). 
     * @param directionType which way to point the arrow head.
     */
    public void addArrowHead(int directionType){
	addArrowHead(directionType, 100);
    }

    /**
     * Turn the ArrowHead on.  The ArrowHead is placed on the
     * finishing end (OMArrowHead.ARROWHEAD_DIRECTION_FORWARD),
     * beginning end (OMArrowHead.ARROWHEAD_DIRECTION_BACKWARD), or
     * both ends(OMArrowHead.ARROWHEAD_DIRECTION_BOTH). 
     * @param directionType which way to point the arrow head.
     * @param location where on the line to put the arrow head - 0 for
     * the starting point, 100 for the end.
     */
    public void addArrowHead(int directionType, int location){
	doArrowHead = true;

	arrowDirectionType = directionType;

	if (location < 1) arrowLocation = 1;
	else if (location > 100) arrowLocation = 100;
	else arrowLocation = location;
    }

    /**
     * Set the arc that is drawn between the points of a x-y or offset
     * line.  
     */
    public void setArc(ArcCalc ac){
	arc = ac;
    }

    /**
     * Return the arc angle set for this line.  Will only be set if it
     * was set externally.
     * @return arc angle in radians.  
     */
    public ArcCalc getArc(){
	return arc;
    }

    /**
     * Prepare the line for rendering.
     * @param proj Projection
     * @return true if generate was successful */
    public boolean generate (Projection proj) {

	if (proj == null) {
	    System.err.println("OMLine: null projection in generate!");
	    return false;
	}

	// reset the internals
	isPolyline = false;

	switch (renderType) {
	  case RENDERTYPE_XY:
	      if (arc != null){
		  xpoints = new int[1][];
		  ypoints = new int[1][];
		  arc.generate(pts[0], pts[1],
			       pts[2], pts[3]);
		  xpoints[0] = arc.getXPoints();
		  ypoints[0] = arc.getYPoints();
	      } else {
		  xpoints = new int[1][2];
		  ypoints = new int[1][2];
		  xpoints[0][0] = pts[0];
		  ypoints[0][0] = pts[1];
		  xpoints[0][1] = pts[2];
		  ypoints[0][1] = pts[3];
	      }
	      break;
	  case RENDERTYPE_OFFSET:
	      if (!proj.isPlotable(latlons[0], latlons[1])) {
		  setNeedToRegenerate(true);//HMMM not the best flag
		  return false;
	      }
	      Point p1 = proj.forward(latlons[0], latlons[1]);
	      if (arc != null){
		  xpoints = new int[1][];
		  ypoints = new int[1][];
		  arc.generate(p1.x + pts[0], p1.y + pts[1],
			       p1.x + pts[2], p1.y + pts[3]);

		  xpoints[0] = arc.getXPoints();
		  ypoints[0] = arc.getYPoints();
	      } else {
		  xpoints = new int[1][2];
		  ypoints = new int[1][2];
		  
		  xpoints[0][0] = p1.x + pts[0];
		  ypoints[0][0] = p1.y + pts[1];
		  xpoints[0][1] = p1.x + pts[2];
		  ypoints[0][1] = p1.y + pts[3];
	      }
	      break;
	  case RENDERTYPE_LATLON:
	      if (arc != null){
		  p1 = proj.forward(latlons[0], latlons[1]);
		  Point p2 = proj.forward(latlons[2], latlons[3]);
		  xpoints = new int[1][];
		  ypoints = new int[1][];
		  arc.generate(p1.x, p1.y, p2.x, p2.y);

		  xpoints[0] = arc.getXPoints();
		  ypoints[0] = arc.getYPoints();
		  isPolyline = true;
	      } else {
		  Vector lines =
		      proj.forwardLine(
			  new LatLonPoint(latlons[0], latlons[1]), 
			  new LatLonPoint(latlons[2], latlons[3]), 
			  lineType, nsegs);
		  int size = lines.size();
		  xpoints = new int[size/2][0];
		  ypoints = new int[xpoints.length][0];
		  
		  for (int i=0, j=0; i<size; i+=2, j++) {
		      xpoints[j] = (int[])lines.elementAt(i);
		      ypoints[j] = (int[])lines.elementAt(i+1);
		  }
		  isPolyline = (lineType != LINETYPE_STRAIGHT);
	      }
	      break;
	  case RENDERTYPE_UNKNOWN:
	      System.err.println("OMLine.generate: invalid RenderType");
	      return false;
	}

	if (doArrowHead) {
	    createArrowHeads();
	}

	if (Debug.debugging("arc") && arc != null){
	    OMGraphicList arcGraphics = arc.getArcGraphics();
	    Debug.output("OMLine generating arcGraphics. " + arcGraphics);
	    arcGraphics.generate(proj);
	}

	setNeedToRegenerate(false);
	return true;
    }

    /**
     * Create the ArrowHead objects for the lines, based on the
     * settings.
     */
    public void createArrowHeads(){

	//NOTE: xpoints[0] refers to the original copy of the xpoints,
	//as opposed to the [1] copy, which gets used when the line
	//needs to wrap around the screen and show up on the other
	//side.  Might have to think about the [1] points, and adding
	//a arrowhead there if it shows up in the future.

	int pointIndex = xpoints[0].length - 1;
	if (Debug.debugging("arrowheads")){
	    Debug.output("createArrowHeads(): Number of points = " + pointIndex);
	}
	int drawingLinetype = STRAIGHT_LINE;	
	if (pointIndex > 1) drawingLinetype = CURVED_LINE;

	// Used as the index for points in the xy point array to use
	// as anchors for the arrowheads
	int[] end = new int[2];
	int[] start = new int[2];
	end[0] = pointIndex;
	start[0] = 0;
	end[1] = 0;
	start[1] = pointIndex;
	int numArrows = 1; // default

	// one for the start and end of each arrowhead (there could be two)
	Point sPoint1 = new Point();
	Point ePoint1 = new Point();
	Point sPoint2 = new Point(); 
	Point ePoint2 = new Point();

	int arrowDirection = arrowDirectionType;

	if (arc != null && arc.getReversed() == true){
	    if (arrowDirection == OMArrowHead.ARROWHEAD_DIRECTION_FORWARD){
		arrowDirection = OMArrowHead.ARROWHEAD_DIRECTION_BACKWARD;
	    } else if (arrowDirection == OMArrowHead.ARROWHEAD_DIRECTION_BACKWARD){
		arrowDirection = OMArrowHead.ARROWHEAD_DIRECTION_FORWARD;
	    }
	}

	switch(drawingLinetype){
	case STRAIGHT_LINE:
  	    Debug.message("arrowheads","createArrowHeads(): Inside x-y space");
	    int newEndX = xpoints[0][end[0]];
	    int newEndY = ypoints[0][end[0]];
	    int dx, dy;
	    double dd;
	    switch(arrowDirection){
	    case OMArrowHead.ARROWHEAD_DIRECTION_BOTH:
		// Doing the backward arrow here...

  	        Debug.message("arrowheads","createArrowHeads(): direction backward and");
		int newEndX2 = xpoints[0][end[1]];
		int newEndY2 = ypoints[0][end[1]];
		if(arrowLocation != 100){
		    dx = xpoints[0][end[1]] - xpoints[0][start[1]];
		    dy = ypoints[0][end[1]] - ypoints[0][start[1]];
		    int offset = 0;
		    // Straight up or down
		    if (dx == 0){
			// doesn't matter, start and end the same
			newEndX2 = xpoints[0][start[1]]; 
			// calculate the percentage from start of line
			offset = (int)((double)dy*(arrowLocation/100.0));
			// set the end at the begining...
			newEndY2 = ypoints[0][start[1]];
			// and adjust...
			if (dy < 0) newEndY2 -= offset;
			else newEndY2 += offset;
		    }
		    else {
			dd = Math.abs((double)dy/(double)dx);
			// If the line moves more x than y
			if (Math.abs(dx) > Math.abs(dy)){
			    // set the x
			    newEndX2 = xpoints[0][start[1]] + 
				(int)((double)dx*(arrowLocation/100.0));
			    // find the y for that x and set that
			    newEndY2 = ypoints[0][start[1]];
			    offset = (int)((double)Math.abs(xpoints[0][start[1]] - newEndX2)*dd);
			    if (dy < 0) newEndY -= offset;
			    else newEndY += offset;
			}
			else  {
			    // switch everything...set y end
			    newEndY2 = ypoints[0][start[1]] + 
				(int)((double)dy*(arrowLocation/100.0));
			    // initialize the x to beginning
			    newEndX2 = xpoints[0][start[1]];
			    // calculate the difference x has to move based on y end
			    offset = (int)((double)Math.abs(ypoints[0][start[1]] - newEndY2)/dd);
			    // set the end
			    if (dx < 0) newEndX2 -= offset;
			    else newEndX2 += offset;
			}
		    }
		}

		if (start[1] < 0 ) start[1] = 0;
		sPoint2.x = xpoints[0][start[1]];
		sPoint2.y = ypoints[0][start[1]];
		ePoint2.x = newEndX2;
		ePoint2.y = newEndY2;
		numArrows = 2;
	    case OMArrowHead.ARROWHEAD_DIRECTION_FORWARD:
 	        Debug.message("arrowheads","createArrowHeads(): direction forward.");
		break;
	    case OMArrowHead.ARROWHEAD_DIRECTION_BACKWARD:
 	        Debug.message("arrowheads","createArrowHeads(): direction backward.");
		start[0] = pointIndex;
		end[0] = 0;
		break;
	    }
	    // And doing the forward arrow here...
	    if(arrowLocation != 100){
		dx = xpoints[0][end[0]] - xpoints[0][start[0]];
		dy = ypoints[0][end[0]] - ypoints[0][start[0]];
		int offset = 0;
		// Straight up or down
		if (dx == 0){
		    // doesn't matter, start and end the same
		    newEndX = xpoints[0][start[0]]; 
		    // calculate the percentage from start of line
		    offset = (int)((double)dy*(arrowLocation/100.0));
		    // set the end at the begining...
		    newEndY = ypoints[0][start[0]];
		    // and adjust...
		    if (dy < 0) newEndY -= offset;
		    else newEndY += offset;
		} else {
		    dd = Math.abs((double)dy/(double)dx);
		    // If the line moves more x than y
		    if (Math.abs(dx) > Math.abs(dy)){
			// set the x
			newEndX = xpoints[0][start[0]] + 
			    (int)((double)dx*(arrowLocation/100.0d));
			// find the y for that x and set that
			newEndY = ypoints[0][start[0]];
			offset = (int)((double)Math.abs(xpoints[0][start[0]] - newEndX)*dd);
			if (dy < 0) newEndY -= offset;
			else newEndY += offset;
		    } else  {
			// switch everything...set y end
			newEndY = ypoints[0][start[0]] + 
			    (int)((double)dy*(arrowLocation/100.0));
			// initialize the x to beginning
			newEndX = xpoints[0][start[0]];
			// calculate the difference x has to move based on y end
			offset = (int)((double)Math.abs(ypoints[0][start[0]] - newEndY)/dd);
			// set the end
			if (dx < 0) newEndX -= offset;
			else newEndX += offset;
		    }
		}
	    }

	    if (start[0] < 0) start[0] = 0;

	    sPoint1.x = xpoints[0][start[0]];
	    sPoint1.y = ypoints[0][start[0]];
	    ePoint1.x = newEndX;
	    ePoint1.y = newEndY;
	    break;
	case CURVED_LINE:
   	    Debug.message("arrowheads","createArrowHeads(): Curved line arrowhead");
	    switch(arrowDirection){
	    case OMArrowHead.ARROWHEAD_DIRECTION_BOTH:
 	        Debug.message("arrowheads","createArrowHeads(): direction backward and");
		start[1] = pointIndex - 
		    (int)((double)pointIndex* arrowLocation/100.0) - 1;
		if (start[1] < 1) start[1] = 1;
		end[1] = start[1] - 1;

		sPoint2.x = xpoints[0][start[1]];
		sPoint2.y = ypoints[0][start[1]];
		ePoint2.x = xpoints[0][end[1]];
		ePoint2.y = ypoints[0][end[1]];

		numArrows = 2;
	    case OMArrowHead.ARROWHEAD_DIRECTION_FORWARD:
   	        Debug.message("arrowheads", "createArrowHeads(): direction forward.");
		pointIndex = (int)((double)pointIndex* arrowLocation/100.0);
		end[0] = pointIndex;
		start[0] = pointIndex - 1;
		break;
	    case OMArrowHead.ARROWHEAD_DIRECTION_BACKWARD:
 	        Debug.message("arrowheads", "createArrowHeads(): direction backward.");
		start[0] =  pointIndex - 
		    (int)((double)pointIndex* arrowLocation/100.0) - 1;
		if (start[0] < 1) start[0] = 1;
		end[0] = start[0] - 1;
		break;
	    }
	    if (start[0] < 0) start[0] = 0;
	    if (end[0] < 0) end[0] = 0;

	    sPoint1.x = xpoints[0][start[0]];
	    sPoint1.y = ypoints[0][start[0]];
	    ePoint1.x = xpoints[0][end[0]]; 
	    ePoint1.y = ypoints[0][end[0]];
	    break;

	}

	arrowHead = new OMArrowHead[numArrows];
	arrowHead[0] = new OMArrowHead(sPoint1, ePoint1);
	if (numArrows > 1)
	    arrowHead[1] = new OMArrowHead(sPoint2, ePoint2);

    }

    /**
     * Paint the line.
     * @param g Graphics context to render into
     */
    public void render (Graphics g) {
	int i;
	
	if(getNeedToRegenerate()) return;

	g.setColor(getDisplayColor());

	// safety: grab local reference of projected points
	int[][] xpts = xpoints;
	int[][] ypts = ypoints;
	for (i=0; i<xpts.length; i++) {
	    g.drawPolyline(xpts[i], ypts[i], xpts[i].length);
	}

	if (doArrowHead) {
	    for (i = 0; i < arrowHead.length; i++)
		arrowHead[i].draw(g);
	}

	if (Debug.debugging("arc") && arc != null){
	    OMGraphicList arcGraphics = arc.getArcGraphics();
	    Debug.output("OMLine rendering " +  arcGraphics.size() + " arcGraphics.");
	    arcGraphics.render(g);
	}
    }

    /**
     * Return the shortest distance from the line to an XY-point.
     * @param x X coordinate of the point.
     * @param y Y coordinate fo the point.
     * @return double distance from line to the point
     */
    public double distance (int x, int y) {
	double temp, distance = Double.POSITIVE_INFINITY;

	if (getNeedToRegenerate()) {
	    return distance;
	}

	for (int i=0; i<xpoints.length; i++) {
	    for (int j=0, k=1; k<xpoints[i].length; j++, k++) {
		temp = DrawUtil.distance_to_line(
			xpoints[i][j], ypoints[i][j],
			xpoints[i][k], ypoints[i][k], x, y);
		if (temp < distance) distance = temp;
	    }
	}
	return distance;
    }
}

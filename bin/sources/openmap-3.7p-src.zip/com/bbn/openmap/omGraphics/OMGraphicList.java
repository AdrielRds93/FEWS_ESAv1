/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/omGraphics/OMGraphicList.java,v $
 * $Revision: 1.42 $
 * $Date: 2000/07/13 21:17:46 $
 * $Author: dietrick $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.omGraphics;

import java.awt.Graphics;
import java.awt.Color;
import java.io.*;
import java.net.*;
import java.util.Vector;
import com.bbn.openmap.proj.Projection;
import com.bbn.openmap.util.GraphicList;
import com.bbn.openmap.omGraphics.grid.*;
import com.bbn.openmap.util.Debug;

/**
 * This class encapsulates a Vector of OMGraphics.
 * <p>
 * There are several things that this list does that make it better that
 * any ol' Vector.  You can make several common OMGraphic modification
 * calls on the list, and the list handles the iteration and changing of
 * all the graphics while taking into account a travese order.
 * <p>
 * An additional benefit is that because the OMGraphicList extends
 * OMGraphic it can contain other instances of OMGraphicList.  This
 * way you can manage groupings of graphics, (for instance, an
 * OMGraphicList of OMGraphicLists which each have an OMRaster and
 * OMText).
 * <p>
 * Many methods, such as generate() and findClosest() traverse the
 * items in the GraphicsList recursively.  The direction that the list
 * is traversed is controlled by then traverseMode variable.  The
 * traverseMode mode lets you set whether the first or last object
 * added to the list (FIRST_ADDED_ON_TOP or LAST_ADDED_ON_TOP) is
 * drawn on top of the list and considered first for searches.  
 */
public class OMGraphicList extends OMGraphic
    implements GraphicList, Serializable
{
    /**
     * The list of graphics.
     * Once an OMGraphicList is constructed, this variable should
     * never be null.
     */
    protected Vector graphics = null;

    /**  
     * Used to set the order in which the list is traversed to draw
     * or search the objects. This means that the last things on the
     * list will be on top of the map because they are drawn last, on
     * top of everything else. For searches, objects added last to the
     * list will be considered first for a search match.
     */
    public final transient static int LAST_ADDED_ON_TOP = 0;

    /**
     * Used to set the order in which the list is traversed to draw or
     * search the objects.  This means that the first things on the
     * list will appear on top because they are drawn last, on top of
     * everything else. For searches, objects added first to the list
     * will be considered first for a search match.  This is the
     * default mode for the list.
     */
    public final transient static int FIRST_ADDED_ON_TOP = 1;

    /** 
     * Used for searches, when OMDist doesn't have a graphic.  The
     * index of a null graphic is NONE.  If you try to remove or
     * insert a graphic at NONE, an exception will be thrown.  If you
     * try to get a graphic at NONE, you'll get null;
     */
    public final static int NONE = -1;

    /**
     * List traversal mode.
     * The default is FIRST_ADDED_ON_TOP.
     */
    protected int traverseMode = FIRST_ADDED_ON_TOP;

    /**
     * Construct an OMGraphicList.
     */
    public OMGraphicList() {
	this (10, 0);//same values as default Vector
    };
    
    /**
     * Construct an OMGraphicList with an initial capacity. 
     * @param initialCapacity the initial capacity of the list 
     */
    public OMGraphicList(int initialCapacity) {
	this (initialCapacity, 0);//same capInc as Vector
    };

    /**
     * Construct an OMGraphicList with an initial capacity and
     * a standard increment value.
     * @param initialCapacity the initial capacity of the list 
     * @param capacityIncrement the capacityIncrement for resizing 
     */
    public OMGraphicList(int initialCapacity, int capacityIncrement) {
        graphics = new Vector(initialCapacity, capacityIncrement);
    };

    /**
     * Add an OMGraphic to the GraphicList.
     * The OMGraphic must not be null.
     * @param g the non-null OMGraphic to add
     * @exception IllegalArgumentException if OMGraphic is null
     */
    public void addOMGraphic(OMGraphic g) {
	add(g);
    }

    /**
     * Add an OMGraphic to the GraphicList.
     * The OMGraphic must not be null.
     * @param g the non-null OMGraphic to add
     * @exception IllegalArgumentException if OMGraphic is null
     */
    public void add(OMGraphic g) {
	if (g == null)
	    throw new IllegalArgumentException("Graphic is null!");
	graphics.addElement(g);
    }

    /**
     * Remove the graphic from the list.
     * @param graphic the graphic to remove.
     * @return true if graphic was on the list, false if otherwise.
     */
    public boolean remove(OMGraphic graphic){
	return graphics.removeElement(graphic);
    }

    /**
     * Return the index of the OMGraphic in the list.
     * @param graphic the graphic to look for
     * @return the index in the list of the graphic, -1 if the object
     * is not found.  
     */
    public int indexOf(OMGraphic graphic){
	return graphics.indexOf(graphic);
    }

    /**
     * Set the order in which the list is traversed to draw or search
     * the objects. The possible modes for the list are
     * FIRST_ADDED_ON_TOP or LAST_ADDED_ON_TOP.
     * @param mode traversal mode
     */
    public void setTraverseMode(int mode){
	traverseMode = mode;
    }

    /**
     * Get the order in which the list is traversed to draw or search
     * the objects. The possible modes for the list are
     * FIRST_ADDED_ON_TOP or LAST_ADDED_ON_TOP.
     * @return int traversal mode
     */
    public int getTraverseMode(){
	return traverseMode;
    }

    /**
     * Remove all elements from the graphic list.
     */
    public void clear() {
	graphics.removeAllElements();
    }

    /**
     * Find out if the list is empty.
     * @return boolean true if the list is empty, false if not
     */
    public boolean isEmpty(){
	return (graphics.size() == 0);
    }

    /**
     * Find out the number of graphics in the list.
     * @return int the number of graphics on the list.
     */
    public int size() {
        return graphics.size();
    }

    /**
     * Set the graphic at the specified location.
     * The OMGraphic must not be null.
     * @param graphic OMGraphic
     * @param index index of the OMGraphic to return
     * @exception IllegalArgumentException if OMGraphic is null
     * @exception ArrayIndexOutOfBoundsException if index is out-of-bounds
     */
    public void setOMGraphicAt(OMGraphic graphic, int index) {
	if (graphic == null)
	    throw new IllegalArgumentException("Graphic is null!");
	graphics.setElementAt(graphic, index);
    }

    /**
     * Get the graphic at the location number on the list.
     * @param location the location of the OMGraphic to return
     * @return OMGraphic or null if location &gt; list size
     * @exception ArrayIndexOutOfBoundsException if
     * <code>location &lt; 0</code> or <code>location &gt;=
     * this.size()</code>
     */
    public OMGraphic getOMGraphicAt(int location){
	java.util.Vector targets = getTargets();
	if (location < 0 || location >= targets.size()){
	    return null;
	}
	return (OMGraphic)targets.elementAt(location);
    }

    /**
     * Get the graphic with the appObject. Traverse mode doesn't
     * matter.  Tests object identity first, then tries equality.
     * @param appObj appObject of the wanted graphic.  
     * @return OMGraphic or null if not found
     * @see Object#equals
     * @see OMGraphic#setAppObject
     * @see OMGraphic#getAppObject
     */
    public OMGraphic getOMGraphicWithAppObject(Object appObj){
	java.util.Vector targets = getTargets();

	int listSize = targets.size();
	for (int i = 0; i < listSize; i++){
	    OMGraphic graphic = (OMGraphic) targets.elementAt(i);
	    Object tObj = graphic.getAppObject();
	    if ((appObj == tObj) || (appObj.equals(tObj))) {
	        return graphic;
	    }
	}
	return null;
    }

    /**
     * Remove the graphic at the location number.
     * @param location the location of the OMGraphic to remove
     */
    public void removeOMGraphicAt(int location){
        graphics.removeElementAt(location);
    }

    /**
     * Insert the graphic at the location number.
     * The OMGraphic must not be null.
     * @param graphic the OMGraphic to insert.
     * @param location the location of the OMGraphic to insert
     * @exception IllegalArgumentException if OMGraphic is null
     * @exception ArrayIndexOutOfBoundsException if index is out-of-bounds
     */
    public void insertOMGraphicAt(OMGraphic graphic, int location){
	if (graphic == null)
	    throw new IllegalArgumentException("Graphic is null!");
        graphics.insertElementAt(graphic, location);
    }

    /** 
     * Moves the graphic at the given index to the part of the list
     * where it will be drawn on top of one of the other graphics
     * which is its neighbor on the list.  This method does check to
     * see what the traverseMode of the list is, and calls either
     * moveIndexedToLast or moveIndexedToFirst, depending on what is
     * appropriate.
     * @param location the index location of the graphic to move.
     * @see #moveIndexedOneToFront(int)
     * @see #moveIndexedOneToBack(int)
     */
    public void moveIndexedOneToTop(int location){
	if (traverseMode == FIRST_ADDED_ON_TOP){
	    moveIndexedOneToFront(location);
	} else {
	    moveIndexedOneToBack(location);
	}
    }

    /** 
     * Moves the graphic at the given index to the part of the list
     * where it will be drawn on top of the other graphics.  This
     * method does check to see what the traverseMode of the list is,
     * and calls either moveIndexedToLast or
     * moveIndexedToFirst, depending on what is appropriate.
     * @param location the index location of the graphic to move.  
     */
    public void moveIndexedToTop(int location){
	if (traverseMode == FIRST_ADDED_ON_TOP){
	    moveIndexedToFirst(location);
	} else {
	    moveIndexedToLast(location);
	}
    }

    /** 
     * Moves the graphic at the given index to the part of the list
     * where it will be drawn under one of the other graphics, its
     * neighbor on the list.  This method does check to see what the
     * traverseMode of the list is, and calls either
     * moveIndexedOneToBack or moveIndexedOneToFront, depending on
     * what is appropriate.
     * @param location the index location of the graphic to move.
     * @see #moveIndexedOneToFront(int)
     * @see #moveIndexedOneToBack(int)
     */
    public void moveIndexedOneToBottom(int location){
	OMGraphic tmpGraphic = getOMGraphicAt(location);
	if (traverseMode == FIRST_ADDED_ON_TOP){
	    moveIndexedOneToBack(location);
	} else {
	    moveIndexedOneToFront(location);
	}
    }

    /** 
     * Moves the graphic at the given index to the part of the list
     * where it will be drawn under all of the other graphics.  This
     * method does check to see what the traverseMode of the list is,
     * and calls either moveIndexedToLast or
     * moveIndexedToFirst, depending on what is appropriate.
     * @param location the index location of the graphic to move.  
     */
    public void moveIndexedToBottom(int location){
	OMGraphic tmpGraphic = getOMGraphicAt(location);
	if (traverseMode == FIRST_ADDED_ON_TOP){
	    moveIndexedToLast(location);
	} else {
	    moveIndexedToFirst(location);
	}
    }

    /** 
     * Moves the graphic at the given index to the front of the list,
     * sliding the other graphics back on in the list in order. If the
     * location is already at the beginning or beyond the end, nothing
     * happens.
     * @param location the index of the graphic to move. 
     * @see #moveIndexedToBottom(int)
     * @see #moveIndexedToTop(int)
     */
    public void moveIndexedToFirst(int location){
	int listSize = graphics.size();
	if (location > 0 && location < listSize){
	    OMGraphic tmpGraphic = getOMGraphicAt(location);
	    for (int i = location; i > 0; i--){
		setOMGraphicAt(getOMGraphicAt(i-1), i);
	    }
	    setOMGraphicAt(tmpGraphic, 0);
	}
    }

    /** 
     * Moves the graphic at the given index toward the front of the
     * list by one spot, sliding the other graphic back on in the list
     * in order.  If the location is already at the beginning or
     * beyond the end, nothing happens.
     * @param location the index of the graphic to move. 
     */
    public void moveIndexedOneToFront(int location){
	int listSize = graphics.size();
	if (location > 0 && location < listSize){
	    OMGraphic tmpGraphic = getOMGraphicAt(location);
	    setOMGraphicAt(getOMGraphicAt(location-1), location);
	    setOMGraphicAt(tmpGraphic, location-1);
	}
    }

    /** 
     * Moves the graphic at the given index to the end of the list,
     * sliding the other graphics up on in the list in order.  If the
     * location is already at the end or less than zero, nothing
     * happens.
     * @param location the index of the graphic to move.  
     * @see #moveIndexedToBottom(int)
     * @see #moveIndexedToTop(int)
     */
    public void moveIndexedToLast(int location){
	int listSize = graphics.size();
	if (location < listSize - 1 && location >= 0){
	    OMGraphic tmpGraphic = getOMGraphicAt(location);
	    for (int i = location; i < listSize - 1; i++){
		setOMGraphicAt(getOMGraphicAt(i+1), i);
	    }
	    setOMGraphicAt(tmpGraphic, listSize - 1);
	}
    }

    /** 
     * Moves the graphic at the given index toward the back of the
     * list by one spot, sliding the other graphic up on in the list
     * in order.  If the location is already at the end or
     * less than zero, nothing happens.
     * @param location the index of the graphic to move. 
     */
    public void moveIndexedOneToBack(int location){
	int listSize = graphics.size();
	if (location < listSize - 1 && location >= 0){
	    OMGraphic tmpGraphic = getOMGraphicAt(location);
	    setOMGraphicAt(getOMGraphicAt(location+1), location);
	    setOMGraphicAt(tmpGraphic, location+1);
	}
    }

    /**
     * Set the line width of all the vector graphics on the list.
     * @param value width.  
     */
    public void setLineWidth(float value){
	java.util.Vector targets = getTargets();
	int size = targets.size();

	for (int i = 0; i < size; i++){
	    OMGraphic graphic = (OMGraphic) targets.elementAt(i);
	    graphic.setLineWidth(value);
	}
    }

    /**
     * Set the fill color for all the objects on the list.
     * @param color java.awt.Color
     */
    public void setFillColor(Color color){
	java.util.Vector targets = getTargets();
	int listSize = targets.size();
	for (int i = 0; i < listSize; i++){
	   ((OMGraphic) targets.elementAt(i)).setFillColor(color);
	}
    }

    /**
     * Set the line color for all the objects on the list.
     * @param color java.awt.Color
     */
    public void setLineColor(Color color){
	java.util.Vector targets = getTargets();
	int listSize = targets.size();
	for (int i = 0; i < listSize; i++){
	   ((OMGraphic) targets.elementAt(i)).setLineColor(color);
	}
    }

    /**
     * Set the selection color for all the objects on the list.
     * @param color java.awt.Color
     */
    public void setSelectColor(Color color){
	java.util.Vector targets = getTargets();
	int listSize = targets.size();
	for (int i = 0; i < listSize; i++){
	   ((OMGraphic) targets.elementAt(i)).setSelectColor(color);
	}
    }

    /**
     * Renders all the objects in the list a graphics context.  This
     * is the same as <code>paint()</code> for AWT components.  The
     * graphics are rendered in the order of traverseMode.  Any
     * graphics where <code>isVisible()</code> returns false are not
     * rendered.
     * @param gr the AWT Graphics context
     */
    public void render (Graphics gr){
	java.util.Vector targets = getTargets();
	int i;
	int size = targets.size();

	if (traverseMode == FIRST_ADDED_ON_TOP) {
	    for (i = size - 1; i >= 0; i--){
		OMGraphic graphic = (OMGraphic) targets.elementAt(i);
		if (graphic.isVisible())
		    graphic.render(gr);
	    }
	} else {
	    for (i = 0; i < size; i++){
		OMGraphic graphic = (OMGraphic) targets.elementAt(i);
		if (graphic.isVisible())
		    graphic.render(gr);
	    }
	}
    }

    /**
     * Renders all the objects in the list a graphics context, in
     * their 'selected' mode.  This is the same as
     * <code>paint()</code> for AWT components.  The graphics are
     * rendered in the order of traverseMode.  Any graphics where
     * <code>isVisible()</code> returns false are not rendered.  All
     * of the graphics on the list are returned to their deselected
     * state.
     * @param gr the AWT Graphics context 
     */
    public void renderAllAsSelected (Graphics gr){
	java.util.Vector targets = getTargets();
	int i;
	int size = targets.size();

	if (traverseMode == FIRST_ADDED_ON_TOP) {
	    for (i = size - 1; i >= 0; i--){
		OMGraphic graphic = (OMGraphic) targets.elementAt(i);
		if (graphic.isVisible()){
		    graphic.select();
		    graphic.render(gr);
		    graphic.deselect();
		}
	    }
	} else {
	    for (i = 0; i < size; i++){
		OMGraphic graphic = (OMGraphic) targets.elementAt(i);
		if (graphic.isVisible()){
		    graphic.select();
		    graphic.render(gr);
		    graphic.deselect();
		}
	    }
	}
    }

    /**
     * Projects any graphics needing projection.
     * Use this method to project any new or changed OMGraphics before
     * painting.  to re-project the whole list, use
     * <code>generate(Projection, boolean)</code> with
     * <code>forceProjectAll</code> set to <code>true</code>.  This is
     * the same as calling <code> generate(p, false)</code>
     * @param p a <code>Projection</code>
     * @see #generate(Projection, boolean)
     */
    public void project (Projection p){
	generate(p, false);
    }


    /**
     * Projects the OMGraphics on the list.
     * This is the same as calling <code>generate(p, forceProjectAll)</code>.
     * @param p a <code>Projection</code>
     * @param forceProjectAll if true, all the graphics on the list
     * are generated with the new projection.  If false they are only
     * generated if getNeedToRegenerate() returns true
     * @see #generate(Projection, boolean)
     */
    public void project(Projection p, boolean forceProjectAll){
	generate(p, forceProjectAll);
    }


    /**
     * Prepare the graphics for rendering.
     * This is the same as calling <code>project(p, true)</code>.
     * @param p a <code>Projection</code>
     * @return boolean true
     * @see #generate(Projection, boolean)
     */
    public boolean generate(Projection p) {
	generate(p, true);
	return true;
    }


    /**
     * Prepare the graphics for rendering.
     * This must be done before calling <code>render()</code>!  This
     * recursively calls generate() on the OMGraphics on the list.
     * @param p a <code>Projection</code>
     * @param forceProjectAll if true, all the graphics on the list
     * are generated with the new projection.  If false they are only
     * generated if getNeedToRegenerate() returns true
     * @see OMGraphic#generate
     * @see OMGraphic#regenerate
     */
    public void generate(Projection p, boolean forceProjectAll) {
	java.util.Vector targets = getTargets();
	OMGraphic graphic;

	// Check forceProjectAll outside the loop for slight
	// performance improvement.
	int listSize = targets.size();
	if (forceProjectAll) {
	    for (int i = 0; i < listSize; i++){
		graphic = (OMGraphic) targets.elementAt(i);
		graphic.generate(p);
	    }
	} else {
	    for (int i = 0; i < listSize; i++){
		graphic = (OMGraphic) targets.elementAt(i);
		graphic.regenerate(p);
	    }
	}
    }


    /**
     * Finds the object located the closest to the point, if the
     * object distance away is within the limit.  The search is always
     * conducted from the topmost graphic to the bottommost, depending
     * on the traverseMode.  Any graphics where
     * <code>isVisible()</code> returns false are not considered.
     *
     * @param x the x coordinate on the component the graphics are
     * displayed on.
     * @param y the y coordinate on the component the graphics are
     * displayed on.
     * @param limit the max distance that a graphic has to be within
     * to be returned, in pixels.
     * @return OMGraphic the closest on the list within the limit, or
     * null if not found.
     */
    public OMGraphic findClosest(int x, int y, double limit){
	return _findClosest(x, y, limit).omg;
    }

    /**
     * Finds the object located the closest to the point, regardless
     * of how far away it is.  This method returns null if the list is
     * not valid.  The search starts at the first-added graphic.<br>
     * This is the same as calling
     * <code>findClosest(x, y, Double.MAX_VALUE)</code>.
     *
     * @param x the horizontal pixel position of the window, from the
     * left of the window.
     * @param y the vertical pixel position of the window, from the
     * top of the window.
     * @return the closest graphic to the xy window point.
     * @see #findClosest(int, int, double)
     */
    public OMGraphic findClosest(int x, int y){
        return _findClosest(x, y, Double.MAX_VALUE).omg;
    }
 
    /**
     * Finds the object located the closest to the point, if the
     * object distance away is within the limit.  The search is always
     * conducted from the topmost graphic to the bottommost, depending
     * on the traverseMode.  Any graphics where
     * <code>isVisible()</code> returns false are not considered.
     *
     * @param x the x coordinate on the component the graphics are
     * displayed on.
     * @param y the y coordinate on the component the graphics are
     * displayed on.
     * @param limit the max distance that a graphic has to be within
     * to be returned, in pixels.  
     * @return index of the closest on the list within the limit, or
     * OMGraphicList.NONE if not found.
     */
    public int findIndexOfClosest(int x, int y, double limit){
	return _findClosest(x, y, limit).index;
    }

    /**
     * Finds the object located the closest to the point, regardless
     * of how far away it is.  This method returns null if the list is
     * not valid.  The search starts at the first-added graphic.<br>
     * This is the same as calling
     * <code>findClosest(x, y, Double.MAX_VALUE)</code>.
     *
     * @param x the horizontal pixel position of the window, from the
     * left of the window.
     * @param y the vertical pixel position of the window, from the
     * top of the window.
     * @return index of the closest graphic to the xy window point, or
     * OMGraphicList.NONE if not found.
     * @see #findIndexOfClosest(int, int, double)
     */
    public int findIndexOfClosest(int x, int y){
        return _findClosest(x, y, Double.MAX_VALUE).index;
    }

    /**
     * Finds the distance to the closest OMGraphic.
     * @param x x coord
     * @param y y coord
     * @return double distance
     * @see #findClosest(int, int, double)
     */
    public double distance(int x, int y) {
	return _findClosest(x, y, Double.MAX_VALUE).d;
    }

    /**
     * RetVal for closest object/distance calculations.
     */
    protected static class OMDist {
	public OMGraphic omg = null;
	public double d = Double.POSITIVE_INFINITY;
	public int index = NONE;  // unknown
    }


    /**
     * Find the closest Object and its distance.
     * The search is always conducted from the topmost graphic to the
     * bottommost, depending on the traverseMode.
     * @param x x coord
     * @param y y coord
     * @param limit the max distance that a graphic has to be within
     * to be returned, in pixels.
     * @return OMDist
     */
    protected OMDist _findClosest(int x, int y, double limit) {
	OMDist omd = new OMDist();

	java.util.Vector targets = getTargets();

        OMGraphic graphic, ret = null;
        double closestDistance = Double.MAX_VALUE;
	double currentDistance;
	int i;
	int index = NONE;
	int size = targets.size();

	if (traverseMode == FIRST_ADDED_ON_TOP) {
	    for (i = 0; i < size; i++) {
		graphic = (OMGraphic)targets.elementAt(i);

		// cannot select a graphic which isn't visible
		if (!graphic.isVisible())
		    continue;
		currentDistance = graphic.distance(x, y);
		if (currentDistance < limit && 
			currentDistance < closestDistance){
		    ret = graphic;
		    closestDistance = currentDistance;
		    index = i;
		}
	    }
	} else {
	    for (i = size -1; i >= 0; i--) {
		graphic = (OMGraphic)targets.elementAt(i);

		// cannot select a graphic which isn't visible
		if (!graphic.isVisible())
		    continue;
		currentDistance = graphic.distance(x, y);
		if (currentDistance < limit && 
			currentDistance < closestDistance){
		    ret = graphic;
		    closestDistance = currentDistance;
		    index = i;
		}
	    }
	}

	omd.omg = ret;
	omd.d = closestDistance;
	omd.index = index;
	return omd;
    }


    /**
     * Finds the object located the closest to the point, if
     * the object distance away is within the limit, and sets the
     * color of that graphic to its select color.  It sets the colors
     * to all the other objects to the regular color. The search
     * starts at the first-added graphic.
     * Any graphics where <code>isVisible()</code> returns false are not
     * considered.
     *
     * @param x the horizontal pixel position of the window, from the
     * left of the window.
     * @param y the vertical pixel position of the window, from the
     * top of the window.
     * @param limit the max distance that a graphic has to be within
     * to be returned, in pixels.
     * @return the closest OMGraphic on the list, within the limit or null if
     * none found.
     */
    public OMGraphic selectClosest(int x, int y, double limit){

	java.util.Vector targets = getTargets();

        OMGraphic ret = null;
	OMGraphic graphic, current;
        double closestDistance = Double.MAX_VALUE;
	double currentDistance;
	int i;
	int size = targets.size();

	if (traverseMode == FIRST_ADDED_ON_TOP)
	    for (i = 0; i < size; i++) {
		graphic = (OMGraphic)targets.elementAt(i);
		
		if (!graphic.isVisible())
		    continue;
		current = graphic;
		// in case this graphic was the last closest
		current.deselect();
		currentDistance = current.distance(x, y);
		if (currentDistance < limit && 
			currentDistance < closestDistance){
		    if(ret != null) ret.deselect();
		    ret = current;
		    ret.select();
		    closestDistance = currentDistance;
		}
	    }
	else
	    for (i = size -1; i >= 0; i--) {
		graphic = (OMGraphic)targets.elementAt(i);
		
		if (!graphic.isVisible())
		    continue;
		current = graphic;
		// in case this graphic was the last closest
		current.deselect();
		currentDistance = current.distance(x, y);
		if (currentDistance < limit && 
			currentDistance < closestDistance){
		    if(ret != null) ret.deselect();
		    ret = current;
		    ret.select();
		    closestDistance = currentDistance;
		}
	    }

	return ret;
    }

    /**
     * Finds the object located the closest to the object,
     * regardless of how far away it is.  Sets the select color of 
     * that object, and resets the color of all the other objects.
     * The search starts at the first-added graphic.
     *
     * @param x the x coordinate on the component the graphics are displayed on.
     * @param y the y coordinate on the component the graphics are displayed on.
     * @return the closest OMGraphic on the list.
     */
    public OMGraphic selectClosest(int x, int y){
        return selectClosest(x, y, Double.MAX_VALUE);
    }

    /**
     * If you call select() on an OMGraphicList, it selects all the
     * graphics it contains.  This is really an OMGraphic method, but
     * it makes OMGraphicLists embedded in other OMGraphicLists act
     * correctly.
     */
    public void select(){
	selectAll();
    }

    /**
     * If you call deselect() on an OMGraphicList, it deselects all
     * the graphics it contains.  This is really an OMGraphic method, but
     * it makes OMGraphicLists embedded in other OMGraphicLists act
     * correctly.
     */
    public void deselect(){
	deselectAll();
    }

    /**
     * Deselects all the items on the graphic list.
     */
    public void deselectAll(){
	java.util.Vector targets = getTargets();
	int size = targets.size();

	for (int i = 0; i < size; i++) {
	    ((OMGraphic)targets.elementAt(i)).deselect();
	}
    }

    /**
     * Selects all the items on the graphic list.
     */
    public void selectAll(){
	java.util.Vector targets = getTargets();
	int size = targets.size();

	for (int i = 0; i < size; i++) {
	    ((OMGraphic)targets.elementAt(i)).select();
	}
    }

    /** 
     * Goes through the list, finds the OMGrid objects, and sets the
     * generator for all of them.  If a projection is passed in, the
     * generator will be used to create a displayable graphic within
     * the grid.
     *
     * @param generator an OMGridGenerator to create a renderable
     * graphic from the OMGrid.
     * @param proj a projection to use to generate the graphic.  If
     * null, the generator will create a renderable graphic the next
     * time a projection is handed to the list.
     */
    public void setGridGenerator(OMGridGenerator generator, Projection proj){
	java.util.Vector targets = getTargets();
	int size = targets.size();

	OMGraphic graphic;
	for (int i = 0; i < size; i++) {
	    graphic = (OMGraphic)targets.elementAt(i);
	    if (graphic instanceof OMGrid){
		((OMGrid)graphic).setGenerator(generator);
		if (proj != null){
		    graphic.generate(proj);
		}
	    }
	}
    }

    /**
     * Get a reference to the graphics vector.
     * This method is meant for use by methods that need to iterate
     * over the graphics vector, or make at least two invocations on
     * the graphics vector.
     * <p>
     * HACK this method should either return a clone of the graphics
     * list or a quick reference.  Currently it returns the latter for
     * simplicity and minor speed improvement.  We should allow a way
     * for the user to set the desired behavior, depending on whether
     * they want responsibility for list synchronization.  Right now,
     * the user is responsible for synchronizing the OMGraphicList if
     * it's being used in two or more threads...
     *
     * @return a reference of the graphics vector.
     */
    public java.util.Vector getTargets() {
//	synchronized (this) {
//	    return (java.util.Vector) graphics.clone();
//	}
	return graphics;
    }

    /** 
     * Read a cache of OMGraphics, given an URL..
     *
     * @param cacheURL URL of serialized graphic list.
     */
    public void readGraphics(URL cacheURL)
	throws java.io.IOException {
	
	try {
	    ObjectInputStream objstream = 
		new ObjectInputStream(cacheURL.openStream());
	    
	    if (Debug.debugging("omGraphics")){
		Debug.out.println("OMGraphicList: Opened " + cacheURL.toString() );
	    }

	    readGraphics(objstream);
	    objstream.close();

	    if (Debug.debugging("omgraphics")){
		Debug.out.println("OMGraphicList: closed " + cacheURL.toString() );
	    }
	    
	} catch (ArrayIndexOutOfBoundsException aioobe){
 	    new com.bbn.openmap.util.HandleError(aioobe);
 	} catch (ClassCastException cce){
 	    cce.printStackTrace();
 	}
    }
    
    /** 
     * Read a cache of OMGraphics, given a ObjectInputStream.
     *
     * @param objstream ObjectInputStream of graphic list.
     */
    public void readGraphics(ObjectInputStream objstream) throws IOException {
	
	Debug.message("omgraphics", "OMGraphicList: Reading cached graphics");
	
	try { 
	    while (true) {
		try {
		    this.add((OMGraphic)(objstream.readObject()));
		} catch (ClassNotFoundException e) {
		    e.printStackTrace();
		} catch (OptionalDataException ode){
		    ode.printStackTrace();
		}
	    }
	} catch (EOFException e){}
    }
    
    /**
     * Write the graphics out to a file
     * @param graphicsSaveFile
     */
    public void writeGraphics(String graphicsSaveFile) 
	throws IOException {
	
	FileOutputStream ostream = new FileOutputStream(graphicsSaveFile);
	ObjectOutputStream objectstream = new ObjectOutputStream(ostream);
	writeGraphics(objectstream);
	objectstream.close();
    }

    /**
     * Write the graphics out to a ObjectOutputStream
     * @param objectstream ObjectOutputStream
     */
    public void writeGraphics(ObjectOutputStream objectstream) 
	throws IOException {
       
	for ( int i = 0 ; i < graphics.size() ; i++ ){
	    OMGraphic g = getOMGraphicAt(i);
	    try {
		objectstream.writeObject(g);
	    } catch ( IOException e ){
		System.err.println("OMGraphicsList: Couldn't write object " + g);
		System.err.println("OMGraphicsList: Reason: " + e.toString());
	    }
	}
	objectstream.close();
    }
}

/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998-2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/omGraphics/OMLine2D.java,v $
 * $Revision: 1.10 $
 * $Date: 2000/08/02 14:25:37 $
 * $Author: dietrick $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.omGraphics;

import com.bbn.openmap.proj.Projection;

import java.awt.BasicStroke;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Stroke;

/**
 * Line object which takes advantage of the Java2D API.
 * This class requires the Java 2 platform.
 */
public class OMLine2D extends OMLine implements OMGraphic2D {

    /**
     * The Java2D Stroke.
     * This is used for lineWidth.
     */
    protected Stroke stroke = new BasicStroke(lineWidth);

    /** The Java2D Paint
     * This is used for filled graphics
     */
    protected Paint paint;

    /** Generic constructor, attributes need to filled later. */
    public OMLine2D () {
	super();
    }

    /**
     * Create a line from lat lon points.
     *
     * @param lat_1 latitude of first point, decimal degrees.
     * @param lon_1 longitude of first point, decimal degrees.
     * @param lat_2 latitude of second point, decimal degrees.
     * @param lon_2 longitude of second point, decimal degrees.
     * @param lineType a choice between LINETYPE_STRAIGHT,
     * LINETYPE_GREATCIRCLE or LINETYPE_RHUMB.
     */
    public OMLine2D (double lat_1, double lon_1, double lat_2, double lon_2,
		  int lineType)
    {
	super(lat_1, lon_1, lat_2, lon_2, lineType);
    }

    /**
     * Create a line from lat lon points.
     *
     * @param lat_1 latitude of first point, decimal degrees.
     * @param lon_1 longitude of first point, decimal degrees.
     * @param lat_2 latitude of second point, decimal degrees.
     * @param lon_2 longitude of second point, decimal degrees.
     * @param lineType a choice between LINETYPE_STRAIGHT,
     * LINETYPE_GREATCIRCLE or LINETYPE_RHUMB.
     * @param nsegs number of segment points (only for
     * LINETYPE_GREATCIRCLE or LINETYPE_RHUMB line types, and if &lt;
     * 1, this value is generated internally)
     */
    public OMLine2D (double lat_1, double lon_1, double lat_2, double lon_2,
		  int lineType, int nsegs)
    {
	super(lat_1, lon_1, lat_2, lon_2, lineType, nsegs);
    }

    /**
     * Create a line between two xy points on the window.
     * @param x1 the x location of the first point, in pixels from the
     * left of the window.
     * @param y1 the y location of the first point, in pixels from the
     * top of the window.
     * @param x2 the x location of the second point, in pixels from
     * the left of the window.
     * @param y2 the y location of the second point, in pixels from
     * the top of the window.
     */
    public OMLine2D (int x1, int y1, 
		  int x2, int y2) {
	super(x1, y1, x2, y2);
    }

    /**
     * Create a line between two x-y points on the window, where the
     * x-y points are offsets from a lat-lon point.  It assumes that
     * you'll want a straight window line between the points, so if
     * you don't, use the setLineType() method to change it.
     *
     * @param lat_1 the latitude of the reference point of the line,
     * in decimal degrees.
     * @param lon_1 the longitude of the reference point of the line,
     * in decimal degrees.
     * @param x1 the x location of the first point, in pixels from the
     * longitude point.
     * @param y1 the y location of the first point, in pixels from the
     * latitude point.
     * @param x2 the x location of the second point, in pixels from
     * the longitude point.
     * @param y2 the y location of the second point, in pixels from
     * the latitude point.
     */
    public OMLine2D (double lat_1, double lon_1,
		  int x1, int y1, 
		  int x2, int y2) {
	super(lat_1, lon_1, x1, y1, x2, y2);
    }

    /**
     * Set the line width to a value between 1 and 10 pixels.
     * Anything outside of these bounds gets set to 1. 
     */
    public void setLineWidth (float w) {
	super.setLineWidth(w);
	stroke = new BasicStroke(getLineWidth(),
				 BasicStroke.CAP_BUTT, 
				 BasicStroke.JOIN_MITER , 10.0f,
				 getLineDash(),getLineDashPhase());
    }

    /**
     * Set the stroke for the graphic.  Also sets the line width of
     * the graphics from the setting in the Stroke object, if it's a
     * BasicStroke.
     */
    public void setStroke(java.awt.Stroke st){
	if (st == null){
	    if (stroke == null){
		stroke = new BasicStroke();
	    }
	} else {
	    stroke = st;
	}

	if (stroke instanceof BasicStroke){
	    super.setLineWidth((int)((BasicStroke)stroke).getLineWidth());
	}
    }

    /**
     * Set the Paint object used to fill the rectangle
     */
    public void setPaint(java.awt.Paint paint) {
        this.paint = paint;
    }

    /**
     */
    public void setLineDash (float [] dasharray, float phase) {
	super.setLineDash(dasharray,phase);
	stroke = new BasicStroke(getLineWidth(),
				 BasicStroke.CAP_BUTT, 
				 BasicStroke.JOIN_MITER,10.0f,
				 getLineDash(),getLineDashPhase());
    }

    /**
     * Prepare the line for rendering.
     * @param proj Projection
     * @return true if generate was successful
     */
    public boolean generate (Projection proj) {
	return super.generate(proj);
    }

    /**
     * Paint the line.
     * @param g Graphics context to render into
     */
    public void render (Graphics g) {
	if (g instanceof Graphics2D){
	    Stroke oldstroke = ((Graphics2D)g).getStroke();
	    ((Graphics2D)g).setStroke(stroke);
	    if (paint != null) {
		((Graphics2D)g).setPaint(paint);
	    }
	    super.render(g);
	    // reset the stroke, in case we want to draw a non 2D graphic 
	    // (like OMText)
	    ((Graphics2D)g).setStroke(oldstroke);
	} else {
	    super.render(g);
	}
    }

    /**
     * Return the shortest distance from the line to an XY-point.
     * @param x X coordinate of the point.
     * @param y Y coordinate fo the point.
     * @return double distance from line to the point
     */
    public double distance (int x, int y) {
	double d = super.distance(x,y);
	if (lineWidth <= 1)
	    return d;
	// extra calculation for lineWidth
	d -= lineWidth/2;
	return (d < 0d) ? 0d : d;
    }
}

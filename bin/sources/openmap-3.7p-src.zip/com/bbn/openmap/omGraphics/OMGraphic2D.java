/* **********************************************************************
 * 
 *  BBNT Solutions LLC, A part of GTE
 *  10 Moulton St.
 *  Cambridge, MA 02138
 *  (617) 873-2000
 * 
 *  Copyright (C) 1998-2000
 *  This software is subject to copyright protection under the laws of 
 *  the United States and other countries.
 * 
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/omGraphics/OMGraphic2D.java,v $
 * $Revision: 1.3 $
 * $Date: 2000/05/08 14:23:15 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.omGraphics;

/**
 * This interface describes the additional methods that OMGraphics
 * the utilize the java 2D interface should implement.  <br>
 */
public interface OMGraphic2D {
  
    /**
     * Set the line width of a vector graphic
     * @param value width.
     */
    public void setLineWidth(float value);

    /** 
     * Set the stroke of the graphic.
     * @param stroke the stroke object to use.
     */
    public void setStroke(java.awt.Stroke stroke);
    
    /**
     * Set the Paint object that is used to fill the object.
     */
    public void setPaint(java.awt.Paint paint);
}

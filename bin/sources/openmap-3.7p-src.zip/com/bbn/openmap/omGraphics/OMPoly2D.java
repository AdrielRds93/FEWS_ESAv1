/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998-2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/omGraphics/OMPoly2D.java,v $
 * $Revision: 1.10 $
 * $Date: 2000/08/02 14:25:38 $
 * $Author: dietrick $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.omGraphics;

import java.awt.*;

import com.bbn.openmap.MoreMath;
import com.bbn.openmap.util.Debug;
import com.bbn.openmap.LatLonPoint;
import com.bbn.openmap.proj.*;

/**
 * Poly object which takes advantage of the Java2D API.
 * This class requires the Java 2 platform.
 */
public class OMPoly2D extends OMPoly implements OMGraphic2D {

    /**
     * The Java2D Stroke.
     * This is used for lineWidth.
     */
    protected Stroke stroke = new BasicStroke(lineWidth);

    /**
     * The Java2D Paint.  This is used for filled graphics.  
     */
    protected Paint paint = null;

    /**
     * Construct a default OMPoly2D.
     */
    public OMPoly2D () {
	super();
    }

    /**
     * Create an OMPoly2D from a list of double lat/lon pairs.
     * <p>
     * NOTES:
     * <ul>
     * <li>llPoints array is converted into radians IN PLACE for more
     * efficient handling internally if it's not already in radians!
     * For even better performance, you should send us an array
     * already in radians format!
     * <li>If you want the poly to be connected (as a polygon), you
     * need to ensure that the first and last coordinate pairs are the
     * same.
     * </ul>
     * @param llPoints array of lat/lon points, arranged lat, lon,
     * lat, lon, etc.
     * @param units radians or decimal degrees.  Use OMGraphic.RADIANS
     * or OMGraphic.DECIMAL_DEGREES
     * @param lType line type, from a list defined in OMGraphic.
     */
    public OMPoly2D (double[] llPoints, int units, int lType) {
	super(llPoints, units, lType);
    }

    /**
     * Create an OMPoly2D from a list of double lat/lon pairs.
     * <p>
     * NOTES:
     * <ul>
     * <li>llPoints array is converted into radians IN PLACE for more
     * efficient handling internally if it's not already in radians!
     * For even better performance, you should send us an array
     * already in radians format!
     * <li>If you want the poly to be connected (as a polygon), you
     * need to ensure that the first and last coordinate pairs are the
     * same.
     * </ul>
     * @param llPoints array of lat/lon points, arranged lat, lon,
     * lat, lon, etc.
     * @param units radians or decimal degrees.  Use OMGraphic.RADIANS
     * or OMGraphic.DECIMAL_DEGREES
     * @param lType line type, from a list defined in OMGraphic.
     * @param nsegs number of segment points (only for
     * LINETYPE_GREATCIRCLE or LINETYPE_RHUMB line types, and if &lt;
     * 1, this value is generated internally)
     */
    public OMPoly2D (double[] llPoints, int units, int lType, int nsegs) {
	super(llPoints, units, lType, nsegs);
    }
    
    /**
     * Create an OMPoly2D from a list of xy pairs.
     * If you want the poly to be connected, you need to ensure that
     * the first and last coordinate pairs are the same.
     * @param xypoints array of x/y points, arranged x, y, x, y, etc.
     */
    public OMPoly2D (int[] xypoints) {
	super(xypoints);
    }

    /**
     * Create an x/y OMPoly2D.
     * If you want the poly to be connected, you need to ensure that
     * the first and last coordinate pairs are the same.
     * @param xPoints int[] of x coordinates
     * @param yPoints int[] of y coordinates
     */
    public OMPoly2D (int[] xPoints, int[] yPoints) {
	super(xPoints, yPoints);
    }

    /**
     * Create an x/y OMPoly2D at an offset from lat/lon.
     * If you want the poly to be connected, you need to ensure that
     * the first and last coordinate pairs are the same.
     * @param latPoint latitude in decimal degrees
     * @param lonPoint longitude in decimal degrees
     * @param xypoints int[] of x,y pairs
     * @param cmode offset coordinate mode
     */
    public OMPoly2D (double latPoint, double lonPoint,
		     int[] xypoints, int cMode) {
	super(latPoint, lonPoint, xypoints, cMode);
    }

    /**
     * Create an x/y OMPoly2D at an offset from lat/lon.
     * If you want the poly to be connected, you need to ensure that
     * the first and last coordinate pairs are the same.
     * @param latPoint latitude in decimal degrees
     * @param lonPoint longitude in decimal degrees
     * @param xPoints int[] of x coordinates
     * @param yPoints int[] of y coordinates
     * @param cmode offset coordinate mode
     */
    public OMPoly2D (double latPoint, double lonPoint,
		     int[] xPoints, int[] yPoints, 
		     int cMode) {
	super(latPoint, lonPoint, xPoints, yPoints, cMode);
    }

    /**
     * Set the line width to a value between 1 and 10 pixels.
     * Anything outside of these bounds gets set to 1. 
     */
    public void setLineWidth (float w) {
	super.setLineWidth(w);
	stroke = new BasicStroke(getLineWidth());
    }

    /**
     * Set the stroke for the graphic.  Also sets the line width of
     * the graphics from the setting in the Stroke object, if it's a
     * BasicStroke.
     */
    public void setStroke(java.awt.Stroke st){
	if (st == null){
	    if (stroke == null){
		stroke = new BasicStroke();
	    }
	} else {
	    stroke = st;
	}

	if (stroke instanceof BasicStroke){
	    super.setLineWidth(((BasicStroke)stroke).getLineWidth());
	}
    }

    /**
     * Set the Paint object used to fill the rectangle
     */
    public void setPaint(java.awt.Paint paint) {
	if (paint != null){
	    isPolygon = true;
	} else {
	    isPolygon = false;
	}

	// The line color and fill color could be the same here, but
	// then, why not use the setFillColor if the paint is just a
	// color?  Assume they will be different.
	isSameColor = false;
        this.paint = paint;
    }

    /**
     * The call to set the Graphics object to handle the Paint that
     * may be contained in the 2D poly.  It's assumed that this is
     * getting called after it's been established that the Poly should
     * be a polygon (not a polyline) and that it should be filled.
     * Therefore, there ought to be either a Paint object or a fill
     * color.  
     * @param g a java.awt.Graphics object to set.
     * @return true if all's well, false if something isn't quite
     * right and the graphics shouldn't be filled.  
     */
    public boolean setPaint(Graphics g){

	//Because it might not be...
	if (g instanceof Graphics2D) {
	    // This is the basic case - the graphics can handle
	    // anything, and either the paint or the fill color should
	    // be set.
	    if (paint != null){
		((Graphics2D)g).setPaint(paint);
	    } else {
		g.setColor(getFillColor());
	    }
	    return true;
	} 
	// Now, things can go a little wacky.  Why a non-graphics 2d
	// whould be here, I don't know.  But let's try to handle it properly.
	else if (isPolygon && !isClear(fillColor)){
	    //  Checking to see at least if the fill color is set so
	    //  that it can be handled by a 1d Graphics object.
	    g.setColor(getFillColor());
	    return true;
	}

	//  Well, if we get here, it means that we had a paint object,
	//  and received a regular Graphics object (not a Graphics2D),
	//  and the fillColor wasn't set to something we could use.
	//  So bail on drawing a fill.
	return false;	  
    }

    /**
     * Prepare the poly for rendering.
     * @param proj Projection
     * @return true if generate was successful
     */
    public boolean generate (Projection proj) {
	return super.generate(proj);
    }

    /**
     * Paint the poly. 
     * This works if generate() has been successful.
     * @param g java.awt.Graphics to paint the poly onto.
     */
    public void render (Graphics g) {

	if (g instanceof Graphics2D){
	    Graphics2D g2d = ((Graphics2D)g);
	    Stroke oldstroke = g2d.getStroke();
	    g2d.setStroke(stroke);
	    super.render(g);
	    g2d.setStroke(oldstroke);
	} else {
	    super.render(g);
	}
    }

    /**
     * Return the shortest distance from the graphic to an XY-point.
     * This works if generate() has been successful.
     * @param x horizontal pixel location.
     * @param y vertical pixel location.
     * @return the distance of the object to the location given.
     */
    public double distance (int x, int y) {
	double d = super.distance(x,y);
	if (lineWidth <= 1)
	    return d;
	// extra calculation for lineWidth
	d -= lineWidth/2;
	return (d < 0d) ? 0d : d;
    }
}

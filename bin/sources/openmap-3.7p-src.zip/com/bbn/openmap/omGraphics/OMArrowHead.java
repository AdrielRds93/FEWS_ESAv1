/* **********************************************************************
 * 
 *  BBNT Solutions LLC, A part of GTE
 *  10 Moulton St.
 *  Cambridge, MA 02138
 *  (617) 873-2000
 * 
 *  Copyright (C) 1998, 2000
 *  This software is subject to copyright protection under the laws of 
 *  the United States and other countries.
 * 
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/omGraphics/OMArrowHead.java,v $
 * $Revision: 1.4 $
 * $Date: 2000/05/08 14:23:14 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.omGraphics;

import java.awt.Point;
import java.awt.Graphics;


/**
 * Basic implementation of arrowhead graphics.
 */
public class OMArrowHead{

    protected int[] xpts = null;
    protected int[] ypts = null;

    public static final int ARROWHEAD_DIRECTION_FORWARD = 0;
    public static final int ARROWHEAD_DIRECTION_BACKWARD = 1;
    public static final int ARROWHEAD_DIRECTION_BOTH = 2;

    /**
     * Create an arrowhead.
     * @param from Point
     * @param to Point
     */
    public OMArrowHead(Point from, Point to){
	int dx = to.x - from.x;
	int dy = to.y - from.y;
	int dd = Dist(dx, dy);
	if (dd < 6) dd = 6;
	int l = 3/* * (lineWidth + 1) / 2*/;
	int l2 = 9/* * (lineWidth + 1) / 2*/;
	xpts = new int[3];
	ypts = new int[3];
	xpts[0] = to.x + (dy * ( l) - dx * l2) / dd;
	ypts[0] = to.y + (dx * (-l) - dy * l2) / dd;
	xpts[1] = to.x;
	ypts[1] = to.y;
	xpts[2] = to.x + (dy * (-l) - dx * l2) / dd;
	ypts[2] = to.y + (dx * ( l) - dy * l2) / dd;
    }
    
    /**
     * Draw the arrowheads.
     * @param gr Graphics
     */
    public void draw(Graphics gr){
	if (xpts != null)
	    gr.fillPolygon(xpts, ypts, xpts.length);
    }

    /**
     * A simple function to figure out the distance between
     * pixels, based on differences in the x and y directions. 
     * @param dx difference in x direction, in pixels.
     * @param dy difference in y direction, in pixels. 
     */ 
    public static int Dist(int dx, int dy){
	if (dx < 0)
	    dx = -dx;
	if (dy < 0)
	    dy = -dy;
	int dd = dx + dy;
	if (dd == 0)
	    return 0;
	return (int)(dd - (1.145 * dx) * dy / dd);
    }
}

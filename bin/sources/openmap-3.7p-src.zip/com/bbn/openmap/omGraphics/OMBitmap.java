/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			  BBNT Solutions LLC
 * 			    A Part of GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/omGraphics/OMBitmap.java,v $
 * $Revision: 1.23 $
 * $Date: 2000/07/05 16:49:04 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.omGraphics;

import java.awt.Point;
import java.awt.Color;
import java.awt.Toolkit;
import java.awt.image.MemoryImageSource;
import java.io.Serializable;
import com.bbn.openmap.proj.Projection;
import com.bbn.openmap.util.Debug;

/** The OMBitmap lets you create a two color image.  The display color
 * is the foreground color, and the fill color is the background
 * color.  OMColors can be used, and their transparency values will be
 * implemented.<p> The array of bytes is used to create the picture.
 * Each bit, representing a pixel, is examined, and the color is set
 * to the display or fill color, depending on the bit value.
 *
 * There is the ability to add a filter to the OMBitmap, to change it's
 * appearance for rendering.  The most common filter, which is
 * included as a kind of default, is the scale filter.  Filtering the
 * OMRasterObject replaces the bitmap variable, which is the internal
 * java.awt.Image used for rendering.
 */

public class OMBitmap extends OMRasterObject implements Serializable {

  /** Create empty, and add parameters later. */
    public OMBitmap(){
        super(RENDERTYPE_UNKNOWN, LINETYPE_UNKNOWN, DECLUTTERTYPE_NONE);
    }
  
  /** Created a OMBitmap with a Lat/lon placement. 
   *
   * @param lt latitude of upper left corner of bitmap.
   * @param ln longitude of upper left corner of bitmap.
   * @param w width of bitmap.
   * @param h height of bitmap.
   * @param bytes byte array of bitmap, each bit representing a pixel.
   * */
    public OMBitmap(double lt, double ln, int w, int h,
		    byte[] bytes)
    {
        super(RENDERTYPE_LATLON, LINETYPE_UNKNOWN, DECLUTTERTYPE_NONE);
	lat = lt;
	lon = ln;
	width = w;
	height = h;
	bits = bytes;
    }

  /** Create an OMBitmap with a X/Y window placement.
   *
   * @param x1 window pixel x location of upper left corner of bitmap.
   * @param y1 window pixel y location of upper left corner of bitmap.
   * @param w width of bitmap.
   * @param h height of bitmap.
   * @param bytes byte array of bitmap, each bit representing a pixel.
   * */
    public OMBitmap(int x1, int y1, int w, int h,
		    byte[] bytes)
    {
        super(RENDERTYPE_XY, LINETYPE_UNKNOWN, DECLUTTERTYPE_NONE);
        x = x1;
	y = y1;
	width = w;
	height = h;
	bits = bytes;
    }

  /** Create an OMBitmap, located at a Lat/lon with a X/Y offset
   * placement.
   *
   * @param lt latitude of upper left corner of bitmap.
   * @param ln longitude of upper left corner of bitmap.
   * @param offset_x1 window pixel x location from ln of upper left
   * corner of bitmap.
   * @param offset_y1 window pixel y location from lt of upper left
   * corner of bitmap.
   * @param w width of bitmap.
   * @param h height of bitmap.
   * @param bytes byte array of bitmap, each bit representing a pixel.
   * */
    public OMBitmap(double lt, double ln, int offset_x1, int offset_y1,
		    int w, int h, byte[] bytes)
    {
        super(RENDERTYPE_OFFSET, LINETYPE_UNKNOWN, DECLUTTERTYPE_NONE);

	lat = lt;
	lon = ln;
        x = offset_x1;
	y = offset_y1;
	width = w;
	height = h;
	bits = bytes;
    }

    /**  Create the image pixels from the display color
     * and the fill color values, and the bitmap bytes.  All of these
     * attributes should have been filled in.  
     * @return true if the pixels were successfully created.  
     * */
    protected boolean computePixels() {
	int foreground, background;
	int nColors = 2;
	int npix, i, j, k, w;
	int[] masks = {1, 2, 4, 8, 16, 32, 64, 128};
      
	int nPixels = width * height;
	if (bits == null || (bits.length * 8) < nPixels) {
	    System.err.println("OMBitmap.computePixels(): not enough bits!");
	    return false;
	}
      
	pixels = new int[nPixels];

	// Init colors.
	
	foreground = getDisplayColor().getRGB();
	background = getFillColor().getRGB();

	int defaultColor = 128 << 24;

	// Now, using the foreground and background colors, build a set of
	// pixels by traversing bitwise through the bitmap data.

	// Determine the excess number of bits at the end of each row.
	int excess = width % 8; // Remainder

        // And how many bytes will be used represent each row?
	int bytes_per_row = width / 8;
	if (excess > 0) {
	    Debug.message("omGraphics", "OMBitmap.computePixels(): excess byte");
	    bytes_per_row++;
	}

	Debug.message("omGraphics", "OMBitmap.computePixels(): bits.length = " +
		      bits.length);
	for (npix=0,i=0; i<height; i++) {		// for each row
	    for (j=0,w=0; j<bytes_per_row; j++) {	// for each row's byte
		int idx = (i*bytes_per_row) + j;
		for (k=0;				// for each byte's bits
		     (k<8) &				// bits per byte 
			 (w<width) &		// bits per row
			 (npix<nPixels);		// bits per bitmap
		     k++, w++, npix++)
		{
		    int set = masks[k] & bits[idx];
		    if (set > 0) {
			pixels[npix] = foreground;
		    } else {
			pixels[npix] = background;
		    }
		}
	    }
	}

	if (npix < nPixels-1) {
	    for (i=npix; i<nPixels; i++) {
		pixels[i] = defaultColor;
	    }
	}
	return true;
    }

    /** Create the rendered image from the pixel values. 
     *
     * @return true if the OMBitmap has enough information and
     * generates the rendered image successfully.  
     */
    public boolean generate (Projection proj) {

	// Position() sets the bitmap location on the screen!!!!
	if(!position(proj)){
	    Debug.message("omGraphics", "OMBitmap: positioning failed in generate!");
	    return false;
	}

	if (!getNeedToRegenerate() && bitmap != null){
	    if (imageFilter != null){
		bitmap = filterImage();
	    }

	    setNeedToRegenerate(false);
	    return true;
	}

	computePixels();

	Toolkit tk = Toolkit.getDefaultToolkit();
	bitmap = tk.createImage(
	    new MemoryImageSource(width, height, pixels, 0, width));

	if (imageFilter != null){
	    bitmap = filterImage();
	}

	setNeedToRegenerate(false);
	return true;
    }

    /** This sets the bitmap to recompute the pixels if the foreground
     * color is changed.
     *
     * @param value the new line color.
     **/
    public void setLineColor(Color value){ 
	super.setLineColor(value);
	if (!selected) setNeedToRegenerate(true);
    }

    /** This sets the bitmap to recompute the pixels if the foreground
     * color is changed.
     *
     * @param value the new select color.
     **/
    public void setSelectColor(Color value){ 
	super.setSelectColor(value);
	if (selected) setNeedToRegenerate(true);
    }

    /** This sets the bitmap to recompute the pixels if the background
     * color is changed.
     *
     * @param value the new background color
     **/
    public void setFillColor(Color value){ 
	super.setFillColor(value);
	setNeedToRegenerate(true);
    }

    /**
     * Set the selected attribute to true, and sets the color to the
     * select color.  
     */
    public void select(){
	super.select();
	setNeedToRegenerate(true); 
    }

    /**
     * Set the selected attribute to false, sets the color to the
     * line color.  
     */
    public void deselect(){
	super.deselect();
	setNeedToRegenerate(true);
    }
}

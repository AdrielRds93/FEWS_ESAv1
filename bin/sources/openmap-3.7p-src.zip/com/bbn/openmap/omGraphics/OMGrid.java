/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			  BBNT Solutions LLC
 * 			    A Part of GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998-2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/omGraphics/OMGrid.java,v $
 * $Revision: 1.7 $
 * $Date: 2000/07/05 16:49:04 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.omGraphics;

import com.bbn.openmap.omGraphics.grid.OMGridGenerator;
import com.bbn.openmap.omGraphics.grid.OMGridObjects;
import com.bbn.openmap.proj.Projection;
import com.bbn.openmap.util.Debug;

import java.awt.Graphics;
import java.awt.Point;

/** An OMGrid object is a two-dimensional container object for
 *  data. The grid can be laid out in geographic or pixel space. There
 *  are two different ways that the OMGrid can be used. <P> The data
 *  placed in the array can represent the attributes of what you want
 *  the grid to represent - elevation values, temperatures, etc.  In
 *  order to render the data on the screen, you'll need to set the
 *  OMGridGenerator object, and let it interpret the data to create
 *  the desired OMGraphics for you. <P> The OMGrid data values can
 *  also contain integer ID keys for objects contained in the
 *  OMGridObjects object held by the OMGrid.  By using the OMGrid in
 *  this way, the OMGrid becomes a placeholder for other graphics, and
 *  will manage the generate() function calls to those objects that
 *  are on the screen. <P>The OMGridGenerator object will take
 *  precidence over the OMGridObjects - If the OMGridGenerator is set
 *  within the grid, the OMGridGenerator will create the OMGpahics to
 *  be displayed for the gird, as opposed the OMGridObjects getting a
 *  chance to generate thenselves.  
 */

public class OMGrid extends OMGraphic{

    /** The orientation angle of the grid, in radians. Up/North is
     *  zero. */
    public double orientation;
    /** Number of rows in the data array. */
    public int rows;
    /** Number of columns in the data array. */
    public int columns; 
    /** The starting latitude point of the grid.  Only relevant when
     *  the data points are laid out in a lat/lon grid, or when an x/y
     *  grid is anchored to a lat/lon location. DOES NOT follow the
     *  OpenMap convention where area object locations are defined by
     *  the upper left location - the location of the grid is noted by
     *  the lower left corner, because grid data is usually defined by
     *  the lower left location.  Make it easier to deal with overlap
     *  rows and columns, and to calculate the locations of the rows
     *  and columns.*/
    public double latitude;
    /** The starting longitude point of the grid.  Only relevant when
     *  the data points are laid out in a lat/lon grid, or when an x/y
     *  grid is anchored to a lat/lon location.  DOES NOT follow the
     *  OpenMap convention where area object locations are defined by
     *  the upper left location - the location of the grid is noted by
     *  the lower left corner, because grid data is usually defined by
     *  the lower left location.  Make it easier to deal with overlap
     *  rows and columns, and to calculate the locations of the rows
     *  and columns.*/
    public double longitude;
    /** The vertical/latitude interval, i.e. the distance between row data
     *  points in the vertical direction. For x/y grids, this can
     *  server as a pixel mulitplier.  For lat/lon grids, it
     *  represents the decimal degrees between grid points. */
    public double verticalResolution;
    /** The horizontal/longitude interval, i.e. the distance between
     *  column data points in the horizontal direction. For x/y grids, this
     *  can server as a pixel mulitplier.  For lat/lon grids, it
     *  represents the decimal degrees between grid points. */
    public double horizontalResolution;
    /** The array of data. */
    public int[][] data;
    /** If needed, the data array can hold numerical identifiers,
     *  which are keys to objects stored in this hashtable. That way,
     *  the grid can be used to hold an array of objects. If the objs
     *  are set, then the OMGrid object automatically assumes that all
     *  graphic operations are supposed to involve the objs.*/
    protected OMGridObjects gridObjects = null; 
    /** Horizontal screen location of the upper left corner of the
     *  grid in pixels, before projection, of XY and OFFSET grids.  */
    public Point point = null;
    /** Horizontal screen location of the upper left corner of the
     *  grid in pixels, after projection.  */
    public Point point1 = null;
   /** Horizontal screen location of the lower right corner of the
     *  grid in pixels, after projection.  */
    public Point point2 = null;
    /** Pixel height of grid, set after generate. */
    public int height = 0;
    /** Pixel width of grid, set after generate. */
    public int width = 0;

    /** Value of a bad/invalid point in the grid. Has roots in the
     *  DTED way of doing things.*/
    public final static int GRID_NULL = -32767;

    /** An object that knows how to generate graphics for the matrix. */
    protected OMGridGenerator generator = null;
    /** How the grid should be drawn on the screen. */
    protected OMGraphic graphic = null;
    /** Means that the first dimension of the array refers to the column count. */
    public static final boolean COLUMN_MAJOR = true;
    /** Means that the first dimension of the array refers to the row count. */
    public static final boolean ROW_MAJOR = false;
    /** Keep track of which dimension different parts of the double array represent. */
    public boolean major = COLUMN_MAJOR;

    /** Default constructor. */    
    public OMGrid(){
        super(RENDERTYPE_UNKNOWN, LINETYPE_UNKNOWN, DECLUTTERTYPE_NONE);
    }

    /**
     * Create a OMGrid that covers a lat/lon area.
     *
     * @param lat latitude of lower left corner of the grid, in
     * decimal degrees.
     * @param lon longitude of lower left corner of the grid, in
     * decimal degrees.
     * @param vResolution the vertical resolution of the data, as
     * decimal degrees per row.
     * @param hResolution the horizontal resolution of the data, as
     * decimal degrees per column.
     * @param data a double array of integers, representing the rows
     * and columns of data.
     */
    public OMGrid (double lat, double lon,
		   double vResolution, double hResolution,
		   int [][] data){
	super(RENDERTYPE_LATLON, LINETYPE_UNKNOWN, DECLUTTERTYPE_NONE);
	set(lat, lon, 0, 0, vResolution, hResolution, data);
    }

    /**
     * Create a OMGrid that covers a x/y screen area.
     *
     * @param x horizontal location, in pixels, of the left side of
     * the grid from the left side of the map.  .
     * @param y vertical location, in pixels, of the top of the grid
     * from the top side of the map.
     * @param vResolution the vertical resolution of the data, as
     * pixels per row.
     * @param vResolution the horizontal resolution of the data, as
     * pixels per column.
     * @param data a double array of integers, representing the rows
     * and columns of data.  
     */
    public OMGrid (int x, int y,
		   double vResolution, double hResolution,
		   int [][] data){
	super(RENDERTYPE_XY, LINETYPE_UNKNOWN, DECLUTTERTYPE_NONE);
	set(0.0d, 0.0d, x, y, vResolution, hResolution, data);
    }

    /**
     * Create a OMGrid that covers a x/y screen area, anchored to a
     * lat/lon point.
     *
     * @param lat latitude of the anchor point of the grid, in
     * decimal degrees.
     * @param lon longitude of the anchor point of the grid, in
     * decimal degrees.
     * @param x horizontal location, in pixels, of the left side of
     * the grid from the longitude anchor point.  .
     * @param y vertical location, in pixels, of the top of the grid
     * from the latitude anchor point.
     * @param vResolution the vertical resolution of the data, as
     * pixels per row.
     * @param vResolution the horizontal resolution of the data, as
     * pixels per column.
     * @param data a double array of integers, representing the rows
     * and columns of data.  
     */
    public OMGrid (double lat, double lon, int x, int y,
		   double vResolution, double hResolution,
		   int [][] data){
	super(RENDERTYPE_OFFSET, LINETYPE_UNKNOWN, DECLUTTERTYPE_NONE);
	set(lat, lon, x, y,
	    vResolution, hResolution, data);
    }

    protected void set(double lat, double lon, int x, int y,
		       double vResolution, double hResolution,
		       int [][] data){
	latitude = lat;
	longitude = lon;
	point = new Point(x, y);
	verticalResolution = vResolution;
	horizontalResolution = hResolution;
	this.data = data;
	if (data != null){
	    this.columns = data.length;
	    this.rows = data[0].length;
	}
    }

    public void setRows(int rows){
	this.rows = rows;
    }

    public int getRows(){
	return rows;
    }

    public void setColumns(int columns){
	this.columns = columns;
    }

    public int getColumns(){
	return columns;
    }

    public void setMajor(boolean maj){
	major = maj;
    }

    public boolean getMajor(){
	return major;
    }

    public void setOrientation(double orient){
	orientation = orient;
    }

    public double getOrientation(){
	return orientation;
    }

    public void setData(int[][] data){
	this.data = data;
    }

    public int[][] getData(){
	return data;
    }

    public void setGridObjects(OMGridObjects someGridObjs){
	gridObjects = someGridObjs;
    }
    
    public OMGridObjects getGridObjects(){
	return gridObjects;
    }

    public void setGenerator(OMGridGenerator aGenerator){
	generator = aGenerator;
    }
    
    public OMGridGenerator getGenerator(){
	return generator;
    }

    public void setVerticalResolution(double vRes){
	verticalResolution = vRes;
    }

    public double getVerticalResolution(){
	return verticalResolution;
    }

    public void setHorizontalResolution(double hRes){
	horizontalResolution = hRes;
    }

    public double getHorizontalResolution(){
	return horizontalResolution;
    }

    /**
     */
    public synchronized boolean generate (Projection proj){

	double upLat;
	/** Let's figure out the dimensions and location of the grid,
            relative to the screen. */
	if (renderType == RENDERTYPE_LATLON){
	    /** Means that the latitudeResolution and
                horizontalResolution refer to degrees/datapoint. */
	    double rightLon;

	    rightLon = longitude + columns * horizontalResolution;
	    upLat = latitude + rows * verticalResolution;

	    point1 = proj.forward(upLat, longitude);
	    point2 = proj.forward(latitude, rightLon);

	    /** For later... */
	    height = point2.y - point1.y;
	    width = point2.x - point1.x;

	} else if (renderType == RENDERTYPE_XY || 
		   renderType == RENDERTYPE_OFFSET){

	    width = (int) Math.round((double)columns * horizontalResolution);
	    height = (int) Math.round((double)rows * verticalResolution);

	    if (renderType == RENDERTYPE_OFFSET){
		upLat = latitude + columns * verticalResolution;
		point1 = proj.forward(upLat, longitude);
		point1.x += point.x;
		point1.y += point.y;
	    } else {
		point1 = point;
	    }

	    point2 = new Point(point1.x + width, point1.y + height);
	} else {
	    return false;
	}
	
	Debug.message("omGraphics", "OMGrid. generated grid, at " + point1 + 
		      " and " + point2 + " with height " + height + 
		      " and width " + width);

	/** Now generate the grid in the desired way...*/
	if (generator != null){
	    graphic = generator.generate(this, proj);
	} else if (gridObjects != null){
	    graphic = generateGridObjects(proj);
	} else {
	    Debug.message("grid", 
			  "OMGrid: Nothing to use to generate a graphic.");
	}

	setNeedToRegenerate(false);

	if (graphic == null){
	    return true;
	}
	else return false;
    }

    /**
     */
    public void render (Graphics g){
	if (generator != null){
	    if (needToRegenerate && generator.needGenerateToRender()){
		Debug.message("omGraphics", "OMGrid: need to generate!");
		return;
	    } 
	}

	if (graphic != null){
	    Debug.message("omGraphics", "OMGrid: rendering...");
	    graphic.render(g);
	} else {
	    Debug.message("omGraphics", "OMGrid: nothing to render...");
	}
    }

    /**
     * Return the shortest distance from the graphic to an XY-point.
     * @param x X coordinate of the point.
     * @param y Y coordinate fo the point.
     * @return double distance from graphic to the point
     */
    public double distance (int x, int y){
	double distance = Double.POSITIVE_INFINITY;

	if (getNeedToRegenerate()) {
	    Debug.message("omGraphics", 
			  "OMRasterObject.distance(): not projected!");
	    return distance;
	}

	if (point1 == null || point2 == null){
	    System.err.println("OMGrid.distance(): invalid Grid location");
	    return distance;
	}

	if ((x >= point1.x && x <= point2.x) &&
	    (y >= point1.y && y <= point2.y))
	{
	    // The point is within my boundaries.
	    distance = 0d;
	} else {
	    // The point is outside my boundaries. Don't calculate the
	    // hypotenuse distance since precision doesn't matter much
	    distance = Math.max(Math.max(point1.x - x, x - point2.x),
				Math.max(point1.y - y, y - point2.y));
	}
	return distance;
    }

    public OMGraphic generateGridObjects(Projection proj){
	OMGraphicList graphiclist = new OMGraphicList();

	/** There could be some way to optimize the search for objects
            in the grid that are actually visible, but that would
            require knowledge of the specifices of projections.
            Keeping this as generic as possible at this point. */

	Point pt = new Point();

	for (int x = 0; x < data.length; x++){
	    for (int y = 0; y < data[0].length; y++){

		// First, calculate if the grid post is even on the map
		if (major == COLUMN_MAJOR){
		    if (renderType == RENDERTYPE_LATLON){
			pt = proj.forward(latitude + y*verticalResolution,
					  longitude + x*horizontalResolution, pt);
		    } else {
			pt.y = point1.y + (int)(y*verticalResolution);
			pt.x = point1.x + (int)(x*horizontalResolution);
		    }
		} else {
		    if (renderType == RENDERTYPE_LATLON){
			pt = proj.forward(latitude + x*verticalResolution,
					  longitude + y*horizontalResolution, pt);
		    } else {
			pt.y = point1.y + (int)(x*verticalResolution);
			pt.x = point1.x + (int)(y*horizontalResolution);
		    }
		}

		if ((pt.x >= 0 || pt.x <= proj.getWidth()) &&
		    (pt.y >= 0 || pt.y <= proj.getHeight())){
		    // It's on the map!  Get a graphic from it!
		    graphiclist.add(gridObjects.generate(data[x][y], proj));
		}
	    }
	}

	return graphiclist;
    }

    /**
     * The value at the closest SW post to the given
     * lat/lon. This is just a go-to-the-closest-post solution.
     *
     * @param lat latitude in decimal degrees.
     * @param lon longitude in decimal degrees.
     * @param proj map projection, which is needed for XY or OFFSET grids.
     * @return value found at the nearest grid point.
     */
    public int valueAt(double lat, double lon, Projection proj){

	int lat_index = -1;
	int lon_index = -1;

	if (renderType == RENDERTYPE_LATLON){
	
	    lat_index = (int) Math.round((lat - latitude)/verticalResolution);
	    lon_index = (int) Math.round((lon - longitude)/horizontalResolution);
	    
	} else if (renderType == RENDERTYPE_XY ||
		   renderType == RENDERTYPE_OFFSET){
	    if (getNeedToRegenerate()){
		/** Only care about this if we need to...*/
		if (proj == null){
		    return GRID_NULL;
		}
		generate(proj);
	    }
	    
	    Point pt = proj.forward(lat, lon);
	    
	    lat_index = (int) Math.round((pt.y - point1.y)/verticalResolution);
	    lon_index = (int) Math.round((pt.x - point1.x)/horizontalResolution);
	}

	if ((lat_index >= 0 || lat_index < rows) && 
	    (lon_index >= 0 || lon_index < columns)){
	    if (major == COLUMN_MAJOR){
		return data[lon_index][lat_index];
	    } else {
		return data[lat_index][lon_index];
	    }
	} else {
	    return GRID_NULL;  // Considered a null value
	}
    }

    /** 
     * Interpolated value at a given lat/lon - should be more
     * precise than valueAt(), but that depends on the resolution
     * of the data.  
     * 
     * @param lat latitude in decimal degrees.
     * @param lon longitude in decimal degrees.
     * @param proj map projection, which is needed for XY or OFFSET grids.
     * @return value at lat/lon.
     */
    public int interpValueAt(double lat, double lon, Projection proj){
	double lat_index = -1;
	double lon_index = -1;

	if (renderType == RENDERTYPE_LATLON){
	
	    lat_index = (lat - latitude)/verticalResolution;
	    lon_index = (lon - longitude)/horizontalResolution;
	    
	} else if (renderType == RENDERTYPE_XY ||
		   renderType == RENDERTYPE_OFFSET){
	    if (getNeedToRegenerate()){
		/** Only care about this if we need to...*/
		if (proj == null){
		    return GRID_NULL;
		}
		generate(proj);
	    }
	    
	    Point pt = proj.forward(lat, lon);
	    
	    lat_index = (pt.y - point1.y)/verticalResolution;
	    lon_index = (pt.x - point1.x)/horizontalResolution;
	}

	if ((lat_index >= 0 || lat_index < rows) && 
	    (lon_index >= 0 || lon_index < columns)){	    

	    int lflon_index = (int)Math.floor(lon_index);
	    int lclon_index = (int)Math.ceil(lon_index);
	    int lflat_index = (int)Math.floor(lat_index);
	    int lclat_index = (int)Math.ceil(lat_index);
	
	    
	    //////////////////////////////////////////////////////
	    // Print out grid of 20x20 elevations with
	    // the "asked for" point being in the middle
	    if (Debug.debugging("grid")){
		System.out.println("***Elevation Map***");
		for(int l = lclat_index + 5; l > lflat_index - 5; l--){
		    System.out.println();
		    for(int k = lflon_index - 5; k < lclon_index + 5; k++){
			if ((l >= 0 || l < rows) && 
			    (k >= 0 || k < columns)){	    
			    if (major == COLUMN_MAJOR){
				System.out.print(data[k][l] + " ");
			    } else {
				System.out.print(data[l][k] + " ");
			    }				
			}
		    }
		}
		System.out.println();System.out.println();
	    }
	    //////////////////////////////////////////////////////

	    int ul, ur, ll, lr;

	    if (major == COLUMN_MAJOR){
		ul = data[lflon_index][lclat_index];
		ur = data[lclon_index][lclat_index];
		ll = data[lflon_index][lclat_index];
		lr = data[lclon_index][lclat_index];
	    } else {
		ul = data[lclat_index][lflon_index];
		ur = data[lclat_index][lclon_index];
		ll = data[lclat_index][lflon_index];
		lr = data[lclat_index][lclon_index];
	    }

	    double answer = resolve_four_points(ul, ur, lr, ll,
					       lat_index, lon_index);
	    return (int) Math.round(answer);
	}

       return GRID_NULL;  // Considered a null value
    }

   /** A try at interoplating the corners of the surrounding posts,
     *	given a lat lon.  Called from a function where the data for
     *	the lon has been read in.
     */
    private double resolve_four_points(int ul, int ur, int lr, int ll,
 				      double lat_index, double lon_index){
        double top_avg =
	  ((lon_index - new Double(Math.floor(lon_index)).floatValue()) * 
	   (double)(ur - ul)) + ul;
	double bottom_avg =
	  ((lon_index - new Double(Math.floor(lon_index)).floatValue()) * 
	   (double)(lr - ll)) + ll;
	double right_avg =
	  ((lat_index - new Double(Math.floor(lat_index)).floatValue()) * 
	   (double)(ur - lr)) + lr;
	double left_avg =
	  ((lat_index - new Double(Math.floor(lat_index)).floatValue()) * 
	   (double)(ul - ll))/100.0d + ll;
	
	double lon_avg =
	  ((lat_index - new Double(Math.floor(lat_index)).floatValue()) *
	   (top_avg - bottom_avg)) + bottom_avg;
	double lat_avg =
	  ((lon_index - new Double(Math.floor(lon_index)).floatValue()) *
	   (right_avg - left_avg)) + left_avg;
	
	double result = (lon_avg + lat_avg) / 2.0d;
	return result;
    }


}

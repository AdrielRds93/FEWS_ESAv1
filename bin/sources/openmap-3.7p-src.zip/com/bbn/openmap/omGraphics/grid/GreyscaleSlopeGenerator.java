/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998, 2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/omGraphics/grid/GreyscaleSlopeGenerator.java,v $
 * $Revision: 1.2 $
 * $Date: 2000/05/08 14:23:18 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */
package com.bbn.openmap.omGraphics.grid;

import com.bbn.openmap.omGraphics.*;
import com.bbn.openmap.proj.Projection;
import java.awt.Graphics;

public class GreyscaleSlopeGenerator {
    
    public OMGraphic generate(OMGrid grid, Projection proj){
	return null;
    }

    public boolean needGenerateToRender(){
	return true;
    }
}


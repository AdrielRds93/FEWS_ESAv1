/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			  BBNT Solutions LLC
 * 			    A Part of GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998-2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/omGraphics/OMCircle.java,v $
 * $Revision: 1.32 $
 * $Date: 2000/07/05 16:49:04 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.omGraphics;

import java.awt.*;
import java.util.Vector;
import java.io.Serializable;
import com.bbn.openmap.LatLonPoint;
import com.bbn.openmap.MoreMath;
import com.bbn.openmap.util.Debug;
import com.bbn.openmap.proj.*;

/**
 * Graphic object that represents a circle or an ellipse.
 * <p>
 * <h3>NOTE:</h3>
 * See the <a href="com.bbn.openmap.proj.Projection.html#poly_restrictions">
 * RESTRICTIONS</a> on Lat/Lon polygons/polylines which apply to
 * circles as well.  Not following the guidelines listed may result in
 * ambiguous/undefined shapes!  Similar assumptions apply to the other
 * vector graphics that we define: polys, rects, lines.
 * <p>
 * We currently do not allow LatLon ellipses, only XY.
 * <p>
 * These assumptions are virtually the same as those on the more
 * generic OMPoly graphic type.
 * <p>
 * @see OMPoly
 *
 */
public class OMCircle extends OMGraphic implements Serializable {

    /** Unit notation - kilometers. */
    final public static transient int KM = 0;
    /** Unit notation - miles. */
    final public static transient int MILES = 1;
    /** Unit notation - nautical miles. */
    final public static transient int NMILES = 2;

    /** Horizontal pixel location of the center. */
    protected int x1 = 0;
    /** Vertical pixel location of the center. */
    protected int y1 = 0;

    /** Horizontal pixel offset. */
    protected int off_x = 0;
    /** Vertical pixel offset. */
    protected int off_y = 0;
    /**
     * Center point.
     */
    protected LatLonPoint center;
    /**
     * Radius of circle in decimal degrees.
     * For LATLON circle.
     */
    protected double radius = 0.0d;
    /**
     * The pixel horizontal diameter of the circle/ellipse.
     * For XY and OFFSET circle/ellipse.
     */
    protected int width = 0;
    /**
     * The pixel vertical diameter of the circle/ellipse.
     * For XY and OFFSET circle/ellipse.
     */
    protected int height = 0;
 
    /** Internal array of x points of the circle/ellipse. */
    protected int[][] xpoints = new int[0][0];
    /** Internal array of y point of the circle/ellipse. */
    protected int[][] ypoints = new int[0][0];
 
    // Render correct stuff for Cylindrical projections.  not
    // accessible until we finalize the api...
    private boolean correctPolar = false;
    private boolean correctFill = false;
    private int[][] fill_xpoints = null;
    private int[][] fill_ypoints = null;

    /**
     * Number of vertices to draw for lat/lon poly-circles.
     */
    protected int nverts;

    /**
     * The simplest constructor for an OMCircle, and it expects that
     * all fields will be filled in later.  Rendertype is
     * RENDERTYPE_UNKNOWN.
     */
    public OMCircle () {
        super(RENDERTYPE_UNKNOWN, LINETYPE_UNKNOWN, DECLUTTERTYPE_NONE);
    }

    /**
     * Create a OMCircle, positioned with a lat-lon center and x-y
     * axis.  Rendertype is RENDERTYPE_OFFSET.
     *
     * @param latPoint latitude of center point, decimal degrees
     * @param lonPoint longitude of center point, decimal degrees
     * @param w horizontal diameter of circle/ellipse, pixels
     * @param h vertical diameter of circle/ellipse, pixels
     */
    public OMCircle (double latPoint, double lonPoint,
		    int w, int h) {
	this (latPoint, lonPoint, 0, 0, w, h);
    }

    /**
     * Create a OMCircle, positioned with a x-y center with x-y axis.
     * Rendertype is RENDERTYPE_XY.
     *
     * @param x1 window position of center point from left of window, in pixels
     * @param y1 window position of center point from top of window, in pixels
     * @param w horizontal diameter of circle/ellipse, pixels
     * @param h vertical diameter of circle/ellipse, pixels
     */
    public OMCircle (int x1, int y1, 
		    int w, int h) { 
        super(RENDERTYPE_XY, LINETYPE_UNKNOWN, DECLUTTERTYPE_NONE);

	this.x1 = x1;
	this.y1 = y1;
	width = w;
	height = h;
    }

    /**
     * Create a OMCircle, positioned at a Lat-lon location, x-y
     * offset, x-y axis.  Rendertype is RENDERTYPE_OFFSET.
     *
     * @param latPoint latitude of center of circle/ellipse.
     * @param lonPoint longitude of center of circle/ellipse.
     * @param offset_x1 # pixels to the right the center will be moved
     * from lonPoint.
     * @param offset_y1 # pixels down that the center will be moved
     * from latPoint.
     * @param w horizontal diameter of circle/ellipse, pixels.
     * @param h vertical diameter of circle/ellipse, pixels.
     */
    public OMCircle (double latPoint, double lonPoint,
		     int offset_x1, int offset_y1, 
		     int w, int h) { 
        super(RENDERTYPE_OFFSET, LINETYPE_UNKNOWN, DECLUTTERTYPE_NONE);

	center = new LatLonPoint(latPoint, lonPoint);
	off_x = offset_x1;
	off_y = offset_y1;
	width = w;
	height = h;
    }

    /**
     * Creates an OMCircle with a Lat-lon center and a lat-lon axis.
     * Rendertype is RENDERTYPE_LATLON.
     *
     * @param latPoint latitude of center point, decimal degrees
     * @param lonPoint longitude of center point, decimal degrees
     * @param radius distance in decimal degrees
     */
    public OMCircle (double latPoint, double lonPoint, double radius) {
	this(new LatLonPoint(latPoint, lonPoint), radius, -1, -1);
    }

    /**
     * Create an OMCircle with a lat/lon center and a physical
     * distance radius.  Rendertype is RENDERTYPE_LATLON.
     *
     * @param latPoint latitude of center of circle in decimal degrees
     * @param lonPoint longitude of center of circle in decimal degrees
     * @param radius distance
     * @param units integer value for units for distance - KM, MILES,
     * NMILES.  If &lt; 0, assume decimal degrees.
     */
    public OMCircle (double latPoint, double lonPoint,
		     double radius, int units){
	this(new LatLonPoint(latPoint, lonPoint), radius, units, -1);
    }

    /**
     * Create an OMCircle with a lat/lon center and a physical
     * distance radius.  Rendertype is RENDERTYPE_LATLON.
     *
     * @param latPoint latitude of center of circle in decimal degrees
     * @param lonPoint longitude of center of circle in decimal degrees
     * @param radius distance
     * @param units integer value for units for distance - KM, MILES,
     * NMILES.  If &lt; 0, assume decimal degrees.
     * @param nverts number of vertices for the poly-circle (if &lt; 3, value
     * is generated internally)
     */
    public OMCircle (double latPoint, double lonPoint,
		     double radius, int units, int nverts)
    {
	this(new LatLonPoint(latPoint, lonPoint), radius, units, nverts);
    }

    /**
     * Create an OMCircle with a lat/lon center and a physical
     * distance radius.  Rendertype is RENDERTYPE_LATLON.
     *
     * @param center LatLon center of circle
     * @param radius distance
     * @param units integer value for units for distance - KM, MILES,
     * NMILES.  If &lt; 0, assume decimal degrees.
     * @param nverts number of vertices for the poly-circle (if &lt; 3, value
     * is generated internally)
     */
    public OMCircle (LatLonPoint center, double radius, int units, int nverts)
    {
        super(RENDERTYPE_LATLON, LINETYPE_UNKNOWN, DECLUTTERTYPE_NONE);
	switch (units) {
	    case KM:
		this.radius = ProjMath.sphericalUnitsToDeg(
			radius, Planet.wgs84_earthEquatorialCircumferenceKM);
		break;
	    case MILES:
		this.radius = ProjMath.sphericalUnitsToDeg(
			radius, Planet.wgs84_earthEquatorialCircumferenceMiles);
		break;
	    case NMILES:
		this.radius = ProjMath.sphericalUnitsToDeg(
			radius, Planet.wgs84_earthEquatorialCircumferenceNMiles);
		break;
	    default:
		this.radius = radius;
		break;
	}

	this.center = center;
	this.nverts = nverts;
    }


    /**
     * Get the x position of the center.  This is meaningful only if
     * the render type is RENDERTYPE_XY or RENDERTYPE_OFFSET.
     * @return x position of center. 
     */
    public int getX(){
        return x1;
    }

    /**
     * Get the y position of the center.  This is meaningful only if
     * the render type is RENDERTYPE_XY or RENDERTYPE_OFFSET.
     * @return y position of center. 
     */
    public int getY(){
        return y1;
    }

    /**
     * Get the x offset from the center.  This is meaningful only if
     * the render type is RENDERTYPE_OFFSET.
     * @return x offset from center. 
     */
    public int getOffX(){
        return off_x;
    }

    /**
     * Get the y position of the center.  This is meaningful only if
     * the render type is RENDERTYPE_OFFSET.
     * @return y offset from center. 
     */
    public int getOffY(){
        return off_y;
    }

    /**
     * Get the center LatLonPoint.
     * This is meaningful only if the rendertype is RENDERTYPE_LATLON
     * or RENDERTYPE_OFFSET.
     * @return LatLonPoint position of center. 
     */
    public LatLonPoint getLatLon(){
        return center;
    }

    /**
     * Get the radius.
     * This is meaningful only if the render type is
     * RENDERTYPE_LATLON.
     * @return double radius in decimal degrees
     */
    public double getRadius(){
        return radius;
    }

    /**
     * Get the horizontal pixel diameter of the circle.  This is
     * meaningful only if the render type is RENDERTYPE_XY or
     * RENDERTYPE_OFFSET.
     *
     * @return the horizontal pixel diameter of the circle. 
     */
    public int getWidth(){
        return width;
    }

    /**
     * Get the vertical pixel diameter of the circle.  This is
     * meaningful only if the render type is RENDERTYPE_XY or
     * RENDERTYPE_OFFSET.
     *
     * @return the vertical pixel diameter of the circle. 
     */
    public int getHeight(){
        return height;
    }

    /**
     * Get the number of vertices of the lat/lon circle.  This will be
     * meaningful only if the render type is RENDERTYPE_XY or
     * RENDERTYPE_OFFSET and for LINETYPE_GREATCIRCLE or
     * LINETYPE_RHUMB line types.
     * @return int number of segment points
     */
    public int getNumVerts () {
	return nverts;
    }

    /**
     * Set the x position of the center.  This will be meaningful
     * only if the render type is RENDERTYPE_XY or RENDERTYPE_OFFSET.
     * @param value the x position of center. 
     */
    public void setX(int value){
        if (x1 == value) return;
	x1 = value;
	setNeedToRegenerate(true);
    }

    /**
     * Set the y position of the center.  This will be meaningful
     * only if the render type is RENDERTYPE_XY or RENDERTYPE_OFFSET.
     * @param value the y position of center. 
     */
    public void setY(int value){
        if (y1 == value) return;
	y1 = value;
	setNeedToRegenerate(true);
    }

    /**
     * Set the x offset from the center.  This will be meaningful only
     * if the render type is RENDERTYPE_OFFSET.
     * @param value the x position of center. 
     */
    public void setOffX(int value){
        if (off_x == value) return;
	off_x = value;
	setNeedToRegenerate(true);
    }

    /**
     * Set the y offset from the center.  This will be meaningful only
     * if the render type is RENDERTYPE_OFFSET.
     * @param value the y position of center. 
     */
    public void setOffY(int value){
        if (off_y == value) return;
	off_y = value;
	setNeedToRegenerate(true);
    }

    /**
     * Set the latitude and longitude of the center point.
     * This is meaningful only if the rendertype is RENDERTYPE_LATLON
     * or RENDERTYPE_OFFSET.
     * @param lat latitude in decimal degrees
     * @param lon longitude in decimal degrees
     */
    public void setLatLon (double lat, double lon){
	LatLonPoint p = new LatLonPoint(lat, lon);
	if (p.equals(center))
	    return;
	center = p;
	setNeedToRegenerate(true);
    }

    /**
     * Set the radius.
     * This is meaningful only if the render type is
     * RENDERTYPE_LATLON.
     * @param radius double radius in decimal degrees
     */
    public void setRadius (double radius) {
        this.radius = radius;
    }

    /**
     * Set the horizontal pixel diameter of the circle.  This is
     * meaningful only if the render type is RENDERTYPE_XY or
     * RENDERTYPE_OFFSET.
     * @param value the horizontial pixel diamter of the circle. 
     */
    public void setWidth(int value){
        if (width == value) return;
	width = value;
	setNeedToRegenerate(true);
    }

    /**
     * Set the vertical pixel diameter of the circle.  This is
     * meaningful only if the render type is RENDERTYPE_XY or
     * RENDERTYPE_OFFSET.
     *
     * @param value the vertical pixel diamter of the circle. 
     */
    public void setHeight(int value){
        if (height == value) return;
	height = value;
	setNeedToRegenerate(true);
    }

    /**
     * Set the number of vertices of the lat/lon circle.  This is
     * meaningful only if the render type is RENDERTYPE_LATLON and for
     * LINETYPE_GREATCIRCLE or LINETYPE_RHUMB line types.  If &lt;
     * 1, this value is generated internally.
     * @param nverts number of segment points
     */
    public void setNumVerts (int nverts) {
	this.nverts = nverts;
    }

    /**
     * Get the polar-fill-correction-flag.
     * @return boolean
     * @see #setPolarCorrection
     */
    public boolean getPolarCorrection () {
	return correctPolar;
    }

    /**
     * Set the polar-fill-correction-flag.
     * We don't correctly render *filled* circles/polygons which
     * encompass a pole in Cylindrical projections.  This method will
     * toggle support for correcting this problem.  You should only
     * set this on circles that encompass a pole and are drawn with a
     * fill color.  You do not need to set this if you're only drawing
     * the circle outline.
     * @param value boolean
     * @see OMGraphic#setLineColor
     * @see OMGraphic#setFillColor
     */
    public void setPolarCorrection (boolean value) {
	correctPolar = value;
	setNeedToRegenerate(true);
    }

    /**
     * Prepare the circle for rendering.
     * @param proj Projection
     * @return true if generate was successful
     */
    public boolean generate (Projection proj) {

	if (proj == null) {
	    System.err.println("OMCircle: null projection in generate!");
	    return false;
	}

	correctFill = correctPolar && (proj instanceof Cylindrical);

	switch (renderType) {
	  case RENDERTYPE_XY:
	      break;
	  case RENDERTYPE_OFFSET:
	      if (!proj.isPlotable(center)) {
		  setNeedToRegenerate(true);//HMMM not the best flag
		  return false;
	      }
	      Point p1 = proj.forward(center.radlat_, center.radlon_, new Point(), true);
	      x1 = p1.x + off_x;
	      y1 = p1.y + off_y;
	      break;
	  case RENDERTYPE_LATLON:
	      Vector circles = null;
	      circles = proj.forwardCircle(
		      center, /*radians*/false, radius, nverts, !isClear(fillColor));

	      int size = circles.size();
	      xpoints = new int[size/2][0];
	      ypoints = new int[xpoints.length][0];
	      int i,j;
	      for (i=0, j=0; i<size; i+=2, j++) {
		  xpoints[j] = (int[])circles.elementAt(i);
		  ypoints[j] = (int[])circles.elementAt(i+1);
		  if (correctFill) {
		      doPolarFillCorrection(
			      xpoints, ypoints, j,
			      (center.radlat_ > 0d) ? -1 : proj.getWidth()+1);
		  }
	      }
	      break;
	  case RENDERTYPE_UNKNOWN:
	      System.err.println("OMCircle.generate(): invalid RenderType");
	      return false;
	}
	setNeedToRegenerate(false);
	return true;
    }

    private int[] getfill_x (int i) {
	return fill_xpoints[i];
    }
    private int[] getfill_y (int i) {
	return fill_ypoints[i];
    }
    // create alternate x,y coordinate arrays for rendering graphics
    // the encompass a pole in the Cylindrical projection.
    private void doPolarFillCorrection (int[][] xpoints, int[][] ypoints, int j, int y1) {
	if (fill_xpoints == null)
	    fill_xpoints = new int[xpoints.length][0];
	if (fill_ypoints == null)
	    fill_ypoints = new int[ypoints.length][0];
	int len = xpoints[j].length;
	int[] alt_xpts = new int[len + 2];
	int[] alt_ypts = new int[len + 2];
	System.arraycopy(xpoints[j], 0, alt_xpts, 0, len);
	System.arraycopy(ypoints[j], 0, alt_ypts, 0, len);
	alt_xpts[len] = alt_xpts[len-1];
	alt_xpts[len+1] = alt_xpts[0];
	alt_ypts[len] = y1;
	alt_ypts[len+1] = alt_ypts[len];
	fill_xpoints[j] = alt_xpts;
	fill_ypoints[j] = alt_ypts;
    }

    /**
     * Paint the circle.
     * @param g Graphics context to render into
     */
    public void render (Graphics g) {
	if (getNeedToRegenerate()) return;

	// LatLon circle
	if (renderType == RENDERTYPE_LATLON) {
	    // safety: grab local reference of projected points
	    int[][] xpts = xpoints;
	    int[][] ypts = ypoints;
	    int len = xpts.length;
	    for (int i=0; i<len; i++) {

		// fill the polygon
		if (setPaint(g)) {
		    if (!correctFill) {
			g.fillPolygon(xpts[i], ypts[i], xpts[i].length);
		    } else {
			int[] alt_xpts = getfill_x(i);
			int[] alt_ypts = getfill_y(i);
			g.fillPolygon(alt_xpts, alt_ypts, alt_xpts.length);
		    }
		}

		// draw the polygon
		if (!isClear(getDisplayColor())) {
		    g.setColor(getDisplayColor());
		    // Projection library connects the circle for us.
		    g.drawPolyline(xpts[i], ypts[i], xpts[i].length);
		}
	    }
	}

	// draw XY circle or ellipse
	else {
	    int x = x1 - width/2;
	    int y = y1 - height/2;
	    Color color;

	    // debugging printouts
	    if (setPaint(g)) {
		g.fillOval(x, y, width, height);
	    }

	    color = getDisplayColor();
	    if (!isClear(color)) {
		g.setColor(color);
		g.drawOval(x, y, width, height);
	    }
	    return;
	}
    }

    /**
     * Return the shortest distance from the circle to an XY-point.
     * @param x X coordinate of the point.
     * @param y Y coordinate fo the point.
     * @return double distance from circle to the point
     */
    public double distance (int x, int y) {
	double temp, distance = Double.POSITIVE_INFINITY;

	if (getNeedToRegenerate()) {
	    return distance;
	}

	// else handle polygon
	if (renderType == RENDERTYPE_LATLON) {
	    for (int i=0; i<xpoints.length; i++) {

		int[] _x = xpoints[i];
		int[] _y = ypoints[i];
		// check if point inside polygon
		if ((!isClear(getFillColor())) && 
			DrawUtil.inside_polygon(_x,_y,x,y))
		    return 0d;		// close as can be

		// otherwise get the closest point
		temp = DrawUtil.closestPolyDistance(_x, _y, x, y, true);
		if (temp < distance) distance = temp;
	    }
	}

	// handle x,y circle/ellipse
	else {
	    // distance from center to point
	    double dist = DrawUtil.distance(x1, y1, x, y);

	    // circle
	    if (width == height) {
		if (dist <= height/2)
		    return 0d;
		else
		    distance = dist - height/2;
	    }

	    // ellipse
	    else {
		// If the distance is less than both the width and
		// height, then the distance is inside the
		// ellipse.
		if (dist <= height/2 && dist <= width/2){
		    return 0d;
		} else {
		    
		    // HACK!  This is a bug.  Since we don't calculate
		    // the ellipse points, we don't know when we are
		    // inside.  Need to get ellipse algorithms in
		    // here, instead of circle ones.  It kinda works,
		    // but it's a little sloppy between axis.
		    double theta = Math.atan2(y-y1, x-x1);
		    int _x = (int)(x1 + ((double)width/2.0d * Math.cos(theta)));
		    int _y = (int)(y1 + ((double)height/2.0d * Math.sin(theta)));

		    // distance to edge of ellipse
		    double dist2 = DrawUtil.distance(x1, y1, _x, _y);

		    // inside ellipse
		    if (dist <= dist2)
			return 0d;
		    // outside ellipse
		    else
			distance = dist - dist2;
		}
	    }
	}
	return distance;
    }
}

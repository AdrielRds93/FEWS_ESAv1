/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			  BBNT Solutions LLC
 * 			    A Part of GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998-2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/omGraphics/OMRect.java,v $
 * $Revision: 1.31 $
 * $Date: 2000/07/05 16:49:05 $
 * $Author: wjeuerle $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.omGraphics;

import java.awt.Graphics;
import java.awt.Point;
import java.util.Vector;
import java.io.Serializable;
import com.bbn.openmap.LatLonPoint;
import com.bbn.openmap.MoreMath;
import com.bbn.openmap.util.Debug;
import com.bbn.openmap.proj.Projection;
import com.bbn.openmap.proj.DrawUtil;

/**
 * Graphic type that lets you draw four-sided polygons
 * that have corners that share coordinates or window points.
 * <p>
 * <h3>NOTE:</h3>
 * See the <a href="com.bbn.openmap.proj.Projection.html#poly_restrictions">
 * RESTRICTIONS</a> on Lat/Lon polygons/polylines which apply to
 * rectangles as well.  Not following the guidelines listed may result
 * in ambiguous/undefined shapes!  Similar assumptions apply to the
 * other vector graphics that we define: circles, ellipses, polys,
 * lines.
 * <p>
 * These assumptions are virtually the same as those on the more
 * generic OMPoly graphic type.
 * <p>
 * @see OMPoly
 *
 */
public class OMRect extends OMGraphic implements Serializable{

    /** internal array of projected x coordinate arrays. */
    protected int[][] xpoints = new int[0][0];
    /** internal array of projected y coordinate arrays. */
    protected int[][] ypoints = new int[0][0];

    /** Horizontal window position of first corner, in pixels from
     * left side of window. */
    protected int x1 = 0;
    /** Vertical window position of first corner, in pixels from the
     * top of the window. */
    protected int y1 = 0;
    /** Latitude of first corner, decimal degrees. */
    protected double lat1 = 0.0d;
    /** Longitude of first corner, decimal degrees. */
    protected double lon1 = 0.0d;
    /** Horizontal window position of second corner, in pixels from
     * left side of window. */
    protected int x2 = 0;
    /** Vertical window position of second corner, in pixels from the
     * top of the window. */
    protected int y2 = 0;
    /** Latitude of second corner, decimal degrees. */
    protected double lat2 = 0.0d;
    /** Longitude of second corner, decimal degrees. */
    protected double lon2 = 0.0d;

    /**
     * Number of segments to draw (used only for
     * LINETYPE_GREATCIRCLE or LINETYPE_RHUMB lines).
     */
    protected int nsegs=-1;

    /** Default constructor, waiting to be filled. */
    public OMRect () {
        super(RENDERTYPE_UNKNOWN, LINETYPE_UNKNOWN, DECLUTTERTYPE_NONE);
    }

    /**
     * Create a lat/lon rectangle.
     * @param lt1 latitude of north edge, decimal degrees.
     * @param ln1 longitude of west edge, decimal degrees.
     * @param lt2 latitude of south edge, decimal degrees.
     * @param ln2 longitude of east edge, decimal degrees.
     * @param lType line type  - see OMGraphic.lineType.
     */
    public OMRect (double lt1, double ln1, double lt2, double ln2,
		  int lType) {
	this (lt1, ln1, lt2, ln2, lType, -1);
    }

    /**
     * Create a lat/lon rectangle.
     * @param lt1 latitude of north edge, decimal degrees.
     * @param ln1 longitude of west edge, decimal degrees.
     * @param lt2 latitude of south edge, decimal degrees.
     * @param ln2 longitude of east edge, decimal degrees.
     * @param lType line type  - see OMGraphic.lineType.
     * @param nsegs number of segment points (only for LINETYPE_GREATCIRCLE
     * or LINETYPE_RHUMB line types, and if &lt; 1, this value is generated
     * internally)
     */
    public OMRect (double lt1, double ln1, double lt2, double ln2,
		  int lType, int nsegs) {
        super(RENDERTYPE_LATLON, lType, DECLUTTERTYPE_NONE);
	lat1 = lt1;
	lon1 = ln1;
	lat2 = lt2;
	lon2 = ln2;
	this.nsegs = nsegs;
    }

    /**
     * Construct an XY rectangle.
     * It doesn't matter which corners of the rectangle are used, as
     * long as they are opposite from each other.
     * @param px1 x pixel position of the first corner relative to the
     * window origin
     * @param py1 y pixel position of the first corner relative to the
     * window origin
     * @param px2 x pixel position of the second corner relative to the
     * window origin
     * @param py2 y pixel position of the second corner relative to the
     * window origin
     */
    public OMRect (int px1, int py1, int px2, int py2) { 
        super(RENDERTYPE_XY, LINETYPE_UNKNOWN, DECLUTTERTYPE_NONE);

	x1 = px1;
	y1 = py1;
	x2 = px2;
	y2 = py2;
    }

    /**
     * Construct an XY rectangle relative to a lat/lon point
     * (RENDERTYPE_OFFSET).
     * It doesn't matter which corners of the rectangle are used, as
     * long as they are opposite from each other.
     * @param lt1 latitude of the reference point, decimal degrees.
     * @param ln1 longitude of the reference point, decimal degrees.
     * @param px1 x pixel position of the first corner relative to the
     * reference point
     * @param py1 y pixel position of the first corner relative to the
     * reference point
     * @param px2 x pixel position of the second corner relative to the
     * reference point
     * @param py2 y pixel position of the second corner relative to the
     * reference point
     */
    public OMRect (double lt1, double ln1,
		  int px1, int py1, int px2, int py2) { 
        super(RENDERTYPE_OFFSET, LINETYPE_UNKNOWN, DECLUTTERTYPE_NONE);
	lat1 = lt1;
	lon1 = ln1;
	x1 = px1;
	y1 = py1;
	x2 = px2;
	y2 = py2;
    }

    /**
     * Set a lat/lon rectangle.
     * @param lt1 latitude of north edge, decimal degrees.
     * @param ln1 longitude of west edge, decimal degrees.
     * @param lt2 latitude of south edge, decimal degrees.
     * @param ln2 longitude of east edge, decimal degrees.
     * @param lType line type  - see OMGraphic.lineType.
     */
    public void setLocation (double lt1, double ln1,
			     double lt2, double ln2,
			     int lType) {
	setRenderType(RENDERTYPE_LATLON);
	setLineType(lType);
	lat1 = lt1;
	lon1 = ln1;
	lat2 = lt2;
	lon2 = ln2;
	setNeedToRegenerate(true);
    }

    /**
     * Set an XY rectangle.
     * It doesn't matter which corners of the rectangle are used, as
     * long as they are opposite from each other.
     * @param px1 x pixel position of the first corner relative to the
     * window origin
     * @param py1 y pixel position of the first corner relative to the
     * window origin
     * @param px2 x pixel position of the second corner relative to the
     * window origin
     * @param py2 y pixel position of the second corner relative to the
     * window origin
     */
    public void setLocation (int px1, int py1, int px2, int py2) { 
	setRenderType(RENDERTYPE_XY);
	setLineType(LINETYPE_UNKNOWN);
	x1 = px1;
	y1 = py1;
	x2 = px2;
	y2 = py2;
	setNeedToRegenerate(true);
    }

    /**
     * Set an XY rectangle relative to a lat/lon point
     * (RENDERTYPE_OFFSET).
     * It doesn't matter which corners of the rectangle are used, as
     * long as they are opposite from each other.
     * @param lt1 latitude of the reference point, decimal degrees.
     * @param ln1 longitude of the reference point, decimal degrees.
     * @param px1 x pixel position of the first corner relative to the
     * reference point
     * @param py1 y pixel position of the first corner relative to the
     * reference point
     * @param px2 x pixel position of the second corner relative to the
     * reference point
     * @param py2 y pixel position of the second corner relative to the
     * reference point
     */
    public void setLocation (double lt1, double ln1,
			     int px1, int py1, int px2, int py2) { 
        setRenderType(RENDERTYPE_OFFSET);
	setLineType(LINETYPE_UNKNOWN);
	lat1 = lt1;
	lon1 = ln1;
	x1 = px1;
	y1 = py1;
	x2 = px2;
	y2 = py2;
	setNeedToRegenerate(true);
    }

    /**
     * Get the latitude of the north edge in a LatLon rectangle.
     * @return double latitude
     */
    public double getNorthLat () {
	return lat1;
    }

    /**
     * Get the longitude of the west edge in a LatLon rectangle.
     * @return double longitude
     */
    public double getWestLon () {
	return lon1;
    }

    /**
     * Get the latitude of the south edge in a LatLon rectangle.
     * @return double latitude
     */
    public double getSouthLat () {
	return lat2;
    }

    /**
     * Get the longitude of the east edge in a LatLon rectangle.
     * @return double longitude
     */
    public double getEastLon () {
	return lon2;
    }

    /**
     * Get the top of XY rectangle.
     * @return int
     */
    public int getTop () {
	return y1;
    }

    /**
     * Get the left of XY rectangle.
     * @return int
     */
    public int getLeft () {
	return x1;
    }

    /**
     * Get the bottom of XY rectangle.
     * @return int
     */
    public int getBottom () {
	return y2;
    }

    /**
     * Get the right of XY rectangle.
     * @return int
     */
    public int getRight () {
	return x2;
    }

    /**
     * Set the number of segments of the lat/lon lines.
     * (This is only for LINETYPE_GREATCIRCLE or LINETYPE_RHUMB line
     * types, and if &lt; 1, this value is generated internally).
     * @param nsegs number of segment points
     */
    public void setNumSegs (int nsegs) {
	this.nsegs = nsegs;
    }

    /**
     * Get the number of segments of the lat/lon lines.
     * (This is only for LINETYPE_GREATCIRCLE or LINETYPE_RHUMB line
     * types).
     * @return int number of segment points
     */
    public int getNumSegs () {
	return nsegs;
    }

    /**
     * Prepare the rectangle for rendering.
     * @param proj Projection
     * @return true if generate was successful
     */
    public boolean generate (Projection proj) {

	if (proj == null) {
	    System.err.println("OMRect: null projection in generate!");
	    return false;
	}

	// reset the internals
	
	switch (renderType) {
	  case RENDERTYPE_XY:
	      xpoints = new int[1][2];
	      ypoints = new int[1][2];
	      xpoints[0][0] = x1; ypoints[0][0] = y1;
	      xpoints[0][1] = x2; ypoints[0][1] = y2;
	      break;
	  case RENDERTYPE_OFFSET:
	      if (!proj.isPlotable(lat1, lon1)) {
		  setNeedToRegenerate(true);//HMMM not the best flag
		  return false;
	      }
	      Point p1 = proj.forward(lat1, lon1);
	      xpoints = new int[1][2];
	      ypoints = new int[1][2];
	      xpoints[0][0] = p1.x + x1;
	      ypoints[0][0] = p1.y + y1;
	      xpoints[0][1] = p1.x + x2;
	      ypoints[0][1] = p1.y + y2;
	      break;
	  case RENDERTYPE_LATLON:
	      Vector rects =
		  proj.forwardRect(
			    new LatLonPoint(lat1, lon1), // NW
			    new LatLonPoint(lat2, lon2), // SE
			    lineType, nsegs, !isClear(fillColor));
	      int size = rects.size();

	      xpoints = new int[size/2][0];
	      ypoints = new int[xpoints.length][0];
	      for (int i=0, j=0; i<size; i+=2, j++) {
		  xpoints[j] = (int[])rects.elementAt(i);
		  ypoints[j] = (int[])rects.elementAt(i+1);
	      }
	      break;
	case RENDERTYPE_UNKNOWN:
	    System.err.println("OMRect.generate(): invalid RenderType");
	    return false;
	}
	setNeedToRegenerate(false);
	return true;
    }


    /**
     * Paint the line.
     * @param g Graphics context to render into
     */
    public void render (Graphics g) {
	if (getNeedToRegenerate()) return;

	// safety: grab local reference of projected points
	int[][] xpts = xpoints;
	int[][] ypts = ypoints;
	int[] _x, _y;
	for (int i=0; i<xpts.length; i++) {
	    _x = xpts[i];
	    _y = ypts[i];

	    if (renderType == RENDERTYPE_LATLON) {
		if (setPaint(g))
		    g.fillPolygon(_x, _y, _x.length);

		g.setColor(getDisplayColor());
		g.drawPolyline(_x, _y, _x.length);
	    } else {
		if (setPaint(g))
		    g.fillRect(_x[0], _y[0],
			       Math.abs(_x[1]-_x[0]),
			       Math.abs(_y[1]-_y[0]));

		g.setColor(getDisplayColor());
		g.drawRect(_x[0], _y[0],
			Math.abs(_x[1]-_x[0]),
			Math.abs(_y[1]-_y[0]));
	    }
	}
    }

    /**
     * Return the shortest distance from the rect to an XY-point.
     * @param x X coordinate of the point.
     * @param y Y coordinate fo the point.
     * @return double distance from rect to the point
     */
    public double distance (int x, int y) {
	double temp, distance = Double.POSITIVE_INFINITY;

	if (getNeedToRegenerate()) {
	    return distance;
	}

	for (int i = 0; i < xpoints.length; i++) {
	    int[] _x = xpoints[i];
	    int[] _y = ypoints[i];

	    // distance to rect
	    if (_x.length == 2) {
		if ((x >= _x[0]) && (x <= _x[1]) &&
		    (y >= _y[0]) && (y <= _y[1]))
		{
		    // The point is within my boundaries.
		    return 0d;
		} else {
		    // The point is outside my boundaries. Don't calculate the
		    // hypotenuse distance since precision doesn't matter much
		    distance =
			Math.max(Math.max(_x[0] - x, x - _x[1]),
				 Math.max(_y[0] - y, y - _y[1]));
		}
	    }

	    // distance to poly
	    else {
		// check if point inside polygon
		if ((!isClear(getFillColor())) && 
		     DrawUtil.inside_polygon(_x,_y,x,y))
		    return 0d;	// close as can be

		// get the closest point to polygon
		temp = DrawUtil.closestPolyDistance(_x, _y, x, y, true);
		if (temp < distance) distance = temp;
	    }
	}
	return distance;
    }
}

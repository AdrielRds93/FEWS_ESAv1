/* **********************************************************************
 * 
 *    Use, duplication, or disclosure by the Government is subject to
 * 	     restricted rights as set forth in the DFARS.
 *  
 * 			   BBNT Solutions LLC
 * 			      A Part of  
 * 			         GTE      
 * 			  10 Moulton Street
 * 			 Cambridge, MA 02138
 * 			    (617) 873-3000
 *  
 * 	  Copyright 1998-2000 by BBNT Solutions LLC,
 * 		A part of GTE, all rights reserved.
 *  
 * **********************************************************************
 * 
 * $Source: /net/blatz/u4/rcs/openmap/com/bbn/openmap/omGraphics/OMCircle2D.java,v $
 * $Revision: 1.10 $
 * $Date: 2000/08/02 14:25:37 $
 * $Author: dietrick $
 * 
 * **********************************************************************
 */

package com.bbn.openmap.omGraphics;

import com.bbn.openmap.LatLonPoint;
import com.bbn.openmap.proj.Projection;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Stroke;

/**
 * Circle object which takes advantage of the Java2D API.
 * This class requires the Java 2 platform.
 */
public class OMCircle2D extends OMCircle implements OMGraphic2D {

    /**
     * The Java2D Stroke.
     * This is used for lineWidth.
     */
    protected Stroke stroke = new BasicStroke(lineWidth);

    /** The Java2D Paint
     * This is used for filled graphics
     */
    protected Paint paint;

    /**
     * The simplest constructor for an OMCircle2D, and it expects that
     * all fields will be filled in later.  Rendertype is
     * RENDERTYPE_UNKNOWN.
     */
    public OMCircle2D () {
        super();
    }

    /**
     * Create a OMCircle2D, positioned with a lat-lon center and x-y
     * axis.  Rendertype is RENDERTYPE_OFFSET.
     *
     * @param latPoint latitude of center point, decimal degrees
     * @param lonPoint longitude of center point, decimal degrees
     * @param w horizontal diameter of circle/ellipse, pixels
     * @param h vertical diameter of circle/ellipse, pixels
     */
    public OMCircle2D (double latPoint, double lonPoint,
		    int w, int h) {
	super(latPoint, lonPoint, w, h);
    }

    /**
     * Create a OMCircle2D, positioned with a x-y center with x-y axis.
     * Rendertype is RENDERTYPE_XY.
     *
     * @param x1 window position of center point from left of window, in pixels
     * @param y1 window position of center point from top of window, in pixels
     * @param w horizontal diameter of circle/ellipse, pixels
     * @param h vertical diameter of circle/ellipse, pixels
     */
    public OMCircle2D (int x1, int y1, 
		    int w, int h) { 
	super(x1, y1, w, h);
    }

    /**
     * Create a OMCircle2D, positioned at a Lat-lon location, x-y
     * offset, x-y axis.  Rendertype is RENDERTYPE_OFFSET.
     *
     * @param latPoint latitude of center of circle/ellipse.
     * @param lonPoint longitude of center of circle/ellipse.
     * @param offset_x1 # pixels to the right the center will be moved
     * from lonPoint.
     * @param offset_y1 # pixels down that the center will be moved
     * from latPoint.
     * @param w horizontal diameter of circle/ellipse, pixels.
     * @param h vertical diameter of circle/ellipse, pixels.
     */
    public OMCircle2D (double latPoint, double lonPoint,
		     int offset_x1, int offset_y1, 
		     int w, int h) { 
	super(latPoint, lonPoint, offset_x1, offset_y1, w, h);
    }

    /**
     * Creates an OMCircle2D with a Lat-lon center and a lat-lon axis.
     * Rendertype is RENDERTYPE_LATLON.
     *
     * @param latPoint latitude of center point, decimal degrees
     * @param lonPoint longitude of center point, decimal degrees
     * @param radius distance in decimal degrees
     */
    public OMCircle2D (double latPoint, double lonPoint, double radius) {
	super(latPoint, lonPoint, radius);
    }

    /**
     * Create an OMCircle2D with a lat/lon center and a physical
     * distance radius.  Rendertype is RENDERTYPE_LATLON.
     *
     * @param latPoint latitude of center of circle in decimal degrees
     * @param lonPoint longitude of center of circle in decimal degrees
     * @param radius distance
     * @param units integer value for units for distance - KM, MILES, NMILES.
     */
    public OMCircle2D (double latPoint, double lonPoint,
		     double radius, int units){
	super(latPoint, lonPoint, radius, units);
    }

    /**
     * Create an OMCircle2D with a lat/lon center and a physical
     * distance radius.  Rendertype is RENDERTYPE_LATLON.
     *
     * @param latPoint latitude of center of circle in decimal degrees
     * @param lonPoint longitude of center of circle in decimal degrees
     * @param radius distance
     * @param units integer value for units for distance - KM, MILES, NMILES.
     * @param nverts number of vertices for the poly-circle (if &lt; 3, value
     * is generated internally)
     */
    public OMCircle2D (double latPoint, double lonPoint,
		     double radius, int units, int nverts)
    {
	super(latPoint, lonPoint, radius, units, nverts);
    }

    /**
     * Create an OMCircle with a lat/lon center and a physical
     * distance radius.  Rendertype is RENDERTYPE_LATLON.
     *
     * @param center LatLon center of circle
     * @param radius distance
     * @param units integer value for units for distance - KM, MILES, NMILES.
     * @param nverts number of vertices for the poly-circle (if &lt; 3, value
     * is generated internally)
     */
    public OMCircle2D (LatLonPoint center, double radius, int units, int nverts)
    {
	super(center, radius, units, nverts);
    }

    /**
     * Set the line width to a value between 1 and 10 pixels.
     * Anything outside of these bounds gets set to 1. 
     */
    public void setLineWidth (float w) {
	super.setLineWidth(w);
	stroke = new BasicStroke(getLineWidth());
    }

    /**
     * Set the stroke for the graphic.  Also sets the line width of
     * the graphics from the setting in the Stroke object, if it's a
     * BasicStroke.
     */
    public void setStroke(java.awt.Stroke st){
	if (st == null){
	    if (stroke == null){
		stroke = new BasicStroke();
	    }
	} else {
	    stroke = st;
	}

	if (stroke instanceof BasicStroke){
	    super.setLineWidth((int)((BasicStroke)stroke).getLineWidth());
	}
    }

    /**
     * Set the Paint object used to fill the rectangle
     */
    public void setPaint(java.awt.Paint paint) {
        this.paint = paint;
    }

    /**
     * The call to set the Graphics object to handle the Paint that
     * may be contained in the 2D circle.  Therefore, there ought to
     * be either a Paint object or a fill color.
     * @param g a java.awt.Graphics object to set.
     * @return true if the paint is set, else true if the fill color
     * is not clear.  
     */
    public boolean setPaint(Graphics g){
	Color color = getFillColor();
	// Because it might not be...
	if (g instanceof Graphics2D){
	    if (paint != null) {
		((Graphics2D)g).setPaint(paint);
		return true;
	    } else if (!isClear(color)){
		((Graphics2D)g).setPaint(color);
		return true;
	    } else {
		return false;
	    }
	} else if (!isClear(color)){
	    g.setColor(color);
	    return true;
	}
	return false;
    }

    /**
     * Prepare the circle for rendering.
     * @param proj Projection
     * @return true if generate was successful
     */
    public boolean generate (Projection proj) {
	return super.generate(proj);
    }

    /**
     * Paint the circle.
     * @param g Graphics context to render into
     */
    public void render (Graphics g) {
	if (g instanceof Graphics2D) {
	    Graphics2D g2d = ((Graphics2D)g);
	    Stroke oldstroke = g2d.getStroke();
	    g2d.setStroke(stroke);
	    super.render(g);
	    g2d.setStroke(oldstroke);
	} else {
	    super.render(g);
	}
    }

    /**
     * Return the shortest distance from the circle to an XY-point.
     * @param x X coordinate of the point.
     * @param y Y coordinate fo the point.
     * @return double distance from circle to the point
     */
    public double distance (int x, int y) {

	// OK, we need to put in a hack to handle the fact that the
	// OMCircle2D could have a null fill color, but contain a
	// paint object, making it opaque.  So, for the purposes of
	// the super.distance measurement, we'll put a color in if
	// there is a paint object, and then set things back after.
	boolean hackUsed = false;
	if (paint != null && isClear(getFillColor())){
	    fillColor = Color.black;
	    hackUsed = true;
	}
			   
	double d = super.distance(x,y);

	if (hackUsed)  setFillColor(null);

	if (lineWidth <= 1)
	    return d;
	// extra calculation for lineWidth
	d -= lineWidth/2;
	return (d < 0d) ? 0d : d;
    }
}

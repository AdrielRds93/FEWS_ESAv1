/**
 * NotSupportedException.java  1.0  16 Sep 2002
 *
 * @author Richard D. Gonzalez
 * @version 1.0
 */

package net.sourceforge.jgrib;


/**
 * A class that represents an exception thrown when a GRIB feature is not
 * (yet) supported.
 *
 * Currently, only GRIB edition 1 is supported
 *
 * @author  Richard D. Gonzalez
 * @version 1.0
 */

public class NotSupportedException extends Exception
{

   /**
    * Construct a new Exception with message <tt>msg</tt>.
    *
    * @param msg error message
    */
   public NotSupportedException(String msg)
   {

      super(msg);
   }
}


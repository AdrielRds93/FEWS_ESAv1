/*
 * GribGDSFactory.java  1.0  10/01/2002
 *
 */

package net.sourceforge.jgrib;

import java.io.IOException;


/**
 * GribGDSFactory determines the proper subclass of GribRecordGDS to create.
 * Extend GribRecordGDS to add a GDS type for your definition.
 * Add types to the switch statement to create an instance of your new type
 *
 * NOTE - only a few types are supported so far
 *
 * @author  Capt Richard D. Gonzalez
 * @version 1.0
 */

public class GribGDSFactory
{

   /**
    * Determines the Grid type and calls the appropriate constructor (if it
    * exists)
    *
    * @param in bit input stream with GDS content
    *
    * @throws IOException           if stream can not be opened etc.
    * @throws NoValidGribException  if stream contains no valid GRIB file
    */
   private GribGDSFactory(){}

   public static GribRecordGDS getGDS(BitInputStream in) throws IOException,
          NoValidGribException,NotSupportedException
   {

      int[] data;
//      int length;
      int grid_type;

      // octets 1-6 give the common GDS data - before the Table D unique data
      data = in.readUI8(6);

      // octet 6 (grid type - see table 6)
      grid_type = data[5];

      switch(grid_type){
         case(0):
            return new GribGDSLatLon(in,data);
         case(1):
            throw new NotSupportedException("GribGDSFactory: GRiB type "
                  +grid_type+": Mercator Projection is not supported yet");
         case(2):
            throw new NotSupportedException("GribGDSFactory: GRiB type "
                  +grid_type+": Gnomonic Projection is not supported yet");
         case(3):
            return new GribGDSLambert(in,data);
         case(4):
            throw new NotSupportedException("GribGDSFactory: GRiB type "
                  +grid_type+": Gaussian Lat/Lon Projection is not supported yet");
         case(5):
            return new GribGDSPolarStereo(in,data);
         case(6):
            throw new NotSupportedException("GribGDSFactory: GRiB type " +
                  grid_type+": Universal Transverse (UTM) Projection " +
                  "is not supported yet");
         case(7):
            throw new NotSupportedException("GribGDSFactory: GRiB type "
                  +grid_type+": Simple Polyconic Projection is not supported yet");
         case(8):
            throw new NotSupportedException("GribGDSFactory: GRiB type "
                  +grid_type+": Alber's equal-area Projection is not supported yet");
         case(9):
            throw new NotSupportedException("GribGDSFactory: GRiB type "
                  +grid_type+": Miller's Cylindrical Projection is not supported yet");
         case(10):
            return new GribGDSLatLon(in,data);
         default:
            throw new NotSupportedException("GribGDSFactory: GRiB type "
                  +grid_type+" not supported yet");
      }
   }


}



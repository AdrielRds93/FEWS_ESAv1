package net.sourceforge.jgrib;

/**
* Class to handle addition of elements
* Kjell R�ang, 18/03/2002
*/
public class SmartStringArray
{
   int sp = 0; // "stack pointer" to keep track of position in the array
   private String[] array;
   private int growthSize;
   private static final int START = 64;

   public SmartStringArray()
   {
      this(START);
   }

   public SmartStringArray( int initialSize )
   {
      this( initialSize, (int)( initialSize / 4 ) );
   }


   public SmartStringArray( int initialSize, int growthSize )
   {
      this.growthSize = growthSize;
      array = new String[ initialSize ];
   }

   public SmartStringArray(String[] anArr)
   {
      array = anArr;
      growthSize = START/4;
      sp = array.length;
   }

   /**
    * Reset stack pointer
    */
   public void reset()
   {
      sp = 0;
   }


   /**
   * Add one string
   */
   public void add(String str )
   {
      if( sp >= array.length ) // time to grow!
      {
         String[] tmpArray = new String[ array.length + growthSize ];
         System.arraycopy( array, 0, tmpArray, 0, array.length );
         array = tmpArray;
      }
      array[ sp ] = str;
      sp += 1;
   }

   /**
   * Return normal array
   */
   public String[] toArray()
   {
      String[] trimmedArray = new String[ sp ];
      System.arraycopy( array, 0, trimmedArray, 0, trimmedArray.length );
      return trimmedArray;
   }

   public int size()
   {
      return sp;
   }

   /**
   * Split string in an array
   */
   public static String[] split( String token, String string )
   {
      SmartStringArray ssa = new SmartStringArray();

      int previousLoc = 0;
      int loc = string.indexOf( token, previousLoc );
      if (loc == -1)
      {
         // No token in string
         ssa.add(string);
         return( ssa.toArray() );
      }

      do
      {
         //String sub = string.substring( previousLoc, loc );
         /*
         if (sub.trim().length() > 0)
         {
            ssa.add(sub);
         }
         */
         ssa.add( string.substring( previousLoc, loc ) );
         previousLoc = ( loc + token.length() );
         loc = string.indexOf( token, previousLoc );
      }
      while( ( loc != -1 ) && ( previousLoc < string.length() ) );

      //String sub = string.substring( previousLoc);
      /*
      if (sub.trim().length() > 0)
      {
         ssa.add(sub);
      }
      */
      ssa.add( string.substring( previousLoc ) );

      return( ssa.toArray() );
   }

   /**
   * Remove array elements with blanks and blanks inside a string
   * Alter number of elements
   */
   public static String[] removeBlanks(String[] inArr)
   {
      // Count number of non blanks

      int nonBl = 0;
      for (int i=0; i<inArr.length; i++)
      {
         String inStr = inArr[i].trim();
         if (inStr.length() != 0)
         {
            nonBl++;
         }
         inArr[i] = inStr;
      }
      if (nonBl == inArr.length)
      {
         return inArr;
      }

      // Copy to new
      String[] outArr = new String[nonBl];
      nonBl = 0;
      for (int i=0; i<inArr.length; i++)
      {
         String inStr = inArr[i].trim();
         if (inStr.length() != 0)
         {
            outArr[nonBl] = inStr;
            nonBl++;
         }
      }
      return outArr;
   }

   /**
   * Join some elements with a token in between
   */
   public static String join( String token, String[] strings )
   {
      StringBuffer sb = new StringBuffer();

      for( int x = 0; x < strings.length; x++ )
      {
         if (strings[x] != null)
         {
            sb.append( strings[x] );
         }

         if( x < ( strings.length - 1 ) )
         {
            sb.append( token );
         }
      }

      return( sb.toString() );
   }

   private static void printArr(String[] arr)
   {
      for (int i=0; i<arr.length; i++)
      {
         System.out.print(arr[i]);
         if (i != (arr.length-1))
         {
            System.out.print(" . ");
         }
      }
      System.out.println();
   }


   public static void main (String[] argv)
   {
      String s1 = "aaa.bbb.ccc";
      String s2 = "aaa..";
      String s3 = "...";

      String token = ".";

      String[] res;

      printArr(split(token, s1));
      printArr(split(token, s2));
      printArr(split(token, s3));

   }



}

package net.sourceforge.jgrib;

/**
 * A class to store multiple GribFile-s while allowing access to the GribRecords
 *    of those files as if they were one large file.
 * This came about because it seems most GRIB files are for a single forecast time,
 *    and this will allow an entire forecast period to be built.
 *    Therefore, the methods are biased towards the separate files being the same
 *      model run at different forecast times.  It can be used otherwise, but
 *      files will be sorted according to forecast time.
 *
 * NOTE - This is not yet functional - the next item on my "todo" list
 * @author Capt Richard D. Gonzalez
 * @version 1.0
 */

import java.util.*;
import java.io.*;

public class GribFileGroup {

   HashMap files = new HashMap();
   Date[] dates = null;
//   HashSet files = new HashSet();

   public GribFileGroup(String[] filenames)throws FileNotFoundException,
         IOException, NotSupportedException, NoValidGribException{
      ArrayList dateList = new ArrayList();
      for (int i=0;i<filenames.length;i++){

         String filename = filenames[i];
         GribFile gribFile = new GribFile(filename);
         Date date = gribFile.getRecord(1).getPDS().getLocalForecastTime().getTime();
         dateList.add(date);
         files.put(date,gribFile);
      }
      dates = (Date[])dateList.toArray(dates);
      Arrays.sort(dates);
   }

   // *** public methods *********************************************************
   // basically, reimplementations of the GribFile methods that adjust for
   //   multiple files.

   /**
    * Get type names
    * @return array with names
    */
   public String[] getTypeNames(){
      GribFile gribFile = null;
      String[] allTypeNames = null;
      HashSet typeNames = new HashSet();
      for (int i = 0; i<dates.length; i++){
         Date date = dates[i];
         gribFile = (GribFile)files.get(date);
         String[] types = gribFile.getTypeNames();
         for (int j = 0; j < types.length; j++){
            typeNames.add(types[j]);
         }
      }
      allTypeNames = (String[])typeNames.toArray(allTypeNames);
      return allTypeNames;
   }

   /**
    * Get Light GRIB records
    * @return Array with Light Grib Records
    */
   public GribRecord[] getLightRecords(){
      GribFile gribFile = null;
      GribRecord[] grls = null;
      ArrayList grlList = new ArrayList();
      for (int i = 0; i<dates.length; i++){
         Date date = dates[i];
         gribFile = (GribFile)files.get(date);
         grls = gribFile.getLightRecords();
         for (int j = 0; j < grls.length; j++){
            grlList.add(grls[j]);
         }
      }
      grls = (GribRecord[])grlList.toArray(grls);
      return grls;
   }

   /**
    * Get get grids
    * @return array with grids
    */
   public GribRecordGDS[] getGrids(){
      GribFile gribFile = null;
      GribRecordGDS[] gdss = null;
      ArrayList gdsList = new ArrayList();
      for (int i = 0; i<dates.length; i++){
         Date date = dates[i];
         gribFile = (GribFile)files.get(date);
         gdss = gribFile.getGrids();
         for (int j = 0; j < gdss.length; j++){
            gdsList.add(gdss[j]);
         }
      }
      gdss = (GribRecordGDS[])gdsList.toArray(gdss);
      return gdss;
   }


   /**
    * Get the number of records this GRIB file contains.
    *
    * @return number of records in this GRIB file
    */
   public int getRecordCount(){
      GribFile gribFile = null;
      int recordCount = 0;
      for (int i = 0; i<dates.length; i++){
         Date date = dates[i];
         gribFile = (GribFile)files.get(date);
         recordCount = recordCount + gribFile.getRecordCount();
      }
      return recordCount;
   }


   /**
    * Print out overview of GRIB file content.
    *
    * @param out print stream the output is written to
    *
    * @throws IOException            if a record can not be opened etc.
    * @throws NoValidGribException   if a record is no valid GRIB record
    */
   public void listRecords(PrintStream out) throws IOException,
          NoValidGribException, NotSupportedException {
      GribFile gribFile = null;
      int recordCount;
      int record;
      for (int i = 0; i<dates.length; i++){
         Date date = dates[i];
         gribFile = (GribFile)files.get(date);
         gribFile.listRecords(out);
      }
   }

   /**
    * Method added by Richard Gonzalez 23 Sep 02.
    *
    * Print out listing of parameters in GRIB file.
    *
    * @param out print stream the output is written to
    *
    * @throws IOException            if a record can not be opened etc.
    * @throws NoValidGribException   if a record is no valid GRIB record
    */
   public void listParameters(PrintStream out){
      GribFile gribFile = null;
      for (int i = 0; i<dates.length; i++){
         Date date = dates[i];
         gribFile = (GribFile)files.get(date);
         gribFile.listParameters(out);
      }
   }

   /**
    * Get a string representation of the GRIB file.
    *
    * @return NoValidGribException   if record is no valid GRIB record
    */
   public String toString(){
      GribFile gribFile = null;
      String theString = null;
      for (int i = 0; i<dates.length; i++){
         Date date = dates[i];
         gribFile = (GribFile)files.get(date);
         theString = theString + gribFile.toString();
      }
      return theString;
   }

}